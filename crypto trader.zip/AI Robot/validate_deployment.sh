#!/bin/bash

# AI Crypto Trading System - Deployment Validation Script
# Tests all installation and deployment components

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m'

# Test results
TESTS_PASSED=0
TESTS_FAILED=0
FAILED_TESTS=()

# Logging functions
log_success() {
    echo -e "${GREEN}✓ $1${NC}"
    ((TESTS_PASSED++))
}

log_failure() {
    echo -e "${RED}✗ $1${NC}"
    ((TESTS_FAILED++))
    FAILED_TESTS+=("$1")
}

log_info() {
    echo -e "${BLUE}ℹ $1${NC}"
}

log_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_header() {
    echo -e "${PURPLE}$1${NC}"
    echo "$(printf '=%.0s' {1..60})"
}

# Test script permissions and executability
test_script_permissions() {
    print_header "Testing Script Permissions"
    
    local scripts=(
        "install.sh"
        "startup.sh"
        "health_check.sh"
        "update.sh"
        "backup.sh"
        "setup_config.py"
    )
    
    for script in "${scripts[@]}"; do
        if [[ -f "$script" ]]; then
            if [[ -x "$script" ]]; then
                log_success "$script is executable"
            else
                log_failure "$script is not executable"
            fi
        else
            log_failure "$script not found"
        fi
    done
}

# Test script syntax
test_script_syntax() {
    print_header "Testing Script Syntax"
    
    # Test bash scripts
    local bash_scripts=("install.sh" "startup.sh" "health_check.sh" "update.sh" "backup.sh")
    
    for script in "${bash_scripts[@]}"; do
        if [[ -f "$script" ]]; then
            if bash -n "$script" 2>/dev/null; then
                log_success "$script syntax is valid"
            else
                log_failure "$script has syntax errors"
            fi
        fi
    done
    
    # Test Python scripts
    if [[ -f "setup_config.py" ]]; then
        if python3 -m py_compile setup_config.py 2>/dev/null; then
            log_success "setup_config.py syntax is valid"
        else
            log_failure "setup_config.py has syntax errors"
        fi
    fi
    
    if [[ -f "src/main.py" ]]; then
        if python3 -m py_compile src/main.py 2>/dev/null; then
            log_success "src/main.py syntax is valid"
        else
            log_failure "src/main.py has syntax errors"
        fi
    fi
}

# Test systemd service files
test_systemd_services() {
    print_header "Testing Systemd Service Files"
    
    local services=("ai-crypto-trader.service" "ollama-enhanced.service")
    
    for service in "${services[@]}"; do
        if [[ -f "$service" ]]; then
            # Basic syntax check
            if grep -q "\[Unit\]" "$service" && grep -q "\[Service\]" "$service" && grep -q "\[Install\]" "$service"; then
                log_success "$service has valid structure"
            else
                log_failure "$service missing required sections"
            fi
            
            # Check for required fields
            if grep -q "ExecStart=" "$service"; then
                log_success "$service has ExecStart defined"
            else
                log_failure "$service missing ExecStart"
            fi
        else
            log_failure "$service not found"
        fi
    done
}

# Test Python module structure
test_python_modules() {
    print_header "Testing Python Module Structure"
    
    local modules=(
        "src/__init__.py"
        "src/main.py"
        "src/utils/__init__.py"
        "src/utils/config.py"
        "src/utils/database.py"
        "src/utils/logging.py"
        "src/utils/browser_automation.py"
        "src/utils/communication.py"
        "src/modules/__init__.py"
        "src/modules/ai_controller/__init__.py"
        "src/modules/ai_controller/controller.py"
        "src/modules/coin_scanner/__init__.py"
        "src/modules/coin_scanner/scanner.py"
        "src/modules/chart_checker/__init__.py"
        "src/modules/chart_checker/checker.py"
        "src/modules/combiner/__init__.py"
        "src/modules/combiner/combiner.py"
        "src/modules/verifier_executor/__init__.py"
        "src/modules/verifier_executor/executor.py"
    )
    
    for module in "${modules[@]}"; do
        if [[ -f "$module" ]]; then
            log_success "$module exists"
        else
            log_failure "$module missing"
        fi
    done
}

# Test requirements.txt
test_requirements() {
    print_header "Testing Requirements File"
    
    if [[ -f "requirements.txt" ]]; then
        log_success "requirements.txt exists"
        
        # Check for critical dependencies
        local critical_deps=(
            "ollama-python"
            "playwright"
            "flask"
            "sqlalchemy"
            "requests"
            "pandas"
            "numpy"
        )
        
        for dep in "${critical_deps[@]}"; do
            if grep -q "$dep" requirements.txt; then
                log_success "Critical dependency $dep found"
            else
                log_failure "Critical dependency $dep missing"
            fi
        done
    else
        log_failure "requirements.txt not found"
    fi
}

# Test configuration structure
test_configuration() {
    print_header "Testing Configuration Structure"
    
    # Test if setup_config.py can run basic checks
    if [[ -f "setup_config.py" ]]; then
        if python3 -c "
import sys
sys.path.append('src')
try:
    from utils.config import ConfigManager
    print('Config import successful')
except ImportError as e:
    print(f'Config import failed: {e}')
    sys.exit(1)
" 2>/dev/null; then
            log_success "Configuration module imports successfully"
        else
            log_failure "Configuration module import failed"
        fi
    fi
}

# Test documentation
test_documentation() {
    print_header "Testing Documentation"
    
    local docs=("README.md" "DEPLOYMENT.md" "AI_Crypto_Trader_Architecture.md")
    
    for doc in "${docs[@]}"; do
        if [[ -f "$doc" ]]; then
            if [[ -s "$doc" ]]; then
                log_success "$doc exists and is not empty"
            else
                log_failure "$doc exists but is empty"
            fi
        else
            log_failure "$doc not found"
        fi
    done
}

# Test script functionality (dry run)
test_script_functionality() {
    print_header "Testing Script Functionality (Dry Run)"
    
    # Test health check script help
    if [[ -f "health_check.sh" ]]; then
        if ./health_check.sh --help >/dev/null 2>&1 || ./health_check.sh 2>&1 | grep -q "Usage\|health"; then
            log_success "health_check.sh responds to help/usage"
        else
            log_warning "health_check.sh may not have help functionality"
        fi
    fi
    
    # Test backup script help
    if [[ -f "backup.sh" ]]; then
        if ./backup.sh --help >/dev/null 2>&1 || ./backup.sh 2>&1 | grep -q "Usage\|backup"; then
            log_success "backup.sh responds to help/usage"
        else
            log_warning "backup.sh may not have help functionality"
        fi
    fi
    
    # Test update script help
    if [[ -f "update.sh" ]]; then
        if ./update.sh --help >/dev/null 2>&1 || ./update.sh 2>&1 | grep -q "Usage\|update"; then
            log_success "update.sh responds to help/usage"
        else
            log_warning "update.sh may not have help functionality"
        fi
    fi
}

# Test file structure completeness
test_file_structure() {
    print_header "Testing File Structure Completeness"
    
    local required_files=(
        "install.sh"
        "startup.sh"
        "health_check.sh"
        "update.sh"
        "backup.sh"
        "setup_config.py"
        "ai-crypto-trader.service"
        "ollama-enhanced.service"
        "requirements.txt"
        "README.md"
        "DEPLOYMENT.md"
        "src/main.py"
    )
    
    for file in "${required_files[@]}"; do
        if [[ -f "$file" ]]; then
            log_success "Required file $file exists"
        else
            log_failure "Required file $file missing"
        fi
    done
}

# Test security considerations
test_security() {
    print_header "Testing Security Considerations"
    
    # Check for hardcoded secrets (basic check)
    local sensitive_patterns=("password" "secret" "token" "key")
    local script_files=(*.sh *.py)
    
    for pattern in "${sensitive_patterns[@]}"; do
        local found=false
        for file in "${script_files[@]}"; do
            if [[ -f "$file" ]] && grep -qi "$pattern.*=" "$file" 2>/dev/null; then
                # Check if it's just a variable name or placeholder
                if grep -qi "$pattern.*=.*your\|$pattern.*=.*\$\|$pattern.*=.*\"\"" "$file" 2>/dev/null; then
                    continue  # This is likely a placeholder
                else
                    log_warning "Potential hardcoded $pattern found in $file"
                    found=true
                fi
            fi
        done
        if ! $found; then
            log_success "No hardcoded $pattern values found"
        fi
    done
    
    # Check script permissions
    for script in *.sh; do
        if [[ -f "$script" ]]; then
            local perms=$(stat -c "%a" "$script" 2>/dev/null || echo "unknown")
            if [[ "$perms" == "755" || "$perms" == "750" ]]; then
                log_success "$script has appropriate permissions ($perms)"
            else
                log_warning "$script has permissions $perms (consider 755)"
            fi
        fi
    done
}

# Generate validation report
generate_report() {
    print_header "Validation Report"
    
    echo "Total Tests: $((TESTS_PASSED + TESTS_FAILED))"
    echo -e "${GREEN}Passed: $TESTS_PASSED${NC}"
    echo -e "${RED}Failed: $TESTS_FAILED${NC}"
    
    if [[ $TESTS_FAILED -gt 0 ]]; then
        echo ""
        echo -e "${RED}Failed Tests:${NC}"
        for test in "${FAILED_TESTS[@]}"; do
            echo -e "${RED}  ✗ $test${NC}"
        done
        echo ""
        echo -e "${YELLOW}Please address the failed tests before deployment.${NC}"
        return 1
    else
        echo ""
        echo -e "${GREEN}🎉 All tests passed! The deployment is ready.${NC}"
        return 0
    fi
}

# Main validation function
main() {
    echo -e "${PURPLE}AI Crypto Trading System - Deployment Validation${NC}"
    echo "$(printf '=%.0s' {1..60})"
    echo ""
    
    test_file_structure
    echo ""
    
    test_script_permissions
    echo ""
    
    test_script_syntax
    echo ""
    
    test_systemd_services
    echo ""
    
    test_python_modules
    echo ""
    
    test_requirements
    echo ""
    
    test_configuration
    echo ""
    
    test_documentation
    echo ""
    
    test_script_functionality
    echo ""
    
    test_security
    echo ""
    
    generate_report
}

# Handle command line arguments
case "${1:-validate}" in
    validate)
        main
        ;;
    quick)
        test_file_structure
        test_script_permissions
        test_script_syntax
        generate_report
        ;;
    security)
        test_security
        ;;
    *)
        echo "Usage: $0 {validate|quick|security}"
        echo ""
        echo "Commands:"
        echo "  validate  - Run full validation suite"
        echo "  quick     - Run basic validation checks"
        echo "  security  - Run security-focused checks"
        exit 1
        ;;
esac