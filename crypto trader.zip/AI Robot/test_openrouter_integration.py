#!/usr/bin/env python3
"""
OpenRouter Integration Test Script
Tests the complete OpenRouter integration with fallback mechanisms.
"""

import asyncio
import json
import sys
import os
from datetime import datetime
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from utils.openrouter_client import OpenRouterClient, ModelType, TaskType
from utils.config import config_manager
from utils.ai_prompt_templates import AIPromptTemplates

async def test_openrouter_client():
    """Test OpenRouter client functionality."""
    print("🔧 Testing OpenRouter Client...")
    
    try:
        client = OpenRouterClient()
        
        # Test model routing
        model = client._get_model_for_task(TaskType.MARKET_ANALYSIS)
        print(f"✅ Model routing: {TaskType.MARKET_ANALYSIS.value} -> {model}")
        
        # Test prompt templates
        templates = AIPromptTemplates()
        prompt = templates.get_scanner_prompt({
            "coins": ["BTC", "ETH"],
            "market_data": {"trend": "bullish"}
        })
        print(f"✅ Prompt template generated: {len(prompt)} characters")
        
        # Test API call with fallback
        test_prompt = "Analyze this simple market data: BTC price is $45000, trending up. Respond with JSON: {\"sentiment\": \"bullish/bearish/neutral\", \"confidence\": 0.8}"
        
        response = await client.generate_response(
            task_type=TaskType.MARKET_ANALYSIS,
            prompt=test_prompt,
            max_tokens=100
        )
        
        if response:
            print(f"✅ OpenRouter API call successful")
            print(f"   Response: {response[:100]}...")
            
            # Try to parse as JSON
            try:
                json.loads(response)
                print("✅ Response is valid JSON")
            except:
                print("⚠️  Response is not JSON (may be expected for test)")
        else:
            print("⚠️  OpenRouter API call failed, fallback may have been used")
        
        # Test cost tracking
        stats = client.get_usage_stats()
        print(f"✅ Usage stats: {stats}")
        
        return True
        
    except Exception as e:
        print(f"❌ OpenRouter client test failed: {e}")
        return False

async def test_module_integrations():
    """Test individual module integrations."""
    print("\n🔧 Testing Module Integrations...")
    
    try:
        # Test imports
        from modules.coin_scanner.scanner import SentimentAnalyzer
        from modules.chart_checker.checker import ChartChecker
        from modules.combiner.combiner import TradingCombiner
        from modules.verifier_executor.executor import VerifierExecutor
        from modules.ai_controller.controller import AIController
        
        print("✅ All module imports successful")
        
        # Test module instantiation
        sentiment_analyzer = SentimentAnalyzer()
        print("✅ SentimentAnalyzer instantiated")
        
        chart_checker = ChartChecker()
        print("✅ ChartChecker instantiated")
        
        combiner = TradingCombiner()
        print("✅ TradingCombiner instantiated")
        
        verifier_executor = VerifierExecutor()
        print("✅ VerifierExecutor instantiated")
        
        ai_controller = AIController()
        print("✅ AIController instantiated")
        
        return True
        
    except Exception as e:
        print(f"❌ Module integration test failed: {e}")
        return False

async def test_configuration():
    """Test configuration system."""
    print("\n🔧 Testing Configuration...")
    
    try:
        # Test OpenRouter config
        openrouter_config = config_manager.openrouter
        print(f"✅ OpenRouter enabled: {openrouter_config.enabled}")
        print(f"✅ API key configured: {'Yes' if openrouter_config.api_key else 'No'}")
        print(f"✅ Daily cost limit: ${openrouter_config.daily_cost_limit}")
        print(f"✅ Fallback enabled: {openrouter_config.fallback_to_local}")
        
        # Test model assignments
        print(f"✅ Scanner model: {openrouter_config.scanner_model}")
        print(f"✅ Chart model: {openrouter_config.chart_model}")
        print(f"✅ Combiner model: {openrouter_config.combiner_model}")
        print(f"✅ Verifier model: {openrouter_config.verifier_model}")
        
        return True
        
    except Exception as e:
        print(f"❌ Configuration test failed: {e}")
        return False

async def test_fallback_mechanisms():
    """Test fallback mechanisms."""
    print("\n🔧 Testing Fallback Mechanisms...")
    
    try:
        client = OpenRouterClient()
        
        # Test with invalid API key to trigger fallback
        original_key = client.api_key
        client.api_key = "invalid_key_for_testing"
        
        response = await client.generate_response(
            task_type=TaskType.MARKET_ANALYSIS,
            prompt="Test fallback",
            max_tokens=50
        )
        
        # Restore original key
        client.api_key = original_key
        
        if response:
            print("✅ Fallback mechanism working")
        else:
            print("⚠️  Fallback mechanism may need adjustment")
        
        return True
        
    except Exception as e:
        print(f"❌ Fallback test failed: {e}")
        return False

async def main():
    """Run all integration tests."""
    print("🚀 OpenRouter Integration Test Suite")
    print("=" * 50)
    
    tests = [
        ("Configuration", test_configuration),
        ("OpenRouter Client", test_openrouter_client),
        ("Module Integrations", test_module_integrations),
        ("Fallback Mechanisms", test_fallback_mechanisms)
    ]
    
    results = []
    
    for test_name, test_func in tests:
        try:
            result = await test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"❌ {test_name} test crashed: {e}")
            results.append((test_name, False))
    
    # Summary
    print("\n" + "=" * 50)
    print("📊 Test Results Summary")
    print("=" * 50)
    
    passed = 0
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status} {test_name}")
        if result:
            passed += 1
    
    print(f"\nOverall: {passed}/{len(results)} tests passed")
    
    if passed == len(results):
        print("🎉 All tests passed! OpenRouter integration is ready.")
        return 0
    else:
        print("⚠️  Some tests failed. Check the output above for details.")
        return 1

if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)