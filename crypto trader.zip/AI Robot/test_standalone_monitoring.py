#!/usr/bin/env python3
"""
Test script for standalone monitoring functionality.
Verifies that monitoring can run without AI system dependencies.
"""

import os
import sys
import time
import subprocess
import requests
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

def test_import_chain_isolation():
    """Test that monitoring imports don't trigger AI system loading."""
    print("🔍 Testing import chain isolation...")
    
    # Set monitoring-only mode
    os.environ['MONITORING_ONLY_MODE'] = 'true'
    
    try:
        # Test importing monitoring without AI dependencies
        from src.monitoring.interfaces import ILogger, ISystemMonitor
        from src.monitoring.dependency_injection import initialize_monitoring_container
        from src.monitoring.standalone_monitor import StandaloneMonitoringSystem
        
        print("✅ Successfully imported monitoring components without AI dependencies")
        return True
        
    except ImportError as e:
        print(f"❌ Import chain coupling detected: {e}")
        return False
    except Exception as e:
        print(f"❌ Unexpected error during import test: {e}")
        return False

def test_dependency_injection():
    """Test dependency injection container functionality."""
    print("🔍 Testing dependency injection container...")
    
    try:
        from src.monitoring.dependency_injection import initialize_monitoring_container
        
        # Initialize container
        container = initialize_monitoring_container()
        
        # Test getting components
        logger = container.get_logger("test")
        db_manager = container.get_database_manager()
        config_manager = container.get_config_manager()
        metrics_collector = container.get_metrics_collector()
        alert_manager = container.get_alert_manager()
        
        # Verify components are not None
        assert logger is not None, "Logger should not be None"
        assert db_manager is not None, "Database manager should not be None"
        assert config_manager is not None, "Config manager should not be None"
        assert metrics_collector is not None, "Metrics collector should not be None"
        assert alert_manager is not None, "Alert manager should not be None"
        
        print("✅ Dependency injection container working correctly")
        return True
        
    except Exception as e:
        print(f"❌ Dependency injection test failed: {e}")
        return False

def test_standalone_monitor_initialization():
    """Test standalone monitoring system initialization."""
    print("🔍 Testing standalone monitor initialization...")
    
    try:
        from src.monitoring.standalone_monitor import StandaloneMonitoringSystem
        
        # Create monitoring system
        monitoring_system = StandaloneMonitoringSystem()
        
        # Test status
        status = monitoring_system.get_status()
        assert 'monitoring_only_mode' in status, "Status should include monitoring_only_mode"
        assert status['monitoring_only_mode'] is True, "Should be in monitoring-only mode"
        
        print("✅ Standalone monitoring system initialized successfully")
        return True
        
    except Exception as e:
        print(f"❌ Standalone monitor initialization failed: {e}")
        return False

def test_config_monitoring_only_mode():
    """Test monitoring configuration in monitoring-only mode."""
    print("🔍 Testing monitoring-only configuration...")
    
    try:
        from src.monitoring.config import MonitoringConfig
        
        # Create config with monitoring-only mode
        config = MonitoringConfig()
        
        # Verify monitoring-only mode is detected
        assert config.is_monitoring_only is True, "Should detect monitoring-only mode"
        assert config.monitoring_only.enabled is True, "Monitoring-only config should be enabled"
        
        # Test dashboard config
        dashboard_config = config.get_dashboard_config()
        assert dashboard_config['port'] == 5050, "Dashboard should use port 5050 in monitoring-only mode"
        
        # Test monitoring config
        monitoring_config = config.get_monitoring_config()
        assert 'collection_interval' in monitoring_config, "Should have collection interval"
        
        print("✅ Monitoring-only configuration working correctly")
        return True
        
    except Exception as e:
        print(f"❌ Monitoring-only configuration test failed: {e}")
        return False

def test_requirements_alternatives():
    """Test that TA-Lib alternatives are available."""
    print("🔍 Testing TA-Lib alternatives...")
    
    try:
        # Test pandas-ta import (TA-Lib alternative)
        import pandas_ta as ta
        print("✅ pandas-ta (TA-Lib alternative) is available")
        
        # Test basic functionality
        import pandas as pd
        import numpy as np
        
        # Create sample data
        data = pd.DataFrame({
            'close': np.random.rand(100) * 100 + 50
        })
        
        # Test SMA calculation
        sma = ta.sma(data['close'], length=10)
        assert sma is not None, "SMA calculation should work"
        
        print("✅ TA-Lib alternative functionality verified")
        return True
        
    except ImportError:
        print("⚠️  pandas-ta not installed, but this is expected in monitoring-only mode")
        return True  # This is acceptable for monitoring-only mode
    except Exception as e:
        print(f"❌ TA-Lib alternatives test failed: {e}")
        return False

def test_standalone_monitoring_service():
    """Test standalone monitoring as a service."""
    print("🔍 Testing standalone monitoring service...")
    
    try:
        # Start monitoring in background
        from src.monitoring.standalone_monitor import StandaloneMonitoringSystem
        
        monitoring_system = StandaloneMonitoringSystem()
        monitoring_system.start()
        
        # Give it a moment to start
        time.sleep(2)
        
        # Test status
        status = monitoring_system.get_status()
        assert status['running'] is True, "Monitoring system should be running"
        
        # Stop monitoring
        monitoring_system.stop()
        
        print("✅ Standalone monitoring service test passed")
        return True
        
    except Exception as e:
        print(f"❌ Standalone monitoring service test failed: {e}")
        return False

def test_dashboard_backend():
    """Test dashboard backend functionality."""
    print("🔍 Testing dashboard backend...")
    
    try:
        from src.monitoring.dashboard_backend import create_standalone_dashboard
        from src.monitoring.dependency_injection import initialize_monitoring_container
        
        # Create dashboard
        container = initialize_monitoring_container()
        app = create_standalone_dashboard(container)
        
        # Test that app was created
        assert app is not None, "Dashboard app should be created"
        assert hasattr(app, 'run'), "App should have run method"
        
        print("✅ Dashboard backend created successfully")
        return True
        
    except Exception as e:
        print(f"❌ Dashboard backend test failed: {e}")
        return False

def run_all_tests():
    """Run all standalone monitoring tests."""
    print("🚀 Starting Standalone Monitoring Tests")
    print("=" * 50)
    
    tests = [
        ("Import Chain Isolation", test_import_chain_isolation),
        ("Dependency Injection", test_dependency_injection),
        ("Standalone Monitor Initialization", test_standalone_monitor_initialization),
        ("Monitoring-Only Configuration", test_config_monitoring_only_mode),
        ("TA-Lib Alternatives", test_requirements_alternatives),
        ("Standalone Monitoring Service", test_standalone_monitoring_service),
        ("Dashboard Backend", test_dashboard_backend),
    ]
    
    results = []
    
    for test_name, test_func in tests:
        print(f"\n📋 Running: {test_name}")
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"❌ {test_name} failed with exception: {e}")
            results.append((test_name, False))
    
    # Summary
    print("\n" + "=" * 50)
    print("📊 Test Results Summary")
    print("=" * 50)
    
    passed = 0
    failed = 0
    
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status} {test_name}")
        if result:
            passed += 1
        else:
            failed += 1
    
    print(f"\n📈 Total: {len(results)} tests")
    print(f"✅ Passed: {passed}")
    print(f"❌ Failed: {failed}")
    
    if failed == 0:
        print("\n🎉 All tests passed! Standalone monitoring is working correctly.")
        return True
    else:
        print(f"\n⚠️  {failed} test(s) failed. Please check the implementation.")
        return False

if __name__ == "__main__":
    # Ensure we're in monitoring-only mode for testing
    os.environ['MONITORING_ONLY_MODE'] = 'true'
    
    success = run_all_tests()
    sys.exit(0 if success else 1)