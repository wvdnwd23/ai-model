#!/bin/bash

# AI Crypto Trading System - Auto-Installer for Raspberry Pi 5
# This script performs a complete installation and setup of the AI trading system

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
INSTALL_DIR="/opt/ai-crypto-trader"
SERVICE_USER="ai-trader"
PYTHON_VERSION="3.11"
OLLAMA_MODEL="llama3.1:8b-instruct-q4_0"
LOG_FILE="/tmp/ai-trader-install.log"

# Functions
log() {
    echo -e "${GREEN}[$(date '+%Y-%m-%d %H:%M:%S')] $1${NC}" | tee -a "$LOG_FILE"
}

warn() {
    echo -e "${YELLOW}[$(date '+%Y-%m-%d %H:%M:%S')] WARNING: $1${NC}" | tee -a "$LOG_FILE"
}

error() {
    echo -e "${RED}[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: $1${NC}" | tee -a "$LOG_FILE"
    exit 1
}

info() {
    echo -e "${BLUE}[$(date '+%Y-%m-%d %H:%M:%S')] $1${NC}" | tee -a "$LOG_FILE"
}

check_root() {
    if [[ $EUID -ne 0 ]]; then
        error "This script must be run as root. Use: sudo $0"
    fi
}

check_raspberry_pi() {
    if ! grep -q "Raspberry Pi" /proc/cpuinfo; then
        warn "This script is optimized for Raspberry Pi. Continuing anyway..."
    fi
    
    # Check for Pi 5 specifically
    if grep -q "BCM2712" /proc/cpuinfo; then
        log "Raspberry Pi 5 detected - optimal performance expected"
    else
        warn "Non-Pi 5 hardware detected. Performance may be limited."
    fi
}

check_system_requirements() {
    log "Checking system requirements..."
    
    # Check available memory (minimum 4GB recommended)
    TOTAL_MEM=$(free -m | awk 'NR==2{printf "%.0f", $2}')
    if [ "$TOTAL_MEM" -lt 3500 ]; then
        warn "Less than 4GB RAM detected ($TOTAL_MEM MB). Performance may be limited."
    else
        log "Memory check passed: ${TOTAL_MEM}MB available"
    fi
    
    # Check available disk space (minimum 8GB)
    AVAILABLE_SPACE=$(df / | awk 'NR==2 {print $4}')
    AVAILABLE_GB=$((AVAILABLE_SPACE / 1024 / 1024))
    if [ "$AVAILABLE_GB" -lt 8 ]; then
        error "Insufficient disk space. Need at least 8GB, have ${AVAILABLE_GB}GB"
    else
        log "Disk space check passed: ${AVAILABLE_GB}GB available"
    fi
    
    # Check internet connectivity
    if ! ping -c 1 google.com &> /dev/null; then
        error "No internet connection. Please check your network settings."
    else
        log "Internet connectivity verified"
    fi
}

optimize_raspberry_pi() {
    log "Optimizing Raspberry Pi 5 settings..."
    
    # GPU memory split optimization
    if ! grep -q "gpu_mem=128" /boot/config.txt; then
        echo "gpu_mem=128" >> /boot/config.txt
        log "GPU memory split optimized"
    fi
    
    # Enable hardware acceleration
    if ! grep -q "dtoverlay=vc4-kms-v3d" /boot/config.txt; then
        echo "dtoverlay=vc4-kms-v3d" >> /boot/config.txt
        log "Hardware acceleration enabled"
    fi
    
    # Increase swap size for AI operations
    if [ -f /etc/dphys-swapfile ]; then
        sed -i 's/CONF_SWAPSIZE=100/CONF_SWAPSIZE=2048/' /etc/dphys-swapfile
        systemctl restart dphys-swapfile
        log "Swap size increased to 2GB"
    fi
    
    # Set CPU governor to performance
    echo 'GOVERNOR="performance"' > /etc/default/cpufrequtils
    log "CPU governor set to performance mode"
}

update_system() {
    log "Updating system packages..."
    
    export DEBIAN_FRONTEND=noninteractive
    apt-get update -y
    apt-get upgrade -y
    
    # Install essential packages
    apt-get install -y \
        curl \
        wget \
        git \
        build-essential \
        software-properties-common \
        apt-transport-https \
        ca-certificates \
        gnupg \
        lsb-release \
        unzip \
        htop \
        nano \
        vim \
        screen \
        tmux \
        sqlite3 \
        libsqlite3-dev \
        pkg-config \
        libssl-dev \
        libffi-dev \
        libbz2-dev \
        libreadline-dev \
        libsqlite3-dev \
        libncurses5-dev \
        libncursesw5-dev \
        xz-utils \
        tk-dev \
        libxml2-dev \
        libxmlsec1-dev \
        libffi-dev \
        liblzma-dev
    
    log "System packages updated successfully"
}

install_python() {
    log "Installing Python ${PYTHON_VERSION}..."
    
    # Check if Python 3.11+ is already installed
    if command -v python3.11 &> /dev/null; then
        CURRENT_VERSION=$(python3.11 --version | cut -d' ' -f2)
        log "Python ${CURRENT_VERSION} already installed"
        return
    fi
    
    # Add deadsnakes PPA for newer Python versions
    add-apt-repository ppa:deadsnakes/ppa -y
    apt-get update -y
    
    # Install Python 3.11 and related packages
    apt-get install -y \
        python3.11 \
        python3.11-dev \
        python3.11-venv \
        python3.11-distutils \
        python3-pip
    
    # Set Python 3.11 as default python3
    update-alternatives --install /usr/bin/python3 python3 /usr/bin/python3.11 1
    
    # Install/upgrade pip
    curl -sS https://bootstrap.pypa.io/get-pip.py | python3.11
    
    log "Python ${PYTHON_VERSION} installed successfully"
}

install_nodejs() {
    log "Installing Node.js for dashboard dependencies..."
    
    # Install Node.js 18.x LTS
    curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
    apt-get install -y nodejs
    
    # Verify installation
    NODE_VERSION=$(node --version)
    NPM_VERSION=$(npm --version)
    log "Node.js ${NODE_VERSION} and npm ${NPM_VERSION} installed"
}

install_ollama() {
    log "Installing Ollama for local AI processing..."
    
    # Download and install Ollama
    curl -fsSL https://ollama.ai/install.sh | sh
    
    # Start Ollama service
    systemctl enable ollama
    systemctl start ollama
    
    # Wait for Ollama to be ready
    log "Waiting for Ollama service to start..."
    sleep 10
    
    # Pull the required model
    log "Downloading LLaMA model (this may take several minutes)..."
    sudo -u ollama ollama pull "$OLLAMA_MODEL"
    
    # Verify model installation
    if sudo -u ollama ollama list | grep -q "$OLLAMA_MODEL"; then
        log "Ollama and $OLLAMA_MODEL installed successfully"
    else
        error "Failed to install Ollama model"
    fi
}

install_talib() {
    log "Installing TA-Lib for technical analysis..."
    
    # Download and compile TA-Lib from source
    cd /tmp
    wget http://prdownloads.sourceforge.net/ta-lib/ta-lib-0.4.0-src.tar.gz
    tar -xzf ta-lib-0.4.0-src.tar.gz
    cd ta-lib/
    
    ./configure --prefix=/usr/local
    make
    make install
    
    # Update library path
    echo '/usr/local/lib' > /etc/ld.so.conf.d/talib.conf
    ldconfig
    
    log "TA-Lib installed successfully"
}

create_user() {
    log "Creating system user for AI trader..."
    
    # Create user if it doesn't exist
    if ! id "$SERVICE_USER" &>/dev/null; then
        useradd -r -s /bin/bash -d "$INSTALL_DIR" -m "$SERVICE_USER"
        log "User $SERVICE_USER created"
    else
        log "User $SERVICE_USER already exists"
    fi
    
    # Add user to necessary groups
    usermod -a -G sudo,dialout,gpio,i2c,spi "$SERVICE_USER"
}

setup_directories() {
    log "Setting up directory structure..."
    
    # Create main installation directory
    mkdir -p "$INSTALL_DIR"
    
    # Create subdirectories
    mkdir -p "$INSTALL_DIR"/{src,config,data,logs,scripts,backups}
    mkdir -p "$INSTALL_DIR"/data/{database,cache,logs,backups}
    mkdir -p "$INSTALL_DIR"/data/logs/{system,trades,errors,ai_learning}
    mkdir -p "$INSTALL_DIR"/data/cache/{market_data,news_data,session_data}
    mkdir -p "$INSTALL_DIR"/data/backups/{database,configs}
    
    # Set ownership
    chown -R "$SERVICE_USER:$SERVICE_USER" "$INSTALL_DIR"
    
    # Set permissions
    chmod -R 755 "$INSTALL_DIR"
    chmod -R 700 "$INSTALL_DIR"/config
    chmod -R 700 "$INSTALL_DIR"/data
    
    log "Directory structure created"
}

copy_source_code() {
    log "Copying source code to installation directory..."
    
    # Copy source files
    cp -r src/* "$INSTALL_DIR/src/"
    cp requirements.txt "$INSTALL_DIR/"
    
    # Copy any existing config files
    if [ -d "config" ]; then
        cp -r config/* "$INSTALL_DIR/config/"
    fi
    
    # Set ownership
    chown -R "$SERVICE_USER:$SERVICE_USER" "$INSTALL_DIR"
    
    log "Source code copied successfully"
}

create_virtual_environment() {
    log "Creating Python virtual environment..."
    
    # Create virtual environment
    sudo -u "$SERVICE_USER" python3.11 -m venv "$INSTALL_DIR/venv"
    
    # Activate and upgrade pip
    sudo -u "$SERVICE_USER" bash -c "source $INSTALL_DIR/venv/bin/activate && pip install --upgrade pip setuptools wheel"
    
    log "Virtual environment created"
}

install_python_packages() {
    log "Installing Python packages..."
    
    # Install packages from requirements.txt
    sudo -u "$SERVICE_USER" bash -c "source $INSTALL_DIR/venv/bin/activate && pip install -r $INSTALL_DIR/requirements.txt"
    
    # Install additional packages for Raspberry Pi optimization
    sudo -u "$SERVICE_USER" bash -c "source $INSTALL_DIR/venv/bin/activate && pip install psutil RPi.GPIO gpiozero"
    
    log "Python packages installed successfully"
}

install_playwright() {
    log "Installing Playwright browsers..."
    
    # Install Playwright browsers
    sudo -u "$SERVICE_USER" bash -c "source $INSTALL_DIR/venv/bin/activate && playwright install chromium"
    sudo -u "$SERVICE_USER" bash -c "source $INSTALL_DIR/venv/bin/activate && playwright install-deps"
    
    log "Playwright browsers installed"
}

initialize_database() {
    log "Initializing database..."
    
    # Create database initialization script
    cat > "$INSTALL_DIR/scripts/init_db.py" << 'EOF'
#!/usr/bin/env python3
import sys
import os
sys.path.append('/opt/ai-crypto-trader/src')

from utils.database import DatabaseManager
from utils.config import create_default_configs

def main():
    # Create default configurations
    create_default_configs()
    
    # Initialize database
    db = DatabaseManager('/opt/ai-crypto-trader/data/database/trading_system.db')
    print("Database initialized successfully")

if __name__ == "__main__":
    main()
EOF
    
    # Make script executable
    chmod +x "$INSTALL_DIR/scripts/init_db.py"
    
    # Run database initialization
    sudo -u "$SERVICE_USER" bash -c "source $INSTALL_DIR/venv/bin/activate && python $INSTALL_DIR/scripts/init_db.py"
    
    log "Database initialized successfully"
}

create_environment_file() {
    log "Creating environment configuration file..."
    
    cat > "$INSTALL_DIR/.env" << EOF
# AI Crypto Trading System Environment Configuration

# Ollama Configuration
OLLAMA_HOST=localhost
OLLAMA_PORT=11434
OLLAMA_MODEL=$OLLAMA_MODEL

# Database Configuration
DATABASE_PATH=/opt/ai-crypto-trader/data/database/trading_system.db

# Trading Configuration
MAX_POSITION_SIZE=0.05
MAX_LEVERAGE=10
EMERGENCY_STOP_LOSS=5.0

# Telegram Configuration (Configure these manually)
TELEGRAM_BOT_TOKEN=
TELEGRAM_CHAT_ID=
TELEGRAM_ENABLED=false

# Exchange API Keys (Configure these manually)
MEXC_API_KEY=
MEXC_API_SECRET=
MEXC_TESTNET=true

XT_API_KEY=
XT_API_SECRET=
XT_TESTNET=true

# System Configuration
LOG_LEVEL=INFO
DEBUG_MODE=false
FLASK_PORT=5050
EOF
    
    # Set secure permissions
    chown "$SERVICE_USER:$SERVICE_USER" "$INSTALL_DIR/.env"
    chmod 600 "$INSTALL_DIR/.env"
    
    log "Environment file created"
}

setup_systemd_services() {
    log "Setting up systemd services..."
    
    # Create main service file
    cat > /etc/systemd/system/ai-crypto-trader.service << EOF
[Unit]
Description=AI Crypto Trading System
After=network.target ollama.service
Wants=ollama.service
Requires=network.target

[Service]
Type=simple
User=$SERVICE_USER
Group=$SERVICE_USER
WorkingDirectory=$INSTALL_DIR
Environment=PATH=$INSTALL_DIR/venv/bin
ExecStart=$INSTALL_DIR/venv/bin/python -m src.main
ExecReload=/bin/kill -HUP \$MAINPID
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=ai-crypto-trader

# Security settings
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=$INSTALL_DIR/data $INSTALL_DIR/logs

[Install]
WantedBy=multi-user.target
EOF
    
    # Enable services
    systemctl daemon-reload
    systemctl enable ai-crypto-trader.service
    
    log "Systemd services configured"
}

setup_log_rotation() {
    log "Setting up log rotation..."
    
    cat > /etc/logrotate.d/ai-crypto-trader << EOF
$INSTALL_DIR/data/logs/*/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 $SERVICE_USER $SERVICE_USER
    postrotate
        systemctl reload ai-crypto-trader.service > /dev/null 2>&1 || true
    endscript
}
EOF
    
    log "Log rotation configured"
}

setup_firewall() {
    log "Configuring firewall..."
    
    # Install ufw if not present
    apt-get install -y ufw
    
    # Configure firewall rules
    ufw --force reset
    ufw default deny incoming
    ufw default allow outgoing
    
    # Allow SSH
    ufw allow ssh
    
    # Allow Flask dashboard
    ufw allow 5050/tcp
    
    # Allow Ollama (local only)
    ufw allow from 127.0.0.1 to any port 11434
    
    # Enable firewall
    ufw --force enable
    
    log "Firewall configured"
}

create_backup_script() {
    log "Creating backup script..."
    
    cat > "$INSTALL_DIR/scripts/backup.sh" << 'EOF'
#!/bin/bash
# Automated backup script for AI Crypto Trading System

BACKUP_DIR="/opt/ai-crypto-trader/data/backups"
DATE=$(date +%Y%m%d_%H%M%S)

# Create backup directories
mkdir -p "$BACKUP_DIR/database"
mkdir -p "$BACKUP_DIR/configs"

# Backup database
sqlite3 /opt/ai-crypto-trader/data/database/trading_system.db ".backup $BACKUP_DIR/database/trading_system_$DATE.db"

# Backup configurations
cp -r /opt/ai-crypto-trader/config/* "$BACKUP_DIR/configs/" 2>/dev/null || true
cp /opt/ai-crypto-trader/.env "$BACKUP_DIR/configs/.env_$DATE" 2>/dev/null || true

# Cleanup old backups (keep 30 days)
find "$BACKUP_DIR" -name "*.db" -mtime +30 -delete
find "$BACKUP_DIR" -name ".env_*" -mtime +30 -delete

echo "Backup completed: $DATE"
EOF
    
    chmod +x "$INSTALL_DIR/scripts/backup.sh"
    chown "$SERVICE_USER:$SERVICE_USER" "$INSTALL_DIR/scripts/backup.sh"
    
    # Setup daily backup cron job
    echo "0 2 * * * $SERVICE_USER $INSTALL_DIR/scripts/backup.sh" > /etc/cron.d/ai-trader-backup
    
    log "Backup script created and scheduled"
}

verify_installation() {
    log "Verifying installation..."
    
    # Check Python environment
    if sudo -u "$SERVICE_USER" bash -c "source $INSTALL_DIR/venv/bin/activate && python -c 'import src.utils.config'"; then
        log "✓ Python environment working"
    else
        error "✗ Python environment failed"
    fi
    
    # Check Ollama
    if curl -s http://localhost:11434/api/tags | grep -q "$OLLAMA_MODEL"; then
        log "✓ Ollama service working"
    else
        warn "✗ Ollama service may have issues"
    fi
    
    # Check database
    if [ -f "$INSTALL_DIR/data/database/trading_system.db" ]; then
        log "✓ Database initialized"
    else
        error "✗ Database not found"
    fi
    
    # Check permissions
    if [ -O "$INSTALL_DIR" ] && [ -G "$INSTALL_DIR" ]; then
        log "✓ Permissions set correctly"
    else
        warn "✗ Permission issues detected"
    fi
    
    log "Installation verification completed"
}

cleanup() {
    log "Cleaning up temporary files..."
    
    # Remove temporary files
    rm -rf /tmp/ta-lib*
    apt-get autoremove -y
    apt-get autoclean
    
    log "Cleanup completed"
}

print_summary() {
    echo ""
    echo "=============================================="
    echo "  AI Crypto Trading System Installation Complete"
    echo "=============================================="
    echo ""
    echo "Installation Directory: $INSTALL_DIR"
    echo "Service User: $SERVICE_USER"
    echo "Database: $INSTALL_DIR/data/database/trading_system.db"
    echo "Logs: $INSTALL_DIR/data/logs/"
    echo ""
    echo "Next Steps:"
    echo "1. Configure API keys in: $INSTALL_DIR/.env"
    echo "2. Run configuration setup: sudo -u $SERVICE_USER $INSTALL_DIR/scripts/setup_config.py"
    echo "3. Start the service: systemctl start ai-crypto-trader"
    echo "4. Check status: systemctl status ai-crypto-trader"
    echo "5. View logs: journalctl -u ai-crypto-trader -f"
    echo ""
    echo "Dashboard will be available at: http://localhost:5050"
    echo ""
    echo "For troubleshooting, check: $LOG_FILE"
    echo "=============================================="
}

# Main installation process
main() {
    log "Starting AI Crypto Trading System installation..."
    
    check_root
    check_raspberry_pi
    check_system_requirements
    
    optimize_raspberry_pi
    update_system
    install_python
    install_nodejs
    install_talib
    install_ollama
    
    create_user
    setup_directories
    copy_source_code
    create_virtual_environment
    install_python_packages
    install_playwright
    
    initialize_database
    create_environment_file
    setup_systemd_services
    setup_log_rotation
    setup_firewall
    create_backup_script
    
    verify_installation
    cleanup
    print_summary
    
    log "Installation completed successfully!"
}

# Run main function
main "$@"