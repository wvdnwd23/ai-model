#!/bin/bash

# AI Crypto Trading System - Health Check Script
# Monitors system resources, module status, and generates alerts

set -e

# Configuration
INSTALL_DIR="/opt/ai-crypto-trader"
SERVICE_USER="ai-trader"
LOG_FILE="$INSTALL_DIR/data/logs/system/health_check.log"
HEALTH_STATUS_FILE="$INSTALL_DIR/data/health_status.json"
ALERT_THRESHOLD_CPU=80
ALERT_THRESHOLD_MEMORY=85
ALERT_THRESHOLD_DISK=90
ALERT_THRESHOLD_TEMP=75
NETWORK_TEST_HOST="8.8.8.8"
OLLAMA_TIMEOUT=10
DATABASE_TIMEOUT=5

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m'

# Health status variables
OVERALL_STATUS="healthy"
ISSUES_FOUND=()
WARNINGS_FOUND=()
CRITICAL_ISSUES=()

# Ensure log directory exists
mkdir -p "$(dirname "$LOG_FILE")"

# Logging functions
log() {
    echo -e "${GREEN}[$(date '+%Y-%m-%d %H:%M:%S')] $1${NC}" | tee -a "$LOG_FILE"
}

warn() {
    echo -e "${YELLOW}[$(date '+%Y-%m-%d %H:%M:%S')] WARNING: $1${NC}" | tee -a "$LOG_FILE"
    WARNINGS_FOUND+=("$1")
    if [[ "$OVERALL_STATUS" == "healthy" ]]; then
        OVERALL_STATUS="warning"
    fi
}

error() {
    echo -e "${RED}[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: $1${NC}" | tee -a "$LOG_FILE"
    ISSUES_FOUND+=("$1")
    OVERALL_STATUS="error"
}

critical() {
    echo -e "${RED}[$(date '+%Y-%m-%d %H:%M:%S')] CRITICAL: $1${NC}" | tee -a "$LOG_FILE"
    CRITICAL_ISSUES+=("$1")
    OVERALL_STATUS="critical"
}

info() {
    echo -e "${BLUE}[$(date '+%Y-%m-%d %H:%M:%S')] $1${NC}" | tee -a "$LOG_FILE"
}

# System resource checks
check_cpu_usage() {
    info "Checking CPU usage..."
    
    # Get CPU usage (1-minute average)
    local cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | cut -d'%' -f1 | cut -d',' -f1)
    
    # Handle different top output formats
    if [[ -z "$cpu_usage" ]]; then
        cpu_usage=$(grep 'cpu ' /proc/stat | awk '{usage=($2+$4)*100/($2+$4+$5)} END {print usage}')
    fi
    
    # Convert to integer for comparison
    cpu_int=${cpu_usage%.*}
    
    if [[ $cpu_int -gt $ALERT_THRESHOLD_CPU ]]; then
        error "High CPU usage: ${cpu_usage}%"
    elif [[ $cpu_int -gt $((ALERT_THRESHOLD_CPU - 10)) ]]; then
        warn "Elevated CPU usage: ${cpu_usage}%"
    else
        log "CPU usage normal: ${cpu_usage}%"
    fi
    
    echo "$cpu_usage"
}

check_memory_usage() {
    info "Checking memory usage..."
    
    # Get memory usage
    local mem_info=$(free | grep Mem)
    local total_mem=$(echo $mem_info | awk '{print $2}')
    local used_mem=$(echo $mem_info | awk '{print $3}')
    local mem_usage=$((used_mem * 100 / total_mem))
    
    if [[ $mem_usage -gt $ALERT_THRESHOLD_MEMORY ]]; then
        error "High memory usage: ${mem_usage}%"
    elif [[ $mem_usage -gt $((ALERT_THRESHOLD_MEMORY - 10)) ]]; then
        warn "Elevated memory usage: ${mem_usage}%"
    else
        log "Memory usage normal: ${mem_usage}%"
    fi
    
    # Check for memory leaks (processes using excessive memory)
    local high_mem_processes=$(ps aux --sort=-%mem | head -6 | tail -5 | awk '$4 > 10 {print $11 ": " $4 "%"}')
    if [[ -n "$high_mem_processes" ]]; then
        warn "High memory processes detected: $high_mem_processes"
    fi
    
    echo "$mem_usage"
}

check_disk_usage() {
    info "Checking disk usage..."
    
    # Check main installation directory
    local disk_usage=$(df "$INSTALL_DIR" | awk 'NR==2 {print $5}' | cut -d'%' -f1)
    
    if [[ $disk_usage -gt $ALERT_THRESHOLD_DISK ]]; then
        critical "Critical disk usage: ${disk_usage}%"
    elif [[ $disk_usage -gt $((ALERT_THRESHOLD_DISK - 10)) ]]; then
        warn "High disk usage: ${disk_usage}%"
    else
        log "Disk usage normal: ${disk_usage}%"
    fi
    
    # Check for large log files
    local large_logs=$(find "$INSTALL_DIR/data/logs" -name "*.log" -size +100M 2>/dev/null | wc -l)
    if [[ $large_logs -gt 0 ]]; then
        warn "Found $large_logs large log files (>100MB)"
    fi
    
    echo "$disk_usage"
}

check_temperature() {
    info "Checking system temperature..."
    
    # Check CPU temperature (Raspberry Pi specific)
    if [[ -f /sys/class/thermal/thermal_zone0/temp ]]; then
        local temp_raw=$(cat /sys/class/thermal/thermal_zone0/temp)
        local temp=$((temp_raw / 1000))
        
        if [[ $temp -gt $ALERT_THRESHOLD_TEMP ]]; then
            error "High CPU temperature: ${temp}°C"
        elif [[ $temp -gt $((ALERT_THRESHOLD_TEMP - 10)) ]]; then
            warn "Elevated CPU temperature: ${temp}°C"
        else
            log "CPU temperature normal: ${temp}°C"
        fi
        
        echo "$temp"
    else
        warn "Temperature monitoring not available"
        echo "N/A"
    fi
}

check_network_connectivity() {
    info "Checking network connectivity..."
    
    # Test internet connectivity
    if ping -c 1 -W 5 "$NETWORK_TEST_HOST" &>/dev/null; then
        log "Internet connectivity: OK"
        
        # Test DNS resolution
        if nslookup google.com &>/dev/null; then
            log "DNS resolution: OK"
        else
            warn "DNS resolution issues detected"
        fi
    else
        error "No internet connectivity"
    fi
    
    # Check network interface status
    local active_interfaces=$(ip link show | grep "state UP" | wc -l)
    if [[ $active_interfaces -eq 0 ]]; then
        critical "No active network interfaces"
    else
        log "Active network interfaces: $active_interfaces"
    fi
}

check_openai_service() {
    info "Checking OpenAI connectivity..."
    
    # Check if OpenAI API key is configured
    local env_file="$INSTALL_DIR/.env"
    if [[ -f "$env_file" ]]; then
        local api_key=$(grep "OPENAI_API_KEY=" "$env_file" | cut -d'=' -f2)
        if [[ -n "$api_key" && "$api_key" != "your_openai_api_key_here" ]]; then
            log "OpenAI API key: Configured"
            
            # Test OpenAI API connectivity
            local test_result=$("$INSTALL_DIR/venv/bin/python3" -c "
import sys
sys.path.append('$INSTALL_DIR/src')
import os
os.environ['OPENAI_API_KEY'] = '$api_key'
try:
    import openai
    client = openai.OpenAI()
    # Simple test call
    response = client.models.list()
    print('SUCCESS')
except Exception as e:
    print(f'FAILED: {e}')
" 2>/dev/null)
            
            if echo "$test_result" | grep -q "SUCCESS"; then
                log "OpenAI API: Responding"
            else
                error "OpenAI API connectivity failed"
            fi
        else
            error "OpenAI API key not configured"
        fi
    else
        error "Environment file not found"
    fi
}

check_database() {
    info "Checking database..."
    
    local db_path="$INSTALL_DIR/data/database/trading_system.db"
    
    # Check if database file exists
    if [[ -f "$db_path" ]]; then
        log "Database file: Found"
        
        # Test database connection
        if timeout $DATABASE_TIMEOUT sqlite3 "$db_path" "SELECT 1;" >/dev/null 2>&1; then
            log "Database connection: OK"
            
            # Check database integrity
            local integrity_check=$(sqlite3 "$db_path" "PRAGMA integrity_check;" 2>/dev/null)
            if [[ "$integrity_check" == "ok" ]]; then
                log "Database integrity: OK"
            else
                error "Database integrity check failed"
            fi
            
            # Check table count
            local table_count=$(sqlite3 "$db_path" "SELECT COUNT(*) FROM sqlite_master WHERE type='table';" 2>/dev/null)
            if [[ $table_count -ge 5 ]]; then
                log "Database tables: $table_count found"
            else
                error "Database appears incomplete: only $table_count tables"
            fi
            
            # Check recent activity
            local recent_records=$(sqlite3 "$db_path" "SELECT COUNT(*) FROM ai_decisions WHERE timestamp > datetime('now', '-1 hour');" 2>/dev/null)
            log "Recent AI decisions: $recent_records in last hour"
            
        else
            error "Cannot connect to database"
        fi
    else
        critical "Database file not found: $db_path"
    fi
}

check_main_service() {
    info "Checking main AI trading service..."
    
    # Check if service is running
    if systemctl is-active --quiet ai-crypto-trader; then
        log "AI Crypto Trader service: Running"
        
        # Check PID file
        local pid_file="$INSTALL_DIR/data/ai-trader.pid"
        if [[ -f "$pid_file" ]]; then
            local pid=$(cat "$pid_file")
            if kill -0 "$pid" 2>/dev/null; then
                log "Main process: Running (PID: $pid)"
                
                # Check process memory usage
                local mem_usage=$(ps -p "$pid" -o %mem --no-headers 2>/dev/null | tr -d ' ')
                if [[ -n "$mem_usage" ]]; then
                    local mem_int=${mem_usage%.*}
                    if [[ $mem_int -gt 50 ]]; then
                        warn "High memory usage by main process: ${mem_usage}%"
                    else
                        log "Main process memory usage: ${mem_usage}%"
                    fi
                fi
            else
                error "Main process not running (stale PID file)"
            fi
        else
            warn "PID file not found"
        fi
        
        # Test Flask dashboard
        if curl -s http://localhost:5050/health >/dev/null 2>&1; then
            log "Flask dashboard: Responding"
        else
            warn "Flask dashboard not responding"
        fi
        
    else
        critical "AI Crypto Trader service not running"
    fi
}

check_browser_automation() {
    info "Checking browser automation..."
    
    # Check if required browsers are installed
    if command -v chromium-browser >/dev/null 2>&1 || command -v google-chrome >/dev/null 2>&1; then
        log "Browser binary: Available"
        
        # Test Playwright functionality (if service is running)
        if systemctl is-active --quiet ai-crypto-trader; then
            # This is a basic check - full browser test would be done by the main application
            log "Browser automation: Service running (detailed test by main app)"
        else
            warn "Cannot test browser automation - main service not running"
        fi
    else
        error "No suitable browser found for automation"
    fi
}

check_log_files() {
    info "Checking log files..."
    
    local log_dir="$INSTALL_DIR/data/logs"
    
    # Check if log directory exists
    if [[ -d "$log_dir" ]]; then
        log "Log directory: Found"
        
        # Check for recent errors
        local recent_errors=$(find "$log_dir" -name "*.log" -mtime -1 -exec grep -l "ERROR\|CRITICAL" {} \; 2>/dev/null | wc -l)
        if [[ $recent_errors -gt 0 ]]; then
            warn "Found errors in $recent_errors log files in last 24 hours"
        else
            log "No recent errors in log files"
        fi
        
        # Check log file sizes
        local large_logs=$(find "$log_dir" -name "*.log" -size +50M 2>/dev/null | wc -l)
        if [[ $large_logs -gt 0 ]]; then
            warn "Found $large_logs large log files (>50MB) - consider rotation"
        fi
        
        # Check log permissions
        local permission_issues=$(find "$log_dir" -not -user "$SERVICE_USER" 2>/dev/null | wc -l)
        if [[ $permission_issues -gt 0 ]]; then
            error "Found $permission_issues files with incorrect ownership in logs"
        fi
        
    else
        error "Log directory not found: $log_dir"
    fi
}

check_configuration() {
    info "Checking configuration..."
    
    # Check .env file
    local env_file="$INSTALL_DIR/.env"
    if [[ -f "$env_file" ]]; then
        log "Environment file: Found"
        
        # Check file permissions
        local perms=$(stat -c "%a" "$env_file")
        if [[ "$perms" != "600" ]]; then
            warn "Environment file has insecure permissions: $perms (should be 600)"
        fi
        
        # Check for required variables
        local required_vars=("OPENAI_API_KEY" "DATABASE_PATH" "MAX_POSITION_SIZE")
        for var in "${required_vars[@]}"; do
            if grep -q "^$var=" "$env_file"; then
                log "Required variable $var: Present"
            else
                error "Required variable $var: Missing"
            fi
        done
        
    else
        error "Environment file not found: $env_file"
    fi
    
    # Check config directory
    local config_dir="$INSTALL_DIR/config"
    if [[ -d "$config_dir" ]]; then
        local config_files=$(find "$config_dir" -name "*.json" | wc -l)
        log "Configuration files: $config_files found"
    else
        warn "Configuration directory not found"
    fi
}

check_security() {
    info "Checking security..."
    
    # Check file permissions
    local install_perms=$(stat -c "%a" "$INSTALL_DIR")
    if [[ "$install_perms" != "755" ]]; then
        warn "Installation directory has unusual permissions: $install_perms"
    fi
    
    # Check for world-writable files
    local world_writable=$(find "$INSTALL_DIR" -type f -perm -002 2>/dev/null | wc -l)
    if [[ $world_writable -gt 0 ]]; then
        error "Found $world_writable world-writable files"
    fi
    
    # Check service user
    if id "$SERVICE_USER" >/dev/null 2>&1; then
        log "Service user exists: $SERVICE_USER"
    else
        critical "Service user not found: $SERVICE_USER"
    fi
    
    # Check firewall status
    if command -v ufw >/dev/null 2>&1; then
        if ufw status | grep -q "Status: active"; then
            log "Firewall: Active"
        else
            warn "Firewall: Inactive"
        fi
    fi
}

generate_health_report() {
    info "Generating health report..."
    
    local timestamp=$(date -Iseconds)
    local cpu_usage=$(check_cpu_usage)
    local mem_usage=$(check_memory_usage)
    local disk_usage=$(check_disk_usage)
    local temperature=$(check_temperature)
    
    # Create JSON health report
    cat > "$HEALTH_STATUS_FILE" << EOF
{
    "timestamp": "$timestamp",
    "overall_status": "$OVERALL_STATUS",
    "system_resources": {
        "cpu_usage": $cpu_usage,
        "memory_usage": $mem_usage,
        "disk_usage": $disk_usage,
        "temperature": "$temperature"
    },
    "services": {
        "openai": "configured",
        "ai_crypto_trader": "$(systemctl is-active ai-crypto-trader 2>/dev/null || echo 'inactive')"
    },
    "issues": {
        "critical": [$(printf '"%s",' "${CRITICAL_ISSUES[@]}" | sed 's/,$//')]
        "errors": [$(printf '"%s",' "${ISSUES_FOUND[@]}" | sed 's/,$//')]
        "warnings": [$(printf '"%s",' "${WARNINGS_FOUND[@]}" | sed 's/,$//')]
    },
    "last_check": "$timestamp"
}
EOF
    
    log "Health report saved to: $HEALTH_STATUS_FILE"
}

send_alerts() {
    info "Processing alerts..."
    
    # Send Telegram alerts if configured and there are issues
    if [[ ${#CRITICAL_ISSUES[@]} -gt 0 || ${#ISSUES_FOUND[@]} -gt 0 ]]; then
        
        # Check if Telegram is configured
        local env_file="$INSTALL_DIR/.env"
        if [[ -f "$env_file" ]] && grep -q "TELEGRAM_ENABLED=true" "$env_file"; then
            
            local bot_token=$(grep "TELEGRAM_BOT_TOKEN=" "$env_file" | cut -d'=' -f2)
            local chat_id=$(grep "TELEGRAM_CHAT_ID=" "$env_file" | cut -d'=' -f2)
            
            if [[ -n "$bot_token" && -n "$chat_id" ]]; then
                
                local message="🚨 AI Crypto Trader Health Alert\\n\\n"
                message+="Status: $OVERALL_STATUS\\n"
                message+="Time: $(date)\\n\\n"
                
                if [[ ${#CRITICAL_ISSUES[@]} -gt 0 ]]; then
                    message+="🔴 Critical Issues:\\n"
                    for issue in "${CRITICAL_ISSUES[@]}"; do
                        message+="• $issue\\n"
                    done
                    message+="\\n"
                fi
                
                if [[ ${#ISSUES_FOUND[@]} -gt 0 ]]; then
                    message+="❌ Errors:\\n"
                    for issue in "${ISSUES_FOUND[@]}"; do
                        message+="• $issue\\n"
                    done
                    message+="\\n"
                fi
                
                if [[ ${#WARNINGS_FOUND[@]} -gt 0 ]]; then
                    message+="⚠️ Warnings:\\n"
                    for warning in "${WARNINGS_FOUND[@]}"; do
                        message+="• $warning\\n"
                    done
                fi
                
                # Send Telegram message
                curl -s -X POST "https://api.telegram.org/bot$bot_token/sendMessage" \
                    -d "chat_id=$chat_id" \
                    -d "text=$message" \
                    -d "parse_mode=HTML" >/dev/null 2>&1
                
                log "Alert sent via Telegram"
            fi
        fi
    fi
}

print_summary() {
    echo ""
    echo "=============================================="
    echo "  AI Crypto Trading System Health Check"
    echo "=============================================="
    echo ""
    echo "Overall Status: $OVERALL_STATUS"
    echo "Check Time: $(date)"
    echo ""
    
    if [[ ${#CRITICAL_ISSUES[@]} -gt 0 ]]; then
        echo "Critical Issues:"
        for issue in "${CRITICAL_ISSUES[@]}"; do
            echo "  🔴 $issue"
        done
        echo ""
    fi
    
    if [[ ${#ISSUES_FOUND[@]} -gt 0 ]]; then
        echo "Errors Found:"
        for issue in "${ISSUES_FOUND[@]}"; do
            echo "  ❌ $issue"
        done
        echo ""
    fi
    
    if [[ ${#WARNINGS_FOUND[@]} -gt 0 ]]; then
        echo "Warnings:"
        for warning in "${WARNINGS_FOUND[@]}"; do
            echo "  ⚠️  $warning"
        done
        echo ""
    fi
    
    if [[ "$OVERALL_STATUS" == "healthy" ]]; then
        echo "✅ All systems operational"
    fi
    
    echo ""
    echo "Detailed logs: $LOG_FILE"
    echo "Health report: $HEALTH_STATUS_FILE"
    echo "=============================================="
}

# Main health check function
main() {
    log "=== Starting Health Check ==="
    
    # System resource checks
    check_cpu_usage >/dev/null
    check_memory_usage >/dev/null
    check_disk_usage >/dev/null
    check_temperature >/dev/null
    check_network_connectivity
    
    # Service checks
    check_openai_service
    check_database
    check_main_service
    check_browser_automation
    
    # Configuration and security
    check_log_files
    check_configuration
    check_security
    
    # Generate reports and alerts
    generate_health_report
    send_alerts
    
    log "=== Health Check Complete ==="
    
    # Print summary if running interactively
    if [[ -t 1 ]]; then
        print_summary
    fi
    
    # Exit with appropriate code
    case "$OVERALL_STATUS" in
        "healthy")
            exit 0
            ;;
        "warning")
            exit 1
            ;;
        "error")
            exit 2
            ;;
        "critical")
            exit 3
            ;;
    esac
}

# Handle command line arguments
case "${1:-check}" in
    check)
        main
        ;;
    status)
        if [[ -f "$HEALTH_STATUS_FILE" ]]; then
            cat "$HEALTH_STATUS_FILE"
        else
            echo "No health status file found. Run health check first."
            exit 1
        fi
        ;;
    summary)
        if [[ -f "$HEALTH_STATUS_FILE" ]]; then
            local status=$(grep '"overall_status"' "$HEALTH_STATUS_FILE" | cut -d'"' -f4)
            local timestamp=$(grep '"timestamp"' "$HEALTH_STATUS_FILE" | cut -d'"' -f4)
            echo "Status: $status (Last check: $timestamp)"
        else
            echo "No health status available"
            exit 1
        fi
        ;;
    *)
        echo "Usage: $0 {check|status|summary}"
        echo "  check   - Run full health check"
        echo "  status  - Show last health status (JSON)"
        echo "  summary - Show brief status summary"
        exit 1
        ;;
esac