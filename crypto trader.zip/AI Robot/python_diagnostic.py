#!/usr/bin/env python3
"""
Python Environment Diagnostic Script
Validates assumptions about Python hanging issues
"""

import sys
import os
import time
import subprocess
import platform
import psutil
import threading
from datetime import datetime

class PythonDiagnostic:
    def __init__(self):
        self.log_file = "python_diagnostic.log"
        self.timeout = 10  # 10 second timeout for operations
        
    def log(self, message):
        """Log message with timestamp"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = f"[{timestamp}] {message}"
        print(log_entry)
        try:
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(log_entry + "\n")
        except Exception as e:
            print(f"Failed to write to log: {e}")
    
    def run_with_timeout(self, func, timeout=10):
        """Run function with timeout to detect hanging"""
        result = {"completed": False, "error": None, "result": None}
        
        def target():
            try:
                result["result"] = func()
                result["completed"] = True
            except Exception as e:
                result["error"] = str(e)
                result["completed"] = True
        
        thread = threading.Thread(target=target)
        thread.daemon = True
        thread.start()
        thread.join(timeout)
        
        if thread.is_alive():
            self.log(f"HANGING DETECTED: Operation timed out after {timeout} seconds")
            return {"hanging": True, "completed": False}
        
        return result
    
    def test_basic_python(self):
        """Test basic Python operations"""
        self.log("=== TESTING BASIC PYTHON OPERATIONS ===")
        
        # Test 1: Basic arithmetic
        self.log("Testing basic arithmetic...")
        result = self.run_with_timeout(lambda: 2 + 2)
        if result.get("hanging"):
            self.log("CRITICAL: Basic arithmetic hanging!")
            return False
        self.log(f"Basic arithmetic: {result}")
        
        # Test 2: String operations
        self.log("Testing string operations...")
        result = self.run_with_timeout(lambda: "test".upper())
        if result.get("hanging"):
            self.log("CRITICAL: String operations hanging!")
            return False
        self.log(f"String operations: {result}")
        
        return True
    
    def test_file_operations(self):
        """Test file I/O operations"""
        self.log("=== TESTING FILE OPERATIONS ===")
        
        def file_test():
            test_file = "diagnostic_test.tmp"
            with open(test_file, "w") as f:
                f.write("test")
            with open(test_file, "r") as f:
                content = f.read()
            os.remove(test_file)
