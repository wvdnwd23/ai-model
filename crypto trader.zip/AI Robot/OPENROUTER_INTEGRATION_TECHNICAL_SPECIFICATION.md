# AI Crypto Trading System - OpenRouter Integration & Monitoring Technical Specification

**Version:** 1.0  
**Date:** 2025-01-29  
**Status:** DRAFT - Architecture Planning Phase

---

## Executive Summary

This technical specification outlines the integration strategy for OpenRouter API and monitoring system fixes for the AI Crypto Trading System running on Raspberry Pi 5. The approach prioritizes fixing monitoring system issues first, followed by OpenRouter integration to enhance AI capabilities while maintaining LLaMA Mini as the central coordinator.

## Current System Analysis

### **Existing Architecture**
- **Central Coordinator**: LLaMA Mini via Ollama (AI Controller only)
- **Submodules**: Traditional algorithms without AI enhancement
- **Monitoring System**: 10,875 lines of code with import chain coupling issues
- **Critical Dependencies**: TA-Lib for Chart Checker module

### **Key Issues Identified**
1. **Import Chain Coupling**: Monitoring system imports trigger entire AI system load
2. **TA-Lib Dependency**: Requires Visual C++ build tools, blocking Chart Checker
3. **No Standalone Monitoring**: Cannot run monitoring independently
4. **Missing AI Enhancement**: Submodules use only traditional algorithms

---

## Phase 1: Monitoring System Fixes (Priority)

### **1.1 Import Chain Decoupling**

**Problem**: Monitoring system imports cause full AI system initialization
```python
# Current problematic pattern in monitoring modules:
from src.utils.logging import get_logger  # Triggers AI system load
from src.utils.database import db_manager  # Triggers AI system load
```

**Solution**: Create standalone monitoring entry point
```python
# New: src/monitoring/standalone.py
"""Standalone monitoring system entry point"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

# Direct imports bypassing AI system
from monitoring.config import monitoring_config
from monitoring.system_monitor import SystemMonitor
```

### **1.2 Dependency Injection Implementation**

**Current Pattern** (Tight Coupling):
```python
class MetricsCollector:
    def __init__(self):
        self.config = monitoring_config  # Direct import
        self.logger = get_logger("metrics")  # Direct import
```

**New Pattern** (Dependency Injection):
```python
class MetricsCollector:
    def __init__(self, config=None, logger=None, db_manager=None):
        self.config = config or self._create_default_config()
        self.logger = logger or self._create_logger()
        self.db_manager = db_manager or self._create_db_manager()
```

### **1.3 TA-Lib Dependency Resolution**

**Options Analysis**:
1. **Visual C++ Build Tools** (Recommended)
   - Download from Microsoft Visual Studio Build Tools
   - Install C++ build tools component
   - Run: `pip install TA-Lib`

2. **Pre-compiled Wheel** (Alternative)
   - Use: `pip install --find-links https://github.com/cgohlke/talib-build/releases TA-Lib`

3. **Alternative Library** (Fallback)
   - Replace with `pandas-ta` or `finta` for technical analysis

### **1.4 Standalone Monitoring Architecture**

```mermaid
graph TB
    subgraph "Standalone Monitoring System"
        SE[Standalone Entry Point]
        MC[Monitoring Config]
        SM[System Monitor]
        AM[AI Monitor]
        AL[Alert Manager]
        NS[Notification System]
    end
    
    subgraph "AI Trading System"
        ATS[AI Trading Modules]
    end
    
    SE --> MC
    SE --> SM
    SE --> AM
    SM -.-> ATS
    AM -.-> ATS
    AL --> NS
```

---

## Phase 2: OpenRouter API Integration

### **2.1 OpenRouter Client Architecture**

**Unified API Client**:
```python
class OpenRouterClient:
    def __init__(self, api_key: str, fallback_client=None):
        self.api_key = api_key
        self.fallback_client = fallback_client  # LLaMA Mini client
        self.model_routing = {
            "coin_scanner": "openrouter/meta-llama-3.1-8b-instruct",
            "chart_checker": "openai/gpt-4o", 
            "combiner": "openai/gpt-4o",
            "verifier": "anthropic/claude-3.5-sonnet"
        }
    
    async def chat_completion(self, module: str, messages: list, **kwargs):
        try:
            # Primary: OpenRouter API
            return await self._openrouter_request(module, messages, **kwargs)
        except Exception as e:
            # Fallback: LLaMA Mini
            return await self._fallback_request(messages, **kwargs)
```

### **2.2 Model Assignment Strategy**

| Module | OpenRouter Model | Reasoning | Fallback |
|--------|------------------|-----------|----------|
| **Coin Scanner** | `openrouter/meta-llama-3.1-8b-instruct` | Fast, cost-effective for sentiment analysis | Traditional algorithms |
| **Chart Checker** | `openai/gpt-4o` | Advanced reasoning for technical analysis | TA-Lib only |
| **Combiner** | `openai/gpt-4o` | Complex decision synthesis | Mathematical fusion |
| **Verifier** | `anthropic/claude-3.5-sonnet` | Thorough validation and risk assessment | Rule-based verification |

### **2.3 Configuration Management**

**Extended Configuration** (`src/utils/config.py`):
```python
@dataclass
class OpenRouterConfig:
    api_key: str = ""
    base_url: str = "https://openrouter.ai/api/v1"
    enabled: bool = False
    rate_limit_requests_per_minute: int = 60
    timeout: int = 30
    retry_attempts: int = 3
    fallback_to_ollama: bool = True
```

### **2.4 Module Enhancement Strategy**

**Coin Scanner Enhancement**:
- Add AI-powered sentiment analysis
- Implement pattern recognition for social media
- Enhance breakout probability calculations

**Chart Checker Enhancement**:
- AI interpretation of technical indicators
- Advanced pattern recognition
- Market context analysis

**Combiner Enhancement**:
- Intelligent signal weighting
- Dynamic risk assessment
- Market regime detection

**Verifier Enhancement**:
- Macro economic analysis
- News impact assessment
- Advanced risk validation

---

## Phase 3: Hybrid Architecture Design

### **3.1 New System Architecture**

```mermaid
graph TB
    subgraph "AI Layer"
        LM[LLaMA Mini<br/>Central Coordinator]
        OR[OpenRouter Gateway]
        
        subgraph "OpenRouter Models"
            OR1[Llama 3.1 8B<br/>Coin Scanner]
            OR2[GPT-4o<br/>Chart Checker]
            OR3[GPT-4o<br/>Combiner]
            OR4[Claude 3.5 Sonnet<br/>Verifier]
        end
    end
    
    subgraph "Trading Modules"
        AC[AI Controller]
        CS[Coin Scanner]
        CC[Chart Checker]
        CB[Combiner]
        VE[Verifier Executor]
    end
    
    subgraph "Monitoring System"
        SE[Standalone Entry]
        SM[System Monitor]
        AM[AI Monitor]
        AL[Alert Manager]
    end
    
    AC --> LM
    CS --> OR1
    CC --> OR2
    CB --> OR3
    VE --> OR4
    
    OR --> OR1
    OR --> OR2
    OR --> OR3
    OR --> OR4
    
    SE --> SM
    SE --> AM
    SM -.-> AC
    AM -.-> CS
    AM -.-> CC
    AM -.-> CB
    AM -.-> VE
```

### **3.2 Fallback Strategy**

**Three-Tier Fallback System**:
1. **Primary**: OpenRouter API calls
2. **Secondary**: LLaMA Mini local processing
3. **Tertiary**: Traditional algorithm-only mode

**Fallback Triggers**:
- API rate limit exceeded
- Network connectivity issues
- OpenRouter service unavailable
- Response timeout or errors

### **3.3 Error Handling & Recovery**

**Graceful Degradation**:
```python
class AIEnhancedModule:
    async def process_with_ai(self, data):
        try:
            # Try OpenRouter first
            result = await self.openrouter_client.chat_completion(
                module=self.module_name,
                messages=self._prepare_messages(data)
            )
            return self._parse_ai_result(result)
        except OpenRouterException:
            # Fallback to LLaMA Mini
            return await self._fallback_to_ollama(data)
        except Exception:
            # Final fallback to traditional algorithms
            return self._traditional_processing(data)
```

---

## Implementation Plan

### **Phase 1: Monitoring Fixes (Week 1-2)**
1. Create `src/monitoring/standalone.py` entry point
2. Implement dependency injection in all monitoring components
3. Resolve TA-Lib dependency installation
4. Test standalone monitoring system

### **Phase 2: OpenRouter Integration (Week 3-4)**
1. Create OpenRouter client wrapper
2. Extend configuration management
3. Implement model-specific routing
4. Add fallback mechanisms

### **Phase 3: Module Enhancement (Week 5-6)**
1. Enhance each module with AI capabilities
2. Implement three-tier fallback system
3. Add comprehensive error handling
4. Performance testing and optimization

### **Phase 4: Deployment & Testing (Week 7-8)**
1. Update deployment automation
2. Comprehensive integration testing
3. Performance benchmarking
4. Documentation and training

---

## Deployment Automation

### **Updated Requirements**
```python
# Additional dependencies for OpenRouter integration
openai>=1.0.0
anthropic>=0.8.0
httpx>=0.25.0
tenacity>=8.2.0  # For retry logic
```

### **Environment Variables**
```bash
# OpenRouter Configuration
OPENROUTER_API_KEY=your_api_key_here
OPENROUTER_ENABLED=true
OPENROUTER_FALLBACK_TO_OLLAMA=true

# Model Assignments
COIN_SCANNER_MODEL=openrouter/meta-llama-3.1-8b-instruct
CHART_CHECKER_MODEL=openai/gpt-4o
COMBINER_MODEL=openai/gpt-4o
VERIFIER_MODEL=anthropic/claude-3.5-sonnet
```

### **Service Configuration**
```bash
# Updated ai-crypto-trader.service
[Unit]
Description=AI Crypto Trading System with OpenRouter Integration
After=network.target ollama.service

[Service]
Type=simple
User=pi
WorkingDirectory=/opt/ai-crypto-trader
Environment=OPENROUTER_API_KEY=${OPENROUTER_API_KEY}
ExecStart=/opt/ai-crypto-trader/venv/bin/python src/main.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

---

## Risk Assessment & Mitigation

### **Technical Risks**
| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| OpenRouter API downtime | Medium | High | LLaMA Mini fallback |
| TA-Lib installation failure | Medium | High | Alternative libraries |
| Import chain issues persist | Low | Medium | Comprehensive testing |
| Performance degradation | Low | Medium | Monitoring and optimization |

### **Operational Risks**
| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| API cost overrun | Medium | Medium | Rate limiting and monitoring |
| Model performance variance | Medium | Medium | A/B testing and validation |
| Integration complexity | High | Medium | Phased implementation |

---

## Success Metrics

### **Phase 1 Success Criteria**
- [ ] Monitoring system runs independently
- [ ] TA-Lib dependency resolved
- [ ] Import chain coupling eliminated
- [ ] All monitoring tests pass

### **Phase 2 Success Criteria**
- [ ] OpenRouter client functional with all models
- [ ] Fallback mechanisms tested and working
- [ ] Configuration management extended
- [ ] API rate limiting implemented

### **Phase 3 Success Criteria**
- [ ] All modules enhanced with AI capabilities
- [ ] Three-tier fallback system operational
- [ ] Performance benchmarks met
- [ ] System runs autonomously on Raspberry Pi 5

---

## Conclusion

This technical specification provides a comprehensive roadmap for integrating OpenRouter API while fixing critical monitoring system issues. The phased approach ensures system stability while progressively enhancing AI capabilities. The hybrid architecture maintains LLaMA Mini as the central coordinator while leveraging specialized OpenRouter models for enhanced performance in each trading module.

**Next Steps**: Review and approve this specification, then proceed with Phase 1 implementation focusing on monitoring system fixes.