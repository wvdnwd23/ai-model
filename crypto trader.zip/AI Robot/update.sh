#!/bin/bash

# AI Crypto Trading System - Update Script
# Handles Git updates, dependency updates, database migrations, and rollback

set -e

# Configuration
INSTALL_DIR="/opt/ai-crypto-trader"
SERVICE_USER="ai-trader"
LOG_FILE="$INSTALL_DIR/data/logs/system/update.log"
BACKUP_DIR="$INSTALL_DIR/data/backups/updates"
GIT_REPO_URL="https://github.com/your-repo/ai-crypto-trader.git"
UPDATE_LOCK_FILE="/tmp/ai-trader-update.lock"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m'

# Update tracking
UPDATE_ID=$(date +%Y%m%d_%H%M%S)
ROLLBACK_POINT=""
SERVICE_WAS_RUNNING=false

# Ensure log directory exists
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$BACKUP_DIR"

# Logging functions
log() {
    echo -e "${GREEN}[$(date '+%Y-%m-%d %H:%M:%S')] $1${NC}" | tee -a "$LOG_FILE"
}

warn() {
    echo -e "${YELLOW}[$(date '+%Y-%m-%d %H:%M:%S')] WARNING: $1${NC}" | tee -a "$LOG_FILE"
}

error() {
    echo -e "${RED}[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: $1${NC}" | tee -a "$LOG_FILE"
}

info() {
    echo -e "${BLUE}[$(date '+%Y-%m-%d %H:%M:%S')] $1${NC}" | tee -a "$LOG_FILE"
}

# Check if running as correct user
check_user() {
    if [[ "$USER" != "root" ]]; then
        error "This script must be run as root for service management. Use: sudo $0"
        exit 1
    fi
}

# Create update lock
create_lock() {
    if [[ -f "$UPDATE_LOCK_FILE" ]]; then
        local lock_pid=$(cat "$UPDATE_LOCK_FILE")
        if kill -0 "$lock_pid" 2>/dev/null; then
            error "Update already in progress (PID: $lock_pid)"
            exit 1
        else
            warn "Removing stale lock file"
            rm -f "$UPDATE_LOCK_FILE"
        fi
    fi
    
    echo $$ > "$UPDATE_LOCK_FILE"
    log "Update lock created"
}

# Remove update lock
remove_lock() {
    rm -f "$UPDATE_LOCK_FILE"
    log "Update lock removed"
}

# Cleanup function
cleanup() {
    remove_lock
    
    # Restart service if it was running
    if [[ "$SERVICE_WAS_RUNNING" == "true" ]]; then
        log "Restarting AI Crypto Trader service..."
        systemctl start ai-crypto-trader
    fi
}

# Set up signal handlers
trap cleanup EXIT
trap 'error "Update interrupted"; exit 1' INT TERM

# Check service status
check_service_status() {
    if systemctl is-active --quiet ai-crypto-trader; then
        SERVICE_WAS_RUNNING=true
        log "Service is currently running"
    else
        SERVICE_WAS_RUNNING=false
        log "Service is not running"
    fi
}

# Stop service safely
stop_service() {
    if [[ "$SERVICE_WAS_RUNNING" == "true" ]]; then
        log "Stopping AI Crypto Trader service..."
        systemctl stop ai-crypto-trader
        
        # Wait for graceful shutdown
        local timeout=30
        while systemctl is-active --quiet ai-crypto-trader && [[ $timeout -gt 0 ]]; do
            sleep 1
            ((timeout--))
        done
        
        if systemctl is-active --quiet ai-crypto-trader; then
            warn "Service did not stop gracefully, forcing stop"
            systemctl kill ai-crypto-trader
        fi
        
        log "Service stopped successfully"
    fi
}

# Create backup before update
create_backup() {
    log "Creating backup before update..."
    
    local backup_path="$BACKUP_DIR/backup_$UPDATE_ID"
    mkdir -p "$backup_path"
    
    # Backup source code
    log "Backing up source code..."
    cp -r "$INSTALL_DIR/src" "$backup_path/"
    
    # Backup configuration
    log "Backing up configuration..."
    cp -r "$INSTALL_DIR/config" "$backup_path/" 2>/dev/null || true
    cp "$INSTALL_DIR/.env" "$backup_path/" 2>/dev/null || true
    
    # Backup database
    log "Backing up database..."
    local db_path="$INSTALL_DIR/data/database/trading_system.db"
    if [[ -f "$db_path" ]]; then
        sqlite3 "$db_path" ".backup $backup_path/trading_system.db"
    fi
    
    # Backup requirements
    cp "$INSTALL_DIR/requirements.txt" "$backup_path/" 2>/dev/null || true
    
    # Create backup manifest
    cat > "$backup_path/manifest.json" << EOF
{
    "backup_id": "$UPDATE_ID",
    "timestamp": "$(date -Iseconds)",
    "git_commit": "$(cd "$INSTALL_DIR" && git rev-parse HEAD 2>/dev/null || echo 'unknown')",
    "python_packages": "$(sudo -u $SERVICE_USER bash -c "source $INSTALL_DIR/venv/bin/activate && pip freeze")"
}
EOF
    
    ROLLBACK_POINT="$backup_path"
    log "Backup created: $backup_path"
}

# Check for updates
check_for_updates() {
    log "Checking for updates..."
    
    cd "$INSTALL_DIR"
    
    # Initialize git if not already done
    if [[ ! -d ".git" ]]; then
        warn "Git repository not initialized. Initializing..."
        sudo -u "$SERVICE_USER" git init
        sudo -u "$SERVICE_USER" git remote add origin "$GIT_REPO_URL"
    fi
    
    # Fetch latest changes
    sudo -u "$SERVICE_USER" git fetch origin main 2>/dev/null || {
        warn "Could not fetch from remote repository"
        return 1
    }
    
    # Check if updates are available
    local local_commit=$(git rev-parse HEAD 2>/dev/null || echo "")
    local remote_commit=$(git rev-parse origin/main 2>/dev/null || echo "")
    
    if [[ "$local_commit" == "$remote_commit" ]]; then
        log "No updates available"
        return 1
    else
        log "Updates available: $local_commit -> $remote_commit"
        return 0
    fi
}

# Update source code
update_source_code() {
    log "Updating source code..."
    
    cd "$INSTALL_DIR"
    
    # Stash any local changes
    if ! sudo -u "$SERVICE_USER" git diff --quiet; then
        warn "Local changes detected, stashing..."
        sudo -u "$SERVICE_USER" git stash push -m "Auto-stash before update $UPDATE_ID"
    fi
    
    # Pull latest changes
    sudo -u "$SERVICE_USER" git pull origin main
    
    # Set proper ownership
    chown -R "$SERVICE_USER:$SERVICE_USER" "$INSTALL_DIR/src"
    
    log "Source code updated successfully"
}

# Update Python dependencies
update_dependencies() {
    log "Updating Python dependencies..."
    
    cd "$INSTALL_DIR"
    
    # Check if requirements.txt changed
    if git diff HEAD~1 HEAD --name-only | grep -q "requirements.txt"; then
        log "Requirements.txt changed, updating dependencies..."
        
        # Update pip first
        sudo -u "$SERVICE_USER" bash -c "source venv/bin/activate && pip install --upgrade pip"
        
        # Install/update requirements
        sudo -u "$SERVICE_USER" bash -c "source venv/bin/activate && pip install -r requirements.txt --upgrade"
        
        log "Dependencies updated successfully"
    else
        log "No dependency changes detected"
    fi
}

# Run database migrations
run_database_migrations() {
    log "Checking for database migrations..."
    
    cd "$INSTALL_DIR"
    
    # Check if database schema files changed
    if git diff HEAD~1 HEAD --name-only | grep -E "(database|migration|schema)" >/dev/null; then
        log "Database-related changes detected, running migrations..."
        
        # Run migration script if it exists
        if [[ -f "scripts/migrate_database.py" ]]; then
            sudo -u "$SERVICE_USER" bash -c "source venv/bin/activate && python scripts/migrate_database.py"
        else
            # Basic database integrity check
            local db_path="$INSTALL_DIR/data/database/trading_system.db"
            if [[ -f "$db_path" ]]; then
                sqlite3 "$db_path" "PRAGMA integrity_check;" >/dev/null
                log "Database integrity check passed"
            fi
        fi
    else
        log "No database migrations needed"
    fi
}

# Update system dependencies
update_system_dependencies() {
    log "Checking system dependencies..."
    
    # Update package lists
    apt-get update -qq
    
    # Check for security updates
    local security_updates=$(apt list --upgradable 2>/dev/null | grep -c security || echo "0")
    if [[ $security_updates -gt 0 ]]; then
        log "Installing $security_updates security updates..."
        apt-get upgrade -y -qq
    fi
    
    # Update Ollama if needed
    if command -v ollama >/dev/null; then
        local current_version=$(ollama --version 2>/dev/null | head -1 || echo "unknown")
        log "Current Ollama version: $current_version"
        
        # Check for Ollama updates (this would need to be implemented based on Ollama's update mechanism)
        # For now, just log the current version
    fi
}

# Validate update
validate_update() {
    log "Validating update..."
    
    # Check Python environment
    if ! sudo -u "$SERVICE_USER" bash -c "source $INSTALL_DIR/venv/bin/activate && python -c 'import src.utils.config'"; then
        error "Python environment validation failed"
        return 1
    fi
    
    # Check database
    local db_path="$INSTALL_DIR/data/database/trading_system.db"
    if [[ -f "$db_path" ]]; then
        if ! sqlite3 "$db_path" "SELECT 1;" >/dev/null 2>&1; then
            error "Database validation failed"
            return 1
        fi
    fi
    
    # Check configuration
    if [[ -f "$INSTALL_DIR/.env" ]]; then
        if ! grep -q "OLLAMA_HOST" "$INSTALL_DIR/.env"; then
            error "Configuration validation failed"
            return 1
        fi
    fi
    
    log "Update validation passed"
    return 0
}

# Test updated system
test_updated_system() {
    log "Testing updated system..."
    
    # Start service temporarily for testing
    systemctl start ai-crypto-trader
    
    # Wait for startup
    sleep 10
    
    # Test service health
    if systemctl is-active --quiet ai-crypto-trader; then
        log "Service started successfully"
        
        # Test dashboard
        if curl -s http://localhost:5050/health >/dev/null 2>&1; then
            log "Dashboard responding"
        else
            warn "Dashboard not responding"
        fi
        
        # Stop service again
        systemctl stop ai-crypto-trader
        
        return 0
    else
        error "Service failed to start after update"
        return 1
    fi
}

# Rollback to previous version
rollback() {
    error "Rolling back to previous version..."
    
    if [[ -z "$ROLLBACK_POINT" ]]; then
        error "No rollback point available"
        return 1
    fi
    
    # Stop service
    systemctl stop ai-crypto-trader 2>/dev/null || true
    
    # Restore source code
    log "Restoring source code..."
    rm -rf "$INSTALL_DIR/src"
    cp -r "$ROLLBACK_POINT/src" "$INSTALL_DIR/"
    
    # Restore configuration
    log "Restoring configuration..."
    cp -r "$ROLLBACK_POINT/config" "$INSTALL_DIR/" 2>/dev/null || true
    cp "$ROLLBACK_POINT/.env" "$INSTALL_DIR/" 2>/dev/null || true
    
    # Restore database
    log "Restoring database..."
    if [[ -f "$ROLLBACK_POINT/trading_system.db" ]]; then
        cp "$ROLLBACK_POINT/trading_system.db" "$INSTALL_DIR/data/database/"
    fi
    
    # Restore requirements and reinstall
    if [[ -f "$ROLLBACK_POINT/requirements.txt" ]]; then
        cp "$ROLLBACK_POINT/requirements.txt" "$INSTALL_DIR/"
        sudo -u "$SERVICE_USER" bash -c "source $INSTALL_DIR/venv/bin/activate && pip install -r $INSTALL_DIR/requirements.txt"
    fi
    
    # Set proper ownership
    chown -R "$SERVICE_USER:$SERVICE_USER" "$INSTALL_DIR"
    
    log "Rollback completed"
}

# Cleanup old backups
cleanup_old_backups() {
    log "Cleaning up old backups..."
    
    # Keep last 10 backups
    local backup_count=$(ls -1 "$BACKUP_DIR" | wc -l)
    if [[ $backup_count -gt 10 ]]; then
        local to_remove=$((backup_count - 10))
        ls -1t "$BACKUP_DIR" | tail -$to_remove | while read backup; do
            rm -rf "$BACKUP_DIR/$backup"
            log "Removed old backup: $backup"
        done
    fi
}

# Main update function
perform_update() {
    log "=== Starting System Update ==="
    
    create_lock
    check_service_status
    
    # Check for updates first
    if ! check_for_updates; then
        log "No updates available, exiting"
        return 0
    fi
    
    # Create backup
    create_backup
    
    # Stop service
    stop_service
    
    # Perform updates
    update_source_code
    update_dependencies
    run_database_migrations
    update_system_dependencies
    
    # Validate update
    if validate_update; then
        log "Update validation successful"
        
        # Test the updated system
        if test_updated_system; then
            log "Update completed successfully"
            cleanup_old_backups
        else
            error "Update testing failed, rolling back..."
            rollback
            return 1
        fi
    else
        error "Update validation failed, rolling back..."
        rollback
        return 1
    fi
    
    log "=== Update Complete ==="
}

# Force update (skip checks)
force_update() {
    log "=== Starting Forced Update ==="
    
    create_lock
    check_service_status
    create_backup
    stop_service
    
    cd "$INSTALL_DIR"
    
    # Force pull latest changes
    sudo -u "$SERVICE_USER" git reset --hard origin/main
    
    update_dependencies
    run_database_migrations
    
    if validate_update; then
        log "Forced update completed"
    else
        error "Forced update validation failed"
        rollback
        return 1
    fi
    
    log "=== Forced Update Complete ==="
}

# Show update status
show_status() {
    echo "AI Crypto Trading System - Update Status"
    echo "========================================"
    
    cd "$INSTALL_DIR" 2>/dev/null || {
        echo "Error: Installation directory not found"
        exit 1
    }
    
    # Current version info
    if [[ -d ".git" ]]; then
        local current_commit=$(git rev-parse HEAD 2>/dev/null || echo "unknown")
        local current_branch=$(git branch --show-current 2>/dev/null || echo "unknown")
        echo "Current commit: $current_commit"
        echo "Current branch: $current_branch"
        
        # Check for available updates
        if git fetch origin main 2>/dev/null; then
            local remote_commit=$(git rev-parse origin/main 2>/dev/null || echo "unknown")
            if [[ "$current_commit" != "$remote_commit" ]]; then
                echo "Updates available: Yes"
                echo "Remote commit: $remote_commit"
            else
                echo "Updates available: No"
            fi
        else
            echo "Updates available: Unable to check"
        fi
    else
        echo "Git repository: Not initialized"
    fi
    
    # Service status
    if systemctl is-active --quiet ai-crypto-trader; then
        echo "Service status: Running"
    else
        echo "Service status: Stopped"
    fi
    
    # Last update
    if [[ -f "$LOG_FILE" ]]; then
        local last_update=$(grep "Update Complete" "$LOG_FILE" | tail -1 | cut -d']' -f1 | tr -d '[')
        if [[ -n "$last_update" ]]; then
            echo "Last update: $last_update"
        else
            echo "Last update: Never"
        fi
    fi
    
    # Available backups
    local backup_count=$(ls -1 "$BACKUP_DIR" 2>/dev/null | wc -l)
    echo "Available backups: $backup_count"
}

# Print usage
print_usage() {
    echo "Usage: $0 {update|force|status|rollback}"
    echo ""
    echo "Commands:"
    echo "  update   - Check for and apply updates"
    echo "  force    - Force update without checks"
    echo "  status   - Show current version and update status"
    echo "  rollback - Rollback to last backup"
    echo ""
    echo "Examples:"
    echo "  $0 update          # Normal update process"
    echo "  $0 force           # Force update"
    echo "  $0 status          # Check status"
    echo "  $0 rollback        # Rollback last update"
}

# Main script logic
main() {
    check_user
    
    case "${1:-update}" in
        update)
            perform_update
            ;;
        force)
            force_update
            ;;
        status)
            show_status
            ;;
        rollback)
            if [[ -z "$2" ]]; then
                # Use latest backup
                local latest_backup=$(ls -1t "$BACKUP_DIR" | head -1)
                if [[ -n "$latest_backup" ]]; then
                    ROLLBACK_POINT="$BACKUP_DIR/$latest_backup"
                    rollback
                else
                    error "No backups available for rollback"
                    exit 1
                fi
            else
                # Use specified backup
                ROLLBACK_POINT="$BACKUP_DIR/$2"
                if [[ -d "$ROLLBACK_POINT" ]]; then
                    rollback
                else
                    error "Backup not found: $2"
                    exit 1
                fi
            fi
            ;;
        *)
            print_usage
            exit 1
            ;;
    esac
}

# Run main function
main "$@"