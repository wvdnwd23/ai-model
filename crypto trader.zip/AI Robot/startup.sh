#!/bin/bash

# AI Crypto Trading System - Startup Script
# Performs health checks and starts modules sequentially with monitoring

set -e

# Configuration
INSTALL_DIR="/opt/ai-crypto-trader"
SERVICE_USER="ai-trader"
LOG_FILE="$INSTALL_DIR/data/logs/system/startup.log"
PID_FILE="$INSTALL_DIR/data/ai-trader.pid"
HEALTH_CHECK_TIMEOUT=30
MODULE_START_DELAY=5

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Ensure log directory exists
mkdir -p "$(dirname "$LOG_FILE")"

# Logging functions
log() {
    echo -e "${GREEN}[$(date '+%Y-%m-%d %H:%M:%S')] $1${NC}" | tee -a "$LOG_FILE"
}

warn() {
    echo -e "${YELLOW}[$(date '+%Y-%m-%d %H:%M:%S')] WARNING: $1${NC}" | tee -a "$LOG_FILE"
}

error() {
    echo -e "${RED}[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: $1${NC}" | tee -a "$LOG_FILE"
    exit 1
}

info() {
    echo -e "${BLUE}[$(date '+%Y-%m-%d %H:%M:%S')] $1${NC}" | tee -a "$LOG_FILE"
}

# Check if running as correct user
check_user() {
    if [[ "$USER" != "$SERVICE_USER" ]]; then
        error "This script must be run as user '$SERVICE_USER'. Use: sudo -u $SERVICE_USER $0"
    fi
}

# Check if already running
check_running() {
    if [[ -f "$PID_FILE" ]]; then
        local pid=$(cat "$PID_FILE")
        if kill -0 "$pid" 2>/dev/null; then
            error "AI Crypto Trader is already running (PID: $pid)"
        else
            warn "Stale PID file found, removing..."
            rm -f "$PID_FILE"
        fi
    fi
}

# System health checks
check_system_health() {
    log "Performing system health checks..."
    
    # Check available memory
    local available_mem=$(free -m | awk 'NR==2{printf "%.0f", $7}')
    if [[ $available_mem -lt 1000 ]]; then
        warn "Low available memory: ${available_mem}MB"
    else
        log "Memory check passed: ${available_mem}MB available"
    fi
    
    # Check disk space
    local available_space=$(df "$INSTALL_DIR" | awk 'NR==2 {print $4}')
    local available_gb=$((available_space / 1024 / 1024))
    if [[ $available_gb -lt 2 ]]; then
        error "Insufficient disk space: ${available_gb}GB available"
    else
        log "Disk space check passed: ${available_gb}GB available"
    fi
    
    # Check CPU temperature (Pi specific)
    if [[ -f /sys/class/thermal/thermal_zone0/temp ]]; then
        local temp=$(($(cat /sys/class/thermal/thermal_zone0/temp) / 1000))
        if [[ $temp -gt 80 ]]; then
            warn "High CPU temperature: ${temp}°C"
        else
            log "CPU temperature normal: ${temp}°C"
        fi
    fi
    
    # Check network connectivity
    if ! ping -c 1 -W 5 8.8.8.8 &>/dev/null; then
        warn "No internet connectivity detected"
    else
        log "Network connectivity verified"
    fi
}

# Check Ollama service
check_ollama() {
    log "Checking Ollama service..."
    
    # Check if Ollama service is running
    if ! systemctl is-active --quiet ollama; then
        warn "Ollama service not running, attempting to start..."
        sudo systemctl start ollama
        sleep 10
    fi
    
    # Wait for Ollama API to be ready
    local timeout=$HEALTH_CHECK_TIMEOUT
    while [[ $timeout -gt 0 ]]; do
        if curl -s http://localhost:11434/api/tags >/dev/null 2>&1; then
            log "Ollama API is responding"
            break
        fi
        sleep 2
        ((timeout -= 2))
    done
    
    if [[ $timeout -le 0 ]]; then
        error "Ollama API not responding after $HEALTH_CHECK_TIMEOUT seconds"
    fi
    
    # Check if required model is available
    if curl -s http://localhost:11434/api/tags | grep -q "llama3.1:8b-instruct-q4_0"; then
        log "Required AI model is available"
    else
        error "Required AI model not found. Run: ollama pull llama3.1:8b-instruct-q4_0"
    fi
}

# Check database connectivity
check_database() {
    log "Checking database connectivity..."
    
    local db_path="$INSTALL_DIR/data/database/trading_system.db"
    
    if [[ ! -f "$db_path" ]]; then
        error "Database file not found: $db_path"
    fi
    
    # Test database connection
    if ! sqlite3 "$db_path" "SELECT 1;" >/dev/null 2>&1; then
        error "Cannot connect to database"
    fi
    
    # Check database tables
    local table_count=$(sqlite3 "$db_path" "SELECT COUNT(*) FROM sqlite_master WHERE type='table';")
    if [[ $table_count -lt 5 ]]; then
        error "Database appears to be incomplete (only $table_count tables found)"
    fi
    
    log "Database connectivity verified ($table_count tables found)"
}

# Check Python environment
check_python_environment() {
    log "Checking Python environment..."
    
    local venv_path="$INSTALL_DIR/venv"
    
    if [[ ! -d "$venv_path" ]]; then
        error "Virtual environment not found: $venv_path"
    fi
    
    # Activate virtual environment and check imports
    source "$venv_path/bin/activate"
    
    # Check critical imports
    local imports=(
        "import sqlite3"
        "import requests"
        "import pandas"
        "import numpy"
        "import flask"
        "import playwright"
        "import ollama"
    )
    
    for import_stmt in "${imports[@]}"; do
        if ! python -c "$import_stmt" 2>/dev/null; then
            error "Failed to import: $import_stmt"
        fi
    done
    
    # Check custom modules
    export PYTHONPATH="$INSTALL_DIR/src:$PYTHONPATH"
    if ! python -c "from utils.config import ConfigManager" 2>/dev/null; then
        error "Failed to import custom modules"
    fi
    
    log "Python environment verified"
}

# Check browser automation
check_browser() {
    log "Checking browser automation..."
    
    source "$INSTALL_DIR/venv/bin/activate"
    export PYTHONPATH="$INSTALL_DIR/src:$PYTHONPATH"
    
    # Test Playwright browser
    if ! python -c "
from playwright.sync_api import sync_playwright
try:
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        browser.close()
    print('Browser test passed')
except Exception as e:
    print(f'Browser test failed: {e}')
    exit(1)
" 2>/dev/null; then
        error "Browser automation test failed"
    fi
    
    log "Browser automation verified"
}

# Check configuration files
check_configuration() {
    log "Checking configuration..."
    
    local env_file="$INSTALL_DIR/.env"
    if [[ ! -f "$env_file" ]]; then
        error "Environment file not found: $env_file"
    fi
    
    # Check for required environment variables
    source "$env_file"
    
    local required_vars=(
        "OLLAMA_HOST"
        "OLLAMA_PORT"
        "DATABASE_PATH"
        "MAX_POSITION_SIZE"
    )
    
    for var in "${required_vars[@]}"; do
        if [[ -z "${!var}" ]]; then
            error "Required environment variable not set: $var"
        fi
    done
    
    log "Configuration verified"
}

# Start AI modules sequentially
start_modules() {
    log "Starting AI modules..."
    
    source "$INSTALL_DIR/venv/bin/activate"
    export PYTHONPATH="$INSTALL_DIR/src:$PYTHONPATH"
    
    # Change to installation directory
    cd "$INSTALL_DIR"
    
    # Start main application
    log "Starting main application..."
    python -m src.main &
    local main_pid=$!
    
    # Store PID
    echo $main_pid > "$PID_FILE"
    
    # Wait a moment for startup
    sleep $MODULE_START_DELAY
    
    # Check if process is still running
    if ! kill -0 $main_pid 2>/dev/null; then
        error "Main application failed to start"
    fi
    
    log "Main application started successfully (PID: $main_pid)"
    
    # Monitor startup for a few seconds
    local startup_timeout=30
    local startup_success=false
    
    while [[ $startup_timeout -gt 0 ]]; do
        if kill -0 $main_pid 2>/dev/null; then
            # Check if Flask dashboard is responding
            if curl -s http://localhost:5050/health >/dev/null 2>&1; then
                startup_success=true
                break
            fi
        else
            error "Application process died during startup"
        fi
        sleep 2
        ((startup_timeout -= 2))
    done
    
    if [[ "$startup_success" == "true" ]]; then
        log "All modules started successfully"
        log "Dashboard available at: http://localhost:5050"
    else
        warn "Startup completed but dashboard not responding yet"
    fi
}

# Monitor system resources
monitor_resources() {
    log "Monitoring system resources..."
    
    # CPU usage
    local cpu_usage=$(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | cut -d'%' -f1)
    
    # Memory usage
    local mem_usage=$(free | grep Mem | awk '{printf("%.1f"), $3/$2 * 100.0}')
    
    # Disk usage
    local disk_usage=$(df "$INSTALL_DIR" | awk 'NR==2 {print $5}' | cut -d'%' -f1)
    
    log "System resources - CPU: ${cpu_usage}%, Memory: ${mem_usage}%, Disk: ${disk_usage}%"
    
    # Log to database if possible
    source "$INSTALL_DIR/venv/bin/activate"
    export PYTHONPATH="$INSTALL_DIR/src:$PYTHONPATH"
    
    python -c "
import sys
sys.path.append('$INSTALL_DIR/src')
from utils.database import db_manager
from datetime import datetime

try:
    db_manager.update_system_health({
        'module_name': 'system',
        'status': 'healthy',
        'cpu_usage': $cpu_usage,
        'memory_usage': $mem_usage,
        'response_time': 0,
        'error_count': 0,
        'last_activity': datetime.now()
    })
except Exception as e:
    print(f'Failed to log system health: {e}')
" 2>/dev/null || warn "Failed to log system health to database"
}

# Setup signal handlers for graceful shutdown
setup_signal_handlers() {
    trap 'handle_shutdown' SIGTERM SIGINT
}

handle_shutdown() {
    log "Received shutdown signal, stopping services..."
    
    if [[ -f "$PID_FILE" ]]; then
        local pid=$(cat "$PID_FILE")
        if kill -0 "$pid" 2>/dev/null; then
            log "Stopping main application (PID: $pid)..."
            kill -TERM "$pid"
            
            # Wait for graceful shutdown
            local timeout=30
            while [[ $timeout -gt 0 ]] && kill -0 "$pid" 2>/dev/null; do
                sleep 1
                ((timeout--))
            done
            
            # Force kill if still running
            if kill -0 "$pid" 2>/dev/null; then
                warn "Force killing application..."
                kill -KILL "$pid"
            fi
        fi
        
        rm -f "$PID_FILE"
    fi
    
    log "Shutdown completed"
    exit 0
}

# Create startup status file
create_status_file() {
    local status_file="$INSTALL_DIR/data/startup_status.json"
    
    cat > "$status_file" << EOF
{
    "startup_time": "$(date -Iseconds)",
    "status": "running",
    "pid": $(cat "$PID_FILE" 2>/dev/null || echo "null"),
    "health_checks": {
        "system": "passed",
        "ollama": "passed",
        "database": "passed",
        "python": "passed",
        "browser": "passed",
        "configuration": "passed"
    },
    "dashboard_url": "http://localhost:5050"
}
EOF
    
    log "Status file created: $status_file"
}

# Main startup function
main() {
    log "=== AI Crypto Trading System Startup ==="
    
    setup_signal_handlers
    check_user
    check_running
    
    # Perform all health checks
    check_system_health
    check_ollama
    check_database
    check_python_environment
    check_browser
    check_configuration
    
    # Start the system
    start_modules
    monitor_resources
    create_status_file
    
    log "=== Startup completed successfully ==="
    log "System is running. Use 'systemctl status ai-crypto-trader' to monitor."
    log "Dashboard: http://localhost:5050"
    log "Logs: tail -f $LOG_FILE"
    
    # Keep script running to maintain PID
    while true; do
        if [[ -f "$PID_FILE" ]]; then
            local pid=$(cat "$PID_FILE")
            if ! kill -0 "$pid" 2>/dev/null; then
                error "Main process died unexpectedly"
            fi
        else
            error "PID file disappeared"
        fi
        sleep 60
    done
}

# Handle command line arguments
case "${1:-start}" in
    start)
        main
        ;;
    stop)
        handle_shutdown
        ;;
    status)
        if [[ -f "$PID_FILE" ]]; then
            local pid=$(cat "$PID_FILE")
            if kill -0 "$pid" 2>/dev/null; then
                echo "AI Crypto Trader is running (PID: $pid)"
                exit 0
            else
                echo "AI Crypto Trader is not running (stale PID file)"
                exit 1
            fi
        else
            echo "AI Crypto Trader is not running"
            exit 1
        fi
        ;;
    restart)
        handle_shutdown
        sleep 5
        main
        ;;
    *)
        echo "Usage: $0 {start|stop|status|restart}"
        exit 1
        ;;
esac