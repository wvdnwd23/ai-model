# AI Crypto Trading System - Complete Architecture Design

## 1. Complete Folder Structure

```
ai_crypto_trader/
├── README.md
├── requirements.txt
├── setup.py
├── config/
│   ├── __init__.py
│   ├── settings.py
│   ├── database_config.py
│   ├── ollama_config.py
│   └── telegram_config.py
├── core/
│   ├── __init__.py
│   ├── base_module.py
│   ├── json_communicator.py
│   ├── database_manager.py
│   ├── ollama_client.py
│   └── error_handler.py
├── modules/
│   ├── __init__.py
│   ├── ai_controller/
│   │   ├── __init__.py
│   │   ├── controller.py
│   │   ├── orchestrator.py
│   │   └── health_monitor.py
│   ├── coin_scanner/
│   │   ├── __init__.py
│   │   ├── scanner.py
│   │   ├── sentiment_analyzer.py
│   │   ├── volume_detector.py
│   │   └── pattern_matcher.py
│   ├── chart_checker/
│   │   ├── __init__.py
│   │   ├── checker.py
│   │   ├── technical_indicators.py
│   │   ├── trend_analyzer.py
│   │   └── wyckoff_analyzer.py
│   ├── combiner/
│   │   ├── __init__.py
│   │   ├── combiner.py
│   │   ├── decision_engine.py
│   │   ├── risk_calculator.py
│   │   └── learning_engine.py
│   └── verifier_executor/
│       ├── __init__.py
│       ├── verifier.py
│       ├── executor.py
│       ├── macro_checker.py
│       └── order_manager.py
├── browser_automation/
│   ├── __init__.py
│   ├── browser_manager.py
│   ├── scraper_base.py
│   ├── scrapers/
│   │   ├── __init__.py
│   │   ├── tradingview_scraper.py
│   │   ├── news_scraper.py
│   │   ├── social_scraper.py
│   │   ├── mexc_scraper.py
│   │   └── xt_scraper.py
│   ├── executors/
│   │   ├── __init__.py
│   │   ├── mexc_executor.py
│   │   └── xt_executor.py
│   └── session_manager.py
├── dashboard/
│   ├── __init__.py
│   ├── app.py
│   ├── routes/
│   │   ├── __init__.py
│   │   ├── main.py
│   │   ├── api.py
│   │   └── websocket.py
│   ├── templates/
│   │   ├── base.html
│   │   ├── dashboard.html
│   │   ├── trades.html
│   │   ├── logs.html
│   │   └── settings.html
│   └── static/
│       ├── css/
│       ├── js/
│       └── images/
├── telegram_bot/
│   ├── __init__.py
│   ├── bot.py
│   ├── handlers.py
│   ├── notifications.py
│   └── commands.py
├── data/
│   ├── database/
│   │   └── trading_system.db
│   ├── cache/
│   │   ├── market_data/
│   │   ├── news_data/
│   │   └── session_data/
│   ├── logs/
│   │   ├── system/
│   │   ├── trades/
│   │   ├── errors/
│   │   └── ai_learning/
│   └── backups/
│       ├── database/
│       └── configs/
├── utils/
│   ├── __init__.py
│   ├── logger.py
│   ├── crypto_utils.py
│   ├── time_utils.py
│   ├── file_utils.py
│   └── validation.py
├── tests/
│   ├── __init__.py
│   ├── unit/
│   ├── integration/
│   └── fixtures/
├── scripts/
│   ├── install.sh
│   ├── startup.sh
│   ├── health_check.sh
│   ├── backup.sh
│   └── update.sh
└── docs/
    ├── API.md
    ├── DEPLOYMENT.md
    ├── TROUBLESHOOTING.md
    └── ARCHITECTURE.md
```

## 2. JSON Communication Protocols

### 2.1 Standard Message Format
```json
{
  "timestamp": "2024-01-01T12:00:00Z",
  "module_id": "coin_scanner",
  "message_id": "uuid-string",
  "message_type": "request|response|notification",
  "priority": "low|medium|high|critical",
  "data": {},
  "metadata": {
    "version": "1.0",
    "correlation_id": "uuid-string",
    "retry_count": 0
  }
}
```

### 2.2 Module Communication Schemas

#### Coin Scanner Output
```json
{
  "coins": [
    {
      "symbol": "DOGE",
      "exchange": "MEXC",
      "volume_anomaly": 1.7,
      "sentiment_score": 0.85,
      "breakout_probability": 0.78,
      "social_mentions": 1250,
      "price_change_24h": 0.15,
      "market_cap_rank": 8,
      "confidence": 0.82
    }
  ],
  "scan_duration": 45.2,
  "total_coins_analyzed": 100
}
```

#### Chart Checker Output
```json
{
  "symbol": "DOGE",
  "timeframes": {
    "15m": {
      "trend": "bullish",
      "rsi": 65.4,
      "macd": {"signal": "buy", "histogram": 0.0012},
      "bollinger": {"position": "upper", "squeeze": false},
      "support": 0.0825,
      "resistance": 0.0890,
      "confidence": 0.78
    },
    "1h": {
      "trend": "bullish",
      "rsi": 58.2,
      "macd": {"signal": "buy", "histogram": 0.0008},
      "bollinger": {"position": "middle", "squeeze": false},
      "support": 0.0810,
      "resistance": 0.0920,
      "confidence": 0.85
    },
    "4h": {
      "trend": "neutral",
      "rsi": 52.1,
      "macd": {"signal": "neutral", "histogram": -0.0002},
      "bollinger": {"position": "middle", "squeeze": true},
      "support": 0.0780,
      "resistance": 0.0950,
      "confidence": 0.65
    }
  },
  "wyckoff_phase": "accumulation",
  "fvg_gaps": [{"price": 0.0835, "strength": "medium"}],
  "overall_bias": "bullish",
  "overall_confidence": 0.76
}
```

#### Combiner Output
```json
{
  "symbol": "DOGE",
  "decision": "buy",
  "multiplier": 10,
  "position_size": 0.05,
  "entry_price": 0.0845,
  "stop_loss": 0.0820,
  "take_profit": [0.0890, 0.0920, 0.0950],
  "risk_reward_ratio": 3.2,
  "confidence": 0.91,
  "reasoning": "Strong volume anomaly + bullish technical confluence",
  "max_risk_percentage": 2.0,
  "expected_duration": "2-6 hours"
}
```

#### Verifier Output
```json
{
  "symbol": "DOGE",
  "approved": true,
  "final_position_size": 0.04,
  "adjusted_multiplier": 8,
  "macro_risk_score": 0.3,
  "liquidity_score": 0.85,
  "correlation_risk": 0.2,
  "execution_plan": {
    "entry_method": "market",
    "split_orders": false,
    "max_slippage": 0.5
  },
  "risk_adjustments": [
    "Reduced position size due to upcoming FOMC",
    "Lowered leverage due to weekend liquidity"
  ]
}
```

## 3. Technical Architecture

### 3.1 Core Dependencies
```
# Core Framework
Python 3.11+
SQLite 3.40+
Ollama 0.1.26+

# AI/ML
ollama-python==0.1.7
numpy==1.24.3
pandas==2.0.3
scikit-learn==1.3.0

# Browser Automation
playwright==1.40.0
beautifulsoup4==4.12.2
selenium==4.15.0

# Web Framework
flask==2.3.3
flask-socketio==5.3.6
gunicorn==21.2.0

# Database
sqlite3 (built-in)
sqlalchemy==2.0.23

# Communication
requests==2.31.0
websockets==11.0.3
python-telegram-bot==20.7

# Utilities
schedule==1.2.0
python-dotenv==1.0.0
pydantic==2.5.0
loguru==0.7.2
```

### 3.2 System Architecture Components

#### Ollama Integration
- **Model**: llama3.1:8b-instruct-q4_0 (optimized for Pi 5)
- **API Endpoint**: http://localhost:11434
- **Context Window**: 4096 tokens
- **Temperature**: 0.3 for trading decisions, 0.7 for analysis
- **Concurrent Requests**: Max 2 (Pi 5 limitation)

#### SQLite Database Schema
```sql
-- Core Tables
CREATE TABLE trades (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT NOT NULL,
    exchange TEXT NOT NULL,
    side TEXT NOT NULL, -- 'buy' or 'sell'
    entry_price REAL,
    exit_price REAL,
    quantity REAL,
    leverage INTEGER,
    pnl REAL,
    status TEXT, -- 'open', 'closed', 'cancelled'
    entry_time TIMESTAMP,
    exit_time TIMESTAMP,
    strategy_version TEXT,
    metadata JSON
);

CREATE TABLE ai_decisions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    module_name TEXT NOT NULL,
    input_data JSON,
    output_data JSON,
    confidence_score REAL,
    execution_time REAL,
    success BOOLEAN,
    error_message TEXT
);

CREATE TABLE learning_data (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    trade_id INTEGER,
    prediction JSON,
    actual_outcome JSON,
    accuracy_score REAL,
    learning_notes TEXT,
    strategy_adjustments JSON,
    FOREIGN KEY (trade_id) REFERENCES trades (id)
);

CREATE TABLE system_health (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    module_name TEXT,
    status TEXT, -- 'healthy', 'warning', 'error', 'offline'
    cpu_usage REAL,
    memory_usage REAL,
    response_time REAL,
    error_count INTEGER,
    last_activity TIMESTAMP
);

CREATE TABLE market_data_cache (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    symbol TEXT NOT NULL,
    timeframe TEXT NOT NULL,
    data JSON,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expiry TIMESTAMP,
    source TEXT
);
```

## 4. Module Specifications

### 4.1 AI Controller (LLaMA Mini Coordinator)
**Purpose**: Central orchestrator managing all AI modules and system health

**Core Functions**:
- Module lifecycle management
- Inter-module communication routing
- Health monitoring and auto-recovery
- Learning coordination and strategy optimization
- Emergency shutdown and fallback procedures

**Input**: System status, module outputs, external triggers
**Output**: Module commands, system adjustments, alerts

### 4.2 AI Coin Scanner
**Purpose**: Identify breakout opportunities through sentiment and volume analysis

**Core Functions**:
- Volume anomaly detection (>1.5x average)
- Social sentiment scraping (Twitter, Reddit, Telegram)
- Price pattern recognition
- Market cap and ranking analysis
- News impact assessment

**Input**: Market data, social feeds, news sources
**Output**: Ranked list of potential breakout coins with confidence scores

### 4.3 AI Chart Checker
**Purpose**: Technical analysis and trend validation

**Core Functions**:
- Multi-timeframe analysis (15m, 1h, 4h)
- Technical indicator calculation (RSI, MACD, Bollinger Bands)
- Support/resistance identification
- Wyckoff method analysis
- Fair Value Gap (FVG) detection

**Input**: OHLCV data, volume profiles
**Output**: Technical bias with confidence levels per timeframe

### 4.4 AI Combiner
**Purpose**: Decision synthesis and trade parameter optimization

**Core Functions**:
- Multi-signal fusion
- Risk/reward calculation
- Position sizing optimization
- Historical performance analysis
- Strategy adaptation based on recent results

**Input**: Scanner output, chart analysis, historical performance
**Output**: Trading decision with specific parameters

### 4.5 AI Verifier & Executor
**Purpose**: Final validation and trade execution

**Core Functions**:
- Macro risk assessment (news, events)
- Liquidity verification
- Correlation analysis
- Order execution via browser automation
- Position monitoring and management

**Input**: Trading decision, market conditions, macro data
**Output**: Execution confirmation or rejection with reasoning

## 5. Browser Automation Architecture

### 5.1 Headless Browser Management
```python
# Browser Configuration
BROWSER_CONFIG = {
    "headless": True,
    "viewport": {"width": 1920, "height": 1080},
    "user_agent": "Mozilla/5.0 (X11; Linux aarch64) AppleWebKit/537.36",
    "timeout": 30000,
    "retry_attempts": 3,
    "session_persistence": True
}
```

### 5.2 Error Handling Strategy
- **Connection Failures**: Automatic retry with exponential backoff
- **Element Not Found**: Multiple selector strategies with fallbacks
- **Captcha Detection**: Notification system with manual intervention option
- **Rate Limiting**: Intelligent delay patterns and session rotation
- **Session Expiry**: Automatic re-authentication with stored credentials

### 5.3 Scraping Targets
- **TradingView**: Chart data, indicators, market sentiment
- **MEXC/XT.com**: Order book, trade execution, position management
- **News Sources**: Cointelegraph, CoinDesk, crypto Twitter
- **Social Media**: Reddit crypto communities, Telegram channels

## 6. Logging and Monitoring System

### 6.1 Log Categories
```python
LOG_LEVELS = {
    "TRADE": "Trade execution and results",
    "DECISION": "AI decision-making process",
    "ERROR": "System errors and exceptions",
    "HEALTH": "System health and performance",
    "LEARNING": "AI learning and adaptation",
    "SECURITY": "Security events and alerts"
}
```

### 6.2 Monitoring Metrics
- **System Performance**: CPU, memory, disk usage
- **Module Health**: Response times, error rates, availability
- **Trading Performance**: Win rate, PnL, drawdown, Sharpe ratio
- **AI Performance**: Prediction accuracy, confidence calibration
- **Network Health**: API response times, connection stability

## 7. Self-Improvement Mechanisms

### 7.1 Learning Feedback Loop
1. **Prediction Tracking**: Store all AI predictions with timestamps
2. **Outcome Measurement**: Compare predictions with actual results
3. **Performance Analysis**: Calculate accuracy metrics per module
4. **Strategy Adjustment**: Modify parameters based on performance
5. **A/B Testing**: Run multiple strategies simultaneously
6. **Rollback Capability**: Revert to previous versions if performance degrades

### 7.2 Adaptive Parameters
- **Confidence Thresholds**: Adjust based on recent accuracy
- **Position Sizing**: Scale based on recent performance
- **Risk Tolerance**: Modify based on market volatility
- **Timeframe Weights**: Adjust importance of different timeframes
- **Signal Combinations**: Optimize signal fusion algorithms

## 8. Installation and Deployment Strategy

### 8.1 Auto-Installation Process
```bash
#!/bin/bash
# install.sh - Complete system setup

# 1. System Dependencies
sudo apt update && sudo apt upgrade -y
sudo apt install python3.11 python3-pip nodejs npm git -y

# 2. Ollama Installation
curl -fsSL https://ollama.ai/install.sh | sh
ollama pull llama3.1:8b-instruct-q4_0

# 3. Python Environment
python3 -m venv ai_trader_env
source ai_trader_env/bin/activate
pip install -r requirements.txt

# 4. Browser Setup
playwright install chromium
playwright install-deps

# 5. Database Initialization
python scripts/init_database.py

# 6. Configuration Setup
python scripts/setup_config.py

# 7. Service Installation
sudo cp scripts/ai_trader.service /etc/systemd/system/
sudo systemctl enable ai_trader
sudo systemctl start ai_trader
```

### 8.2 Health Monitoring and Auto-Recovery
```python
# Health Check System
HEALTH_CHECKS = {
    "ollama_service": "curl -f http://localhost:11434/api/tags",
    "database_connection": "sqlite3 data/database/trading_system.db '.tables'",
    "browser_automation": "python -c 'from playwright.sync_api import sync_playwright'",
    "telegram_bot": "python -c 'import telegram; bot = telegram.Bot(token=TOKEN)'",
    "flask_dashboard": "curl -f http://localhost:5050/health"
}
```

## 9. System Architecture Diagram

```mermaid
graph TB
    subgraph "AI Controller Layer"
        AC[AI Controller<br/>LLaMA Mini]
        HM[Health Monitor]
        OR[Orchestrator]
    end
    
    subgraph "AI Processing Modules"
        CS[Coin Scanner]
        CC[Chart Checker]
        CB[Combiner]
        VE[Verifier & Executor]
    end
    
    subgraph "Data Layer"
        DB[(SQLite Database)]
        CACHE[Cache System]
        LOGS[Log Files]
    end
    
    subgraph "External Interfaces"
        BA[Browser Automation]
        DASH[Flask Dashboard]
        TG[Telegram Bot]
    end
    
    subgraph "External Sources"
        TV[TradingView]
        MEXC[MEXC Exchange]
        XT[XT.com Exchange]
        NEWS[News Sources]
        SOCIAL[Social Media]
    end
    
    AC --> CS
    AC --> CC
    AC --> CB
    AC --> VE
    
    CS --> CC
    CC --> CB
    CB --> VE
    
    CS -.-> DB
    CC -.-> DB
    CB -.-> DB
    VE -.-> DB
    
    BA --> TV
    BA --> MEXC
    BA --> XT
    BA --> NEWS
    BA --> SOCIAL
    
    VE --> BA
    CS --> BA
    
    AC --> DASH
    AC --> TG
    
    HM --> AC
    OR --> AC
    
    DB --> CACHE
    DB --> LOGS
```

## 10. Data Flow Architecture

```mermaid
sequenceDiagram
    participant AC as AI Controller
    participant CS as Coin Scanner
    participant CC as Chart Checker
    participant CB as Combiner
    participant VE as Verifier/Executor
    participant BA as Browser Automation
    participant DB as Database
    
    AC->>CS: Trigger scan
    CS->>BA: Scrape market data
    BA-->>CS: Market data + sentiment
    CS->>DB: Store scan results
    CS-->>AC: Potential coins
    
    AC->>CC: Analyze coin X
    CC->>BA: Get chart data
    BA-->>CC: OHLCV + indicators
    CC->>DB: Store analysis
    CC-->>AC: Technical bias
    
    AC->>CB: Combine signals
    CB->>DB: Get historical performance
    DB-->>CB: Past trade data
    CB->>DB: Store decision
    CB-->>AC: Trading decision
    
    AC->>VE: Verify and execute
    VE->>BA: Check macro conditions
    VE->>BA: Execute trade
    BA-->>VE: Execution confirmation
    VE->>DB: Store trade record
    VE-->>AC: Trade status
    
    AC->>DB: Update learning data
```

This comprehensive architecture provides a robust foundation for implementing the self-learning AI crypto trading system on Raspberry Pi 5, with complete local operation, comprehensive error handling, and continuous self-improvement capabilities.