#!/bin/bash

# Ollama Installation Script for Raspberry Pi ARM64
# AI Crypto Trading System - Local AI Setup with Gemma Models ONLY
# Optimized for Raspberry Pi 5 with 8GB RAM - Gemma 2B/9B Focus
# Complete migration from external APIs to local Gemma AI brain

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Configuration
OLLAMA_VERSION="latest"
OLLAMA_DATA_DIR="/opt/ai-crypto-trader/data/ollama"
OLLAMA_MODELS_DIR="${OLLAMA_DATA_DIR}/models"
OLLAMA_CONFIG_DIR="/etc/ollama"
OLLAMA_USER="ollama"
OLLAMA_SERVICE_FILE="/etc/systemd/system/ollama.service"
PI_MEMORY_GB=8
MAX_CONCURRENT_MODELS=1  # Conservative for Pi 5

# Gemma Model Configuration (optimized for Pi 5 crypto trading)
GEMMA_MODELS=(
    "gemma2:2b"                    # Primary model - fast and efficient for real-time trading
    "gemma2:9b-instruct-q4_0"     # Secondary model - higher quality for complex analysis
)

PRIMARY_MODEL="gemma2:2b"
SECONDARY_MODEL="gemma2:9b-instruct-q4_0"
DEFAULT_AI_BRAIN="$PRIMARY_MODEL"

# Trading-specific configuration
TRADING_CONFIG_DIR="/opt/ai-crypto-trader/config"
GEMMA_BRAIN_CONFIG="${TRADING_CONFIG_DIR}/gemma_brain.json"

# Logging
LOG_FILE="/opt/ai-crypto-trader/data/logs/system/ollama_install.log"
GEMMA_LOG_FILE="/opt/ai-crypto-trader/data/logs/system/gemma_brain.log"
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$(dirname "$GEMMA_LOG_FILE")"

log() {
    echo -e "${GREEN}[$(date '+%Y-%m-%d %H:%M:%S')]${NC} $1" | tee -a "$LOG_FILE"
}

warn() {
    echo -e "${YELLOW}[$(date '+%Y-%m-%d %H:%M:%S')] WARNING:${NC} $1" | tee -a "$LOG_FILE"
}

error() {
    echo -e "${RED}[$(date '+%Y-%m-%d %H:%M:%S')] ERROR:${NC} $1" | tee -a "$LOG_FILE"
    exit 1
}

info() {
    echo -e "${BLUE}[$(date '+%Y-%m-%d %H:%M:%S')] INFO:${NC} $1" | tee -a "$LOG_FILE"
}

success() {
    echo -e "${PURPLE}[$(date '+%Y-%m-%d %H:%M:%S')] SUCCESS:${NC} $1" | tee -a "$LOG_FILE"
}

# Banner
show_banner() {
    echo -e "${CYAN}"
    echo "╔══════════════════════════════════════════════════════════════╗"
    echo "║                 GEMMA AI BRAIN INSTALLER                     ║"
    echo "║              Raspberry Pi 5 Crypto Trading System           ║"
    echo "║                                                              ║"
    echo "║  🧠 Primary AI: Gemma 2B (Real-time Trading)               ║"
    echo "║  🎯 Secondary AI: Gemma 9B (Deep Analysis)                 ║"
    echo "║  🚀 Optimized for Pi 5 ARM64 Architecture                  ║"
    echo "║  💰 Local AI Brain for Crypto Trading Operations           ║"
    echo "╚══════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

# Check if running as root
check_root() {
    if [[ $EUID -ne 0 ]]; then
        error "This script must be run as root (use sudo)"
    fi
}

# Check system requirements for Gemma models
check_system_requirements() {
    log "Checking system requirements for Gemma AI brain..."
    
    # Check architecture
    ARCH=$(uname -m)
    if [[ "$ARCH" != "aarch64" ]]; then
        error "This script is designed for ARM64 (aarch64) architecture. Detected: $ARCH"
    fi
    
    # Check Raspberry Pi model
    PI_MODEL=$(cat /proc/device-tree/model 2>/dev/null || echo "Unknown")
    if [[ "$PI_MODEL" == *"Raspberry Pi 5"* ]]; then
        success "Raspberry Pi 5 detected - optimal for Gemma models"
    else
        warn "Non-Pi5 hardware detected: $PI_MODEL"
    fi
    
    # Check memory (Gemma 2B needs ~3GB, Gemma 9B needs ~6GB)
    TOTAL_MEM_KB=$(grep MemTotal /proc/meminfo | awk '{print $2}')
    TOTAL_MEM_GB=$((TOTAL_MEM_KB / 1024 / 1024))
    
    if [[ $TOTAL_MEM_GB -lt 6 ]]; then
        warn "Less than 6GB RAM detected (${TOTAL_MEM_GB}GB). Only Gemma 2B will be installed."
        GEMMA_MODELS=("gemma2:2b")
        SECONDARY_MODEL=""
    elif [[ $TOTAL_MEM_GB -ge 8 ]]; then
        success "8GB+ RAM detected - both Gemma models will be available"
    fi
    
    log "System requirements met: ARM64 architecture, ${TOTAL_MEM_GB}GB RAM"
    
    # Check available disk space (Gemma models need ~12GB)
    AVAILABLE_SPACE_GB=$(df /opt | tail -1 | awk '{print int($4/1024/1024)}')
    if [[ $AVAILABLE_SPACE_GB -lt 15 ]]; then
        error "Minimum 15GB free space required in /opt for Gemma models. Available: ${AVAILABLE_SPACE_GB}GB"
    fi
    
    success "Disk space check passed: ${AVAILABLE_SPACE_GB}GB available"
    
    # Check CPU features for optimization
    if grep -q "asimd" /proc/cpuinfo; then
        success "ARM NEON SIMD support detected - Gemma performance will be optimized"
    fi
}

# Install system dependencies
install_dependencies() {
    log "Installing system dependencies for Gemma AI brain..."
    
    apt-get update
    apt-get install -y \
        curl \
        wget \
        git \
        build-essential \
        python3-dev \
        python3-pip \
        htop \
        iotop \
        stress-ng \
        cpufrequtils \
        thermald \
        fancontrol \
        lm-sensors \
        jq \
        bc \
        psmisc \
        procps \
        coreutils
    
    # Install Python packages for Gemma integration
    pip3 install --upgrade \
        requests \
        psutil \
        numpy \
        json5
    
    success "System dependencies installed successfully"
}

# Create ollama user and directories
setup_ollama_user() {
    log "Setting up Ollama user and directories for Gemma brain..."
    
    # Create ollama user if it doesn't exist
    if ! id "$OLLAMA_USER" &>/dev/null; then
        useradd -r -s /bin/false -d "$OLLAMA_DATA_DIR" "$OLLAMA_USER"
        log "Created ollama user"
    else
        log "Ollama user already exists"
    fi
    
    # Create directories
    mkdir -p "$OLLAMA_DATA_DIR"
    mkdir -p "$OLLAMA_MODELS_DIR"
    mkdir -p "$OLLAMA_CONFIG_DIR"
    mkdir -p "/var/log/ollama"
    mkdir -p "$TRADING_CONFIG_DIR"
    mkdir -p "/opt/ai-crypto-trader/scripts/gemma"
    
    # Set permissions
    chown -R "$OLLAMA_USER:$OLLAMA_USER" "$OLLAMA_DATA_DIR"
    chown -R "$OLLAMA_USER:$OLLAMA_USER" "/var/log/ollama"
    chmod 755 "$OLLAMA_DATA_DIR"
    chmod 755 "$OLLAMA_MODELS_DIR"
    
    success "Ollama user and directories configured"
}

# Download and install Ollama
install_ollama() {
    log "Installing Ollama for ARM64 Gemma brain..."
    
    # Download Ollama installer
    curl -fsSL https://ollama.ai/install.sh | sh
    
    # Verify installation
    if ! command -v ollama &> /dev/null; then
        error "Ollama installation failed"
    fi
    
    OLLAMA_VERSION_INSTALLED=$(ollama --version | head -n1 | awk '{print $3}' || echo "unknown")
    success "Ollama installed successfully - Version: $OLLAMA_VERSION_INSTALLED"
}

# Configure Ollama service for Pi 5 Gemma optimization
configure_ollama_service() {
    log "Configuring Ollama service for Raspberry Pi 5 Gemma brain..."
    
    # Create optimized service file
    cat > "$OLLAMA_SERVICE_FILE" << EOF
[Unit]
Description=Ollama Gemma AI Brain Service for Crypto Trading System
After=network-online.target
Wants=network-online.target
Documentation=https://github.com/ollama/ollama

[Service]
Type=exec
User=$OLLAMA_USER
Group=$OLLAMA_USER
ExecStart=/usr/local/bin/ollama serve
Environment="OLLAMA_HOST=127.0.0.1:11434"
Environment="OLLAMA_MODELS=$OLLAMA_MODELS_DIR"
Environment="OLLAMA_KEEP_ALIVE=10m"
Environment="OLLAMA_MAX_LOADED_MODELS=1"
Environment="OLLAMA_NUM_PARALLEL=2"
Environment="OLLAMA_MAX_QUEUE=8"
Environment="OLLAMA_FLASH_ATTENTION=1"
Environment="OLLAMA_LLM_LIBRARY=cpu"
Environment="OLLAMA_RUNNERS_DIR=/tmp/ollama_runners"
Environment="OLLAMA_DEBUG=0"
Environment="OLLAMA_NOPRUNE=0"
Environment="OLLAMA_ORIGINS=http://localhost:*,http://127.0.0.1:*"
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal
SyslogIdentifier=ollama-gemma
KillMode=mixed
KillSignal=SIGINT
TimeoutStopSec=45
TimeoutStartSec=120

# Resource limits optimized for Pi 5 Gemma models
MemoryMax=6G
MemoryHigh=5G
CPUQuota=350%
IOWeight=100
Nice=5
LimitNOFILE=65536

# Security settings
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=$OLLAMA_DATA_DIR /tmp /var/log/ollama
CapabilityBoundingSet=CAP_NET_BIND_SERVICE
SystemCallFilter=@system-service
SystemCallErrorNumber=EPERM

[Install]
WantedBy=multi-user.target
EOF

    # Set permissions
    chmod 644 "$OLLAMA_SERVICE_FILE"
    
    # Reload systemd and enable service
    systemctl daemon-reload
    systemctl enable ollama
    
    success "Ollama Gemma service configured and enabled"
}

# Start Ollama service
start_ollama_service() {
    log "Starting Ollama Gemma brain service..."
    
    systemctl start ollama
    
    # Wait for service to be ready
    local max_attempts=60
    local attempt=1
    
    while [[ $attempt -le $max_attempts ]]; do
        if curl -s http://127.0.0.1:11434/api/tags >/dev/null 2>&1; then
            success "Ollama Gemma brain service is running and ready"
            return 0
        fi
        
        info "Waiting for Ollama service... (attempt $attempt/$max_attempts)"
        sleep 3
        ((attempt++))
    done
    
    error "Ollama service failed to start within expected time"
}

# Download and configure Gemma models
install_gemma_models() {
    log "Installing Gemma AI brain models optimized for crypto trading..."
    
    for model in "${GEMMA_MODELS[@]}"; do
        log "Downloading $model (this may take 10-20 minutes)..."
        
        # Show progress and download model
        if ! ollama pull "$model"; then
            error "Failed to download $model"
        fi
        
        success "Successfully downloaded $model"
        
        # Test model with crypto-specific prompt
        log "Testing $model with crypto trading prompt..."
        local test_response
        test_response=$(timeout 45s ollama run "$model" "Analyze: BTC price trend. Respond with: GEMMA_READY" 2>/dev/null || echo "TIMEOUT")
        
        if [[ "$test_response" == *"GEMMA_READY"* ]]; then
            success "$model is working correctly for crypto analysis"
        else
            warn "$model test completed but response unclear - model is downloaded"
        fi
        
        # Log model info
        echo "$(date): $model installed and tested" >> "$GEMMA_LOG_FILE"
    done
    
    # Set primary model as default AI brain
    log "Configuring $PRIMARY_MODEL as primary AI brain..."
    ollama run "$PRIMARY_MODEL" "Gemma AI brain initialized for crypto trading" >/dev/null 2>&1 || true
    
    success "Gemma AI brain models installed and configured"
}

# Create Gemma brain configuration
create_gemma_brain_config() {
    log "Creating Gemma brain configuration for crypto trading..."
    
    cat > "$GEMMA_BRAIN_CONFIG" << EOF
{
  "gemma_brain": {
    "primary_model": "$PRIMARY_MODEL",
    "secondary_model": "$SECONDARY_MODEL",
    "ollama_endpoint": "http://127.0.0.1:11434",
    "auto_switch": true,
    "performance_monitoring": true,
    "crypto_trading_optimized": true,
    "models": {
      "gemma2:2b": {
        "role": "primary",
        "use_cases": ["real_time_analysis", "quick_decisions", "market_scanning"],
        "max_tokens": 2048,
        "temperature": 0.3,
        "memory_usage_mb": 3072,
        "response_time_target_ms": 2000
      },
      "gemma2:9b-instruct-q4_0": {
        "role": "secondary", 
        "use_cases": ["deep_analysis", "complex_strategies", "risk_assessment"],
        "max_tokens": 4096,
        "temperature": 0.2,
        "memory_usage_mb": 6144,
        "response_time_target_ms": 5000
      }
    },
    "switching_thresholds": {
      "memory_usage_percent": 80,
      "cpu_load_average": 2.5,
      "response_time_ms": 3000
    },
    "health_check": {
      "interval_seconds": 300,
      "timeout_seconds": 30,
      "retry_attempts": 3
    }
  }
}
EOF

    chmod 644 "$GEMMA_BRAIN_CONFIG"
    success "Gemma brain configuration created"
}

# Create Gemma model management scripts
create_model_management_scripts() {
    log "Creating Gemma AI brain management scripts..."
    
    # Model switcher script
    cat > "/usr/local/bin/gemma-switch" << 'EOF'
#!/bin/bash

# Gemma AI Brain Switcher for Crypto Trading System
# Intelligent model switching based on system load and task complexity

MODELS=("gemma2:2b" "gemma2:9b-instruct-q4_0")
CURRENT_MODEL_FILE="/opt/ai-crypto-trader/data/ollama/current_model"
CONFIG_FILE="/opt/ai-crypto-trader/config/gemma_brain.json"
LOG_FILE="/opt/ai-crypto-trader/data/logs/system/gemma_brain.log"

log_action() {
    echo "$(date '+%Y-%m-%d %H:%M:%S'): $1" >> "$LOG_FILE"
}

show_usage() {
    echo "Gemma AI Brain Switcher v1.0"
    echo "Usage: $0 [model_name|list|status|auto|health]"
    echo ""
    echo "Available Gemma models:"
    for model in "${MODELS[@]}"; do
        echo "  🧠 $model"
    done
    echo ""
    echo "Commands:"
    echo "  list    - List available Gemma models"
    echo "  status  - Show current AI brain status"
    echo "  auto    - Auto-select best model based on system load"
    echo "  health  - Check Gemma brain health"
}

get_system_metrics() {
    local mem_usage=$(free | grep Mem | awk '{printf "%.0f", $3/$2 * 100}')
    local cpu_load=$(uptime | awk -F'load average:' '{print $2}' | awk '{print $1}' | sed 's/,//')
    local cpu_temp=$(vcgencmd measure_temp 2>/dev/null | cut -d= -f2 | cut -d\' -f1 || echo "0")
    echo "$mem_usage $cpu_load $cpu_temp"
}

auto_select_model() {
    read -r mem_usage cpu_load cpu_temp <<< "$(get_system_metrics)"
    
    log_action "Auto-selection: Memory: ${mem_usage}%, CPU Load: ${cpu_load}, Temp: ${cpu_temp}°C"
    
    # Use lighter model under high load or temperature
    if [[ $mem_usage -gt 75 ]] || [[ $(echo "$cpu_load > 2.5" | bc -l 2>/dev/null || echo 0) -eq 1 ]] || [[ $(echo "$cpu_temp > 70" | bc -l 2>/dev/null || echo 0) -eq 1 ]]; then
        echo "gemma2:2b"
    else
        # Check if secondary model is available
        if [[ " ${MODELS[@]} " =~ " gemma2:9b-instruct-q4_0 " ]]; then
            echo "gemma2:9b-instruct-q4_0"
        else
            echo "gemma2:2b"
        fi
    fi
}

switch_model() {
    local target_model="$1"
    
    # Validate model
    local valid=false
    for model in "${MODELS[@]}"; do
        if [[ "$model" == "$target_model" ]]; then
            valid=true
            break
        fi
    done
    
    if [[ "$valid" != "true" ]]; then
        echo "❌ Error: Invalid Gemma model '$target_model'"
        show_usage
        exit 1
    fi
    
    echo "🔄 Switching Gemma AI brain to $target_model..."
    log_action "Switching to $target_model"
    
    # Preload model
    if timeout 60s ollama run "$target_model" "Gemma brain ready for crypto trading" >/dev/null 2>&1; then
        echo "$target_model" > "$CURRENT_MODEL_FILE"
        log_action "Successfully switched to $target_model"
        echo "✅ Successfully switched Gemma AI brain to $target_model"
    else
        log_action "Failed to switch to $target_model"
        echo "❌ Error: Failed to switch to $target_model"
        exit 1
    fi
}

check_health() {
    echo "🏥 Gemma AI Brain Health Check"
    echo "=============================="
    
    # Check Ollama service
    if systemctl is-active --quiet ollama; then
        echo "✅ Ollama service: Running"
    else
        echo "❌ Ollama service: Not running"
        return 1
    fi
    
    # Check API endpoint
    if curl -s http://127.0.0.1:11434/api/tags >/dev/null 2>&1; then
        echo "✅ Ollama API: Responsive"
    else
        echo "❌ Ollama API: Not responsive"
        return 1
    fi
    
    # Check models
    local healthy_models=0
    for model in "${MODELS[@]}"; do
        if ollama list | grep -q "$model"; then
            echo "✅ Model $model: Available"
            ((healthy_models++))
        else
            echo "❌ Model $model: Not available"
        fi
    done
    
    # System metrics
    read -r mem_usage cpu_load cpu_temp <<< "$(get_system_metrics)"
    echo "📊 System: ${mem_usage}% memory, ${cpu_load} CPU load, ${cpu_temp}°C"
    
    if [[ $healthy_models -gt 0 ]]; then
        echo "🎉 Gemma AI brain is healthy ($healthy_models models available)"
        return 0
    else
        echo "💀 Gemma AI brain is unhealthy (no models available)"
        return 1
    fi
}

case "$1" in
    "list")
        echo "🧠 Available Gemma AI Brain Models:"
        ollama list | grep gemma || echo "No Gemma models found"
        ;;
    "status")
        if [[ -f "$CURRENT_MODEL_FILE" ]]; then
            current=$(cat "$CURRENT_MODEL_FILE")
            echo "🧠 Current Gemma AI brain: $current"
        else
            echo "❓ No current Gemma model set"
        fi
        read -r mem_usage cpu_load cpu_temp <<< "$(get_system_metrics)"
        echo "📊 System load: ${mem_usage}% memory, ${cpu_load} CPU, ${cpu_temp}°C"
        ;;
    "auto")
        auto_model=$(auto_select_model)
        echo "🤖 Auto-selected Gemma model: $auto_model"
        switch_model "$auto_model"
        ;;
    "health")
        check_health
        ;;
    "")
        show_usage
        ;;
    *)
        switch_model "$1"
        ;;
esac
EOF

    chmod +x "/usr/local/bin/gemma-switch"
    
    # Model health check script
    cat > "/usr/local/bin/gemma-health" << 'EOF'
#!/bin/bash

# Gemma AI Brain Health Monitor
# Comprehensive health checking for crypto trading AI brain

MODELS=("gemma2:2b" "gemma2:9b-instruct-q4_0")
HEALTH_LOG="/var/log/ollama/health.log"
ALERT_THRESHOLD_RESPONSE_TIME=10  # seconds
ALERT_THRESHOLD_MEMORY=85         # percent

check_model_health() {
    local model="$1"
    local start_time=$(date +%s)
    
    echo "🔍 Testing $model..."
    
    # Test with crypto-specific prompt
    local response
    response=$(timeout 45s ollama run "$model" "Crypto market status check. Respond: HEALTHY" 2>/dev/null || echo "TIMEOUT")
    
    local end_time=$(date +%s)
    local duration=$((end_time - start_time))
    
    if [[ "$response" == *"HEALTHY"* ]]; then
        echo "✅ $model: HEALTHY (${duration}s response time)"
        echo "$(date): $model HEALTHY ${duration}s" >> "$HEALTH_LOG"
        return 0
    else
        echo "❌ $model: UNHEALTHY (${duration}s, response: ${response:0:50}...)"
        echo "$(date): $model UNHEALTHY ${duration}s" >> "$HEALTH_LOG"
        return 1
    fi
}

check_system_resources() {
    echo "📊 System Resource Check"
    echo "======================="
    
    # Memory check
    local mem_usage=$(free | grep Mem | awk '{printf "%.0f", $3/$2 * 100}')
    if [[ $mem_usage -gt $ALERT_THRESHOLD_MEMORY ]]; then
        echo "⚠️  Memory usage: ${mem_usage}% (HIGH)"
    else
        echo "✅ Memory usage: ${mem_usage}%"
    fi
    
    # CPU temperature (Pi specific)
    local cpu_temp=$(vcgencmd measure_temp 2>/dev/null | cut -d= -f2 | cut -d\' -f1 || echo "0")
    if [[ $(echo "$cpu_temp > 75" | bc -l 2>/dev/null || echo 0) -eq 1 ]]; then
        echo "🔥 CPU temperature: ${cpu_temp}°C (HIGH)"
    else
        echo "✅ CPU temperature: ${cpu_temp}°C"
    fi
    
    # Disk space
    local disk_usage=$(df /opt | tail -1 | awk '{print $5}' | sed 's/%//')
    if [[ $disk_usage -gt 90 ]]; then
        echo "💾 Disk usage: ${disk_usage}% (HIGH)"
    else
        echo "✅ Disk usage: ${disk_usage}%"
    fi
}

echo "🏥 Gemma AI Brain Comprehensive Health Check"
echo "==========================================="
echo "$(date)"
echo ""

# Check Ollama service
if systemctl is-active --quiet ollama; then
    echo "✅ Ollama service: Running"
else
    echo "❌ Ollama service: Not running"
    echo "🔧 Attempting to restart..."
    systemctl restart ollama
    sleep 5
fi

echo ""

# Check system resources
check_system_resources
echo ""

# Check models
echo "🧠 Gemma Model Health Check"
echo "=========================="

healthy_count=0
total_count=0

for model in "${MODELS[@]}"; do
    if ollama list | grep -q "$model"; then
        ((total_count++))
        if check_model_health "$model"; then
            ((healthy_count++))
        fi
        echo ""
    else
        echo "❌ $model: Not installed"
        echo ""
    fi
done

# Summary
echo "📋 Health Summary"
echo "================"
echo "Healthy models: $healthy_count/$total_count"

if [[ $healthy_count -eq $total_count ]] && [[ $total_count -gt 0 ]]; then
    echo "🎉 Gemma AI brain is fully operational!"
    exit 0
elif [[ $healthy_count -gt 0 ]]; then
    echo "⚠️  Gemma AI brain is partially operational"
    exit 1
else
    echo "💀 Gemma AI brain is not operational"
    exit 2
fi
EOF

    chmod +x "/usr/local/bin/gemma-health"
    
    # Performance monitor script
    cat > "/usr/local/bin/gemma-monitor" << 'EOF'
#!/bin/bash

# Gemma AI Brain Performance Monitor
# Real-time monitoring for crypto trading AI performance

MONITOR_LOG="/opt/ai-crypto-trader/data/logs/system/gemma_performance.log"
INTERVAL=30  # seconds

monitor_performance() {
    while true; do
        local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
        local mem_usage=$(free | grep Mem | awk '{printf "%.1f", $3/$2 * 100}')
        local cpu_load=$(uptime | awk -F'load average:' '{print $2}' | awk '{print $1}' | sed 's/,//')
        local cpu_temp=$(vcgencmd measure_temp 2>/dev/null | cut -d= -f2 | cut -d\' -f1 || echo "0")
        
        # Check if Ollama is using resources
        local ollama_mem=$(ps aux | grep '[o]llama' | awk '{sum+=$6} END {printf "%.1f", sum/1024}' || echo "0")
        local ollama_cpu=$(ps aux | grep '[o]llama' | awk '{sum+=$3} END {printf "%.1f", sum}' || echo "0")
        
        echo "$timestamp,MEM:${mem_usage}%,CPU:${cpu_load},TEMP:${cpu_temp}C,OLLAMA_MEM:${ollama_mem}MB,OLLAMA_CPU:${ollama_cpu}%" >> "$MONITOR_LOG"
        
        # Console output
        echo "[$timestamp] 🧠 Gemma Brain - MEM: ${mem_usage}% | CPU: ${cpu_load} | TEMP: ${cpu_temp}°C | Ollama: ${ollama_mem}MB/${ollama_cpu}%"
        
        sleep $INTERVAL
    done
}

echo "🔍 Starting Gemma AI Brain Performance Monitor"
echo "Logging to: $MONITOR_LOG"
echo "Press Ctrl+C to stop"
echo ""

monitor_performance
EOF

    chmod +x "/usr/local/bin/gemma-monitor"
    
    success "Gemma AI brain management scripts created"
}

# Configure automatic startup and optimization
configure_startup_optimization() {
    log "Configuring automatic startup and optimization for Gemma brain..."
    
    # Create startup script
    cat > "/opt/ai-crypto-trader/scripts/gemma/startup.sh" << 'EOF'
#!/bin/bash

# Gemma AI Brain Startup Script
# Optimizes system for crypto trading AI performance

LOG_FILE="/opt/ai-crypto-trader/data/logs/system/gemma_startup.log"

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S'): $1" | tee -a "$LOG_FILE"
}

log "Starting Gemma AI brain optimization..."

# CPU governor optimization for sustained performance
echo performance | tee /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor >/dev/null 2>&1 || true
log "CPU governor set to performance mode"

# Memory optimization
echo 1 > /proc/sys/vm/drop_caches 2>/dev/null || true
log "Memory caches cleared"

# Network optimization for API responses
echo 'net.core.rmem_max = 16777216' >> /etc/sysctl.conf 2>/dev/null || true
echo 'net.core.wmem_max = 16777216' >> /etc/sysctl.conf 2>/dev/null || true
sysctl -p >/dev/null 2>&1 || true
log "Network buffers optimized"

# Wait for Ollama service
local max_wait=60
local wait_count=0
while ! curl -s http://127.0.0.1:11434/api/tags >/dev/null 2>&1; do
    if [[ $wait_count -ge $max_wait ]]; then
        log "ERROR: Ollama service not ready after ${max_wait}s"
        exit 1
    fi
    sleep 1
    ((wait_count++))
done

log "Ollama service is ready"

# Auto-select optimal Gemma model
/usr/local/bin/gemma-switch auto
log "Gemma AI brain auto-configured"

# Preload primary model for faster first response
ollama run "gemma2:2b" "Gemma AI brain ready for crypto trading operations" >/dev/null 2>&1 || true
log "Primary Gemma model preloaded"

log "Gemma AI brain startup optimization complete"
EOF

    chmod +x "/opt/ai-crypto-trader/scripts/gemma/startup.sh"
    
    # Create systemd service for startup optimization
    cat > "/etc/systemd/system/gemma-startup.service" << 'EOF'
[Unit]
Description=Gemma AI Brain Startup Optimization
After=ollama.service
Requires=ollama.service

[Service]
Type=oneshot
ExecStart=/opt/ai-crypto-trader/scripts/gemma/startup.sh
RemainAfterExit=yes
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable gemma-startup
    
    success "Gemma brain startup optimization configured"
}

# Create Pi 5 hardware optimization
configure_pi5_optimization() {
    log "Configuring Raspberry Pi 5 hardware optimizations for Gemma..."
    
    # GPU memory split optimization
    if command -v raspi-config >/dev/null 2>&1; then
        # Reduce GPU memory to maximize RAM for Gemma
        echo "gpu_mem=64" >> /boot/config.txt
        log "GPU memory reduced to 64MB for more RAM"
    fi
    
    # CPU frequency optimization
    cat > "/etc/systemd/system/gemma-cpu-optimization.service" << 'EOF'
[Unit]
Description=Gemma AI Brain CPU Optimization
After=multi-user.target

[Service]
Type=oneshot
ExecStart=/bin/bash -c 'echo performance > /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor'
ExecStart=/bin/bash -c 'echo 2400000 > /sys/devices/system/cpu/cpu*/cpufreq/scaling_min_freq'
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable gemma-cpu-optimization
    
    # Memory optimization for Gemma
    cat >> /etc/sysctl.conf << 'EOF'

# Gemma AI Brain Memory Optimizations
vm.swappiness=10
vm.dirty_ratio=15
vm.dirty_background_ratio=5
vm.vfs_cache_pressure=50
kernel.sched_autogroup_enabled=0
EOF

    success "Pi 5 hardware optimizations configured"
}

# Create comprehensive logging system
setup_comprehensive_logging() {
    log "Setting up comprehensive logging for Gemma AI brain..."
    
    # Create log rotation configuration
    cat > "/etc/logrotate.d/gemma-brain" << 'EOF'
/opt/ai-crypto-trader/data/logs/system/gemma_*.log {
    daily
    rotate 30
    compress
    delaycompress
    missingok
    notifempty
    create 644 root root
    postrotate
        systemctl reload ollama 2>/dev/null || true
    endscript
}

/var/log/ollama/*.log {
    daily
    rotate 14
    compress
    delaycompress
    missingok
    notifempty
    create 644 ollama ollama
    postrotate
        systemctl reload ollama 2>/dev/null || true
    endscript
}
EOF

    # Create log analysis script
    cat > "/usr/local/bin/gemma-logs" << 'EOF'
#!/bin/bash

# Gemma AI Brain Log Analyzer

GEMMA_LOG="/opt/ai-crypto-trader/data/logs/system/gemma_brain.log"
PERFORMANCE_LOG="/opt/ai-crypto-trader/data/logs/system/gemma_performance.log"
OLLAMA_LOG="/var/log/ollama/health.log"

show_usage() {
    echo "Gemma AI Brain Log Analyzer"
    echo "Usage: $0 [errors|performance|health|tail|summary]"
    echo ""
    echo "Commands:"
    echo "  errors      - Show recent errors"
    echo "  performance - Show performance metrics"
    echo "  health      - Show health check results"
    echo "  tail        - Follow live logs"
    echo "  summary     - Show daily summary"
}

show_errors() {
    echo "🚨 Recent Gemma Brain Errors (last 24 hours)"
    echo "==========================================="
    find /opt/ai-crypto-trader/data/logs -name "*.log" -mtime -1 -exec grep -l "ERROR\|FAILED\|UNHEALTHY" {} \; | while read -r logfile; do
        echo "📁 $logfile:"
        grep "ERROR\|FAILED\|UNHEALTHY" "$logfile" | tail -10
        echo ""
    done
}

show_performance() {
    echo "📊 Gemma Brain Performance Metrics (last 100 entries)"
    echo "=================================================="
    if [[ -f "$PERFORMANCE_LOG" ]]; then
        tail -100 "$PERFORMANCE_LOG" | while IFS=',' read -r timestamp metrics; do
            echo "$timestamp: $metrics"
        done
    else
        echo "No performance log found. Run 'gemma-monitor' to start collecting metrics."
    fi
}

show_health() {
    echo "🏥 Gemma Brain Health History (last 50 entries)"
    echo "==========================================="
    if [[ -f "$OLLAMA_LOG" ]]; then
        tail -50 "$OLLAMA_LOG"
    else
        echo "No health log found."
    fi
}

tail_logs() {
    echo "📡 Live Gemma Brain Logs (Press Ctrl+C to stop)"
    echo "============================================="
    tail -f "$GEMMA_LOG" "$PERFORMANCE_LOG" 2>/dev/null
}

show_summary() {
    echo "📋 Daily Gemma Brain Summary ($(date '+%Y-%m-%d'))"
    echo "============================================"
    
    local today=$(date '+%Y-%m-%d')
    local error_count=$(grep "$today" /opt/ai-crypto-trader/data/logs/system/*.log 2>/dev/null | grep -c "ERROR" || echo 0)
    local switch_count=$(grep "$today" "$GEMMA_LOG" 2>/dev/null | grep -c "switched to" || echo 0)
    local health_checks=$(grep "$today" "$OLLAMA_LOG" 2>/dev/null | grep -c "HEALTHY\|UNHEALTHY" || echo 0)
    
    echo "Errors today: $error_count"
    echo "Model switches: $switch_count"
    echo "Health checks: $health_checks"
    
    if [[ -f "$PERFORMANCE_LOG" ]]; then
        local avg_memory=$(grep "$today" "$PERFORMANCE_LOG" | grep -o 'MEM:[0-9.]*' | cut -d: -f2 | awk '{sum+=$1; count++} END {if(count>0) printf "%.1f", sum/count; else print "N/A"}')
        echo "Average memory usage: ${avg_memory}%"
    fi
}

case "$1" in
    "errors") show_errors ;;
    "performance") show_performance ;;
    "health") show_health ;;
    "tail") tail_logs ;;
    "summary") show_summary ;;
    *) show_usage ;;
esac
EOF

    chmod +x "/usr/local/bin/gemma-logs"
    
    success "Comprehensive logging system configured"
}

# Create trading integration configuration
create_trading_integration() {
    log "Creating Gemma brain trading system integration..."
    
    # Create integration script
    cat > "/opt/ai-crypto-trader/scripts/gemma/integrate_trading.py" << 'EOF'
#!/usr/bin/env python3

"""
Gemma AI Brain Trading Integration
Configures the crypto trading system to use local Gemma models
"""

import json
import os
import sys
import requests
import time

def check_gemma_availability():
    """Check if Gemma models are available and responsive"""
    try:
        response = requests.get('http://127.0.0.1:11434/api/tags', timeout=10)
        if response.status_code == 200:
            models = response.json().get('models', [])
            gemma_models = [m for m in models if 'gemma' in m.get('name', '').lower()]
            return len(gemma_models) > 0, gemma_models
        return False, []
    except Exception as e:
        print(f"Error checking Gemma availability: {e}")
        return False, []

def update_trading_config():
    """Update trading system configuration to use Gemma brain"""
    config_path = '/opt/ai-crypto-trader/config/config.json'
    
    # Default configuration with Gemma brain
    gemma_config = {
        "ai_provider": "ollama_gemma",
        "ollama": {
            "endpoint": "http://127.0.0.1:11434",
            "primary_model": "gemma2:2b",
            "secondary_model": "gemma2:9b-instruct-q4_0",
            "timeout": 30,
            "max_retries": 3,
            "auto_switch": True
        },
        "gemma_brain": {
            "enabled": True,
            "real_time_analysis": True,
            "deep_analysis": True,
            "risk_assessment": True,
            "market_sentiment": True
        }
    }
    
    # Load existing config or create new
    if os.path.exists(config_path):
        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
        except:
            config = {}
    else:
        config = {}
    
    # Update with Gemma configuration
    config.update(gemma_config)
    
    # Ensure config directory exists
    os.makedirs(os.path.dirname(config_path), exist_ok=True)
    
    # Write updated configuration
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=2)
    
    print(f"✅ Trading system configuration updated: {config_path}")

def test_gemma_integration():
    """Test Gemma integration with trading-specific prompts"""
    test_prompts = [
        "Analyze BTC price trend and provide trading signal",
        "Assess market risk for ETH position",
        "Generate quick market summary"
    ]
    
    available, models = check_gemma_availability()
    if not available:
        print("❌ Gemma models not available for testing")
        return False
    
    print("🧪 Testing Gemma brain with trading prompts...")
    
    for model_info in models:
        model_name = model_info.get('name', '')
        if 'gemma' not in model_name.lower():
            continue
            
        print(f"Testing {model_name}...")
        
        for prompt in test_prompts:
            try:
                payload = {
                    "model": model_name,
                    "prompt": prompt,
                    "stream": False
                }
                
                response = requests.post(
                    'http://127.0.0.1:11434/api/generate',
                    json=payload,
                    timeout=30
                )
                
                if response.status_code == 200:
                    print(f"  ✅ {prompt[:30]}... - OK")
                else:
                    print(f"  ❌ {prompt[:30]}... - Failed")
                    
            except Exception as e:
                print(f"  ❌ {prompt[:30]}... - Error: {e}")
        
        print("")
    
    return True

def main():
    print("🧠 Gemma AI Brain Trading Integration")
    print("===================================")
    
    # Check Gemma availability
    print("Checking Gemma brain availability...")
    available, models = check_gemma_availability()
    
    if not available:
        print("❌ Gemma models not available. Please run the installation first.")
        sys.exit(1)
    
    print(f"✅ Found {len(models)} Gemma models:")
    for model in models:
        print(f"  🧠 {model.get('name', 'Unknown')}")
    
    print("")
    
    # Update trading configuration
    print("Updating trading system configuration...")
    update_trading_config()
    
    print("")
    
    # Test integration
    print("Testing Gemma brain integration...")
    if test_gemma_integration():
        print("🎉 Gemma AI brain successfully integrated with trading system!")
    else:
        print("⚠️  Integration completed but testing had issues")

if __name__ == "__main__":
    main()
EOF

    chmod +x "/opt/ai-crypto-trader/scripts/gemma/integrate_trading.py"
    
    success "Gemma brain trading integration created"
}

# Main installation function
main() {
    show_banner
    
    log "Starting Gemma AI brain installation for Raspberry Pi 5..."
    
    # Pre-installation checks
    check_root
    check_system_requirements
    
    # Installation steps
    install_dependencies
    setup_ollama_user
    install_ollama
    configure_ollama_service
    start_ollama_service
    install_gemma_models
    create_gemma_brain_config
    create_model_management_scripts
    configure_startup_optimization
    configure_pi5_optimization
    setup_comprehensive_logging
    create_trading_integration
    
    # Final configuration
    log "Performing final Gemma brain configuration..."
    
    # Set primary model as current
    echo "$PRIMARY_MODEL" > "$OLLAMA_DATA_DIR/current_model"
    
    # Run initial health check
    /usr/local/bin/gemma-health
    
    # Run trading integration
    python3 /opt/ai-crypto-trader/scripts/gemma/integrate_trading.py
    
    success "Gemma AI brain installation completed successfully!"
    
    echo ""
    echo -e "${CYAN}╔══════════════════════════════════════════════════════════════╗"
    echo -e "║                    INSTALLATION COMPLETE                    ║"
    echo -e "║                                                              ║"
    echo -e "║  🧠 Gemma AI Brain Status: OPERATIONAL                     ║"
    echo -e "║  🚀 Primary Model: $PRIMARY_MODEL                    ║"
    if [[ -n "$SECONDARY_MODEL" ]]; then
    echo -e "║  🎯 Secondary Model: $SECONDARY_MODEL  ║"
    fi
    echo -e "║  📊 Management: gemma-switch, gemma-health, gemma-monitor  ║"
    echo -e "║  📋 Logs: gemma-logs [errors|performance|health|summary]   ║"
    echo -e "║                                                              ║"
    echo -e "║  Next Steps:                                                 ║"
    echo -e "║  1. Reboot system for full optimization                     ║"
    echo -e "║  2. Run 'gemma-health' to verify operation                  ║"
    echo -e "║  3. Start crypto trading system                             ║"
    echo -e "╚══════════════════════════════════════════════════════════════╝${NC}"
    echo ""
    
    log "Gemma AI brain is ready for crypto trading operations!"
}

# Run main installation
main "$@"
