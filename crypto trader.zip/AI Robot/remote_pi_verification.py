#!/usr/bin/env python3
"""
Remote Raspberry Pi Verification Script
Tests SSH connectivity and executes comprehensive verification on the Pi remotely.
"""

import subprocess
import sys
import json
import time
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Optional
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('remote_verification.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class RemotePiVerifier:
    """Remote verification system for Raspberry Pi deployment."""
    
    def __init__(self, pi_host: str = "192.168.1.91", pi_user: str = "pi", 
                 install_dir: str = "/opt/ai-crypto-trader"):
        self.pi_host = pi_host
        self.pi_user = pi_user
        self.install_dir = install_dir
        self.ssh_base = f"{pi_user}@{pi_host}"
        self.verification_results = []
        self.start_time = datetime.now()
        
    def log_test(self, test_name: str, status: str, details: str = "", duration: float = 0.0):
        """Log test result."""
        result = {
            "test": test_name,
            "status": status,
            "details": details,
            "duration": duration,
            "timestamp": datetime.now().isoformat()
        }
        self.verification_results.append(result)
        
        status_icon = {"PASS": "✅", "FAIL": "❌", "WARN": "⚠️", "SKIP": "⏭️"}.get(status, "❓")
        logger.info(f"{status_icon} {test_name}: {status}")
        if details:
            logger.info(f"   {details}")
        if duration > 0:
            logger.info(f"   Duration: {duration:.2f}s")

    def test_ssh_connectivity(self) -> bool:
        """Test basic SSH connectivity to the Pi."""
        logger.info("\n🔗 Testing SSH Connectivity...")
        
        try:
            start_time = time.time()
            
            # Test basic SSH connection
            cmd = ["ssh", "-o", "ConnectTimeout=10", "-o", "BatchMode=yes", 
                   self.ssh_base, "echo 'SSH connection successful'"]
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
            
            if result.returncode == 0:
                duration = time.time() - start_time
                self.log_test("SSH Connectivity", "PASS", 
                             f"Connected to {self.pi_host} successfully", duration)
                return True
            else:
                self.log_test("SSH Connectivity", "FAIL", 
                             f"SSH connection failed: {result.stderr}")
                return False
                
        except subprocess.TimeoutExpired:
            self.log_test("SSH Connectivity", "FAIL", "SSH connection timed out")
            return False
        except Exception as e:
            self.log_test("SSH Connectivity", "FAIL", f"SSH error: {e}")
            return False

    def test_pi_system_info(self) -> bool:
        """Gather basic system information from the Pi."""
        logger.info("\n📋 Gathering Pi System Information...")
        
        try:
            start_time = time.time()
            
            # Get system information
            commands = {
                "hostname": "hostname",
                "uptime": "uptime",
                "kernel": "uname -r",
                "architecture": "uname -m",
                "memory": "free -h | head -2",
                "disk_space": "df -h / | tail -1",
                "temperature": "cat /sys/class/thermal/thermal_zone0/temp 2>/dev/null || echo 'N/A'"
            }
            
            system_info = {}
            for info_type, cmd in commands.items():
                ssh_cmd = ["ssh", "-o", "ConnectTimeout=10", self.ssh_base, cmd]
                result = subprocess.run(ssh_cmd, capture_output=True, text=True, timeout=10)
                
                if result.returncode == 0:
                    system_info[info_type] = result.stdout.strip()
                else:
                    system_info[info_type] = f"Error: {result.stderr.strip()}"
            
            # Process temperature
            if system_info["temperature"] != "N/A":
                try:
                    temp_raw = int(system_info["temperature"])
                    temp_celsius = temp_raw / 1000
                    system_info["temperature"] = f"{temp_celsius}°C"
                except:
                    pass
            
            duration = time.time() - start_time
            details = f"Hostname: {system_info['hostname']}, Arch: {system_info['architecture']}, Temp: {system_info['temperature']}"
            self.log_test("System Information", "PASS", details, duration)
            
            # Log detailed system info
            logger.info("📊 Detailed System Information:")
            for key, value in system_info.items():
                logger.info(f"   {key.title()}: {value}")
            
            return True
            
        except Exception as e:
            self.log_test("System Information", "FAIL", f"Error: {e}")
            return False

    def test_installation_directory(self) -> bool:
        """Test if the installation directory exists and is accessible."""
        logger.info("\n📁 Testing Installation Directory...")
        
        try:
            start_time = time.time()
            
            # Check if installation directory exists
            cmd = ["ssh", self.ssh_base, f"test -d {self.install_dir} && echo 'EXISTS' || echo 'NOT_FOUND'"]
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                if "EXISTS" in result.stdout:
                    # Get directory info
                    info_cmd = ["ssh", self.ssh_base, f"ls -la {self.install_dir} | head -10"]
                    info_result = subprocess.run(info_cmd, capture_output=True, text=True, timeout=10)
                    
                    duration = time.time() - start_time
                    self.log_test("Installation Directory", "PASS", 
                                 f"Directory {self.install_dir} exists and is accessible", duration)
                    
                    # Log directory contents
                    if info_result.returncode == 0:
                        logger.info("📂 Directory contents (first 10 items):")
                        for line in info_result.stdout.strip().split('\n'):
                            logger.info(f"   {line}")
                    
                    return True
                else:
                    self.log_test("Installation Directory", "FAIL", 
                                 f"Directory {self.install_dir} not found")
                    return False
            else:
                self.log_test("Installation Directory", "FAIL", 
                             f"Error checking directory: {result.stderr}")
                return False
                
        except Exception as e:
            self.log_test("Installation Directory", "FAIL", f"Error: {e}")
            return False

    def upload_verification_script(self) -> bool:
        """Upload the verification script to the Pi."""
        logger.info("\n📤 Uploading Verification Script...")
        
        try:
            start_time = time.time()
            
            # Check if local verification script exists
            local_script = Path("pi_deployment_verifier.py")
            if not local_script.exists():
                self.log_test("Script Upload", "FAIL", "Local verification script not found")
                return False
            
            # Upload script to Pi
            remote_script_path = f"{self.install_dir}/pi_deployment_verifier.py"
            scp_cmd = ["scp", str(local_script), f"{self.ssh_base}:{remote_script_path}"]
            
            result = subprocess.run(scp_cmd, capture_output=True, text=True, timeout=30)
            
            if result.returncode == 0:
                # Make script executable
                chmod_cmd = ["ssh", self.ssh_base, f"chmod +x {remote_script_path}"]
                chmod_result = subprocess.run(chmod_cmd, capture_output=True, text=True, timeout=10)
                
                if chmod_result.returncode == 0:
                    duration = time.time() - start_time
                    self.log_test("Script Upload", "PASS", 
                                 f"Verification script uploaded and made executable", duration)
                    return True
                else:
                    self.log_test("Script Upload", "WARN", 
                                 "Script uploaded but chmod failed")
                    return True
            else:
                self.log_test("Script Upload", "FAIL", 
                             f"SCP upload failed: {result.stderr}")
                return False
                
        except Exception as e:
            self.log_test("Script Upload", "FAIL", f"Error: {e}")
            return False

    def run_remote_verification(self) -> Optional[Dict[str, Any]]:
        """Execute the verification script remotely on the Pi."""
        logger.info("\n🚀 Running Remote Verification...")
        
        try:
            start_time = time.time()
            
            # Execute verification script on Pi
            remote_script_path = f"{self.install_dir}/pi_deployment_verifier.py"
            cmd = ["ssh", self.ssh_base, 
                   f"cd {self.install_dir} && python3 {remote_script_path} --install-dir {self.install_dir}"]
            
            logger.info("⏳ Executing comprehensive verification on Pi (this may take a few minutes)...")
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)  # 5 minute timeout
            
            duration = time.time() - start_time
            
            if result.returncode == 0:
                self.log_test("Remote Verification Execution", "PASS", 
                             "Verification script completed successfully", duration)
                
                # Log the output
                logger.info("📊 Verification Output:")
                for line in result.stdout.split('\n'):
                    if line.strip():
                        logger.info(f"   {line}")
                
                # Try to retrieve the JSON report
                report_cmd = ["ssh", self.ssh_base, f"cat {self.install_dir}/pi_verification_report.json"]
                report_result = subprocess.run(report_cmd, capture_output=True, text=True, timeout=10)
                
                if report_result.returncode == 0:
                    try:
                        report_data = json.loads(report_result.stdout)
                        self.log_test("Report Retrieval", "PASS", "Verification report retrieved")
                        return report_data
                    except json.JSONDecodeError:
                        self.log_test("Report Retrieval", "WARN", "Report file exists but contains invalid JSON")
                else:
                    self.log_test("Report Retrieval", "WARN", "Could not retrieve verification report")
                
                return {"status": "completed", "output": result.stdout}
                
            elif result.returncode == 1:
                self.log_test("Remote Verification Execution", "WARN", 
                             "Verification completed with warnings", duration)
                logger.info("⚠️ Verification Output (with warnings):")
                for line in result.stdout.split('\n'):
                    if line.strip():
                        logger.info(f"   {line}")
                return {"status": "warnings", "output": result.stdout}
                
            else:
                self.log_test("Remote Verification Execution", "FAIL", 
                             f"Verification failed with exit code {result.returncode}", duration)
                logger.error("❌ Verification Error Output:")
                for line in result.stderr.split('\n'):
                    if line.strip():
                        logger.error(f"   {line}")
                return {"status": "failed", "error": result.stderr, "output": result.stdout}
                
        except subprocess.TimeoutExpired:
            self.log_test("Remote Verification Execution", "FAIL", "Verification timed out after 5 minutes")
            return None
        except Exception as e:
            self.log_test("Remote Verification Execution", "FAIL", f"Error: {e}")
            return None

    def cleanup_remote_files(self) -> bool:
        """Clean up temporary files on the Pi."""
        logger.info("\n🧹 Cleaning Up Remote Files...")
        
        try:
            # Remove uploaded script and logs
            cleanup_cmd = ["ssh", self.ssh_base, 
                          f"rm -f {self.install_dir}/pi_deployment_verifier.py {self.install_dir}/pi_verification.log"]
            
            result = subprocess.run(cleanup_cmd, capture_output=True, text=True, timeout=10)
            
            if result.returncode == 0:
                self.log_test("Cleanup", "PASS", "Temporary files cleaned up")
                return True
            else:
                self.log_test("Cleanup", "WARN", f"Cleanup warning: {result.stderr}")
                return True
                
        except Exception as e:
            self.log_test("Cleanup", "WARN", f"Cleanup error: {e}")
            return True  # Non-critical

    def generate_summary_report(self, verification_report: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """Generate a comprehensive summary report."""
        total_tests = len(self.verification_results)
        passed_tests = len([r for r in self.verification_results if r["status"] == "PASS"])
        failed_tests = len([r for r in self.verification_results if r["status"] == "FAIL"])
        warning_tests = len([r for r in self.verification_results if r["status"] == "WARN"])
        
        total_duration = (datetime.now() - self.start_time).total_seconds()
        
        summary_report = {
            "remote_verification_summary": {
                "timestamp": datetime.now().isoformat(),
                "pi_host": self.pi_host,
                "pi_user": self.pi_user,
                "install_directory": self.install_dir,
                "remote_tests": {
                    "total": total_tests,
                    "passed": passed_tests,
                    "failed": failed_tests,
                    "warnings": warning_tests,
                    "success_rate": round((passed_tests / total_tests * 100), 2) if total_tests > 0 else 0
                },
                "total_duration": round(total_duration, 2),
                "remote_test_results": self.verification_results,
                "pi_verification_report": verification_report
            }
        }
        
        return summary_report

    async def run_comprehensive_remote_verification(self) -> Dict[str, Any]:
        """Run complete remote verification process."""
        logger.info("🌐 Starting Remote Raspberry Pi Verification")
        logger.info("=" * 80)
        logger.info(f"Target: {self.pi_user}@{self.pi_host}")
        logger.info(f"Install Directory: {self.install_dir}")
        logger.info("=" * 80)
        
        verification_report = None
        
        # Step 1: Test SSH connectivity
        if not self.test_ssh_connectivity():
            logger.error("❌ SSH connectivity failed - cannot proceed with remote verification")
            return self.generate_summary_report(None)
        
        # Step 2: Gather system information
        self.test_pi_system_info()
        
        # Step 3: Test installation directory
        if not self.test_installation_directory():
            logger.error("❌ Installation directory not accessible - cannot proceed")
            return self.generate_summary_report(None)
        
        # Step 4: Upload verification script
        if not self.upload_verification_script():
            logger.error("❌ Could not upload verification script")
            return self.generate_summary_report(None)
        
        # Step 5: Run remote verification
        verification_report = self.run_remote_verification()
        
        # Step 6: Cleanup
        self.cleanup_remote_files()
        
        # Generate final report
        final_report = self.generate_summary_report(verification_report)
        
        # Save report locally
        report_file = Path(f"remote_pi_verification_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json")
        with open(report_file, 'w') as f:
            json.dump(final_report, f, indent=2)
        
        logger.info(f"\n📄 Remote verification report saved to: {report_file}")
        
        return final_report

def print_final_summary(report: Dict[str, Any]):
    """Print final remote verification summary."""
    print("\n" + "=" * 80)
    print("🌐 REMOTE RASPBERRY PI VERIFICATION SUMMARY")
    print("=" * 80)
    
    summary = report["remote_verification_summary"]
    remote_tests = summary["remote_tests"]
    
    print(f"Target Pi: {summary['pi_user']}@{summary['pi_host']}")
    print(f"Install Directory: {summary['install_directory']}")
    print(f"Total Duration: {summary['total_duration']}s")
    print()
    
    print("Remote Connection Tests:")
    print(f"  ✅ Passed: {remote_tests['passed']}")
    print(f"  ❌ Failed: {remote_tests['failed']}")
    print(f"  ⚠️ Warnings: {remote_tests['warnings']}")
    print(f"  Success Rate: {remote_tests['success_rate']}%")
    print()
    
    if summary.get("pi_verification_report"):
        pi_report = summary["pi_verification_report"]
        if isinstance(pi_report, dict) and "verification_report" in pi_report:
            pi_summary = pi_report["verification_report"]["summary"]
            print("Pi System Verification Results:")
            print(f"  Overall Status: {pi_summary['overall_status']}")
            print(f"  Total Tests: {pi_summary['total_tests']}")
            print(f"  ✅ Passed: {pi_summary['passed_tests']}")
            print(f"  ❌ Failed: {pi_summary['failed_tests']}")
            print(f"  ⚠️ Warnings: {pi_summary['warning_tests']}")
            print(f"  Success Rate: {pi_summary['success_rate']}%")
            
            if pi_summary['overall_status'] == "HEALTHY":
                print("\n🎉 PI DEPLOYMENT VERIFICATION PASSED!")
                print("✅ System is ready for production deployment")
            elif pi_summary['overall_status'] == "WARNING":
                print("\n⚠️ PI DEPLOYMENT HAS WARNINGS")
                print("🔍 System is mostly functional but requires attention")
            else:
                print("\n❌ PI DEPLOYMENT VERIFICATION FAILED")
                print("🚨 Critical issues detected")
        else:
            print("Pi System Verification: Completed with output (see logs)")
    else:
        print("Pi System Verification: Not completed or failed")
    
    print("=" * 80)

def main():
    """Main execution function."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Remote Raspberry Pi Deployment Verification")
    parser.add_argument("--host", default="192.168.1.91", help="Pi hostname or IP address")
    parser.add_argument("--user", default="pi", help="SSH username")
    parser.add_argument("--install-dir", default="/opt/ai-crypto-trader", help="Installation directory on Pi")
    parser.add_argument("--verbose", action="store_true", help="Enable verbose output")
    
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Initialize remote verifier
    verifier = RemotePiVerifier(
        pi_host=args.host,
        pi_user=args.user,
        install_dir=args.install_dir
    )
    
    try:
        # Run remote verification
        import asyncio
        report = asyncio.run(verifier.run_comprehensive_remote_verification())
        
        # Print summary
        print_final_summary(report)
        
        # Exit with appropriate code
        remote_tests = report["remote_verification_summary"]["remote_tests"]
        if remote_tests["failed"] == 0:
            return 0
        else:
            return 1
            
    except KeyboardInterrupt:
        logger.info("\n⏹️ Remote verification interrupted by user")
        return 130
    except Exception as e:
        logger.error(f"\n💥 CRITICAL ERROR: {e}")
        return 3

if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)