"""
AI Controller - Central orchestrator for the AI Crypto Trading System.
Uses LLaMA Mini via Ollama for intelligent coordination and decision making.
Enhanced to coordinate with OpenRouter-powered specialized AI modules.
"""

import asyncio
import json
import time
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Callable
from dataclasses import dataclass
from enum import Enum
import threading

import requests


from src.utils.communication import ModuleCommunicator, message_bus, Priority, CommunicationProtocol
from src.utils.database import db_manager
from src.utils.config import config_manager
from src.utils.logging import get_logger, get_performance_logger, TimedOperation
from src.utils.openai_client import openai_client, TaskType
from src.utils.ai_prompt_templates import AIPromptTemplates

class SystemState(Enum):
    """System operational states."""
    INITIALIZING = "initializing"
    RUNNING = "running"
    PAUSED = "paused"
    ERROR = "error"
    SHUTDOWN = "shutdown"

class ModuleStatus(Enum):
    """Module status states."""
    HEALTHY = "healthy"
    WARNING = "warning"
    ERROR = "error"
    OFFLINE = "offline"

@dataclass
class ModuleHealth:
    """Module health information."""
    name: str
    status: ModuleStatus
    last_heartbeat: datetime
    response_time: float
    error_count: int
    cpu_usage: float = 0.0
    memory_usage: float = 0.0
    ai_enhanced: bool = False  # Track if module has AI enhancement

@dataclass
class AICoordinationMetrics:
    """Metrics for AI coordination performance."""
    total_decisions: int = 0
    ai_enhanced_decisions: int = 0
    fallback_decisions: int = 0
    average_confidence: float = 0.0
    openrouter_api_calls: int = 0
    openrouter_cost: float = 0.0

class AIController:
    """Central AI controller managing all trading system modules with OpenRouter coordination."""
    
    def __init__(self):
        self.logger = get_logger("ai_controller")
        self.perf_logger = get_performance_logger("ai_controller")
        
        # Communication
        self.communicator = ModuleCommunicator("ai_controller", message_bus)
        self._setup_request_handlers()
        
        # AI clients
        
        
        self.prompt_templates = AIPromptTemplates()
        
        # System state
        self.state = SystemState.INITIALIZING
        self.modules_health: Dict[str, ModuleHealth] = {}
        self.last_health_check = datetime.now()
        
        # Trading state
        self.active_trades: Dict[str, Dict[str, Any]] = {}
        self.daily_trade_count = 0
        self.daily_pnl = 0.0
        self.emergency_stop = False
        
        # AI coordination metrics
        self.ai_metrics = AICoordinationMetrics()
        
        # Learning and adaptation
        self.learning_data: List[Dict[str, Any]] = []
        self.strategy_adjustments: Dict[str, Any] = {}
        
        # OpenRouter coordination state
        self.module_ai_status: Dict[str, Dict[str, Any]] = {
            "coin_scanner": {"model": "Gemma-2-2B-IT", "status": "unknown"},
            "chart_checker": {"model": "GPT-4o", "status": "unknown"},
            "combiner": {"model": "GPT-4o", "status": "unknown"},
            "verifier_executor": {"model": "Claude-3.5-Sonnet", "status": "unknown"}
        }
        
        # Background tasks
        self.running = False
        self.background_tasks: List[asyncio.Task] = []
        
        self.logger.system("AI Controller initialized with OpenRouter coordination")
    
    def _setup_request_handlers(self):
        """Set up request handlers for inter-module communication."""
        handlers = {
            "health_check": self._handle_health_check,
            "start_scan": self._handle_start_scan,
            "process_scan_results": self._handle_scan_results,
            "process_chart_analysis": self._handle_chart_analysis,
            "process_trade_decision": self._handle_trade_decision,
            "process_trade_execution": self._handle_trade_execution,
            "emergency_stop": self._handle_emergency_stop,
            "get_system_status": self._handle_get_system_status,
            "update_strategy": self._handle_update_strategy,
            "get_ai_metrics": self._handle_get_ai_metrics,
            "optimize_ai_coordination": self._handle_optimize_ai_coordination
        }
        
        for request_type, handler in handlers.items():
            self.communicator.register_request_handler(request_type, handler)
    
    async def start(self):
        """Start the AI controller and all background tasks."""
        try:
            self.running = True
            self.state = SystemState.RUNNING
            
            # Start message bus
            message_bus.start()
            
            # Initialize modules and check AI capabilities
            await self._initialize_modules()
            await self._assess_ai_capabilities()
            
            # Start background tasks
            self.background_tasks = [
                asyncio.create_task(self._health_monitoring_loop()),
                asyncio.create_task(self._trading_coordination_loop()),
                asyncio.create_task(self._learning_loop()),
                asyncio.create_task(self._emergency_monitoring_loop()),
                asyncio.create_task(self._ai_coordination_monitoring_loop())
            ]
            
            self.logger.system("AI Controller started successfully with OpenRouter coordination")
            
            # Main coordination loop
            await self._main_coordination_loop()
            
        except Exception as e:
            self.logger.error("Failed to start AI Controller", exception=e)
            self.state = SystemState.ERROR
            raise
    
    async def stop(self):
        """Stop the AI controller and cleanup."""
        self.running = False
        self.state = SystemState.SHUTDOWN
        
        # Cancel background tasks
        for task in self.background_tasks:
            task.cancel()
        
        # Wait for tasks to complete
        if self.background_tasks:
            await asyncio.gather(*self.background_tasks, return_exceptions=True)
        
        # Stop message bus
        message_bus.stop()
        
        self.logger.system("AI Controller stopped")
    
    async def _initialize_modules(self):
        """Initialize and health check all modules."""
        modules = ["coin_scanner", "chart_checker", "combiner", "verifier_executor"]
        
        for module in modules:
            try:
                # Send health check
                response = self.communicator.send_request(
                    module, "health_check", {}, Priority.HIGH, timeout=10.0
                )
                
                if response:
                    ai_enhanced = response.get("ai_enhancement") == "enabled"
                    self.modules_health[module] = ModuleHealth(
                        name=module,
                        status=ModuleStatus.HEALTHY,
                        last_heartbeat=datetime.now(),
                        response_time=response.get("response_time", 0.0),
                        error_count=0,
                        ai_enhanced=ai_enhanced
                    )
                    
                    # Update AI status
                    if module in self.module_ai_status:
                        self.module_ai_status[module]["status"] = "active" if ai_enhanced else "fallback"
                    
                    self.logger.health(f"Module {module} initialized", {
                        "module": module,
                        "ai_enhanced": ai_enhanced
                    })
                else:
                    self.modules_health[module] = ModuleHealth(
                        name=module,
                        status=ModuleStatus.OFFLINE,
                        last_heartbeat=datetime.now(),
                        response_time=0.0,
                        error_count=1,
                        ai_enhanced=False
                    )
                    self.logger.error(f"Module {module} failed to initialize")
                    
            except Exception as e:
                self.logger.error(f"Error initializing module {module}", exception=e)
    
    async def _assess_ai_capabilities(self):
        """Assess AI capabilities across the system."""
        try:
            # Test OpenRouter connectivity
            test_response = await openai_client.generate_response("Test connectivity", TaskType.ANALYSIS)
            
            openai_available = test_response and test_response.get("success", False)
            
            # Test Ollama connectivity
            try:
                ollama_response = self.ollama_client.chat(
                    model=config_manager.ollama.model,
                    messages=[{"role": "user", "content": "Test"}],
                    options={"num_predict": 10}
                )
                ollama_available = bool(ollama_response)
            except Exception:
                ollama_available = False
            
            self.logger.system("AI capabilities assessed", {
                "openai_available": openai_available,
                "ollama_available": ollama_available,
                "ai_enhanced_modules": sum(1 for h in self.modules_health.values() if h.ai_enhanced)
            })
            
        except Exception as e:
            self.logger.error("Error assessing AI capabilities", exception=e)
    
    async def _main_coordination_loop(self):
        """Main coordination loop for trading operations with AI enhancement."""
        while self.running and self.state == SystemState.RUNNING:
            try:
                with TimedOperation(self.perf_logger, "coordination_cycle"):
                    # Check if we should trade using AI coordination
                    if await self._should_start_trading_cycle():
                        await self._execute_ai_enhanced_trading_cycle()
                    
                    # Brief pause between cycles
                    await asyncio.sleep(30)  # 30 second cycles
                    
            except Exception as e:
                self.logger.error("Error in coordination loop", exception=e)
                await asyncio.sleep(60)  # Longer pause on error
    
    async def _should_start_trading_cycle(self) -> bool:
        """Determine if a new trading cycle should start using AI coordination."""
        # Check emergency stop
        if self.emergency_stop:
            return False
        
        # Check daily trade limit
        if self.daily_trade_count >= config_manager.trading.max_daily_trades:
            return False
        
        # Check system health
        unhealthy_modules = [
            name for name, health in self.modules_health.items()
            if health.status in [ModuleStatus.ERROR, ModuleStatus.OFFLINE]
        ]
        
        if unhealthy_modules:
            self.logger.system(f"Skipping trading cycle - unhealthy modules: {unhealthy_modules}")
            return False
        
        # Use AI coordination to decide if market conditions are suitable
        return await self._ai_coordinated_trading_decision()
    
    async def _ai_coordinated_trading_decision(self) -> bool:
        """Use AI coordination to determine if trading conditions are favorable."""
        try:
            # Get recent performance data
            performance = db_manager.get_performance_metrics(days=7)
            
            # Get AI enhancement status
            ai_status = {
                module: {
                    "enhanced": health.ai_enhanced,
                    "model": self.module_ai_status.get(module, {}).get("model", "unknown"),
                    "status": self.module_ai_status.get(module, {}).get("status", "unknown")
                }
                for module, health in self.modules_health.items()
            }
            
            # Get current market conditions
            market_data = {
                "recent_performance": performance,
                "active_trades": len(self.active_trades),
                "daily_pnl": self.daily_pnl,
                "time_of_day": datetime.now().hour,
                "ai_enhancement_status": ai_status,
                "ai_metrics": {
                    "total_decisions": self.ai_metrics.total_decisions,
                    "ai_enhanced_ratio": (self.ai_metrics.ai_enhanced_decisions / max(1, self.ai_metrics.total_decisions)),
                    "average_confidence": self.ai_metrics.average_confidence,
                    "openrouter_cost": self.ai_metrics.openrouter_cost
                }
            }
            
            # Use LLaMA Mini for coordination decision with AI enhancement context
            prompt = f"""
            As the central AI coordinator, analyze current trading conditions and decide if we should start a new trading cycle.
            
            Market Data:
            {json.dumps(market_data, indent=2)}
            
            AI Enhancement Status:
            - Coin Scanner: {ai_status.get('coin_scanner', {}).get('model', 'Unknown')} ({ai_status.get('coin_scanner', {}).get('status', 'unknown')})
            - Chart Checker: {ai_status.get('chart_checker', {}).get('model', 'Unknown')} ({ai_status.get('chart_checker', {}).get('status', 'unknown')})
            - Combiner: {ai_status.get('combiner', {}).get('model', 'Unknown')} ({ai_status.get('combiner', {}).get('status', 'unknown')})
            - Verifier: {ai_status.get('verifier_executor', {}).get('model', 'Unknown')} ({ai_status.get('verifier_executor', {}).get('status', 'unknown')})
            
            Consider:
            1. Recent performance trends and AI enhancement effectiveness
            2. Current market volatility and AI model capabilities
            3. Time of day and liquidity considerations
            4. Risk management with AI-enhanced verification
            5. Cost efficiency of OpenRouter API usage
            
            Respond with JSON: {{"should_trade": true/false, "reasoning": "explanation", "confidence": 0.0-1.0, "ai_coordination_notes": "notes about AI module coordination"}}
            """
            
            response = self.ollama_client.chat(
                model=config_manager.ollama.model,
                messages=[{"role": "user", "content": prompt}],
                options={
                    "temperature": config_manager.ollama.temperature,
                    "num_predict": 300
                }
            )
            
            # Parse AI response
            ai_response = json.loads(response['message']['content'])
            should_trade = ai_response.get("should_trade", False)
            reasoning = ai_response.get("reasoning", "No reasoning provided")
            confidence = ai_response.get("confidence", 0.5)
            ai_notes = ai_response.get("ai_coordination_notes", "")
            
            # Update metrics
            self.ai_metrics.total_decisions += 1
            if any(h.ai_enhanced for h in self.modules_health.values()):
                self.ai_metrics.ai_enhanced_decisions += 1
            
            # Update average confidence
            self.ai_metrics.average_confidence = (
                (self.ai_metrics.average_confidence * (self.ai_metrics.total_decisions - 1) + confidence) /
                self.ai_metrics.total_decisions
            )
            
            self.logger.decision("AI coordinated trading decision", {
                "should_trade": should_trade,
                "reasoning": reasoning,
                "confidence": confidence,
                "ai_coordination_notes": ai_notes,
                "market_data": market_data
            })
            
            return should_trade
            
        except Exception as e:
            self.logger.error("Error in AI coordinated trading decision", exception=e)
            return False  # Conservative default
    
    async def _execute_ai_enhanced_trading_cycle(self):
        """Execute a complete trading cycle with AI enhancement coordination."""
        try:
            self.logger.system("Starting AI-enhanced trading cycle")
            
            # Step 1: AI-enhanced coin scanning
            scan_results = await self._coordinate_ai_enhanced_scan()
            if not scan_results:
                return
            
            # Step 2: AI-enhanced chart analysis for top coins
            top_coins = scan_results.get("coins", [])[:5]  # Analyze top 5
            chart_analyses = {}
            
            for coin in top_coins:
                symbol = coin.get("symbol")
                if symbol:
                    analysis = await self._coordinate_ai_enhanced_chart_analysis(symbol)
                    if analysis:
                        chart_analyses[symbol] = analysis
            
            # Step 3: AI-enhanced decision making
            for symbol, chart_data in chart_analyses.items():
                coin_data = next((c for c in top_coins if c["symbol"] == symbol), None)
                if coin_data:
                    decision = await self._coordinate_ai_enhanced_trade_decision(coin_data, chart_data)
                    if decision and decision.get("decision") == "buy":
                        # Step 4: AI-enhanced trade execution
                        await self._coordinate_ai_enhanced_trade_execution(decision)
            
            self.logger.system("AI-enhanced trading cycle completed")
            
        except Exception as e:
            self.logger.error("Error in AI-enhanced trading cycle", exception=e)
    
    async def _coordinate_ai_enhanced_scan(self) -> Optional[Dict[str, Any]]:
        """Coordinate AI-enhanced coin scanning process."""
        try:
            request_data = CommunicationProtocol.create_scan_request(
                symbols=["BTC", "ETH", "BNB", "ADA", "SOL"],  # Expanded for AI analysis
                timeframe="1h"
            )
            
            response = self.communicator.send_request(
                "coin_scanner", "scan_coins", request_data, Priority.HIGH, timeout=90.0  # Longer timeout for AI
            )
            
            if response:
                ai_enhanced = response.get("ai_enhanced", False)
                if ai_enhanced:
                    self.ai_metrics.openrouter_api_calls += response.get("api_calls", 0)
                    self.ai_metrics.openrouter_cost += response.get("api_cost", 0.0)
                
                self.logger.decision("AI-enhanced coin scan completed", {
                    "response": response,
                    "ai_enhanced": ai_enhanced
                })
                return response
            
        except Exception as e:
            self.logger.error("Error coordinating AI-enhanced coin scan", exception=e)
        
        return None
    
    async def _coordinate_ai_enhanced_chart_analysis(self, symbol: str) -> Optional[Dict[str, Any]]:
        """Coordinate AI-enhanced chart analysis for a specific symbol."""
        try:
            request_data = CommunicationProtocol.create_chart_analysis_request(
                symbol=symbol,
                timeframes=["15m", "1h", "4h", "1d"]  # More timeframes for AI analysis
            )
            
            response = self.communicator.send_request(
                "chart_checker", "analyze_chart", request_data, Priority.HIGH, timeout=75.0  # Longer timeout for AI
            )
            
            if response:
                ai_enhanced = response.get("ai_enhanced", False)
                if ai_enhanced:
                    self.ai_metrics.openrouter_api_calls += response.get("api_calls", 0)
                    self.ai_metrics.openrouter_cost += response.get("api_cost", 0.0)
                
                self.logger.decision("AI-enhanced chart analysis completed", {
                    "symbol": symbol,
                    "analysis": response,
                    "ai_enhanced": ai_enhanced
                })
                return response
            
        except Exception as e:
            self.logger.error(f"Error coordinating AI-enhanced chart analysis for {symbol}", exception=e)
        
        return None
    
    async def _coordinate_ai_enhanced_trade_decision(self, coin_data: Dict[str, Any], 
                                                   chart_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Coordinate AI-enhanced trade decision making."""
        try:
            request_data = CommunicationProtocol.create_trade_decision_request(
                scanner_output=coin_data,
                chart_output=chart_data
            )
            
            response = self.communicator.send_request(
                "combiner", "make_decision", request_data, Priority.HIGH, timeout=60.0  # Longer timeout for AI
            )
            
            if response:
                ai_enhanced = response.get("ai_enhanced", False)
                if ai_enhanced:
                    self.ai_metrics.openrouter_api_calls += response.get("api_calls", 0)
                    self.ai_metrics.openrouter_cost += response.get("api_cost", 0.0)
                
                self.logger.decision("AI-enhanced trade decision made", {
                    "response": response,
                    "ai_enhanced": ai_enhanced
                })
                return response
            
        except Exception as e:
            self.logger.error("Error coordinating AI-enhanced trade decision", exception=e)
        
        return None
    
    async def _coordinate_ai_enhanced_trade_execution(self, decision: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Coordinate AI-enhanced trade execution."""
        try:
            request_data = CommunicationProtocol.create_trade_execution_request(decision)
            
            response = self.communicator.send_request(
                "verifier_executor", "execute_trade", request_data, Priority.CRITICAL, timeout=180.0  # Longer timeout for AI verification
            )
            
            if response:
                ai_enhanced = response.get("ai_enhancements") is not None
                if ai_enhanced:
                    self.ai_metrics.openrouter_api_calls += response.get("api_calls", 0)
                    self.ai_metrics.openrouter_cost += response.get("api_cost", 0.0)
                
                # Track the trade
                trade_id = response.get("trade_id")
                if trade_id:
                    self.active_trades[trade_id] = {
                        "decision": decision,
                        "execution": response,
                        "start_time": datetime.now(),
                        "ai_enhanced": ai_enhanced
                    }
                    self.daily_trade_count += 1
                
                self.logger.trade("AI-enhanced trade executed", {
                    "response": response,
                    "ai_enhanced": ai_enhanced
                })
                return response
            
        except Exception as e:
            self.logger.error("Error coordinating AI-enhanced trade execution", exception=e)
        
        return None
    
    async def _ai_coordination_monitoring_loop(self):
        """Monitor AI coordination performance and costs."""
        while self.running:
            try:
                await self._monitor_ai_performance()
                await self._optimize_ai_usage()
                await asyncio.sleep(300)  # Check every 5 minutes
                
            except Exception as e:
                self.logger.error("Error in AI coordination monitoring", exception=e)
                await asyncio.sleep(300)
    
    async def _monitor_ai_performance(self):
        """Monitor AI coordination performance."""
        try:
            # Calculate AI enhancement effectiveness
            total_trades = len(self.active_trades)
            ai_enhanced_trades = sum(1 for trade in self.active_trades.values() if trade.get("ai_enhanced", False))
            
            if total_trades > 0:
                ai_enhancement_ratio = ai_enhanced_trades / total_trades
            else:
                ai_enhancement_ratio = 0.0
            
            # Log AI coordination metrics
            self.logger.system("AI coordination metrics", {
                "total_decisions": self.ai_metrics.total_decisions,
                "ai_enhanced_decisions": self.ai_metrics.ai_enhanced_decisions,
                "ai_enhancement_ratio": ai_enhancement_ratio,
                "average_confidence": self.ai_metrics.average_confidence,
                "openrouter_api_calls": self.ai_metrics.openrouter_api_calls,
                "openrouter_cost": self.ai_metrics.openrouter_cost,
                "active_ai_modules": sum(1 for h in self.modules_health.values() if h.ai_enhanced)
            })
            
        except Exception as e:
            self.logger.error("Error monitoring AI performance", exception=e)
    
    async def _optimize_ai_usage(self):
        """Optimize AI usage based on performance and costs."""
        try:
            # Check if costs are within limits
            daily_cost_limit = config_manager.openrouter.daily_cost_limit
            if self.ai_metrics.openrouter_cost > daily_cost_limit * 0.8:  # 80% threshold
                self.logger.system("OpenRouter cost approaching limit", {
                    "current_cost": self.ai_metrics.openrouter_cost,
                    "daily_limit": daily_cost_limit,
                    "usage_percentage": (self.ai_metrics.openrouter_cost / daily_cost_limit) * 100
                })
            
            # Reset daily metrics at midnight
            now = datetime.now()
            if now.hour == 0 and now.minute < 5:  # Reset in first 5 minutes of day
                self.ai_metrics = AICoordinationMetrics()
                self.logger.system("AI coordination metrics reset for new day")
            
        except Exception as e:
            self.logger.error("Error optimizing AI usage", exception=e)
    
    async def _health_monitoring_loop(self):
        """Monitor health of all modules with AI enhancement tracking."""
        while self.running:
            try:
                await self._check_modules_health()
                await asyncio.sleep(30)  # Check every 30 seconds
            except Exception as e:
                self.logger.error("Error in health monitoring", exception=e)
                await asyncio.sleep(60)
    
    async def _check_modules_health(self):
        """Check health of all modules including AI enhancement status."""
        for module_name in self.modules_health.keys():
            try:
                start_time = time.time()
                response = self.communicator.send_request(
                    module_name, "health_check", {}, Priority.LOW, timeout=10.0
                )
                response_time = time.time() - start_time
                
                if response:
                    ai_enhanced = response.get("ai_enhancement") == "enabled"
                    
                    self.modules_health[module_name].status = ModuleStatus.HEALTHY
                    self.modules_health[module_name].last_heartbeat = datetime.now()
                    self.modules_health[module_name].response_time = response_time
                    self.modules_health[module_name].error_count = 0
                    self.modules_health[module_name].ai_enhanced = ai_enhanced
                    
                    # Update AI status
                    if module_name in self.module_ai_status:
                        self.module_ai_status[module_name]["status"] = "active" if ai_enhanced else "fallback"
                else:
                    self._handle_module_unhealthy(module_name)
                    
            except Exception as e:
                self.logger.error(f"Health check failed for {module_name}", exception=e)
                self._handle_module_unhealthy(module_name)
    
    def _handle_module_unhealthy(self, module_name: str):
        """Handle unhealthy module."""
        if module_name in self.modules_health:
            health = self.modules_health[module_name]
            health.error_count += 1
            health.ai_enhanced = False  # Assume AI enhancement is lost when unhealthy
            
            if module_name in self.module_ai_status:
                self.module_ai_status[module_name]["status"] = "offline"
            
            if health.error_count >= 3:
                health.status = ModuleStatus.ERROR
                self.logger.error(f"Module {module_name} marked as ERROR")
            else:
                health.status = ModuleStatus.WARNING
                self.logger.health(f"Module {module_name} health warning")
    
    async def _trading_coordination_loop(self):
        """Background loop for trading coordination."""
        while self.running:
            try:
                # Monitor active trades
                await self._monitor_active_trades()
                
                # Reset daily counters at midnight
                await self._reset_daily_counters()
                
                await asyncio.sleep(60)  # Check every minute
                
            except Exception as e:
                self.logger.error("Error in trading coordination loop", exception=e)
                await asyncio.sleep(60)
    
    async def _monitor_active_trades(self):
        """Monitor and manage active trades."""
        for trade_id, trade_info in list(self.active_trades.items()):
            try:
                # Check if trade should be closed (simplified logic)
                elapsed = datetime.now() - trade_info["start_time"]
                if elapsed > timedelta(hours=6):  # Close trades after 6 hours
                    # Request trade closure
                    self.communicator.send_request(
                        "verifier_executor", "close_trade", 
                        {"trade_id": trade_id}, Priority.HIGH
                    )
                    
                    # Remove from active trades
                    del self.active_trades[trade_id]
                    
            except Exception as e:
                self.logger.error(f"Error monitoring trade {trade_id}", exception=e)
    
    async def _reset_daily_counters(self):
        """Reset daily trading counters at midnight."""
        now = datetime.now()
        if now.hour == 0 and now.minute == 0:
            self.daily_trade_count = 0
            self.daily_pnl = 0.0
            self.logger.system("Daily counters reset")
    
    async def _learning_loop(self):
        """Background loop for AI learning and adaptation with OpenRouter insights."""
        while self.running:
            try:
                await self._analyze_ai_enhanced_performance()
                await self._adapt_ai_coordination_strategy()
                await asyncio.sleep(3600)  # Run every hour
                
            except Exception as e:
                self.logger.error("Error in learning loop", exception=e)
                await asyncio.sleep(3600)
    
    async def _analyze_ai_enhanced_performance(self):
        """Analyze recent performance including AI enhancement effectiveness."""
        try:
            # Get recent trades
            recent_trades = db_manager.get_trades(limit=50)
            
            if len(recent_trades) < 10:
                return  # Need more data
            
            # Separate AI-enhanced vs traditional trades
            ai_enhanced_trades = [t for t in recent_trades if t.get("metadata", {}).get("ai_verification")]
            traditional_trades = [t for t in recent_trades if not t.get("metadata", {}).get("ai_verification")]
            
            # Analyze with LLaMA Mini
            performance_data = {
                "total_trades": len(recent_trades),
                "ai_enhanced_trades": len(ai_enhanced_trades),
                "traditional_trades": len(traditional_trades),
                "ai_enhancement_ratio": len(ai_enhanced_trades) / len(recent_trades) if recent_trades else 0,
                "ai_enhanced_performance": {
                    "count": len(ai_enhanced_trades),
                    "avg_pnl": sum(t.get("pnl", 0) for t in ai_enhanced_trades) / len(ai_enhanced_trades) if ai_enhanced_trades else 0,
                    "win_rate": len([t for t in ai_enhanced_trades if t.
get("pnl", 0) > 0]) / len(ai_enhanced_trades) if ai_enhanced_trades else 0
                },
                "traditional_performance": {
                    "count": len(traditional_trades),
                    "avg_pnl": sum(t.get("pnl", 0) for t in traditional_trades) / len(traditional_trades) if traditional_trades else 0,
                    "win_rate": len([t for t in traditional_trades if t.get("pnl", 0) > 0]) / len(traditional_trades) if traditional_trades else 0
                },
                "ai_coordination_metrics": {
                    "total_decisions": self.ai_metrics.total_decisions,
                    "ai_enhanced_ratio": self.ai_metrics.ai_enhanced_decisions / max(1, self.ai_metrics.total_decisions),
                    "average_confidence": self.ai_metrics.average_confidence,
                    "openrouter_cost": self.ai_metrics.openrouter_cost
                }
            }
            
            prompt = f"""
            Analyze the recent trading performance including AI enhancement effectiveness:
            
            Performance Data:
            {json.dumps(performance_data, indent=2, default=str)}
            
            Provide insights on:
            1. AI enhancement effectiveness vs traditional methods
            2. Cost-benefit analysis of OpenRouter usage
            3. Module-specific AI performance
            4. Coordination improvements needed
            5. Strategy adjustments for better AI utilization
            
            Respond with JSON: {{"insights": [], "ai_coordination_adjustments": {{}}, "cost_optimization": []}}
            """
            
            response = self.ollama_client.chat(
                model=config_manager.ollama.model,
                messages=[{"role": "user", "content": prompt}],
                options={"temperature": 0.7}
            )
            
            analysis = json.loads(response['message']['content'])
            
            self.logger.learning("AI-enhanced performance analysis completed", {
                "performance_data": performance_data,
                "ai_analysis": analysis
            })
            
            # Store learning data
            self.learning_data.append({
                "timestamp": datetime.now().isoformat(),
                "analysis": analysis,
                "performance": performance_data
            })
            
        except Exception as e:
            self.logger.error("Error analyzing AI-enhanced performance", exception=e)
    
    async def _adapt_ai_coordination_strategy(self):
        """Adapt AI coordination strategy based on learning."""
        if not self.learning_data:
            return
        
        try:
            # Get latest learning insights
            latest_learning = self.learning_data[-1]
            adjustments = latest_learning.get("analysis", {}).get("ai_coordination_adjustments", {})
            
            if adjustments:
                # Apply strategy adjustments
                self.strategy_adjustments.update(adjustments)
                
                self.logger.learning("AI coordination strategy adapted", {
                    "adjustments": adjustments,
                    "current_strategy": self.strategy_adjustments
                })
                
                # Broadcast strategy update to all modules
                self.communicator.broadcast({
                    "type": "ai_coordination_update",
                    "adjustments": self.strategy_adjustments
                }, Priority.MEDIUM)
                
        except Exception as e:
            self.logger.error("Error adapting AI coordination strategy", exception=e)
    
    async def _emergency_monitoring_loop(self):
        """Monitor for emergency conditions including AI system failures."""
        while self.running:
            try:
                await self._check_emergency_conditions()
                await asyncio.sleep(10)  # Check every 10 seconds
                
            except Exception as e:
                self.logger.error("Error in emergency monitoring", exception=e)
                await asyncio.sleep(30)
    
    async def _check_emergency_conditions(self):
        """Check for emergency stop conditions including AI failures."""
        try:
            # Check portfolio loss
            performance = db_manager.get_performance_metrics(days=1)
            daily_pnl = performance.get("total_pnl", 0)
            
            # Emergency stop if daily loss exceeds threshold
            if daily_pnl < -config_manager.trading.emergency_stop_loss:
                await self._trigger_emergency_stop(f"Daily loss exceeded threshold: {daily_pnl}%")
            
            # Check for system errors
            error_modules = [
                name for name, health in self.modules_health.items()
                if health.status == ModuleStatus.ERROR
            ]
            
            if len(error_modules) >= 2:  # Multiple module failures
                await self._trigger_emergency_stop(f"Multiple module failures: {error_modules}")
            
            # Check AI coordination health
            ai_enhanced_modules = sum(1 for h in self.modules_health.values() if h.ai_enhanced)
            if ai_enhanced_modules == 0 and config_manager.openrouter.enabled:
                self.logger.system("All AI enhancements offline, running on fallback systems")
            
            # Check OpenRouter cost limits
            if self.ai_metrics.openrouter_cost > config_manager.openrouter.daily_cost_limit:
                self.logger.system("OpenRouter daily cost limit exceeded, switching to fallback")
                
        except Exception as e:
            self.logger.error("Error checking emergency conditions", exception=e)
    
    async def _trigger_emergency_stop(self, reason: str):
        """Trigger emergency stop of all trading."""
        if not self.emergency_stop:
            self.emergency_stop = True
            
            self.logger.security("EMERGENCY STOP TRIGGERED", {
                "reason": reason,
                "timestamp": datetime.now().isoformat(),
                "active_trades": len(self.active_trades),
                "ai_enhanced_trades": sum(1 for t in self.active_trades.values() if t.get("ai_enhanced", False))
            })
            
            # Close all active trades
            for trade_id in list(self.active_trades.keys()):
                try:
                    self.communicator.send_request(
                        "verifier_executor", "emergency_close_trade",
                        {"trade_id": trade_id}, Priority.CRITICAL
                    )
                except Exception as e:
                    self.logger.error(f"Error emergency closing trade {trade_id}", exception=e)
            
            # Broadcast emergency stop
            self.communicator.broadcast({
                "type": "emergency_stop",
                "reason": reason
            }, Priority.CRITICAL)
    
    # Request handlers
    def _handle_health_check(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle health check requests."""
        return {
            "status": self.state.value,
            "modules_health": {
                name: {
                    "status": health.status.value,
                    "last_heartbeat": health.last_heartbeat.isoformat(),
                    "response_time": health.response_time,
                    "error_count": health.error_count,
                    "ai_enhanced": health.ai_enhanced
                }
                for name, health in self.modules_health.items()
            },
            "active_trades": len(self.active_trades),
            "daily_trade_count": self.daily_trade_count,
            "emergency_stop": self.emergency_stop,
            "ai_coordination": {
                "total_decisions": self.ai_metrics.total_decisions,
                "ai_enhanced_decisions": self.ai_metrics.ai_enhanced_decisions,
                "openrouter_cost": self.ai_metrics.openrouter_cost,
                "average_confidence": self.ai_metrics.average_confidence
            }
        }
    
    def _handle_start_scan(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle manual scan start requests."""
        # Trigger immediate AI-enhanced scan
        asyncio.create_task(self._coordinate_ai_enhanced_scan())
        return {"status": "ai_enhanced_scan_started"}
    
    def _handle_scan_results(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle scan results from coin scanner."""
        self.logger.decision("Received AI-enhanced scan results", data)
        return {"status": "received"}
    
    def _handle_chart_analysis(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle chart analysis results."""
        self.logger.decision("Received AI-enhanced chart analysis", data)
        return {"status": "received"}
    
    def _handle_trade_decision(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle trade decision results."""
        self.logger.decision("Received AI-enhanced trade decision", data)
        return {"status": "received"}
    
    def _handle_trade_execution(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle trade execution results."""
        self.logger.trade("Received AI-enhanced trade execution result", data)
        return {"status": "received"}
    
    def _handle_emergency_stop(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle emergency stop requests."""
        reason = data.get("reason", "Manual emergency stop")
        asyncio.create_task(self._trigger_emergency_stop(reason))
        return {"status": "emergency_stop_triggered"}
    
    def _handle_get_system_status(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle system status requests."""
        return self._handle_health_check(data)
    
    def _handle_update_strategy(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle strategy update requests."""
        adjustments = data.get("adjustments", {})
        self.strategy_adjustments.update(adjustments)
        
        self.logger.system("Strategy updated manually", {"adjustments": adjustments})
        
        # Broadcast to all modules
        self.communicator.broadcast({
            "type": "strategy_update",
            "adjustments": self.strategy_adjustments
        }, Priority.MEDIUM)
        
        return {"status": "strategy_updated", "current_strategy": self.strategy_adjustments}
    
    def _handle_get_ai_metrics(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle AI metrics requests."""
        return {
            "ai_coordination_metrics": {
                "total_decisions": self.ai_metrics.total_decisions,
                "ai_enhanced_decisions": self.ai_metrics.ai_enhanced_decisions,
                "fallback_decisions": self.ai_metrics.fallback_decisions,
                "average_confidence": self.ai_metrics.average_confidence,
                "openrouter_api_calls": self.ai_metrics.openrouter_api_calls,
                "openrouter_cost": self.ai_metrics.openrouter_cost
            },
            "module_ai_status": self.module_ai_status,
            "ai_enhanced_modules": sum(1 for h in self.modules_health.values() if h.ai_enhanced)
        }
    
    def _handle_optimize_ai_coordination(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle AI coordination optimization requests."""
        try:
            # Trigger immediate optimization
            asyncio.create_task(self._optimize_ai_usage())
            
            return {
                "status": "optimization_triggered",
                "current_metrics": {
                    "openrouter_cost": self.ai_metrics.openrouter_cost,
                    "ai_enhancement_ratio": self.ai_metrics.ai_enhanced_decisions / max(1, self.ai_metrics.total_decisions)
                }
            }
        except Exception as e:
            return {"status": "error", "error": str(e)}

# Main entry point
async def main():
    """Main entry point for AI Controller."""
    controller = AIController()
    
    try:
        await controller.start()
    except KeyboardInterrupt:
        print("Shutting down AI Controller...")
    finally:
        await controller.stop()

if __name__ == "__main__":
    asyncio.run(main())