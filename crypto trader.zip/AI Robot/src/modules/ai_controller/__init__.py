"""
AI Controller module - Central orchestrator for the AI Crypto Trading System.

Uses LLaMA Mini via Ollama for intelligent coordination and decision making.
Manages all other AI modules via JSON communication and implements 
self-learning and adaptation mechanisms.
"""

from .controller import AIController

__all__ = ["AIController"]