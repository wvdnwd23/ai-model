"""
Learning Engine - Coordinate learning across all system components for Gemma Brain.

This module implements the central learning coordination system:
- Orchestrate feedback analysis and self-improvement cycles
- Manage learning strategies and adaptation policies
- Track learning progress and performance evolution
- Coordinate between different learning components
- Implement meta-learning for strategy optimization
- Handle learning data persistence and retrieval
"""

import asyncio
import json
import time
import statistics
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple, Union
from dataclasses import dataclass, asdict
from enum import Enum
from collections import defaultdict, deque

from src.utils.database import db_manager
from src.utils.logging import get_logger, get_performance_logger, TimedOperation
from src.utils.config import config_manager

class LearningPhase(Enum):
    """Learning phases for different system states."""
    INITIALIZATION = "initialization"
    EXPLORATION = "exploration"
    EXPLOITATION = "exploitation"
    ADAPTATION = "adaptation"
    OPTIMIZATION = "optimization"
    MAINTENANCE = "maintenance"

class LearningStrategy(Enum):
    """Learning strategies for different scenarios."""
    CONSERVATIVE = "conservative"    # Slow, safe learning
    BALANCED = "balanced"           # Moderate learning pace
    AGGRESSIVE = "aggressive"       # Fast learning with higher risk
    ADAPTIVE = "adaptive"          # Strategy changes based on performance

class LearningPriority(Enum):
    """Priority levels for learning tasks."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"

@dataclass
class LearningTask:
    """Represents a learning task to be executed."""
    task_id: str
    task_type: str
    priority: LearningPriority
    component: str
    data: Dict[str, Any]
    created_at: datetime
    scheduled_at: Optional[datetime]
    completed_at: Optional[datetime]
    status: str
    results: Dict[str, Any]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "task_id": self.task_id,
            "task_type": self.task_type,
            "priority": self.priority.value,
            "component": self.component,
            "data": self.data,
            "created_at": self.created_at.isoformat(),
            "scheduled_at": self.scheduled_at.isoformat() if self.scheduled_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "status": self.status,
            "results": self.results
        }

@dataclass
class LearningMetrics:
    """Comprehensive learning performance metrics."""
    timestamp: datetime
    learning_phase: LearningPhase
    strategy: LearningStrategy
    
    # Performance metrics
    accuracy_improvement: float
    confidence_calibration: float
    risk_reduction: float
    profit_improvement: float
    
    # Learning efficiency
    learning_rate: float
    adaptation_speed: float
    knowledge_retention: float
    
    # System health
    stability_score: float
    error_rate: float
    rollback_frequency: float
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "timestamp": self.timestamp.isoformat(),
            "learning_phase": self.learning_phase.value,
            "strategy": self.strategy.value,
            "accuracy_improvement": self.accuracy_improvement,
            "confidence_calibration": self.confidence_calibration,
            "risk_reduction": self.risk_reduction,
            "profit_improvement": self.profit_improvement,
            "learning_rate": self.learning_rate,
            "adaptation_speed": self.adaptation_speed,
            "knowledge_retention": self.knowledge_retention,
            "stability_score": self.stability_score,
            "error_rate": self.error_rate,
            "rollback_frequency": self.rollback_frequency
        }

class LearningEngine:
    """
    Central learning engine that coordinates all learning activities.
    """
    
    def __init__(self, parent_brain):
        self.parent_brain = parent_brain
        self.logger = get_logger("learning_engine")
        self.perf_logger = get_performance_logger("learning_engine")
        
        # Learning components (will be injected)
        self.feedback_analyzer = None
        self.self_improver = None
        
        # Learning state
        self.current_phase = LearningPhase.INITIALIZATION
        self.current_strategy = LearningStrategy.BALANCED
        self.learning_active = True
        
        # Task management
        self.learning_tasks: deque = deque(maxlen=1000)
        self.active_tasks: Dict[str, LearningTask] = {}
        self.completed_tasks: deque = deque(maxlen=500)
        
        # Performance tracking
        self.learning_metrics: deque = deque(maxlen=100)
        self.performance_baseline = None
        self.last_evaluation = None
        
        # Learning configuration
        self.learning_config = {
            "feedback_analysis_interval": 300,  # 5 minutes
            "improvement_evaluation_interval": 1800,  # 30 minutes
            "strategy_review_interval": 3600,  # 1 hour
            "performance_evaluation_interval": 7200,  # 2 hours
            "max_concurrent_improvements": 3,
            "min_confidence_threshold": 0.6,
            "rollback_threshold": 0.3
        }
        
        # Learning statistics
        self.learning_stats = {
            "total_learning_cycles": 0,
            "successful_improvements": 0,
            "failed_improvements": 0,
            "rollbacks_triggered": 0,
            "strategy_changes": 0,
            "phase_transitions": 0,
            "average_learning_rate": 0.0,
            "total_learning_time": 0.0
        }
        
    async def initialize(self):
        """Initialize the learning engine."""
        try:
            # Load learning history and baseline
            await self._load_learning_history()
            await self._establish_performance_baseline()
            
            # Start learning cycles
            asyncio.create_task(self._learning_cycle_manager())
            
            self.logger.system("Learning Engine initialized")
            
        except Exception as e:
            self.logger.error("Error initializing learning engine", exception=e)
            raise
    
    def set_components(self, feedback_analyzer, self_improver):
        """Set the learning components."""
        self.feedback_analyzer = feedback_analyzer
        self.self_improver = self_improver
        
        self.logger.debug("Learning components set")
    
    async def process_trading_outcome(self, decision, outcome_data: Dict[str, Any]):
        """
        Process a trading outcome and trigger learning activities.
        
        Args:
            decision: GemmaDecision object
            outcome_data: Trading outcome data
        """
        try:
            if not self.learning_active:
                return
            
            with TimedOperation(self.perf_logger, "trading_outcome_processing"):
                # Create feedback analysis task
                feedback_task = LearningTask(
                    task_id=f"feedback_{decision.decision_id}_{int(time.time())}",
                    task_type="feedback_analysis",
                    priority=LearningPriority.HIGH,
                    component="feedback_analyzer",
                    data={
                        "decision": decision,
                        "outcome_data": outcome_data
                    },
                    created_at=datetime.now(),
                    scheduled_at=None,
                    completed_at=None,
                    status="pending",
                    results={}
                )
                
                await self._schedule_learning_task(feedback_task)
                
                self.logger.learning("Trading outcome queued for learning", {
                    "decision_id": decision.decision_id,
                    "task_id": feedback_task.task_id
                })
                
        except Exception as e:
            self.logger.error("Error processing trading outcome", exception=e)
    
    async def trigger_improvement_cycle(self, insights_data: Dict[str, Any]):
        """
        Trigger an improvement cycle based on accumulated insights.
        
        Args:
            insights_data: Accumulated learning insights
        """
        try:
            if not self.learning_active:
                return
            
            # Create improvement analysis task
            improvement_task = LearningTask(
                task_id=f"improvement_{int(time.time())}",
                task_type="improvement_analysis",
                priority=LearningPriority.MEDIUM,
                component="self_improver",
                data=insights_data,
                created_at=datetime.now(),
                scheduled_at=None,
                completed_at=None,
                status="pending",
                results={}
            )
            
            await self._schedule_learning_task(improvement_task)
            
            self.logger.learning("Improvement cycle triggered", {
                "task_id": improvement_task.task_id,
                "insights_count": len(insights_data.get("insights", []))
            })
            
        except Exception as e:
            self.logger.error("Error triggering improvement cycle", exception=e)
    
    async def evaluate_learning_progress(self) -> LearningMetrics:
        """
        Evaluate current learning progress and system performance.
        
        Returns:
            LearningMetrics with current performance data
        """
        try:
            with TimedOperation(self.perf_logger, "learning_progress_evaluation"):
                # Calculate performance improvements
                current_performance = await self._calculate_current_performance()
                baseline_performance = self.performance_baseline or current_performance
                
                # Calculate learning metrics
                metrics = LearningMetrics(
                    timestamp=datetime.now(),
                    learning_phase=self.current_phase,
                    strategy=self.current_strategy,
                    accuracy_improvement=self._calculate_accuracy_improvement(
                        current_performance, baseline_performance
                    ),
                    confidence_calibration=self._calculate_confidence_calibration(),
                    risk_reduction=self._calculate_risk_reduction(
                        current_performance, baseline_performance
                    ),
                    profit_improvement=self._calculate_profit_improvement(
                        current_performance, baseline_performance
                    ),
                    learning_rate=self._calculate_learning_rate(),
                    adaptation_speed=self._calculate_adaptation_speed(),
                    knowledge_retention=self._calculate_knowledge_retention(),
                    stability_score=self._calculate_stability_score(),
                    error_rate=self._calculate_error_rate(),
                    rollback_frequency=self._calculate_rollback_frequency()
                )
                
                # Store metrics
                self.learning_metrics.append(metrics)
                self.last_evaluation = datetime.now()
                
                # Trigger strategy adaptation if needed
                await self._adapt_learning_strategy(metrics)
                
                self.logger.learning("Learning progress evaluated", {
                    "accuracy_improvement": metrics.accuracy_improvement,
                    "learning_rate": metrics.learning_rate,
                    "stability_score": metrics.stability_score
                })
                
                return metrics
                
        except Exception as e:
            self.logger.error("Error evaluating learning progress", exception=e)
            return self._create_default_metrics()
    
    async def adapt_learning_strategy(self, performance_data: Dict[str, Any]):
        """
        Adapt the learning strategy based on performance data.
        
        Args:
            performance_data: Current performance metrics
        """
        try:
            current_strategy = self.current_strategy
            
            # Analyze performance trends
            if len(self.learning_metrics) >= 3:
                recent_metrics = list(self.learning_metrics)[-3:]
                
                # Check for declining performance
                accuracy_trend = [m.accuracy_improvement for m in recent_metrics]
                stability_trend = [m.stability_score for m in recent_metrics]
                
                if self._is_declining_trend(accuracy_trend) or self._is_declining_trend(stability_trend):
                    # Switch to more conservative strategy
                    if self.current_strategy == LearningStrategy.AGGRESSIVE:
                        self.current_strategy = LearningStrategy.BALANCED
                    elif self.current_strategy == LearningStrategy.BALANCED:
                        self.current_strategy = LearningStrategy.CONSERVATIVE
                
                # Check for stable good performance
                elif all(a > 0.1 for a in accuracy_trend) and all(s > 0.8 for s in stability_trend):
                    # Can be more aggressive
                    if self.current_strategy == LearningStrategy.CONSERVATIVE:
                        self.current_strategy = LearningStrategy.BALANCED
                    elif self.current_strategy == LearningStrategy.BALANCED:
                        self.current_strategy = LearningStrategy.AGGRESSIVE
            
            if current_strategy != self.current_strategy:
                self.learning_stats["strategy_changes"] += 1
                
                self.logger.learning("Learning strategy adapted", {
                    "old_strategy": current_strategy.value,
                    "new_strategy": self.current_strategy.value,
                    "reason": "performance_based_adaptation"
                })
                
                # Update learning configuration based on new strategy
                await self._update_learning_config()
            
        except Exception as e:
            self.logger.error("Error adapting learning strategy", exception=e)
    
    async def transition_learning_phase(self, new_phase: LearningPhase, reason: str = "automatic"):
        """
        Transition to a new learning phase.
        
        Args:
            new_phase: Target learning phase
            reason: Reason for transition
        """
        try:
            old_phase = self.current_phase
            self.current_phase = new_phase
            self.learning_stats["phase_transitions"] += 1
            
            # Update configuration for new phase
            await self._configure_for_phase(new_phase)
            
            self.logger.learning("Learning phase transitioned", {
                "old_phase": old_phase.value,
                "new_phase": new_phase.value,
                "reason": reason
            })
            
        except Exception as e:
            self.logger.error("Error transitioning learning phase", exception=e)
    
    async def _learning_cycle_manager(self):
        """Main learning cycle management loop."""
        try:
            while self.learning_active:
                try:
                    # Process pending learning tasks
                    await self._process_learning_tasks()
                    
                    # Periodic evaluations based on current strategy
                    current_time = datetime.now()
                    
                    # Check if it's time for performance evaluation
                    if (not self.last_evaluation or 
                        (current_time - self.last_evaluation).total_seconds() >= 
                        self.learning_config["performance_evaluation_interval"]):
                        
                        await self.evaluate_learning_progress()
                    
                    # Sleep based on current strategy
                    sleep_time = self._get_cycle_sleep_time()
                    await asyncio.sleep(sleep_time)
                    
                except Exception as e:
                    self.logger.error("Error in learning cycle", exception=e)
                    await asyncio.sleep(60)  # Wait before retrying
                    
        except Exception as e:
            self.logger.error("Learning cycle manager stopped", exception=e)
    
    async def _process_learning_tasks(self):
        """Process pending learning tasks."""
        try:
            # Get tasks to process (prioritized)
            tasks_to_process = self._get_prioritized_tasks()
            
            for task in tasks_to_process[:5]:  # Process up to 5 tasks per cycle
                try:
                    await self._execute_learning_task(task)
                except Exception as e:
                    self.logger.error("Error executing learning task", {
                        "task_id": task.task_id,
                        "error": str(e)
                    })
                    task.status = "failed"
                    task.results = {"error": str(e)}
                    task.completed_at = datetime.now()
                    
                    # Move to completed tasks
                    if task.task_id in self.active_tasks:
                        del self.active_tasks[task.task_id]
                    self.completed_tasks.append(task)
            
        except Exception as e:
            self.logger.error("Error processing learning tasks", exception=e)
    
    async def _execute_learning_task(self, task: LearningTask):
        """Execute a specific learning task."""
        try:
            task.status = "executing"
            start_time = time.time()
            
            if task.task_type == "feedback_analysis":
                await self._execute_feedback_analysis_task(task)
            elif task.task_type == "improvement_analysis":
                await self._execute_improvement_analysis_task(task)
            elif task.task_type == "performance_evaluation":
                await self._execute_performance_evaluation_task(task)
            else:
                raise ValueError(f"Unknown task type: {task.task_type}")
            
            # Mark as completed
            task.status = "completed"
            task.completed_at = datetime.now()
            execution_time = time.time() - start_time
            task.results["execution_time"] = execution_time
            
            # Update statistics
            self.learning_stats["total_learning_cycles"] += 1
            self.learning_stats["total_learning_time"] += execution_time
            
            # Move to completed tasks
            if task.task_id in self.active_tasks:
                del self.active_tasks[task.task_id]
            self.completed_tasks.append(task)
            
            self.logger.debug("Learning task completed", {
                "task_id": task.task_id,
                "task_type": task.task_type,
                "execution_time": execution_time
            })
            
        except Exception as e:
            self.logger.error("Error executing learning task", exception=e)
            raise
    
    async def _execute_feedback_analysis_task(self, task: LearningTask):
        """Execute a feedback analysis task."""
        if not self.feedback_analyzer:
            raise ValueError("Feedback analyzer not available")
        
        decision = task.data["decision"]
        outcome_data = task.data["outcome_data"]
        
        # Process feedback through analyzer
        insights = await self.feedback_analyzer.process_feedback(decision, outcome_data)
        
        task.results = {
            "insights": insights.to_dict(),
            "recommendations": insights.actionable_recommendations,
            "confidence": insights.confidence
        }
        
        # If insights suggest improvements, trigger improvement cycle
        if insights.actionable_recommendations and insights.confidence > 0.6:
            await self.trigger_improvement_cycle({"insights": [insights.to_dict()]})
    
    async def _execute_improvement_analysis_task(self, task: LearningTask):
        """Execute an improvement analysis task."""
        if not self.self_improver:
            raise ValueError("Self improver not available")
        
        insights_data = task.data
        
        # Analyze improvement opportunities
        modifications = []
        for insight_data in insights_data.get("insights", []):
            # Convert dict back to FeedbackInsights-like object
            insight_obj = type('FeedbackInsights', (), insight_data)()
            mods = await self.self_improver.analyze_improvement_opportunities(insight_obj)
            modifications.extend(mods)
        
        task.results = {
            "modifications_proposed": len(modifications),
            "high_confidence_modifications": len([m for m in modifications if m.confidence > 0.8]),
            "modifications": [m.to_dict() for m in modifications]
        }
        
        # Propose modifications
        for modification in modifications:
            success = await self.self_improver.propose_modification(modification)
            if success:
                self.learning_stats["successful_improvements"] += 1
            else:
                self.learning_stats["failed_improvements"] += 1
    
    async def _execute_performance_evaluation_task(self, task: LearningTask):
        """Execute a performance evaluation task."""
        metrics = await self.evaluate_learning_progress()
        
        task.results = {
            "metrics": metrics.to_dict(),
            "evaluation_timestamp": datetime.now().isoformat()
        }
    
    async def _schedule_learning_task(self, task: LearningTask):
        """Schedule a learning task for execution."""
        self.learning_tasks.append(task)
        self.active_tasks[task.task_id] = task
        
        self.logger.debug("Learning task scheduled", {
            "task_id": task.task_id,
            "task_type": task.task_type,
            "priority": task.priority.value
        })
    
    def _get_prioritized_tasks(self) -> List[LearningTask]:
        """Get learning tasks sorted by priority."""
        pending_tasks = [task for task in self.active_tasks.values() if task.status == "pending"]
        
        # Sort by priority (critical first) and creation time
        priority_order = {
            LearningPriority.CRITICAL: 0,
            LearningPriority.HIGH: 1,
            LearningPriority.MEDIUM: 2,
            LearningPriority.LOW: 3
        }
        
        return sorted(pending_tasks, key=lambda t: (priority_order[t.priority], t.created_at))
    
    def _get_cycle_sleep_time(self) -> float:
        """Get sleep time between learning cycles based on strategy."""
        base_sleep = {
            LearningStrategy.AGGRESSIVE: 30,    # 30 seconds
            LearningStrategy.BALANCED: 60,      # 1 minute
            LearningStrategy.CONSERVATIVE: 120, # 2 minutes
            LearningStrategy.ADAPTIVE: 60       # 1 minute
        }
        
        return base_sleep.get(self.current_strategy, 60)
    
    async def _calculate_current_performance(self) -> Dict[str, float]:
        """Calculate current system performance metrics."""
        try:
            # Get recent trading data
            recent_trades = db_manager.get_trades(limit=50)
            
            if not recent_trades:
                return {"accuracy": 0.5, "profit": 0.0, "risk": 1.0}
            
            # Calculate basic metrics
            winning_trades = [t for t in recent_trades if t.get("pnl", 0) > 0]
            accuracy = len(winning_trades) / len(recent_trades)
            
            total_pnl = sum(t.get("pnl", 0) for t in recent_trades)
            avg_profit = total_pnl / len(recent_trades)
            
            # Calculate risk metrics
            losses = [t.get("pnl", 0) for t in recent_trades if t.get("pnl", 0) < 0]
            avg_loss = abs(statistics.mean(losses)) if losses else 0
            
            return {
                "accuracy": accuracy,
                "profit": avg_profit,
                "risk": avg_loss
            }
            
        except Exception as e:
            self.logger.error("Error calculating current performance", exception=e)
            return {"accuracy": 0.5, "profit": 0.0, "risk": 1.0}
    
    def _calculate_accuracy_improvement(self, current: Dict[str, float], baseline: Dict[str, float]) -> float:
        """Calculate accuracy improvement over baseline."""
        current_acc = current.get("accuracy", 0.5)
        baseline_acc = baseline.get("accuracy", 0.5)
        return current_acc - baseline_acc
    
    def _calculate_confidence_calibration(self) -> float:
        """Calculate confidence calibration score."""
        # This would analyze how well confidence predictions match actual outcomes
        # Simplified implementation
        return 0.75
    
    def _calculate_risk_reduction(self, current: Dict[str, float], baseline: Dict[str, float]) -> float:
        """Calculate risk reduction compared to baseline."""
        current_risk = current.get("risk", 1.0)
        baseline_risk = baseline.get("risk", 1.0)
        return baseline_risk - current_risk
    
    def _calculate_profit_improvement(self, current: Dict[str, float], baseline: Dict[str, float]) -> float:
        """Calculate profit improvement over baseline."""
        current_profit = current.get("profit", 0.0)
        baseline_profit = baseline.get("profit", 0.0)
        return current_profit - baseline_profit
    
    def _calculate_learning_rate(self) -> float:
        """Calculate current learning rate."""
        if len(self.learning_metrics) < 2:
            return 0.0
        
        recent_improvements = [m.accuracy_improvement for m in list(self.learning_metrics)[-5:]]
        return statistics.mean(recent_improvements) if recent_improvements else 0.0
    
    def _calculate_adaptation_speed(self) -> float:
        """Calculate adaptation speed metric."""
        # Based on how quickly the system responds to changes
        return 0.6  # Simplified
    
    def _calculate_knowledge_retention(self) -> float:
        """Calculate knowledge retention score."""
        # Based on consistency of improvements over time
        return 0.8  # Simplified
    
    def _calculate_stability_score(self) -> float:
        """Calculate system stability score."""
        if not self.self_improver:
            return 1.0
        
        stats = self.self_improver.get_improvement_statistics()
        total_mods = stats.get("successful_modifications", 0) + stats.get("failed_modifications", 0)
        
        if total_mods == 0:
            return 1.0
        
        success_rate = stats.get("successful_modifications", 0) / total_mods
        rollback_rate = stats.get("rollbacks_performed", 0) / total_mods
        
        return success_rate * (1 - rollback_rate)
    
    def _calculate_error_rate(self) -> float:
        """Calculate current error rate."""
        completed_tasks = len(self.completed_tasks)
        if completed_tasks == 0:
            return 0.0
        
        failed_tasks = len([t for t in self.completed_tasks if t.status == "failed"])
        return failed_tasks / completed_tasks
    
    def _calculate_rollback_frequency(self) -> float:
        """Calculate rollback frequency."""
        if not self.self_improver:
            return 0.0
        
        stats = self.self_improver.get_improvement_statistics()
        return stats.get("rollbacks_performed", 0) / max(1, stats.get("total_modifications", 1))
    
    def _is_declining_trend(self, values: List[float]) -> bool:
        """Check if values show a declining trend."""
        if len(values) < 2:
            return False
        
        # Simple trend check - more sophisticated analysis could be implemented
        return values[-1] < values[0] and all(values[i] <= values[i-1] for i in range(1, len(values)))
    
    async def _adapt_learning_strategy(self, metrics: LearningMetrics):
        """Adapt learning strategy based on metrics."""
        try:
            # Check if strategy adaptation is needed
            if metrics.stability_score < 0.5 or metrics.error_rate > 0.3:
                # System is unstable, be more conservative
                if self.current_strategy != LearningStrategy.CONSERVATIVE:
                    await self.adapt_learning_strategy(metrics.to_dict())
            
            elif metrics.accuracy_improvement > 0.1 and metrics.stability_score > 0.8:
                # System is performing well, can be more aggressive
                if self.current_strategy == LearningStrategy.CONSERVATIVE:
                    self.current_strategy = LearningStrategy.BALANCED
                elif self.current_strategy == LearningStrategy.BALANCED:
                    self.current_strategy = LearningStrategy.AGGRESSIVE
                
                await self._update_learning_config()
            
        except Exception as e:
            self.logger.error("Error adapting learning strategy", exception=e)
    
    async def _update_learning_config(self):
        """Update learning configuration based on current strategy."""
        try:
            if self.current_strategy == LearningStrategy.CONSERVATIVE:
                self.learning_config.update({
                    "max_concurrent_improvements": 1,
                    "min_confidence_threshold": 0.8,
                    "rollback_threshold": 0.2
                })
            elif self.current_strategy == LearningStrategy.BALANCED:
                self.learning_config.update({
                    "max_concurrent_improvements": 3,
                    "min_confidence_threshold": 0.6,
                    "rollback_threshold": 0.3
                })
            elif self.current_strategy == LearningStrategy.AGGRESSIVE:
                self.learning_config.update({
                    "max_concurrent_improvements": 5,
                    "min_confidence_threshold": 0.5,
                    "rollback_threshold": 0.4
                })
            
            self.logger.debug("Learning configuration updated", {
                "strategy": self.current_strategy.value,
                "config": self.learning_config
            })
            
        except Exception as e:
            self.logger.error("Error updating learning config", exception=e)
    
    async def _configure_for_phase(self, phase: LearningPhase):
        """Configure system for specific learning phase."""
        try:
            if phase == LearningPhase.INITIALIZATION:
                self.current_strategy = LearningStrategy.CONSERVATIVE
            elif phase == LearningPhase.EXPLORATION:
                self.current_strategy = LearningStrategy.BALANCED
            elif phase == LearningPhase.EXPLOITATION:
                self.current_strategy = LearningStrategy.AGGRESSIVE
            elif phase == LearningPhase.ADAPTATION:
                self.current_strategy = LearningStrategy.ADAPTIVE
            
            await self._update_learning_config()
            
        except Exception as e:
            self.logger.error("Error configuring for phase", exception=e)
    
    async def _load_learning_history(self):
        """Load learning history from database."""
        try:
            # Load learning metrics history
            learning_data = db_manager.get_learning_data(
                category="learning_metrics",
                limit=50
            )
            
            # Load completed tasks
            task_data = db_manager.get_learning_data(
                category="learning_tasks",
                limit=100
            )
            
            self.logger.debug(f"Loaded learning history: {len(learning_data)} metrics, {len(task_data)} tasks")
            
        except Exception as e:
            self.logger.error("Error loading learning history", exception=e)
    
    async def _establish_performance_baseline(self):
        """Establish initial performance baseline."""
        try:
            self.performance_baseline = await self._calculate_current_performance()
            
            self.logger.system("Performance baseline established", {
                "baseline": self.performance_baseline
            })
            
        except Exception as e:
            self.logger.error("Error establishing performance baseline", exception=e)
    
    def _create_default_metrics(self) -> LearningMetrics:
        """Create default learning metrics."""
        return LearningMetrics(
            timestamp=datetime.now(),
            learning_phase=self.current_phase,
            strategy=self.current_strategy,
            accuracy_improvement=0.0,
            confidence_calibration=0.5,
            risk_reduction=0.0,
            profit_improvement=0.0,
            learning_rate=0.0,
            adaptation_speed=0.0,
            knowledge_retention=0.5,
            stability_score=1.0,
            error_rate=0.0,
            rollback_frequency=0.0
        )
    
    def get_learning_statistics(self) -> Dict[str, Any]:
        """Get comprehensive learning
statistics."""
        stats = self.learning_stats.copy()
        
        # Add current state information
        stats["current_phase"] = self.current_phase.value
        stats["current_strategy"] = self.current_strategy.value
        stats["learning_active"] = self.learning_active
        stats["active_tasks_count"] = len(self.active_tasks)
        stats["completed_tasks_count"] = len(self.completed_tasks)
        
        # Add recent performance metrics
        if self.learning_metrics:
            recent_metric = self.learning_metrics[-1]
            stats["latest_metrics"] = recent_metric.to_dict()
        
        # Calculate derived statistics
        if stats["total_learning_cycles"] > 0:
            stats["average_learning_rate"] = (
                stats["total_learning_time"] / stats["total_learning_cycles"]
            )
            
            improvement_rate = (
                stats["successful_improvements"] / 
                max(1, stats["successful_improvements"] + stats["failed_improvements"])
            )
            stats["improvement_success_rate"] = improvement_rate
        
        # Add configuration information
        stats["learning_config"] = self.learning_config.copy()
        
        return stats
    
    async def shutdown(self):
        """Shutdown the learning engine gracefully."""
        try:
            self.learning_active = False
            
            # Complete any critical tasks
            critical_tasks = [
                task for task in self.active_tasks.values() 
                if task.priority == LearningPriority.CRITICAL and task.status == "executing"
            ]
            
            if critical_tasks:
                self.logger.system(f"Waiting for {len(critical_tasks)} critical tasks to complete")
                # Wait up to 30 seconds for critical tasks
                for _ in range(30):
                    if not any(task.status == "executing" for task in critical_tasks):
                        break
                    await asyncio.sleep(1)
            
            # Save current state
            await self._save_learning_state()
            
            self.logger.system("Learning Engine shutdown complete")
            
        except Exception as e:
            self.logger.error("Error during learning engine shutdown", exception=e)
    
    async def _save_learning_state(self):
        """Save current learning state to database."""
        try:
            # Save learning metrics
            if self.learning_metrics:
                latest_metrics = self.learning_metrics[-1]
                db_manager.insert_learning_data({
                    "category": "learning_metrics",
                    "data": latest_metrics.to_dict(),
                    "timestamp": datetime.now().isoformat()
                })
            
            # Save learning statistics
            db_manager.insert_learning_data({
                "category": "learning_statistics",
                "data": self.get_learning_statistics(),
                "timestamp": datetime.now().isoformat()
            })
            
            self.logger.debug("Learning state saved to database")
            
        except Exception as e:
            self.logger.error("Error saving learning state", exception=e)