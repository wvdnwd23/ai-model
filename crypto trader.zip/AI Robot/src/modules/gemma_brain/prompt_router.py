"""
Prompt Router - Intelligent model selection and prompt routing for Gemma Brain.

This module implements intelligent routing of prompts to optimal AI models based on:
- Task complexity analysis
- Model specialization matching
- Performance history tracking
- Cost optimization
- Latency requirements
"""

import asyncio
import json
import time
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
from collections import defaultdict, deque
import hashlib

from src.utils.openrouter_client import openrouter_client, ModelType, TaskType, APIResponse
from src.utils.logging import get_logger, get_performance_logger, TimedOperation
from src.utils.config import config_manager

class RoutingStrategy(Enum):
    """Routing strategies for model selection."""
    PERFORMANCE_BASED = "performance_based"
    COST_OPTIMIZED = "cost_optimized"
    LATENCY_OPTIMIZED = "latency_optimized"
    BALANCED = "balanced"
    CONSERVATIVE = "conservative"

class TaskComplexity(Enum):
    """Task complexity levels."""
    SIMPLE = "simple"
    MODERATE = "moderate"
    COMPLEX = "complex"
    CRITICAL = "critical"

@dataclass
class ModelPerformance:
    """Performance metrics for a specific model."""
    model_type: ModelType
    total_requests: int = 0
    successful_requests: int = 0
    average_response_time: float = 0.0
    average_confidence: float = 0.0
    total_cost: float = 0.0
    error_rate: float = 0.0
    last_used: Optional[datetime] = None
    specialization_scores: Dict[str, float] = None
    
    def __post_init__(self):
        if self.specialization_scores is None:
            self.specialization_scores = defaultdict(float)
    
    @property
    def success_rate(self) -> float:
        """Calculate success rate."""
        if self.total_requests == 0:
            return 0.0
        return self.successful_requests / self.total_requests
    
    @property
    def cost_per_success(self) -> float:
        """Calculate cost per successful request."""
        if self.successful_requests == 0:
            return float('inf')
        return self.total_cost / self.successful_requests

@dataclass
class RoutingDecision:
    """Represents a routing decision made by the router."""
    selected_model: ModelType
    fallback_models: List[ModelType]
    routing_strategy: RoutingStrategy
    confidence: float
    reasoning: str
    estimated_cost: float
    estimated_time: float
    task_complexity: TaskComplexity

class ModelSelector:
    """
    Intelligent model selector that chooses optimal models based on various criteria.
    """
    
    def __init__(self, parent_brain):
        self.parent_brain = parent_brain
        self.logger = get_logger("model_selector")
        
        # Model performance tracking
        self.model_performance: Dict[ModelType, ModelPerformance] = {}
        self._initialize_model_performance()
        
        # Task-to-model specialization mapping
        self.specialization_matrix = {
            "sentiment_analysis": {
                ModelType.GEMMA_2_2B_IT: 0.9,
                ModelType.GPT_4O: 0.7,
                ModelType.CLAUDE_3_5_SONNET: 0.6,
                ModelType.GEMMA_LOCAL: 0.8
            },
            "technical_analysis": {
                ModelType.GPT_4O: 0.95,
                ModelType.CLAUDE_3_5_SONNET: 0.8,
                ModelType.GEMMA_2_2B_IT: 0.6,
                ModelType.GEMMA_LOCAL: 0.7
            },
            "risk_assessment": {
                ModelType.CLAUDE_3_5_SONNET: 0.95,
                ModelType.GPT_4O: 0.8,
                ModelType.GEMMA_2_2B_IT: 0.5,
                ModelType.GEMMA_LOCAL: 0.6
            },
            "data_synthesis": {
                ModelType.GPT_4O: 0.9,
                ModelType.CLAUDE_3_5_SONNET: 0.85,
                ModelType.GEMMA_2_2B_IT: 0.7,
                ModelType.GEMMA_LOCAL: 0.75
            },
            "coordination": {
                ModelType.GEMMA_LOCAL: 0.9,
                ModelType.GEMMA_2_2B_IT: 0.8,
                ModelType.GPT_4O: 0.7,
                ModelType.CLAUDE_3_5_SONNET: 0.6
            }
        }
        
        # Recent performance tracking
        self.recent_decisions: deque = deque(maxlen=100)
        
    def _initialize_model_performance(self):
        """Initialize performance tracking for all models."""
        for model_type in ModelType:
            self.model_performance[model_type] = ModelPerformance(model_type=model_type)
    
    def select_optimal_model(self, task_type: str, context: Dict[str, Any], 
                           strategy: RoutingStrategy = RoutingStrategy.BALANCED,
                           force_model: Optional[ModelType] = None) -> RoutingDecision:
        """
        Select the optimal model for a given task.
        
        Args:
            task_type: Type of task (e.g., 'sentiment_analysis', 'technical_analysis')
            context: Context data for the task
            strategy: Routing strategy to use
            force_model: Force selection of specific model
            
        Returns:
            RoutingDecision with selected model and metadata
        """
        try:
            # Handle forced model selection
            if force_model:
                return RoutingDecision(
                    selected_model=force_model,
                    fallback_models=self._get_fallback_models(force_model, task_type),
                    routing_strategy=strategy,
                    confidence=1.0,
                    reasoning=f"Forced selection of {force_model.value}",
                    estimated_cost=self._estimate_cost(force_model, context),
                    estimated_time=self._estimate_time(force_model, context),
                    task_complexity=self._assess_task_complexity(context)
                )
            
            # Assess task complexity
            complexity = self._assess_task_complexity(context)
            
            # Get candidate models
            candidates = self._get_candidate_models(task_type, complexity)
            
            # Score models based on strategy
            model_scores = self._score_models(candidates, task_type, context, strategy, complexity)
            
            # Select best model
            selected_model = max(model_scores.keys(), key=lambda m: model_scores[m])
            
            # Get fallback models
            fallback_models = self._get_fallback_models(selected_model, task_type)
            
            # Calculate confidence
            confidence = self._calculate_selection_confidence(selected_model, model_scores, task_type)
            
            # Generate reasoning
            reasoning = self._generate_selection_reasoning(
                selected_model, task_type, strategy, complexity, model_scores
            )
            
            decision = RoutingDecision(
                selected_model=selected_model,
                fallback_models=fallback_models,
                routing_strategy=strategy,
                confidence=confidence,
                reasoning=reasoning,
                estimated_cost=self._estimate_cost(selected_model, context),
                estimated_time=self._estimate_time(selected_model, context),
                task_complexity=complexity
            )
            
            self.logger.decision("Model selected", {
                "selected_model": selected_model.value,
                "task_type": task_type,
                "strategy": strategy.value,
                "confidence": confidence,
                "complexity": complexity.value
            })
            
            return decision
            
        except Exception as e:
            self.logger.error("Error in model selection", exception=e)
            
            # Return safe fallback
            return RoutingDecision(
                selected_model=ModelType.GEMMA_LOCAL,
                fallback_models=[],
                routing_strategy=strategy,
                confidence=0.5,
                reasoning=f"Error in selection, using fallback: {str(e)}",
                estimated_cost=0.0,
                estimated_time=5.0,
                task_complexity=TaskComplexity.SIMPLE
            )
    
    def _assess_task_complexity(self, context: Dict[str, Any]) -> TaskComplexity:
        """Assess the complexity of a task based on context."""
        try:
            complexity_indicators = {
                "data_size": len(str(context)),
                "nested_objects": self._count_nested_objects(context),
                "time_sensitivity": context.get("time_sensitive", False),
                "critical_decision": context.get("critical", False),
                "multi_step": context.get("multi_step", False)
            }
            
            # Calculate complexity score
            score = 0
            
            # Data size factor
            if complexity_indicators["data_size"] > 5000:
                score += 2
            elif complexity_indicators["data_size"] > 2000:
                score += 1
            
            # Nested complexity
            if complexity_indicators["nested_objects"] > 5:
                score += 2
            elif complexity_indicators["nested_objects"] > 2:
                score += 1
            
            # Boolean factors
            if complexity_indicators["time_sensitivity"]:
                score += 1
            if complexity_indicators["critical_decision"]:
                score += 2
            if complexity_indicators["multi_step"]:
                score += 1
            
            # Map score to complexity level
            if score >= 6:
                return TaskComplexity.CRITICAL
            elif score >= 4:
                return TaskComplexity.COMPLEX
            elif score >= 2:
                return TaskComplexity.MODERATE
            else:
                return TaskComplexity.SIMPLE
                
        except Exception as e:
            self.logger.error("Error assessing task complexity", exception=e)
            return TaskComplexity.MODERATE
    
    def _count_nested_objects(self, obj: Any, depth: int = 0) -> int:
        """Count nested objects in data structure."""
        if depth > 10:  # Prevent infinite recursion
            return 0
        
        count = 0
        if isinstance(obj, dict):
            count += 1
            for value in obj.values():
                count += self._count_nested_objects(value, depth + 1)
        elif isinstance(obj, list):
            for item in obj:
                count += self._count_nested_objects(item, depth + 1)
        
        return count
    
    def _get_candidate_models(self, task_type: str, complexity: TaskComplexity) -> List[ModelType]:
        """Get candidate models for a task type and complexity."""
        # Base candidates from specialization matrix
        if task_type in self.specialization_matrix:
            candidates = list(self.specialization_matrix[task_type].keys())
        else:
            candidates = list(ModelType)
        
        # Filter based on complexity
        if complexity == TaskComplexity.CRITICAL:
            # For critical tasks, prefer more powerful models
            candidates = [m for m in candidates if m in [
                ModelType.GPT_4O, ModelType.CLAUDE_3_5_SONNET, ModelType.GEMMA_LOCAL
            ]]
        elif complexity == TaskComplexity.SIMPLE:
            # For simple tasks, prefer faster/cheaper models
            candidates = [m for m in candidates if m in [
                ModelType.GEMMA_2_2B_IT, ModelType.GEMMA_LOCAL
            ]]
        
        # Ensure we always have at least one candidate
        if not candidates:
            candidates = [ModelType.GEMMA_LOCAL]
        
        return candidates
    
    def _score_models(self, candidates: List[ModelType], task_type: str, 
                     context: Dict[str, Any], strategy: RoutingStrategy,
                     complexity: TaskComplexity) -> Dict[ModelType, float]:
        """Score candidate models based on strategy and performance."""
        scores = {}
        
        for model in candidates:
            performance = self.model_performance[model]
            
            # Base specialization score
            specialization_score = self.specialization_matrix.get(task_type, {}).get(model, 0.5)
            
            # Performance-based factors
            success_rate = performance.success_rate if performance.total_requests > 0 else 0.5
            response_time = performance.average_response_time if performance.average_response_time > 0 else 5.0
            cost_efficiency = 1.0 / (performance.cost_per_success + 0.001)  # Avoid division by zero
            
            # Strategy-specific scoring
            if strategy == RoutingStrategy.PERFORMANCE_BASED:
                score = (specialization_score * 0.4 + 
                        success_rate * 0.4 + 
                        (1.0 / (response_time + 1.0)) * 0.2)
            
            elif strategy == RoutingStrategy.COST_OPTIMIZED:
                score = (cost_efficiency * 0.5 + 
                        specialization_score * 0.3 + 
                        success_rate * 0.2)
            
            elif strategy == RoutingStrategy.LATENCY_OPTIMIZED:
                score = ((1.0 / (response_time + 1.0)) * 0.5 + 
                        specialization_score * 0.3 + 
                        success_rate * 0.2)
            
            elif strategy == RoutingStrategy.CONSERVATIVE:
                # Prefer local models and proven performers
                local_bonus = 0.3 if model == ModelType.GEMMA_LOCAL else 0.0
                score = (success_rate * 0.4 + 
                        specialization_score * 0.3 + 
                        local_bonus * 0.3)
            
            else:  # BALANCED
                score = (specialization_score * 0.3 + 
                        success_rate * 0.25 + 
                        (1.0 / (response_time + 1.0)) * 0.2 + 
                        cost_efficiency * 0.25)
            
            # Complexity adjustments
            if complexity == TaskComplexity.CRITICAL:
                if model in [ModelType.GPT_4O, ModelType.CLAUDE_3_5_SONNET]:
                    score *= 1.2  # Boost powerful models for critical tasks
            elif complexity == TaskComplexity.SIMPLE:
                if model in [ModelType.GEMMA_2_2B_IT, ModelType.GEMMA_LOCAL]:
                    score *= 1.1  # Boost efficient models for simple tasks
            
            scores[model] = max(0.0, min(1.0, score))  # Clamp to [0, 1]
        
        return scores
    
    def _get_fallback_models(self, primary_model: ModelType, task_type: str) -> List[ModelType]:
        """Get fallback models for a primary model selection."""
        fallbacks = []
        
        # Always include local fallback
        if primary_model != ModelType.GEMMA_LOCAL:
            fallbacks.append(ModelType.GEMMA_LOCAL)
        
        # Add task-specific fallbacks
        if task_type in self.specialization_matrix:
            specialized_models = sorted(
                self.specialization_matrix[task_type].items(),
                key=lambda x: x[1],
                reverse=True
            )
            
            for model, score in specialized_models:
                if model != primary_model and model not in fallbacks and len(fallbacks) < 3:
                    fallbacks.append(model)
        
        return fallbacks
    
    def _calculate_selection_confidence(self, selected_model: ModelType, 
                                      model_scores: Dict[ModelType, float],
                                      task_type: str) -> float:
        """Calculate confidence in model selection."""
        try:
            selected_score = model_scores[selected_model]
            
            # If only one model, confidence is based on its score
            if len(model_scores) == 1:
                return selected_score
            
            # Calculate margin over second-best
            sorted_scores = sorted(model_scores.values(), reverse=True)
            if len(sorted_scores) > 1:
                margin = sorted_scores[0] - sorted_scores[1]
                confidence = selected_score + (margin * 0.5)
            else:
                confidence = selected_score
            
            # Adjust based on model's historical performance
            performance = self.model_performance[selected_model]
            if performance.total_requests > 10:
                confidence *= (0.5 + performance.success_rate * 0.5)
            
            return max(0.0, min(1.0, confidence))
            
        except Exception as e:
            self.logger.error("Error calculating selection confidence", exception=e)
            return 0.5
    
    def _generate_selection_reasoning(self, selected_model: ModelType, task_type: str,
                                    strategy: RoutingStrategy, complexity: TaskComplexity,
                                    model_scores: Dict[ModelType, float]) -> str:
        """Generate human-readable reasoning for model selection."""
        try:
            performance = self.model_performance[selected_model]
            selected_score = model_scores[selected_model]
            
            reasoning_parts = [
                f"Selected {selected_model.value} for {task_type}",
                f"Strategy: {strategy.value}",
                f"Task complexity: {complexity.value}",
                f"Selection score: {selected_score:.3f}"
            ]
            
            # Add performance context
            if performance.total_requests > 0:
                reasoning_parts.append(
                    f"Historical success rate: {performance.success_rate:.2%}"
                )
            
            # Add specialization context
            if task_type in self.specialization_matrix:
                spec_score = self.specialization_matrix[task_type].get(selected_model, 0.0)
                reasoning_parts.append(f"Specialization score: {spec_score:.3f}")
            
            return "; ".join(reasoning_parts)
            
        except Exception as e:
            return f"Model selection reasoning generation failed: {str(e)}"
    
    def _estimate_cost(self, model: ModelType, context: Dict[str, Any]) -> float:
        """Estimate cost for using a model with given context."""
        try:
            # Get model config from openrouter client
            model_config = openrouter_client.model_configs.get(model)
            if not model_config:
                return 0.0
            
            # Estimate tokens based on context size
            context_size = len(str(context))
            estimated_tokens = max(100, context_size // 3)  # Rough estimation
            
            return estimated_tokens * model_config.cost_per_1k_tokens / 1000
            
        except Exception as e:
            self.logger.error("Error estimating cost", exception=e)
            return 0.001  # Small default cost
    
    def _estimate_time(self, model: ModelType, context: Dict[str, Any]) -> float:
        """Estimate response time for using a model with given context."""
        try:
            performance = self.model_performance[model]
            
            if performance.average_response_time > 0:
                base_time = performance.average_response_time
            else:
                # Default estimates based on model type
                default_times = {
                    ModelType.GEMMA_2_2B_IT: 2.0,
                    ModelType.GPT_4O: 5.0,
                    ModelType.CLAUDE_3_5_SONNET: 7.0,
                    ModelType.GEMMA_LOCAL: 2.0
                }
                base_time = default_times.get(model, 5.0)
            
            # Adjust based on context complexity
            context_size = len(str(context))
            if context_size > 5000:
                base_time *= 1.5
            elif context_size > 2000:
                base_time *= 1.2
            
            return base_time
            
        except Exception as e:
            self.logger.error("Error estimating time", exception=e)
            return 5.0  # Default estimate
    
    def update_performance(self, model: ModelType, response: APIResponse, 
                          task_type: str, success: bool):
        """Update performance metrics for a model."""
        try:
            performance = self.model_performance[model]
            
            # Update basic metrics
            performance.total_requests += 1
            if success:
                performance.successful_requests += 1
            
            # Update average response time
            if response.response_time > 0:
                if performance.average_response_time == 0:
                    performance.average_response_time = response.response_time
                else:
                    performance.average_response_time = (
                        (performance.average_response_time * (performance.total_requests - 1) + 
                         response.response_time) / performance.total_requests
                    )
            
            # Update cost tracking
            performance.total_cost += response.cost
            
            # Update error rate
            performance.error_rate = 1.0 - performance.success_rate
            
            # Update last used timestamp
            performance.last_used = datetime.now()
            
            # Update specialization scores based on success
            if task_type in performance.specialization_scores:
                current_score = performance.specialization_scores[task_type]
                if success:
                    performance.specialization_scores[task_type] = min(1.0, current_score + 0.01)
                else:
                    performance.specialization_scores[task_type] = max(0.0, current_score - 0.02)
            else:
                performance.specialization_scores[task_type] = 0.7 if success else 0.3
            
            self.logger.debug("Model performance updated", {
                "model": model.value,
                "task_type": task_type,
                "success": success,
                "success_rate": performance.success_rate,
                "avg_response_time": performance.average_response_time
            })
            
        except Exception as e:
            self.logger.error("Error updating model performance", exception=e)


class PromptRouter:
    """
    Main prompt router that coordinates model selection and prompt optimization.
    """
    
    def __init__(self, parent_brain):
        self.parent_brain = parent_brain
        self.logger = get_logger("prompt_router")
        self.perf_logger = get_performance_logger("prompt_router")
        
        # Components
        self.model_selector = ModelSelector(parent_brain)
        
        # Prompt optimization cache
        self.prompt_cache: Dict[str, Dict[str, Any]] = {}
        self.cache_ttl = timedelta(hours=1)
        
        # Routing statistics
        self.routing_stats = {
            "total_routes": 0,
            "successful_routes": 0,
            "cache_hits": 0,
            "fallback_uses": 0
        }
        
    async def initialize(self):
        """Initialize the prompt router."""
        self.logger.system("Prompt Router initialized")
    
    async def select_optimal_model(self, decision_type, context: Dict[str, Any],
                                 force_model: Optional[ModelType] = None) -> ModelType:
        """Select optimal model for a decision type."""
        try:
            # Map decision type to task type
            task_type_mapping = {
                "trading_signal": "sentiment_analysis",
                "risk_assessment": "risk_assessment", 
                "strategy_adjustment": "data_synthesis",
                "error_correction": "coordination",
                "resource_allocation": "coordination",
                "learning_update": "data_synthesis"
            }
            
            task_type = task_type_mapping.get(str(decision_type).split('.')[-1].lower(), "coordination")
            
            # Get routing strategy from parent brain
            strategy_name = self.parent_brain.strategy_parameters.get("model_selection_strategy", "balanced")
            strategy = RoutingStrategy(strategy_name)
            
            # Select model
            decision = self.model_selector.select_optimal_model(
                task_type, context, strategy, force_model
            )
            
            self.routing_stats["total_routes"] += 1
            
            return decision.selected_model
            
        except Exception as e:
            self.logger.error("Error selecting optimal model", exception=e)
            return ModelType.GEMMA_LOCAL  # Safe fallback
    
    async def optimize_prompt(self, prompt: str, decision_type, context: Dict[str, Any],
                            selected_model: ModelType) -> str:
        """Optimize prompt for the selected model and task."""
        try:
            # Generate cache key
            cache_key = self._generate_cache_key(prompt, decision_type, selected_model)
            
            # Check cache
            if cache_key in self.prompt_cache:
                cache_entry = self.prompt_cache[cache_key]
                if datetime.now() - cache_entry["timestamp"] < self.cache_ttl:
                    self.routing_stats["cache_hits"] += 1
                    return cache_entry["optimized_prompt"]
            
            # Optimize prompt based on model capabilities
            optimized_prompt = self._optimize_for_model(prompt, selected_model, context)
            
            # Cache the result
            self.prompt_cache[cache_key] = {
                "optimized_prompt": optimized_prompt,
                "timestamp": datetime.now()
            }
            
            return optimized_prompt
            
        except Exception as e:
            self.logger.error("Error optimizing prompt", exception=e)
            return prompt  # Return original on error
    
    def _generate_cache_key(self, prompt: str, decision_type, model: ModelType) -> str:
        """Generate cache key for prompt optimization."""
        key_data = f"{prompt[:100]}{decision_type}{model.value}"
        return hashlib.md5(key_data.encode()).hexdigest()
    
    def _optimize_for_model(self, prompt: str, model: ModelType, context: Dict[str, Any]) -> str:
        """Optimize prompt for specific model characteristics."""
        try:
            # Model-specific optimizations
            if model == ModelType.GEMMA_2_2B_IT:
                # Gemma prefers concise, direct prompts
                optimized = self._make_concise(prompt)
                optimized = f"Be direct and concise. {optimized}"
                
            elif model == ModelType.GPT_4O:
                # GPT-4o handles complex, detailed prompts well
                optimized = self._add_context_details(prompt, context)
                optimized = f"Provide detailed analysis. {optimized}"
                
            elif model == ModelType.CLAUDE_3_5_SONNET:
                # Claude prefers structured, methodical prompts
                optimized = self._structure_prompt(prompt)
                optimized = f"Think step by step. {optimized}"
                
            elif model == ModelType.GEMMA_LOCAL:
                # Local Gemma prefers simple, clear instructions
                optimized = self._simplify_prompt(prompt)
                optimized = f"Answer clearly and simply. {optimized}"
                
            else:
                optimized = prompt
            
            # Ensure prompt isn't too long
            if len(optimized) > 4000:  # Conservative token limit
                optimized = optimized[:4000] + "... [truncated for length]"
            
            return optimized
            
        except Exception as e:
            self.logger.error("Error in model-specific optimization", exception=e)
            return prompt
    
    def _make_concise(self, prompt: str) -> str:
        """Make prompt more concise."""
        # Remove redundant phrases and verbose explanations
        concise = prompt.replace("Please provide", "Provide")
        concise = concise.replace("I would like you to", "")
        concise = concise.replace("Could you please", "")
        return concise.strip()
    
    def _add_context_details(self, prompt: str, context: Dict[str, Any]) -> str:
        """Add relevant context details for complex models."""
        if not context:
            return prompt
        
        context_summary = f"\nContext: {json.dumps(context, indent=2, default=str)[:500]}"
        return prompt + context_summary
    
    def _structure_prompt(self, prompt: str) -> str:
        """Structure prompt for methodical processing."""
        if "1." not in prompt and "Step" not in prompt:
            structured = f"""
            Please analyze this systematically:
            1. Understand the request
            2. Consider the context
            3. Provide your analysis
            4. Give your conclusion
            
            Request: {prompt}
            """
            return structured.strip()
        return prompt
    
    def _simplify_prompt(self, prompt: str) -> str:
        """Simplify prompt for local models."""
        # Remove complex instructions and focus on core request
        simple = prompt.split('\n')[0]  # Take first line as main instruction
        if len(simple) > 200:
            simple = simple[:200] + "..."
        return simple
    
    async def route_trading_requests(self, aggregated_data: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
        """Route trading requests to appropriate modules with optimal models."""
        try:
            routing_decisions = {}
            
            # Define routing for each module
            module_tasks = {
                "coin_scanner": {
                    "task_type": "sentiment_analysis",
                    "symbols": aggregated_data.get("target_symbols", ["BTC", "ETH"]),
                    "timeframe": "1h",
                    "priority": "high"
                },
                "chart_checker": {
                    "task_type": "technical_analysis", 
                    "symbols": aggregated_data.get("target_symbols", ["BTC"]),
                    "timeframes": ["15m", "1h", "4h"],
                    "priority": "high"
                },
                "combiner": {
                    "task_type": "data_synthesis",
                    "synthesis_mode": "comprehensive",
                    "priority": "critical"
                },
                "verifier_executor": {
                    "task_type": "risk_assessment",
                    "validation_level": "strict",
                    "priority": "critical"
                }
            }
            
            # Route each module's requests
            for module, task_info in module_tasks.items():
                try:
                    # Select optimal model for this module's task
                    decision = self.model_selector.select_optimal_model(
                        task_info["task_type"],
                        aggregated_data,
                        RoutingStrategy.BALANCED
                    )
                    
                    routing_decisions[module] = {
                        "selected_model": decision.selected_model,
                        "fallback_models": decision.fallback_models,
                        "task_info": task_info,
                        "routing_confidence": decision.confidence,
                        "estimated_cost": decision.estimated_cost,
                        "estimated_time": decision.estimated_time,
                        "timeout": max(30.0, decision.estimated_time * 2)
                    }
                    
                except Exception as e:
                    self.logger.error(f"Error routing for module {module}", exception=e)
                    # Provide fallback routing
                    routing_decisions[module] = {
                        "selected_model": ModelType.GEMMA_LOCAL,
"selected_model": ModelType.GEMMA_LOCAL,
                        "fallback_models": [],
                        "task_info": task_info,
                        "routing_confidence": 0.5,
                        "estimated_cost": 0.0,
                        "estimated_time": 5.0,
                        "timeout": 30.0
                    }
            
            self.routing_stats["successful_routes"] += len(routing_decisions)
            
            self.logger.system("Trading requests routed", {
                "modules_routed": len(routing_decisions),
                "routing_decisions": {k: v["selected_model"].value for k, v in routing_decisions.items()}
            })
            
            return routing_decisions
            
        except Exception as e:
            self.logger.error("Error in routing trading requests", exception=e)
            return {}
    
    def update_routing_performance(self, model: ModelType, response: APIResponse, 
                                 task_type: str, success: bool):
        """Update routing performance metrics."""
        try:
            self.model_selector.update_performance(model, response, task_type, success)
            
            if success:
                self.routing_stats["successful_routes"] += 1
            else:
                self.routing_stats["fallback_uses"] += 1
                
        except Exception as e:
            self.logger.error("Error updating routing performance", exception=e)
    
    def get_routing_statistics(self) -> Dict[str, Any]:
        """Get current routing statistics."""
        try:
            stats = self.routing_stats.copy()
            
            # Add success rate
            if stats["total_routes"] > 0:
                stats["success_rate"] = stats["successful_routes"] / stats["total_routes"]
                stats["cache_hit_rate"] = stats["cache_hits"] / stats["total_routes"]
            else:
                stats["success_rate"] = 0.0
                stats["cache_hit_rate"] = 0.0
            
            # Add model performance summary
            stats["model_performance"] = {}
            for model_type, performance in self.model_selector.model_performance.items():
                stats["model_performance"][model_type.value] = {
                    "success_rate": performance.success_rate,
                    "average_response_time": performance.average_response_time,
                    "total_requests": performance.total_requests,
                    "total_cost": performance.total_cost
                }
            
            return stats
            
        except Exception as e:
            self.logger.error("Error getting routing statistics", exception=e)
            return self.routing_stats
    
    def cleanup_cache(self):
        """Clean up expired cache entries."""
        try:
            current_time = datetime.now()
            expired_keys = []
            
            for key, entry in self.prompt_cache.items():
                if current_time - entry["timestamp"] > self.cache_ttl:
                    expired_keys.append(key)
            
            for key in expired_keys:
                del self.prompt_cache[key]
            
            if expired_keys:
                self.logger.debug(f"Cleaned up {len(expired_keys)} expired cache entries")
                
        except Exception as e:
            self.logger.error("Error cleaning up cache", exception=e)