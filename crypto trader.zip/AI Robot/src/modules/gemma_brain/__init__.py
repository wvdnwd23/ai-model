"""
Gemma-2B-IT Brain Module - Central AI orchestrator for the crypto trading system.

This module implements the Gemma-2B-IT as the central AI brain that coordinates
all trading operations through intelligent prompt routing, data aggregation,
and autonomous decision making.

Key Components:
- GemmaBrain: Main controller class
- PromptRouter: Intelligent model selection and routing
- DataAggregator: Real-time data collection and correlation
- FeedbackAnalyzer: Trade outcome learning and adaptation
- SelfImprover: Code modification and optimization
- ErrorMonitor: Proactive error detection and fixing
- LearningEngine: Strategy evolution and performance tracking
- CommunicationHub: External interface management
"""

from .gemma_controller import GemmaBrain, GemmaOrchestrator
from .prompt_router import PromptRouter, ModelSelector
from .data_aggregator import DataAggregator, RealTimeCollector
from .feedback_analyzer import FeedbackAnalyzer, TradeOutcomeProcessor
from .self_improver import SelfImprover, CodeModificationEngine
from .error_monitor import ErrorMonitor, AutoFixEngine
from .learning_engine import LearningEngine, StrategyEvolution
from .communication_hub import CommunicationHub, ExternalInterfaceManager

__version__ = "1.0.0"
__author__ = "AI Crypto Trading System"

# Export main classes
__all__ = [
    "GemmaBrain",
    "GemmaOrchestrator", 
    "PromptRouter",
    "ModelSelector",
    "DataAggregator",
    "RealTimeCollector",
    "FeedbackAnalyzer",
    "TradeOutcomeProcessor",
    "SelfImprover",
    "CodeModificationEngine",
    "ErrorMonitor",
    "AutoFixEngine",
    "LearningEngine",
    "StrategyEvolution",
    "CommunicationHub",
    "ExternalInterfaceManager"
]

# Module metadata
GEMMA_MODULE_INFO = {
    "name": "gemma_brain",
    "version": __version__,
    "description": "Gemma-2B-IT central AI brain for crypto trading",
    "capabilities": [
        "intelligent_prompt_routing",
        "dynamic_model_selection", 
        "real_time_data_aggregation",
        "autonomous_learning",
        "self_code_modification",
        "error_auto_fixing",
        "strategy_evolution",
        "performance_optimization"
    ],
    "supported_models": [
        "google/gemma-2-2b-it",
        "openai/gpt-4o",
        "anthropic/claude-3.5-sonnet",
        "meta-llama/llama-3-8b-instruct",
        "microsoft/deepseek-coder-6.7b-instruct"
    ],
    "optimization_targets": {
        "memory_usage": "< 2GB",
        "response_time": "< 5s",
        "cpu_usage": "< 70%",
        "accuracy": "> 95%"
    }
}