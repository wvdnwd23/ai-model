"""
Gemma Brain Controller - Central AI orchestrator for the crypto trading system.

This module implements the main GemmaBrain class that serves as the central AI brain,
coordinating all trading operations through intelligent prompt routing, data aggregation,
and autonomous decision making with self-improvement capabilities.
"""

import asyncio
import json
import time
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Callable, Union
from dataclasses import dataclass, asdict
from enum import Enum
import threading
import uuid
from collections import defaultdict, deque

from src.utils.communication import ModuleCommunicator, message_bus, Priority, CommunicationProtocol
from src.utils.database import db_manager
from src.utils.config import config_manager
from src.utils.logging import get_logger, get_performance_logger, TimedOperation
from src.utils.openrouter_client import openrouter_client, ModelType, TaskType, APIResponse

class GemmaState(Enum):
    """Gemma brain operational states."""
    INITIALIZING = "initializing"
    LEARNING = "learning"
    ACTIVE = "active"
    OPTIMIZING = "optimizing"
    ERROR_RECOVERY = "error_recovery"
    MAINTENANCE = "maintenance"
    SHUTDOWN = "shutdown"

class DecisionType(Enum):
    """Types of decisions Gemma can make."""
    TRADING_SIGNAL = "trading_signal"
    RISK_ASSESSMENT = "risk_assessment"
    STRATEGY_ADJUSTMENT = "strategy_adjustment"
    ERROR_CORRECTION = "error_correction"
    RESOURCE_ALLOCATION = "resource_allocation"
    LEARNING_UPDATE = "learning_update"

@dataclass
class GemmaDecision:
    """Represents a decision made by the Gemma brain."""
    decision_id: str
    timestamp: datetime
    decision_type: DecisionType
    confidence: float
    reasoning: str
    data: Dict[str, Any]
    model_used: str
    execution_time: float
    success: Optional[bool] = None
    feedback: Optional[Dict[str, Any]] = None

@dataclass
class GemmaMetrics:
    """Performance metrics for the Gemma brain."""
    total_decisions: int = 0
    successful_decisions: int = 0
    average_confidence: float = 0.0
    average_response_time: float = 0.0
    model_usage: Dict[str, int] = None
    cost_tracking: Dict[str, float] = None
    learning_iterations: int = 0
    self_improvements: int = 0
    error_corrections: int = 0
    
    def __post_init__(self):
        if self.model_usage is None:
            self.model_usage = defaultdict(int)
        if self.cost_tracking is None:
            self.cost_tracking = defaultdict(float)

class GemmaBrain:
    """
    Central AI brain implementing Gemma-2B-IT as the core orchestrator.
    
    Features:
    - Intelligent prompt routing to optimal AI models
    - Real-time data aggregation from all modules
    - Autonomous learning and self-improvement
    - Error detection and auto-fixing
    - Strategy evolution based on performance
    - Resource optimization for Raspberry Pi 5
    """
    
    def __init__(self):
        self.logger = get_logger("gemma_brain")
        self.perf_logger = get_performance_logger("gemma_brain")
        
        # Core state
        self.state = GemmaState.INITIALIZING
        self.brain_id = str(uuid.uuid4())
        self.startup_time = datetime.now()
        
        # Communication
        self.communicator = ModuleCommunicator("gemma_brain", message_bus)
        self._setup_request_handlers()
        
        # Components (will be initialized in start())
        self.prompt_router = None
        self.data_aggregator = None
        self.feedback_analyzer = None
        self.self_improver = None
        self.error_monitor = None
        self.learning_engine = None
        self.communication_hub = None
        
        # Decision tracking
        self.decisions: deque = deque(maxlen=1000)  # Keep last 1000 decisions
        self.active_decisions: Dict[str, GemmaDecision] = {}
        
        # Performance metrics
        self.metrics = GemmaMetrics()
        
        # Learning and adaptation
        self.learning_data: List[Dict[str, Any]] = []
        self.strategy_parameters: Dict[str, Any] = {
            "risk_tolerance": 0.3,
            "confidence_threshold": 0.7,
            "model_selection_strategy": "performance_based",
            "learning_rate": 0.1,
            "adaptation_frequency": 3600  # seconds
        }
        
        # Module coordination state
        self.module_status: Dict[str, Dict[str, Any]] = {
            "coin_scanner": {"status": "unknown", "last_update": None, "performance": 0.0},
            "chart_checker": {"status": "unknown", "last_update": None, "performance": 0.0},
            "combiner": {"status": "unknown", "last_update": None, "performance": 0.0},
            "verifier_executor": {"status": "unknown", "last_update": None, "performance": 0.0}
        }
        
        # Background tasks
        self.running = False
        self.background_tasks: List[asyncio.Task] = []
        
        # Memory optimization for Raspberry Pi 5
        self.memory_limit = 1.5 * 1024 * 1024 * 1024  # 1.5GB limit
        self.cpu_limit = 0.7  # 70% CPU limit
        
        self.logger.system("Gemma Brain initialized", {
            "brain_id": self.brain_id,
            "startup_time": self.startup_time.isoformat(),
            "memory_limit_gb": self.memory_limit / (1024**3),
            "cpu_limit_percent": self.cpu_limit * 100
        })
    
    def _setup_request_handlers(self):
        """Set up request handlers for inter-module communication."""
        handlers = {
            "health_check": self._handle_health_check,
            "make_decision": self._handle_make_decision,
            "process_feedback": self._handle_process_feedback,
            "get_metrics": self._handle_get_metrics,
            "update_strategy": self._handle_update_strategy,
            "trigger_learning": self._handle_trigger_learning,
            "emergency_stop": self._handle_emergency_stop,
            "optimize_performance": self._handle_optimize_performance,
            "get_decision_history": self._handle_get_decision_history,
            "coordinate_modules": self._handle_coordinate_modules
        }
        
        for request_type, handler in handlers.items():
            self.communicator.register_request_handler(request_type, handler)
    
    async def start(self):
        """Start the Gemma brain and all components."""
        try:
            self.running = True
            self.state = GemmaState.LEARNING
            
            # Initialize components
            await self._initialize_components()
            
            # Start message bus
            message_bus.start()
            
            # Assess system capabilities
            await self._assess_system_capabilities()
            
            # Load existing learning data
            await self._load_learning_data()
            
            # Start background tasks
            self.background_tasks = [
                asyncio.create_task(self._decision_coordination_loop()),
                asyncio.create_task(self._learning_loop()),
                asyncio.create_task(self._performance_monitoring_loop()),
                asyncio.create_task(self._error_monitoring_loop()),
                asyncio.create_task(self._resource_optimization_loop()),
                asyncio.create_task(self._module_coordination_loop())
            ]
            
            self.state = GemmaState.ACTIVE
            
            self.logger.system("Gemma Brain started successfully", {
                "state": self.state.value,
                "components_initialized": 7,
                "background_tasks": len(self.background_tasks)
            })
            
            # Main coordination loop
            await self._main_coordination_loop()
            
        except Exception as e:
            self.logger.error("Failed to start Gemma Brain", exception=e)
            self.state = GemmaState.ERROR_RECOVERY
            raise
    
    async def stop(self):
        """Stop the Gemma brain and cleanup."""
        self.running = False
        self.state = GemmaState.SHUTDOWN
        
        # Cancel background tasks
        for task in self.background_tasks:
            task.cancel()
        
        # Wait for tasks to complete
        if self.background_tasks:
            await asyncio.gather(*self.background_tasks, return_exceptions=True)
        
        # Save learning data
        await self._save_learning_data()
        
        # Stop message bus
        message_bus.stop()
        
        self.logger.system("Gemma Brain stopped", {
            "total_decisions": self.metrics.total_decisions,
            "successful_decisions": self.metrics.successful_decisions,
            "learning_iterations": self.metrics.learning_iterations,
            "uptime_hours": (datetime.now() - self.startup_time).total_seconds() / 3600
        })
    
    async def _initialize_components(self):
        """Initialize all Gemma brain components."""
        from .prompt_router import PromptRouter
        from .data_aggregator import DataAggregator
        from .feedback_analyzer import FeedbackAnalyzer
        from .self_improver import SelfImprover
        from .error_monitor import ErrorMonitor
        from .learning_engine import LearningEngine
        from .communication_hub import CommunicationHub
        
        # Initialize components
        self.prompt_router = PromptRouter(self)
        self.data_aggregator = DataAggregator(self)
        self.feedback_analyzer = FeedbackAnalyzer(self)
        self.self_improver = SelfImprover(self)
        self.error_monitor = ErrorMonitor(self)
        self.learning_engine = LearningEngine(self)
        self.communication_hub = CommunicationHub(self)
        
        # Initialize each component
        await self.prompt_router.initialize()
        await self.data_aggregator.initialize()
        await self.feedback_analyzer.initialize()
        await self.self_improver.initialize()
        await self.error_monitor.initialize()
        await self.learning_engine.initialize()
        await self.communication_hub.initialize()
        
        self.logger.system("All Gemma components initialized successfully")
    
    async def _assess_system_capabilities(self):
        """Assess available AI models and system capabilities."""
        try:
            # Test OpenRouter connectivity and models
            model_health = await openrouter_client.health_check()
            
            available_models = []
            for model_type, health_info in model_health.items():
                if health_info.get("status") == "healthy":
                    available_models.append(model_type)
            
            # Test system resources
            import psutil
            memory_available = psutil.virtual_memory().available
            cpu_count = psutil.cpu_count()
            
            capabilities = {
                "available_models": available_models,
                "memory_available_gb": memory_available / (1024**3),
                "cpu_cores": cpu_count,
                "openrouter_available": len(available_models) > 0,
                "local_fallback": True  # Always available
            }
            
            self.logger.system("System capabilities assessed", capabilities)
            
            # Update strategy based on capabilities
            if len(available_models) < 2:
                self.strategy_parameters["model_selection_strategy"] = "conservative"
            
            if memory_available < self.memory_limit:
                self.strategy_parameters["risk_tolerance"] = 0.2  # More conservative
                
        except Exception as e:
            self.logger.error("Error assessing system capabilities", exception=e)
    
    async def _main_coordination_loop(self):
        """Main coordination loop for Gemma brain operations."""
        while self.running and self.state == GemmaState.ACTIVE:
            try:
                with TimedOperation(self.perf_logger, "coordination_cycle"):
                    # Check if we should make trading decisions
                    if await self._should_coordinate_trading():
                        await self._coordinate_trading_cycle()
                    
                    # Process any pending decisions
                    await self._process_pending_decisions()
                    
                    # Brief pause between cycles
                    await asyncio.sleep(10)  # 10 second cycles
                    
            except Exception as e:
                self.logger.error("Error in main coordination loop", exception=e)
                await asyncio.sleep(30)  # Longer pause on error
    
    async def _should_coordinate_trading(self) -> bool:
        """Determine if Gemma should coordinate a trading cycle."""
        try:
            # Check system health
            unhealthy_modules = [
                name for name, status in self.module_status.items()
                if status["status"] in ["error", "offline"]
            ]
            
            if unhealthy_modules:
                self.logger.debug(f"Skipping trading - unhealthy modules: {unhealthy_modules}")
                return False
            
            # Use intelligent decision making
            decision_data = {
                "module_status": self.module_status,
                "recent_performance": self.metrics,
                "strategy_parameters": self.strategy_parameters,
                "system_load": await self._get_system_load()
            }
            
            decision = await self.make_decision(
                DecisionType.TRADING_SIGNAL,
                decision_data,
                "Should coordinate trading cycle based on current conditions?"
            )
            
            return decision.data.get("should_trade", False)
            
        except Exception as e:
            self.logger.error("Error determining trading coordination", exception=e)
            return False
    
    async def _coordinate_trading_cycle(self):
        """Coordinate a complete trading cycle across all modules."""
        try:
            self.logger.system("Starting Gemma-coordinated trading cycle")
            
            # Step 1: Aggregate data from all modules
            aggregated_data = await self.data_aggregator.collect_all_data()
            
            # Step 2: Make intelligent routing decisions
            routing_decisions = await self.prompt_router.route_trading_requests(aggregated_data)
            
            # Step 3: Execute coordinated analysis
            analysis_results = {}
            for module, routing_info in routing_decisions.items():
                result = await self._execute_module_analysis(module, routing_info)
                if result:
                    analysis_results[module] = result
            
            # Step 4: Synthesize results and make final decision
            if analysis_results:
                final_decision = await self._synthesize_trading_decision(analysis_results)
                
                # Step 5: Execute if decision is positive
                if final_decision.data.get("decision") == "execute":
                    await self._execute_coordinated_trade(final_decision)
            
            self.logger.system("Gemma-coordinated trading cycle completed")
            
        except Exception as e:
            self.logger.error("Error in coordinated trading cycle", exception=e)
    
    async def make_decision(self, decision_type: DecisionType, data: Dict[str, Any], 
                          prompt: str, force_model: Optional[ModelType] = None) -> GemmaDecision:
        """
        Make an intelligent decision using the best available AI model.
        
        Args:
            decision_type: Type of decision to make
            data: Context data for the decision
            prompt: The decision prompt
            force_model: Optional model to force use
            
        Returns:
            GemmaDecision object with the decision and metadata
        """
        decision_id = str(uuid.uuid4())
        start_time = time.time()
        
        try:
            # Route to optimal model
            selected_model = await self.prompt_router.select_optimal_model(
                decision_type, data, force_model
            )
            
            # Prepare optimized prompt
            optimized_prompt = await self.prompt_router.optimize_prompt(
                prompt, decision_type, data, selected_model
            )
            
            # Make API call
            response = await openrouter_client.generate_response(
                optimized_prompt,
                self._map_decision_to_task_type(decision_type),
                context=data,
                force_model=selected_model
            )
            
            execution_time = time.time() - start_time
            
            # Parse response
            decision_data = self._parse_decision_response(response.content, decision_type)
            
            # Create decision object
            decision = GemmaDecision(
                decision_id=decision_id,
                timestamp=datetime.now(),
                decision_type=decision_type,
                confidence=decision_data.get("confidence", 0.5),
                reasoning=decision_data.get("reasoning", "No reasoning provided"),
                data=decision_data,
                model_used=response.model_used,
                execution_time=execution_time,
                success=response.success
            )
            
            # Track decision
            self.decisions.append(decision)
            self.active_decisions[decision_id] = decision
            
            # Update metrics
            self._update_decision_metrics(decision, response)
            
            self.logger.decision("Gemma decision made", {
                "decision_id": decision_id,
                "decision_type": decision_type.value,
                "confidence": decision.confidence,
                "model_used": decision.model_used,
                "execution_time": execution_time
            })
            
            return decision
            
        except Exception as e:
            self.logger.error(f"Error making decision {decision_id}", exception=e)
            
            # Return error decision
            return GemmaDecision(
                decision_id=decision_id,
                timestamp=datetime.now(),
                decision_type=decision_type,
                confidence=0.0,
                reasoning=f"Error making decision: {str(e)}",
                data={"error": str(e)},
                model_used="error",
                execution_time=time.time() - start_time,
                success=False
            )
    
    def _map_decision_to_task_type(self, decision_type: DecisionType) -> TaskType:
        """Map Gemma decision types to OpenRouter task types."""
        mapping = {
            DecisionType.TRADING_SIGNAL: TaskType.MARKET_SCANNING,
            DecisionType.RISK_ASSESSMENT: TaskType.EXECUTION_VALIDATION,
            DecisionType.STRATEGY_ADJUSTMENT: TaskType.DATA_SYNTHESIS,
            DecisionType.ERROR_CORRECTION: TaskType.GENERAL_COORDINATION,
            DecisionType.RESOURCE_ALLOCATION: TaskType.GENERAL_COORDINATION,
            DecisionType.LEARNING_UPDATE: TaskType.DATA_SYNTHESIS
        }
        return mapping.get(decision_type, TaskType.GENERAL_COORDINATION)
    
    def _parse_decision_response(self, response_content: str, decision_type: DecisionType) -> Dict[str, Any]:
        """Parse AI response into structured decision data."""
        try:
            # Try to parse as JSON first
            if response_content.strip().startswith('{'):
                return json.loads(response_content)
            
            # Fallback parsing based on decision type
            decision_data = {
                "confidence": 0.5,
                "reasoning": response_content,
                "raw_response": response_content
            }
            
            # Extract confidence if mentioned
            if "confidence" in response_content.lower():
                import re
                confidence_match = re.search(r'confidence[:\s]*([0-9.]+)', response_content.lower())
                if confidence_match:
                    decision_data["confidence"] = float(confidence_match.group(1))
            
            return decision_data
            
        except Exception as e:
            self.logger.error("Error parsing decision response", exception=e)
            return {
                "confidence": 0.0,
                "reasoning": "Failed to parse response",
                "error": str(e),
                "raw_response": response_content
            }
    
    def _update_decision_metrics(self, decision: GemmaDecision, response: APIResponse):
        """Update performance metrics based on decision."""
        self.metrics.total_decisions += 1
        
        if decision.success:
            self.metrics.successful_decisions += 1
        
        # Update average confidence
        self.metrics.average_confidence = (
            (self.metrics.average_confidence * (self.metrics.total_decisions - 1) + decision.confidence) /
            self.metrics.total_decisions
        )
        
        # Update average response time
        self.metrics.average_response_time = (
            (self.metrics.average_response_time * (self.metrics.total_decisions - 1) + decision.execution_time) /
            self.metrics.total_decisions
        )
        
        # Update model usage
        self.metrics.model_usage[decision.model_used] += 1
        
        # Update cost tracking
        self.metrics.cost_tracking[decision.model_used] += response.cost
    
    # Background task loops
    async def _decision_coordination_loop(self):
        """Background loop for decision coordination."""
        while self.running:
            try:
                await self._process_pending_decisions()
                await self._cleanup_old_decisions()
                await asyncio.sleep(30)
            except Exception as e:
                self.logger.error("Error in decision coordination loop", exception=e)
                await asyncio.sleep(60)
    
    async def _learning_loop(self):
        """Background loop for continuous learning."""
        while self.running:
            try:
                if self.learning_engine:
                    await self.learning_engine.perform_learning_cycle()
                await asyncio.sleep(self.strategy_parameters["adaptation_frequency"])
            except Exception as e:
                self.logger.error("Error in learning loop", exception=e)
                await asyncio.sleep(3600)
    
    async def _performance_monitoring_loop(self):
        """Background loop for performance monitoring."""
        while self.running:
            try:
                await self._monitor_performance()
                await self._optimize_if_needed()
                await asyncio.sleep(300)  # Every 5 minutes
            except Exception as e:
                self.logger.error("Error in performance monitoring loop", exception=e)
                await asyncio.sleep(300)
    
    async def _error_monitoring_loop(self):
        """Background loop for error monitoring."""
        while self.running:
            try:
                if self.error_monitor:
                    await self.error_monitor.check_for_errors()
                await asyncio.sleep(60)  # Every minute
            except Exception as e:
                self.logger.error("Error in error monitoring loop", exception=e)
                await asyncio.sleep(60)
    
    async def _resource_optimization_loop(self):
        """Background loop for resource optimization."""
        while self.running:
            try:
                await self._optimize_resources()
                await asyncio.sleep(600)  # Every 10 minutes
            except Exception as e:
                self.logger.error("Error in resource optimization loop", exception=e)
                await asyncio.sleep(600)
    
    async def _module_coordination_loop(self):
        """Background loop for module coordination."""
        while self.running:
            try:
                await self._update_module_status()
                await asyncio.sleep(30)  # Every 30 seconds
            except Exception as e:
                self.logger.error("Error in module coordination loop", exception=e)
                await asyncio.sleep(60)
    
    # Request handlers
    def _handle_health_check(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle health check requests."""
        return {
            "status": self.state.value,
            "brain_id": self.brain_id,
            "uptime_seconds": (datetime.now() - self.startup_time).total_seconds(),
            "metrics": asdict(self.metrics),
            "active_decisions": len(self.active_decisions),
            "module_status": self.module_status,
            "strategy_parameters": self.strategy_parameters
        }
    
    def _handle_make_decision(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle decision making requests."""
        try:
            decision_type = DecisionType(data.get("decision_type", "trading_signal"))
            prompt = data.get("prompt", "Make a decision based on provided data")
            context_data = data.get("data", {})
            
            # Create async task for decision making
            decision = asyncio.create_task(
                self.make_decision(decision_type, context_data, prompt)
            )
            
            return {
                "status": "decision_initiated",
                "decision_id": "pending",
                "message": "Decision making in progress"
            }
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e)
            }
    
    def _handle_process_feedback(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle feedback processing requests."""
        try:
            decision_id = data.get("decision_id")
            feedback_data = data.get("feedback", {})
            
            if decision_id in self.active_decisions:
                decision = self.active_decisions[decision_id]
                decision.feedback = feedback_data
                
                # Process feedback through feedback analyzer
                if self.feedback_analyzer:
                    asyncio.create_task(
                        self.feedback_analyzer.process_feedback(decision, feedback_data)
                    )
                
                return {"status": "feedback_processed"}
            else:
                return {"status": "decision_not_found"}
                
        except Exception as e:
            return {"status": "error", "error": str(e)}
    
    def _handle_get_metrics(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle metrics requests."""
        return {
            "metrics": asdict(self.metrics),
            "recent_decisions": len([d for d in self.decisions if 
                                   (datetime.now() - d.timestamp).total_seconds() < 3600]),
            "strategy_parameters": self.strategy_parameters
        }
    
    def _handle_update_strategy(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle strategy update requests."""
        try:
            updates = data.get("updates", {})
            self.strategy_parameters.update(updates)
            
            self.logger.system("Strategy parameters updated", {
                "updates": updates,
                "current_strategy": self.strategy_parameters
            })
            
            return {"status": "strategy_updated"}
            
        except Exception as e:
            return {"status": "error", "error": str(e)}
    
    def _handle_trigger_learning(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle learning trigger requests."""
        try:
            if self.learning_engine:
                asyncio.create_task(self.learning_engine.perform_learning_cycle())
                return {"status": "learning_triggered"}
            else:
                return {"status": "learning_engine_not_available"}
                
        except Exception as e:
            return {"status": "error", "error": str(e)}
    
    def _handle_emergency_stop(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle emergency stop requests."""
        try:
            reason = data.get("reason", "Emergency stop requested")
            self.state = GemmaState.ERROR_RECOVERY
            
            self.logger.security("Gemma Brain emergency stop triggered", {
                "reason": reason,
                "timestamp": datetime.now().isoformat()
            })
            
            return {"status": "emergency_stop_activated"}
            
        except Exception as e:
            return {"status": "error", "error": str(e)}
    
    def _handle_optimize_performance(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle performance optimization requests."""
        try:
            asyncio.create_task(self._optimize_resources())
            return {"status": "optimization_triggered"}
            
        except Exception as e:
            return {"status": "error", "error": str(e)}
    
    def _handle_get_decision_history(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle decision history requests."""
        try:
            limit = data.get("limit", 50)
            recent_decisions = list(self.decisions)[-limit:]
            
            decision_history = []
            for decision in recent_decisions:
                decision_history.append({
                    "decision_id": decision.decision_id,
                    "timestamp": decision.timestamp.isoformat(),
                    "decision_type": decision.decision_type.value,
                    "confidence": decision.confidence,
                    "model_used": decision.model_used,
                    "success": decision.success
                })
            
            return {
                "decision_history": decision_history,
                "total_decisions": len(decision_history)
            }
            
        except Exception as e:
            return {"status": "error", "error": str(e)}
    
    def _handle_coordinate_modules(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle module coordination requests."""
        try:
            coordination_type = data.get("type", "status_update")
            
            if coordination_type == "status_update":
                return {"module_status": self.module_status}
            elif coordination_type == "performance_sync":
                asyncio.create_task(self._sync_module_performance())
                return {"status": "sync_initiated"}
            else:
                return {"status": "unknown_coordination_type"}
                
        except Exception as e:
            return {"status": "error", "error": str(e)}
    
    # Utility methods
    async def _get_system_load(self) -> Dict[str, float]:
        """Get current system load metrics."""
        try:
            import psutil
            return {
                "cpu_percent": psutil.cpu_percent(),
                "memory_percent": psutil.virtual_memory().percent,
                "disk_percent": psutil.disk_usage('/').percent
            }
        except ImportError:
            return {"cpu_percent": 0.0, "memory_percent": 0.0, "disk_percent": 0.0}
    
    async def _process_pending_decisions(self):
        """Process any pending decisions."""
        # Implementation for processing pending decisions
        pass
    
    async def _cleanup_old_decisions(self):
        """Clean up old decisions to manage memory."""
        cutoff_time = datetime.now() - timedelta(hours=24)
        
        # Remove old decisions from active tracking
        old_decision_ids = [
            decision_id for decision_id, decision in self.active_decisions.items()
            if decision.timestamp < cutoff_time
        ]
        
        for decision_id in old_decision_ids:
            del self.active_decisions[decision_id]
    
    async def _monitor_performance(self):
        """Monitor Gemma brain performance."""
        # Implementation for performance monitoring
        pass
    
    async def _optimize_if_needed(self):
        """Optimize performance if needed."""
        # Implementation for conditional optimization
        pass
    
    async def _optimize_resources(self):
        """Optimize system resources for Raspberry Pi 5."""
        # Implementation for resource optimization
        pass
    
    async def _update_module_status(self):
        """Update status of all coordinated modules."""
        # Implementation for module status updates
        pass
    
    async def _load_learning_data(self):
        """Load existing learning data from database."""
        # Implementation for loading learning data
        pass
    
    async def _save_learning_data(self):
        """Save learning data to database."""
        # Implementation for saving learning data
        pass
    
    async def _execute_module_analysis(self, module: str, routing_info: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Execute analysis for a specific module with routing information."""
        try:
            # Prepare request based on module type
            if module == "coin_scanner":
                request_data = CommunicationProtocol.create_scan_request(
                    symbols=routing_info.get("symbols", ["BTC", "ETH"]),
                    timeframe=routing_info.get("timeframe", "1h")
                )
            elif module == "chart_checker":
                request_data = CommunicationProtocol.create_chart_analysis_request(
                    symbol=routing_info.get("symbol", "BTC"),
                    timeframes=routing_info.get("timeframes", ["1h", "4h"])
                )
            elif module == "combiner":
                request_data = CommunicationProtocol.create_trade_decision_request(
                    scanner_output=routing_info.get("scanner_data", {}),
                    chart_output=routing_info.get("chart_data", {})
                )
            elif module == "verifier_executor":
                request_data = CommunicationProtocol.create_trade_execution_request(
                    decision=routing_info.get("decision", {})
                )
            else:
                self.logger.warning(f"Unknown module for analysis: {module}")
                return None
            
            # Send request to module
            response = self.communicator.send_request(
                module, 
                request_data.get("type", "analyze"), 
                request_data, 
                Priority.HIGH, 
                timeout=routing_info.get("timeout", 60.0)
            )
            
            if response:
                self.logger.decision(f"Module {module} analysis completed", {
                    "module": module,
                    "response_size": len(str(response)),
                    "routing_info": routing_info
                })
                return response
            else:
                self.logger.warning(f"No response from module {module}")
                return None
                
        except Exception as e:
            self.logger.error(f"Error executing analysis for module {module}", exception=e)
            return None
    
    async def _synthesize_trading_decision(self, analysis_results: Dict[str, Any]) -> GemmaDecision:
        """Synthesize analysis results into a final trading decision."""
        try:
            # Prepare synthesis data
            synthesis_data = {
                "analysis_results": analysis_results,
                "timestamp": datetime.now().isoformat(),
                "market_context": await self._get_market_context()
            }
            
            # Create synthesis prompt
            prompt = f"""
            Synthesize the following analysis results into a final trading decision:
            
            Analysis Results:
            {json.dumps(analysis_results, indent=2, default=str)}
            
            Market Context:
            {json.dumps(synthesis_data["market_context"], indent=2, default=str)}
            
            Provide a comprehensive trading decision with:
            1. Final recommendation (buy/sell/hold)
            2. Confidence level (0-1)
            3. Risk assessment
            4. Position sizing recommendation
            5. Entry/exit strategy
            6. Reasoning based on all analysis inputs
            
            Respond in JSON format with all required fields.
            """
            
            # Make synthesis decision
            decision = await self.make_decision(
                DecisionType.TRADING_SIGNAL,
                synthesis_data,
                prompt
            )
            
            return decision
            
        except Exception as e:
            self.logger.error("Error synthesizing trading decision", exception=e)
            
            # Return error decision
            return GemmaDecision(
                decision_id=str(uuid.uuid4()),
                timestamp=datetime.now(),
                decision_type=DecisionType.TRADING_SIGNAL,
                confidence=0.0,
                reasoning=f"Error in synthesis: {str(e)}",
                data={"error": str(e), "decision": "hold"},
                model_used="error",
                execution_time=0.0,
                success=False
            )
    
    async def _execute_coordinated_trade(self, decision: GemmaDecision):
        """Execute a coordinated trade based on Gemma decision."""
        try:
            if decision.data.get("decision") != "execute":
                return
            
            # Prepare execution request
            execution_data = {
                "decision": decision.data,
                "gemma_decision_id": decision.decision_id,
                "confidence": decision.confidence,
                "reasoning": decision.reasoning
            }
            
            # Send to verifier/executor
            response = self.communicator.send_request(
                "verifier_executor",
                "execute_trade",
                execution_data,
                Priority.CRITICAL,
                timeout=180.0
            )
            
            if response:
                # Update decision with execution result
                decision.data["execution_result"] = response
                decision.success = response.get("success", False)
                
                self.logger.trade("Coordinated trade executed", {
                    "decision_id": decision.decision_id,
                    "execution_result": response
                })
            else:
                self.logger.error("Failed to execute coordinated trade")
                decision.success = False
                
        except Exception as e:
            self.logger.error("Error executing coordinated trade", exception=e)
            decision.success = False
    
    async def _get_market_context(self) -> Dict[str, Any]:
        """Get current market context for decision making."""
        try:
            return {
                "timestamp": datetime.now().isoformat(),
                "system_load": await self._get_system_load(),
                "module_status": self.module_status,
                "recent_performance": {
                    "total_decisions": self.metrics.total_decisions,
                    "success_rate": (self.metrics.successful_decisions / max(1, self.metrics.total_decisions)),
                    "average_confidence": self.metrics.average_confidence
                }
            }
        except Exception as e:
            self.logger.error("Error getting market context", exception=e)
            return {}
    
    async def _sync_module_performance(self):
        """Synchronize performance data with all modules."""
        try:
            for module_name in self.module_status.keys():
                try:
                    response = self.communicator.send_request(
                        module_name,
                        "get_performance_metrics",
                        {},
                        Priority.LOW,
                        timeout=10.0
                    )
                    
                    if response:
                        self.module_status[module_name]["performance"] = response.get("performance_score", 0.0)
                        self.module_status[module_name]["last_update"] = datetime.now()
                        
                except Exception as e:
                    self.logger.error(f"Error syncing performance for {module_name}", exception=e)
                    
        except Exception as e:
            self.logger.error("Error in module performance sync", exception=e)


class GemmaOrchestrator:
    """
    High-level orchestrator that manages multiple GemmaBrain instances.
    Provides load balancing and failover capabilities.
    """
    
    def __init__(self, num_brains: int = 1):
        self.logger = get_logger("gemma_orchestrator")
        self.num_brains = num_brains
        self.brains: List[GemmaBrain] = []
        self.current_brain_index = 0
        self.running = False
        
    async def start(self):
        """Start all Gemma brain instances."""
        try:
            self.running = True
            
            # Initialize brain instances
            for i in range(self.num_brains):
                brain = GemmaBrain()
                self.brains.append(brain)
                
                # Start brain in background
                asyncio.create_task(brain.start())
            
            self.logger.system(f"Gemma Orchestrator started with {self.num_brains} brain instances")
            
        except Exception as e:
            self.logger.error("Failed to start Gemma Orchestrator", exception=e)
            raise
    
    async def stop(self):
        """Stop all Gemma brain instances."""
        self.running = False
        
        # Stop all brains
        for brain in self.brains:
            await brain.stop()
        
        self.logger.system("Gemma Orchestrator stopped")
    
    def get_active_brain(self) -> GemmaBrain:
        """Get the currently active brain instance."""
        if not self.brains:
            raise RuntimeError("No brain instances available")
        
        # Simple round-robin selection
        brain = self.brains[self.current_brain_index]
        self.current_brain_index = (self.current_brain_index + 1) % len(self.brains)
        
        return brain
    
    async def make_coordinated_decision(self, decision_type: DecisionType, 
                                      data: Dict[str, Any], prompt: str) -> GemmaDecision:
        """Make a decision using the best available brain."""
        brain = self.get_active_brain()
        return await brain.make_decision(decision_type, data, prompt)