"""
Feedback Analyzer - Analyze trading results and extract learning insights for Gemma Brain.

This module implements comprehensive feedback analysis from trading outcomes:
- Trade outcome analysis with detailed metrics
- Pattern recognition for successful vs failed trades
- Performance correlation and statistical analysis
- Strategy effectiveness tracking across market conditions
- Confidence scoring and prediction accuracy assessment
- Market condition analysis for different trading environments
"""

import asyncio
import json
import time
import statistics
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple, Union
from dataclasses import dataclass, asdict
from enum import Enum
from collections import defaultdict, deque

from src.utils.database import db_manager
from src.utils.logging import get_logger, get_performance_logger, TimedOperation
from src.utils.config import config_manager

class TradeOutcome(Enum):
    """Trade outcome types."""
    WIN = "win"
    LOSS = "loss"
    BREAKEVEN = "breakeven"
    PENDING = "pending"

class MarketCondition(Enum):
    """Market condition types."""
    BULL = "bull"
    BEAR = "bear"
    SIDEWAYS = "sideways"
    VOLATILE = "volatile"
    UNKNOWN = "unknown"

class AnalysisType(Enum):
    """Types of feedback analysis."""
    TRADE_PERFORMANCE = "trade_performance"
    PATTERN_RECOGNITION = "pattern_recognition"
    STRATEGY_EFFECTIVENESS = "strategy_effectiveness"
    CONFIDENCE_CALIBRATION = "confidence_calibration"
    MARKET_ADAPTATION = "market_adaptation"
    RISK_ASSESSMENT = "risk_assessment"

@dataclass
class TradeOutcomeData:
    """Comprehensive trade outcome data structure."""
    trade_id: int
    symbol: str
    side: str
    entry_price: float
    exit_price: Optional[float]
    quantity: float
    leverage: int
    entry_time: datetime
    exit_time: Optional[datetime]
    pnl: Optional[float]
    pnl_percentage: Optional[float]
    outcome: TradeOutcome
    duration_minutes: Optional[int]
    
    # Decision context
    prediction_confidence: float
    decision_reasoning: str
    market_condition: MarketCondition
    strategy_version: str
    
    # Technical indicators at entry
    rsi_entry: Optional[float]
    bollinger_position: Optional[str]
    volume_ratio: Optional[float]
    trend_strength: Optional[float]
    
    # Risk metrics
    risk_reward_ratio: Optional[float]
    max_drawdown: Optional[float]
    stop_loss_hit: bool
    take_profit_hit: bool
    
    # Metadata
    metadata: Dict[str, Any]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "trade_id": self.trade_id,
            "symbol": self.symbol,
            "side": self.side,
            "entry_price": self.entry_price,
            "exit_price": self.exit_price,
            "quantity": self.quantity,
            "leverage": self.leverage,
            "entry_time": self.entry_time.isoformat() if self.entry_time else None,
            "exit_time": self.exit_time.isoformat() if self.exit_time else None,
            "pnl": self.pnl,
            "pnl_percentage": self.pnl_percentage,
            "outcome": self.outcome.value,
            "duration_minutes": self.duration_minutes,
            "prediction_confidence": self.prediction_confidence,
            "decision_reasoning": self.decision_reasoning,
            "market_condition": self.market_condition.value,
            "strategy_version": self.strategy_version,
            "rsi_entry": self.rsi_entry,
            "bollinger_position": self.bollinger_position,
            "volume_ratio": self.volume_ratio,
            "trend_strength": self.trend_strength,
            "risk_reward_ratio": self.risk_reward_ratio,
            "max_drawdown": self.max_drawdown,
            "stop_loss_hit": self.stop_loss_hit,
            "take_profit_hit": self.take_profit_hit,
            "metadata": self.metadata
        }

@dataclass
class FeedbackInsights:
    """Insights extracted from feedback analysis."""
    analysis_type: AnalysisType
    timestamp: datetime
    insights: Dict[str, Any]
    confidence: float
    actionable_recommendations: List[str]
    statistical_significance: float
    sample_size: int
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "analysis_type": self.analysis_type.value,
            "timestamp": self.timestamp.isoformat(),
            "insights": self.insights,
            "confidence": self.confidence,
            "actionable_recommendations": self.actionable_recommendations,
            "statistical_significance": self.statistical_significance,
            "sample_size": self.sample_size
        }

class FeedbackAnalyzer:
    """
    Main feedback analyzer that coordinates all analysis components.
    """
    
    def __init__(self, parent_brain):
        self.parent_brain = parent_brain
        self.logger = get_logger("feedback_analyzer")
        self.perf_logger = get_performance_logger("feedback_analyzer")
        
        # Analysis cache
        self.analysis_cache: Dict[str, FeedbackInsights] = {}
        self.cache_ttl = timedelta(hours=2)
        
        # Learning data storage
        self.trade_outcomes: deque = deque(maxlen=1000)  # Keep last 1000 trades
        self.feedback_history: deque = deque(maxlen=500)  # Keep last 500 feedback entries
        
        # Analysis statistics
        self.analysis_stats = {
            "total_analyses": 0,
            "successful_analyses": 0,
            "insights_generated": 0,
            "patterns_identified": 0,
            "recommendations_made": 0
        }
        
    async def initialize(self):
        """Initialize the feedback analyzer."""
        try:
            # Load existing trade data
            await self._load_historical_data()
            
            self.logger.system("Feedback Analyzer initialized")
            
        except Exception as e:
            self.logger.error("Error initializing feedback analyzer", exception=e)
            raise
    
    async def process_feedback(self, decision, feedback_data: Dict[str, Any]) -> FeedbackInsights:
        """
        Process feedback from a trading decision and extract insights.
        
        Args:
            decision: GemmaDecision object
            feedback_data: Feedback data including trade outcome
            
        Returns:
            FeedbackInsights with analysis results
        """
        try:
            with TimedOperation(self.perf_logger, "feedback_processing"):
                # Convert feedback to trade outcome
                trade_outcome = await self._convert_to_trade_outcome(decision, feedback_data)
                
                if trade_outcome:
                    self.trade_outcomes.append(trade_outcome)
                    
                    # Store in database
                    await self._store_trade_outcome(trade_outcome)
                
                # Perform comprehensive analysis
                insights = await self._analyze_feedback(trade_outcome, feedback_data)
                
                # Cache insights
                cache_key = f"{decision.decision_id}_{datetime.now().strftime('%Y%m%d_%H')}"
                self.analysis_cache[cache_key] = insights
                
                # Update statistics
                self._update_analysis_stats(insights)
                
                self.logger.learning("Feedback processed and analyzed", {
                    "decision_id": decision.decision_id,
                    "trade_outcome": trade_outcome.outcome.value if trade_outcome else "unknown",
                    "insights_confidence": insights.confidence,
                    "recommendations_count": len(insights.actionable_recommendations)
                })
                
                return insights
                
        except Exception as e:
            self.logger.error("Error processing feedback", exception=e)
            
            # Return empty insights on error
            return FeedbackInsights(
                analysis_type=AnalysisType.TRADE_PERFORMANCE,
                timestamp=datetime.now(),
                insights={"error": str(e)},
                confidence=0.0,
                actionable_recommendations=[],
                statistical_significance=0.0,
                sample_size=0
            )
    
    async def analyze_trading_patterns(self, lookback_days: int = 30) -> FeedbackInsights:
        """Analyze trading patterns over a specified period."""
        try:
            # Get recent trade outcomes
            cutoff_date = datetime.now() - timedelta(days=lookback_days)
            recent_trades = [
                t for t in self.trade_outcomes 
                if t.entry_time >= cutoff_date
            ]
            
            if len(recent_trades) < 5:
                return FeedbackInsights(
                    analysis_type=AnalysisType.PATTERN_RECOGNITION,
                    timestamp=datetime.now(),
                    insights={"insufficient_data": True, "sample_size": len(recent_trades)},
                    confidence=0.0,
                    actionable_recommendations=["Collect more trading data before pattern analysis"],
                    statistical_significance=0.0,
                    sample_size=len(recent_trades)
                )
            
            # Analyze patterns
            winning_patterns = self._analyze_winning_patterns(recent_trades)
            losing_patterns = self._analyze_losing_patterns(recent_trades)
            
            # Generate insights
            insights = {
                "analysis_period_days": lookback_days,
                "total_trades_analyzed": len(recent_trades),
                "winning_patterns": winning_patterns,
                "losing_patterns": losing_patterns,
                "pattern_summary": self._summarize_patterns(winning_patterns, losing_patterns)
            }
            
            # Generate recommendations
            recommendations = self._generate_pattern_recommendations(winning_patterns, losing_patterns)
            
            # Calculate confidence and significance
            confidence = self._calculate_pattern_confidence(recent_trades, winning_patterns, losing_patterns)
            significance = self._calculate_statistical_significance(len(recent_trades))
            
            return FeedbackInsights(
                analysis_type=AnalysisType.PATTERN_RECOGNITION,
                timestamp=datetime.now(),
                insights=insights,
                confidence=confidence,
                actionable_recommendations=recommendations,
                statistical_significance=significance,
                sample_size=len(recent_trades)
            )
            
        except Exception as e:
            self.logger.error("Error analyzing trading patterns", exception=e)
            return FeedbackInsights(
                analysis_type=AnalysisType.PATTERN_RECOGNITION,
                timestamp=datetime.now(),
                insights={"error": str(e)},
                confidence=0.0,
                actionable_recommendations=[],
                statistical_significance=0.0,
                sample_size=0
            )
    
    def _analyze_winning_patterns(self, trade_outcomes: List[TradeOutcomeData]) -> Dict[str, Any]:
        """Analyze patterns in winning trades."""
        try:
            winning_trades = [t for t in trade_outcomes if t.outcome == TradeOutcome.WIN]
            
            if len(winning_trades) < 3:
                return {"insufficient_data": True, "sample_size": len(winning_trades)}
            
            # Analyze confidence patterns
            confidences = [t.prediction_confidence for t in winning_trades]
            avg_confidence = statistics.mean(confidences)
            
            # Analyze timing patterns
            durations = [t.duration_minutes for t in winning_trades if t.duration_minutes is not None]
            avg_duration = statistics.mean(durations) if durations else None
            
            # Analyze market conditions
            conditions = [t.market_condition.value for t in winning_trades]
            condition_counts = {cond: conditions.count(cond) for cond in set(conditions)}
            
            return {
                "sample_size": len(winning_trades),
                "average_confidence": avg_confidence,
                "average_duration": avg_duration,
                "market_conditions": condition_counts,
                "high_confidence_wins": len([c for c in confidences if c > 0.8])
            }
            
        except Exception as e:
            self.logger.error("Error analyzing winning patterns", exception=e)
            return {"error": str(e)}
    
    def _analyze_losing_patterns(self, trade_outcomes: List[TradeOutcomeData]) -> Dict[str, Any]:
        """Analyze patterns in losing trades."""
        try:
            losing_trades = [t for t in trade_outcomes if t.outcome == TradeOutcome.LOSS]
            
            if len(losing_trades) < 2:
                return {"insufficient_data": True, "sample_size": len(losing_trades)}
            
            # Analyze overconfidence
            high_conf_losses = [t for t in losing_trades if t.prediction_confidence > 0.8]
            overconfidence_rate = len(high_conf_losses) / len(losing_trades)
            
            # Analyze timing issues
            durations = [t.duration_minutes for t in losing_trades if t.duration_minutes is not None]
            quick_losses = len([d for d in durations if d < 30]) if durations else 0
            
            return {
                "sample_size": len(losing_trades),
                "overconfidence_rate": overconfidence_rate,
                "quick_losses": quick_losses,
                "average_confidence": statistics.mean([t.prediction_confidence for t in losing_trades])
            }
            
        except Exception as e:
            self.logger.error("Error analyzing losing patterns", exception=e)
            return {"error": str(e)}
    
    async def _convert_to_trade_outcome(self, decision, feedback_data: Dict[str, Any]) -> Optional[TradeOutcomeData]:
        """Convert decision and feedback to TradeOutcomeData."""
        try:
            # Extract trade information from feedback
            trade_info = feedback_data.get("trade_info", {})
            
            if not trade_info:
                return None
            
            # Determine outcome
            pnl = trade_info.get("pnl")
            if pnl is None:
                outcome = TradeOutcome.PENDING
            elif pnl > 0:
                outcome = TradeOutcome.WIN
            elif pnl < 0:
                outcome = TradeOutcome.LOSS
            else:
                outcome = TradeOutcome.BREAKEVEN
            
            # Calculate duration
            entry_time = decision.timestamp
            exit_time_str = trade_info.get("exit_time")
            exit_time = datetime.fromisoformat(exit_time_str) if exit_time_str else None
            
            duration_minutes = None
            if exit_time:
                duration_minutes = int((exit_time - entry_time).total_seconds() / 60)
            
            # Determine market condition
            market_condition = MarketCondition.UNKNOWN
            if "market_condition" in decision.data:
                try:
                    market_condition = MarketCondition(decision.data["market_condition"])
                except ValueError:
                    pass
            
            return TradeOutcomeData(
                trade_id=trade_info.get("trade_id", 0),
                symbol=trade_info.get("symbol", ""),
                side=trade_info.get("side", ""),
                entry_price=trade_info.get("entry_price", 0.0),
                exit_price=trade_info.get("exit_price"),
                quantity=trade_info.get("quantity", 0.0),
                leverage=trade_info.get("leverage", 1),
                entry_time=entry_time,
                exit_time=exit_time,
                pnl=pnl,
                pnl_percentage=trade_info.get("pnl_percentage"),
                outcome=outcome,
                duration_minutes=duration_minutes,
                prediction_confidence=decision.confidence,
                decision_reasoning=decision.reasoning,
                market_condition=market_condition,
                strategy_version=decision.data.get("strategy_version", "unknown"),
                rsi_entry=decision.data.get("rsi", None),
                bollinger_position=decision.data.get("bollinger_position"),
                volume_ratio=decision.data.get("volume_ratio"),
                trend_strength=decision.data.get("trend_strength"),
                risk_reward_ratio=trade_info.get("risk_reward_ratio"),
                max_drawdown=trade_info.get("max_drawdown"),
                stop_loss_hit=trade_info.get("stop_loss_hit", False),
                take_profit_hit=trade_info.get("take_profit_hit", False),
                metadata=feedback_data.get("metadata", {})
            )
            
        except Exception as e:
            self.logger.error("Error converting to trade outcome", exception=e)
            return None
    
    async def _analyze_feedback(self, trade_outcome: Optional[TradeOutcomeData], 
                              feedback_data: Dict[str, Any]) -> FeedbackInsights:
        """Perform comprehensive feedback analysis."""
        try:
            if not trade_outcome:
                return FeedbackInsights(
                    analysis_type=AnalysisType.TRADE_PERFORMANCE,
                    timestamp=datetime.now(),
                    insights={"no_trade_outcome": True},
                    confidence=0.0,
                    actionable_recommendations=[],
                    statistical_significance=0.0,
                    sample_size=0
                )
            
            # Analyze individual trade performance
            trade_analysis = self._analyze_individual_trade(trade_outcome)
            
            # Generate insights
            insights = {
                "trade_analysis": trade_analysis,
                "learning_opportunities": self._identify_learning_opportunities(trade_outcome),
                "immediate_feedback": self._generate_immediate_feedback(trade_outcome)
            }
            
            # Generate recommendations
            recommendations = self._generate_trade_recommendations(trade_outcome)
            
            # Calculate confidence
            confidence = self._calculate_feedback_confidence(trade_outcome)
            
            return FeedbackInsights(
                analysis_type=AnalysisType.TRADE_PERFORMANCE,
                timestamp=datetime.now(),
                insights=insights,
                confidence=confidence,
                actionable_recommendations=recommendations,
                statistical_significance=0.8,
                sample_size=1
            )
            
        except Exception as e:
            self.logger.error("Error analyzing feedback", exception=e)
            return FeedbackInsights(
                analysis_type=AnalysisType.TRADE_PERFORMANCE,
                timestamp=datetime.now(),
                insights={"error": str(e)},
                confidence=0.0,
                actionable_recommendations=[],
                statistical_significance=0.0,
                sample_size=0
            )
    
    def _analyze_individual_trade(self, trade_outcome: TradeOutcomeData) -> Dict[str, Any]:
        """Analyze an individual trade outcome."""
        try:
            return {
                "outcome": trade_outcome.outcome.value,
                "pnl_percentage": trade_outcome.pnl_percentage,
                "duration_minutes": trade_outcome.duration_minutes,
                "confidence_level": trade_outcome.prediction_confidence,
                "market_condition": trade_outcome.market_condition.value,
                "confidence_accuracy": self._assess_confidence_accuracy(trade_outcome)
            }
        except Exception as e:
            self.logger.error("Error analyzing individual trade", exception=e)
            return {}
    
    def _assess_confidence_accuracy(self, trade_outcome: TradeOutcomeData) -> str:
        """Assess how accurate the confidence prediction was."""
        if trade_outcome.outcome == TradeOutcome.WIN:
            if trade_outcome.prediction_confidence > 0.7:
                return "well_calibrated"
            else:
                return "underconfident"
        else:  # Loss or breakeven
            if trade_outcome.prediction_confidence > 0.7:
                return "overconfident"
            else:
                return "appropriately_cautious"
    
    def _identify_learning_opportunities(self, trade_outcome: TradeOutcomeData) -> List[str]:
        """Identify specific learning opportunities from the trade."""
        opportunities = []
        
        # Confidence calibration opportunities
        if trade_outcome.outcome == TradeOutcome.LOSS and trade_outcome.prediction_confidence > 0.8:
            opportunities.append("Review factors that led to overconfidence in losing trade")
        
        if trade_outcome.outcome == TradeOutcome.WIN and trade_outcome.prediction_confidence < 0.5:
            opportunities.append("Analyze why confidence was low for winning trade")
        
        # Risk management opportunities
        if trade_outcome.outcome == TradeOutcome.LOSS and not trade_outcome.stop_loss_hit:
            opportunities.append("Improve stop-loss discipline and risk management")
        
        # Timing opportunities
        if trade_outcome.duration_minutes and trade_outcome.duration_minutes < 15:
            opportunities.append("Analyze very short trade duration - possible premature exit")
        
        return opportunities
    
    def _generate_immediate_feedback(self, trade_outcome: TradeOutcomeData) -> Dict[str, Any]:
        """Generate immediate feedback for the trade."""
        return {
            "outcome_summary": f"{trade_outcome.outcome.value.title()} trade on {trade_outcome.symbol}",
            "key_metrics": {
                "pnl_percentage": trade_outcome.pnl_percentage,
                "confidence_accuracy": self._assess_confidence_accuracy(trade_outcome),
                "duration_minutes": trade_outcome.duration_minutes
            }
        }
    
    def _generate_trade_recommendations(self, trade_outcome: TradeOutcomeData) -> List[str]:
        """Generate recommendations for individual trade."""
        recommendations = []
        
        if trade_outcome.outcome == TradeOutcome.LOSS:
            if trade_outcome.prediction_confidence > 0.8:
                recommendations.append("Review analysis methodology - high confidence loss")
            
            if not trade_outcome.stop_loss_hit:
                recommendations.append("Implement stricter stop-loss discipline")
        
        if trade_outcome.duration_minutes and trade_outcome.duration_minutes < 10:
            recommendations.append("Consider longer holding periods - very short trade duration")
        
        return recommendations
    
    def _generate_pattern_recommendations(self, winning_patterns: Dict[str, Any], 
                                        losing_patterns: Dict[str, Any]) -> List[str]:
        """Generate recommendations based on pattern analysis."""
        recommendations = []
        
        # Winning pattern recommendations
        if winning_patterns.get("high_confidence_wins", 0) > 0:
            recommendations.append("Continue using high-confidence signals - they show good results")
        
        # Losing pattern recommendations
        if losing_patterns.get("overconfidence_rate", 0) > 0.3:
            recommendations.append("Reduce confidence levels - showing signs of overconfidence")
        
        if losing_patterns.get("quick_losses", 0) > losing_patterns.get("sample_size", 1) * 0.4:
            recommendations.append("Review trade timing - too many quick losses detected")
        
        return recommendations
    
    def _summarize_patterns(self, winning_patterns: Dict[str, Any], 
                           losing_patterns: Dict[str, Any]) -> Dict[str, Any]:
        """Summarize key patterns from analysis."""
        return {
            "key_winning_factors": ["High confidence predictions"] if winning_patterns.get("high_confidence_wins", 0) > 0 else [],
            "key_losing_factors": ["Overconfidence"] if losing_patterns.get("overconfidence_rate", 0) > 0.3 else [],
            "pattern_strength": "moderate" if (winning_patterns.get("sample_size", 0) + losing_patterns.get("sample_size", 0)) > 10 else "weak"
        }
    
    def _calculate_pattern_confidence(self, trades: List[TradeOutcomeData], 
                                    winning_patterns: Dict[str, Any], 
                                    losing_patterns: Dict[str, Any]) -> float:
        """Calculate confidence in pattern analysis."""
        sample_size = len(trades)
        
        if sample_size < 5:
            return 0.2
        elif sample_size < 10:
            return 0.5
        elif sample_size < 20:
            return 0.7
        else:
            return 0.9
    
    def _calculate_feedback_confidence(self, trade_outcome: TradeOutcomeData) -> float:
        """Calculate confidence in feedback analysis."""
        confidence = 0.5  # Base confidence
        
        # Adjust based on data completeness
        if trade_outcome.pnl_percentage is not None:
            confidence += 0.2
        
        if trade_outcome.duration_minutes is not None:
            confidence += 0.1
        
        if trade_outcome.market_condition != MarketCondition.UNKNOWN:
            confidence += 0.1
        
        return min(1.0, confidence)
    
    def _calculate_statistical_significance(self, sample_size: int) -> float:
        """Calculate statistical significance based on sample size."""
        if sample_size < 5:
            return 0.1
        elif sample_size < 10:
            return 0.3
        elif sample_size < 20:
            return 0.5
        elif sample_size < 50:
            return 0.7
        else:
            return 0.9
    
    async def _load_historical_data(self):
        """Load historical trade data from database."""
        try:
            # Load recent trades
            trades = db_manager.get_trades(limit=500)
            
            for trade in trades:
                # Convert database trade to TradeOutcomeData
                trade_outcome = self._convert_db_trade_to_outcome(trade)
                if trade_outcome:
                    self.trade_outcomes.append(trade_outcome)
            
            self.logger.system(f"Loaded {len(self.trade_outcomes)} historical trades")
            
        except Exception as e:
            self.logger.error("Error loading historical data", exception=e)
    
    def _convert_db_trade_to_outcome(self, db_trade: Dict[str, Any]) -> Optional[TradeOutcomeData]:
        """Convert database trade record to TradeOutcomeData."""
        try:
            # Determine outcome
            pnl = db_trade.get("pnl")
            if pnl is None:
                outcome = TradeOutcome.PENDING
            elif pnl > 0:
                outcome = TradeOutcome.WIN
            elif pnl < 0:
                outcome = TradeOutcome.LOSS
            else:
                outcome = TradeOutcome.BREAKEVEN
            
            # Parse timestamps
            entry_time = db_trade.get("entry_time")
            if isinstance(entry_time, str):
                entry_time = datetime.fromisoformat(entry_time)
            
            exit_time = db_trade.get("exit_time")
            if isinstance(exit_time, str):
                exit_time = datetime.fromisoformat(exit_time)
            
            # Calculate duration
            duration_minutes = None
            if entry_time and exit_time:
                duration_minutes = int((exit_time - entry_time).total_seconds() / 60)
            
            # Extract metadata
            metadata = db_trade.get("metadata", {})
            if isinstance(metadata, str):
                metadata = json.loads(metadata)
            
            return TradeOutcomeData(
                trade_id=db_trade.get("id", 0),
                symbol=db_trade.get("symbol", ""),
                side=db_trade.get("side", ""),
                entry_price=db_trade.get("entry_price", 0.0),
                exit_price=db_trade.get("exit_price"),
                quantity=db_trade.get("quantity", 0.0),
                leverage=db_trade.get("leverage", 1),
                entry_time=entry_time or datetime.now(),
                exit_time=exit_time,
                pnl=pnl,
                pnl_percentage=metadata.get("pnl_percentage"),
                outcome=outcome,
                duration_minutes=duration_minutes,
                prediction_confidence=metadata.get("prediction_confidence", 0.5),
                decision_reasoning=metadata.get("decision_reasoning", ""),
                market_condition=MarketCondition(metadata.get("market_condition", "unknown")),
                strategy_version=db_trade.get("strategy_version", "unknown"),
                rsi_entry=metadata.get("rsi_entry"),
                bollinger_position=metadata.get("bollinger_position"),
                volume_ratio=metadata.get("volume_ratio"),
                trend_strength=metadata.get("trend_strength"),
                risk_reward_ratio=metadata.get("risk_reward_ratio"),
                max_drawdown=metadata.get("max_drawdown"),
                stop_loss_hit=metadata.get("stop_loss_hit", False),
                take_profit_hit=metadata.get("take_profit_hit", False),
                metadata=metadata
            )
            
        except Exception as e:
            self.logger.error("Error converting DB trade to outcome", exception=e)
            return None
    
    async def _store_trade_outcome(self, trade_outcome: TradeOutcomeData):
        """Store trade outcome in database for learning."""
        try:
            learning_data = {
                "trade_id": trade_outcome.trade_id,
                "prediction": {
                    "confidence": trade_outcome.prediction_confidence,
                    "reasoning": trade_outcome.decision_reasoning,
                    "market_condition": trade_outcome.market_condition.value,
                    "strategy_version": trade_outcome.strategy_version
                },
                "actual_outcome": {
                    "result": trade_outcome.outcome.value,
                    "pnl_percentage": trade_outcome.pnl_percentage,
                    "duration_minutes": trade_outcome.duration_minutes
                },
                "accuracy_score": 1.0 if trade_outcome.outcome == TradeOutcome.WIN else 0.0,
                "learning_notes": f"Trade outcome analysis for {trade_outcome.symbol}",
                "strategy_adjustments": {}
            }
            
            db_manager.insert_learning_data(learning_data)
            
        except Exception as e:
            self.logger.error("Error storing trade outcome", exception=e)
    
    def _update_analysis_stats(self, insights: FeedbackInsights):
        """Update analysis statistics."""
        self.analysis_stats["total_analyses"] += 1
        
        if insights.confidence > 0.5:
            self.analysis_stats["successful_analyses"] += 1
        
        if insights.insights:
            self.analysis_stats["insights_generated"] += 1
        
        if len(insights.actionable_recommendations) > 0:
            self.analysis_stats["recommendations_made"] += len(insights.actionable_recommendations)
    
    def get_analysis_statistics(self) -> Dict[str, Any]:
        """Get feedback analysis statistics."""
        stats = self.analysis_stats.copy()
        
        # Add success rate
        if stats["total_analyses"] > 0:
            stats["success_rate"] = stats["successful_analyses"] / stats["total_analyses"]
        else:
            stats["success_rate"] = 0.0
        
        # Add data summary
        stats["data_summary"] = {
            "total_trade_outcomes": len(self.trade_outcomes),
            "feedback_history_size": len(self.feedback_history),
            "cache_size": len(self.analysis_cache)
        }
        
        return stats
    
    def cleanup_cache(self):
        """Clean up expired cache entries."""
        try:
            current_time = datetime.now()
            expired_keys = []
            
            for key, insights in self.analysis_cache.items():
                if current_time - insights.timestamp > self.cache_ttl:
                    expired_keys.append(key)
            
            for key in expired_keys:
                del self.analysis_cache[
key]
            
            if expired_keys:
                self.logger.debug(f"Cleaned up {len(expired_keys)} expired analysis cache entries")
                
        except Exception as e:
            self.logger.error("Error cleaning up analysis cache", exception=e)