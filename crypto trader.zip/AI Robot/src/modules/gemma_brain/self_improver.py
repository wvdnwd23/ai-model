"""
Self Improver - Autonomous code modification and improvement engine for Gemma Brain.

This module implements safe autonomous code modification capabilities:
- Strategy parameter optimization based on feedback
- Code pattern improvement suggestions
- Automated rollback mechanisms for failed improvements
- Safety validation before applying changes
- Performance monitoring of modifications
- Version control and change tracking
"""

import asyncio
import json
import os
import shutil
import hashlib
import time
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple, Union, Callable
from dataclasses import dataclass, asdict
from enum import Enum
from pathlib import Path
import ast
import inspect
import importlib.util

from src.utils.database import db_manager
from src.utils.logging import get_logger, get_performance_logger, TimedOperation
from src.utils.config import config_manager

class ImprovementType(Enum):
    """Types of improvements that can be made."""
    PARAMETER_OPTIMIZATION = "parameter_optimization"
    STRATEGY_REFINEMENT = "strategy_refinement"
    RISK_ADJUSTMENT = "risk_adjustment"
    CONFIDENCE_CALIBRATION = "confidence_calibration"
    PERFORMANCE_ENHANCEMENT = "performance_enhancement"
    BUG_FIX = "bug_fix"

class SafetyLevel(Enum):
    """Safety levels for code modifications."""
    SAFE = "safe"           # Parameter adjustments only
    MODERATE = "moderate"   # Logic modifications with validation
    RISKY = "risky"        # Structural changes requiring approval
    CRITICAL = "critical"  # Core system modifications

class ModificationStatus(Enum):
    """Status of code modifications."""
    PROPOSED = "proposed"
    VALIDATED = "validated"
    APPLIED = "applied"
    TESTING = "testing"
    SUCCESSFUL = "successful"
    FAILED = "failed"
    ROLLED_BACK = "rolled_back"

@dataclass
class CodeModification:
    """Represents a proposed code modification."""
    modification_id: str
    improvement_type: ImprovementType
    safety_level: SafetyLevel
    target_file: str
    target_function: str
    original_code: str
    modified_code: str
    reasoning: str
    expected_improvement: str
    confidence: float
    timestamp: datetime
    status: ModificationStatus
    
    # Validation and testing
    validation_results: Dict[str, Any]
    test_results: Dict[str, Any]
    performance_metrics: Dict[str, Any]
    
    # Rollback information
    backup_path: Optional[str] = None
    rollback_reason: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "modification_id": self.modification_id,
            "improvement_type": self.improvement_type.value,
            "safety_level": self.safety_level.value,
            "target_file": self.target_file,
            "target_function": self.target_function,
            "original_code": self.original_code,
            "modified_code": self.modified_code,
            "reasoning": self.reasoning,
            "expected_improvement": self.expected_improvement,
            "confidence": self.confidence,
            "timestamp": self.timestamp.isoformat(),
            "status": self.status.value,
            "validation_results": self.validation_results,
            "test_results": self.test_results,
            "performance_metrics": self.performance_metrics,
            "backup_path": self.backup_path,
            "rollback_reason": self.rollback_reason
        }

@dataclass
class ImprovementPlan:
    """Represents a comprehensive improvement plan."""
    plan_id: str
    modifications: List[CodeModification]
    priority: int
    estimated_impact: float
    risk_assessment: Dict[str, Any]
    dependencies: List[str]
    timeline: Dict[str, datetime]
    approval_required: bool

class SelfImprover:
    """
    Main self-improvement engine that coordinates autonomous code modifications.
    """
    
    def __init__(self, parent_brain):
        self.parent_brain = parent_brain
        self.logger = get_logger("self_improver")
        self.perf_logger = get_performance_logger("self_improver")
        
        # Configuration
        self.max_concurrent_modifications = 3
        self.safety_threshold = 0.7  # Minimum confidence for auto-apply
        self.backup_retention_days = 30
        
        # State tracking
        self.active_modifications: Dict[str, CodeModification] = {}
        self.modification_history: List[CodeModification] = []
        self.improvement_plans: Dict[str, ImprovementPlan] = {}
        
        # Safety mechanisms
        self.backup_directory = Path("backups/self_improver")
        self.backup_directory.mkdir(parents=True, exist_ok=True)
        
        # Performance tracking
        self.improvement_stats = {
            "total_modifications": 0,
            "successful_modifications": 0,
            "failed_modifications": 0,
            "rollbacks_performed": 0,
            "performance_improvements": 0,
            "average_confidence": 0.0
        }
        
    async def initialize(self):
        """Initialize the self-improver."""
        try:
            # Load existing modification history
            await self._load_modification_history()
            
            # Clean up old backups
            await self._cleanup_old_backups()
            
            self.logger.system("Self Improver initialized")
            
        except Exception as e:
            self.logger.error("Error initializing self improver", exception=e)
            raise
    
    async def analyze_improvement_opportunities(self, feedback_insights) -> List[CodeModification]:
        """
        Analyze feedback insights to identify code improvement opportunities.
        
        Args:
            feedback_insights: FeedbackInsights from feedback analyzer
            
        Returns:
            List of proposed code modifications
        """
        try:
            with TimedOperation(self.perf_logger, "improvement_analysis"):
                modifications = []
                
                # Analyze different types of improvements
                param_mods = await self._analyze_parameter_optimizations(feedback_insights)
                modifications.extend(param_mods)
                
                strategy_mods = await self._analyze_strategy_refinements(feedback_insights)
                modifications.extend(strategy_mods)
                
                risk_mods = await self._analyze_risk_adjustments(feedback_insights)
                modifications.extend(risk_mods)
                
                confidence_mods = await self._analyze_confidence_calibrations(feedback_insights)
                modifications.extend(confidence_mods)
                
                # Filter and prioritize modifications
                filtered_mods = await self._filter_and_prioritize_modifications(modifications)
                
                self.logger.learning("Improvement opportunities analyzed", {
                    "total_opportunities": len(modifications),
                    "filtered_opportunities": len(filtered_mods),
                    "high_confidence_count": len([m for m in filtered_mods if m.confidence > 0.8])
                })
                
                return filtered_mods
                
        except Exception as e:
            self.logger.error("Error analyzing improvement opportunities", exception=e)
            return []
    
    async def propose_modification(self, modification: CodeModification) -> bool:
        """
        Propose a code modification for validation and potential application.
        
        Args:
            modification: CodeModification to propose
            
        Returns:
            True if modification was successfully proposed
        """
        try:
            # Validate the modification
            validation_results = await self._validate_modification(modification)
            modification.validation_results = validation_results
            
            if not validation_results.get("is_valid", False):
                self.logger.warning("Modification failed validation", {
                    "modification_id": modification.modification_id,
                    "validation_errors": validation_results.get("errors", [])
                })
                return False
            
            # Store the proposed modification
            self.active_modifications[modification.modification_id] = modification
            modification.status = ModificationStatus.VALIDATED
            
            # Auto-apply if safety conditions are met
            if await self._should_auto_apply(modification):
                await self.apply_modification(modification.modification_id)
            
            self.logger.learning("Modification proposed", {
                "modification_id": modification.modification_id,
                "improvement_type": modification.improvement_type.value,
                "safety_level": modification.safety_level.value,
                "confidence": modification.confidence
            })
            
            return True
            
        except Exception as e:
            self.logger.error("Error proposing modification", exception=e)
            return False
    
    async def apply_modification(self, modification_id: str) -> bool:
        """
        Apply a validated code modification.
        
        Args:
            modification_id: ID of modification to apply
            
        Returns:
            True if modification was successfully applied
        """
        try:
            modification = self.active_modifications.get(modification_id)
            if not modification:
                self.logger.error("Modification not found", {"modification_id": modification_id})
                return False
            
            if modification.status != ModificationStatus.VALIDATED:
                self.logger.error("Modification not validated", {
                    "modification_id": modification_id,
                    "status": modification.status.value
                })
                return False
            
            # Create backup before applying
            backup_path = await self._create_backup(modification.target_file)
            modification.backup_path = backup_path
            
            # Apply the modification
            success = await self._apply_code_change(modification)
            
            if success:
                modification.status = ModificationStatus.APPLIED
                
                # Start testing phase
                await self._start_modification_testing(modification)
                
                self.logger.learning("Modification applied successfully", {
                    "modification_id": modification_id,
                    "target_file": modification.target_file,
                    "backup_path": backup_path
                })
                
                return True
            else:
                # Restore from backup if application failed
                await self._restore_from_backup(modification)
                modification.status = ModificationStatus.FAILED
                
                self.logger.error("Failed to apply modification", {
                    "modification_id": modification_id
                })
                
                return False
                
        except Exception as e:
            self.logger.error("Error applying modification", exception=e)
            return False
    
    async def rollback_modification(self, modification_id: str, reason: str = "Manual rollback") -> bool:
        """
        Rollback a previously applied modification.
        
        Args:
            modification_id: ID of modification to rollback
            reason: Reason for rollback
            
        Returns:
            True if rollback was successful
        """
        try:
            modification = self.active_modifications.get(modification_id)
            if not modification:
                # Check modification history
                modification = next(
                    (m for m in self.modification_history if m.modification_id == modification_id),
                    None
                )
            
            if not modification:
                self.logger.error("Modification not found for rollback", {
                    "modification_id": modification_id
                })
                return False
            
            if not modification.backup_path or not os.path.exists(modification.backup_path):
                self.logger.error("Backup not found for rollback", {
                    "modification_id": modification_id,
                    "backup_path": modification.backup_path
                })
                return False
            
            # Restore from backup
            success = await self._restore_from_backup(modification)
            
            if success:
                modification.status = ModificationStatus.ROLLED_BACK
                modification.rollback_reason = reason
                
                # Move to history if still active
                if modification_id in self.active_modifications:
                    self.modification_history.append(modification)
                    del self.active_modifications[modification_id]
                
                self.improvement_stats["rollbacks_performed"] += 1
                
                self.logger.learning("Modification rolled back", {
                    "modification_id": modification_id,
                    "reason": reason
                })
                
                return True
            else:
                self.logger.error("Failed to rollback modification", {
                    "modification_id": modification_id
                })
                return False
                
        except Exception as e:
            self.logger.error("Error rolling back modification", exception=e)
            return False
    
    async def _analyze_parameter_optimizations(self, feedback_insights) -> List[CodeModification]:
        """Analyze opportunities for parameter optimization."""
        modifications = []
        
        try:
            insights = feedback_insights.insights
            
            # Check for overconfidence patterns
            if insights.get("losing_patterns", {}).get("overconfidence_rate", 0) > 0.3:
                mod = await self._create_confidence_adjustment_modification(
                    "reduce_confidence_threshold",
                    "Lower confidence thresholds to reduce overconfidence",
                    0.8
                )
                if mod:
                    modifications.append(mod)
            
            # Check for risk management issues
            trade_analysis = insights.get("trade_analysis", {})
            if trade_analysis.get("confidence_accuracy") == "overconfident":
                mod = await self._create_risk_adjustment_modification(
                    "increase_risk_caution",
                    "Increase risk management caution based on overconfidence",
                    0.75
                )
                if mod:
                    modifications.append(mod)
            
        except Exception as e:
            self.logger.error("Error analyzing parameter optimizations", exception=e)
        
        return modifications
    
    async def _analyze_strategy_refinements(self, feedback_insights) -> List[CodeModification]:
        """Analyze opportunities for strategy refinements."""
        modifications = []
        
        try:
            insights = feedback_insights.insights
            winning_patterns = insights.get("winning_patterns", {})
            
            # Check for successful high-confidence patterns
            if winning_patterns.get("high_confidence_wins", 0) > 0:
                mod = await self._create_strategy_enhancement_modification(
                    "enhance_high_confidence_detection",
                    "Improve detection of high-confidence trading opportunities",
                    0.7
                )
                if mod:
                    modifications.append(mod)
            
        except Exception as e:
            self.logger.error("Error analyzing strategy refinements", exception=e)
        
        return modifications
    
    async def _analyze_risk_adjustments(self, feedback_insights) -> List[CodeModification]:
        """Analyze opportunities for risk adjustments."""
        modifications = []
        
        try:
            insights = feedback_insights.insights
            losing_patterns = insights.get("losing_patterns", {})
            
            # Check for quick losses
            if losing_patterns.get("quick_losses", 0) > losing_patterns.get("sample_size", 1) * 0.4:
                mod = await self._create_risk_adjustment_modification(
                    "improve_stop_loss_timing",
                    "Adjust stop-loss timing to reduce quick losses",
                    0.65
                )
                if mod:
                    modifications.append(mod)
            
        except Exception as e:
            self.logger.error("Error analyzing risk adjustments", exception=e)
        
        return modifications
    
    async def _analyze_confidence_calibrations(self, feedback_insights) -> List[CodeModification]:
        """Analyze opportunities for confidence calibration."""
        modifications = []
        
        try:
            insights = feedback_insights.insights
            trade_analysis = insights.get("trade_analysis", {})
            
            # Check confidence accuracy
            confidence_accuracy = trade_analysis.get("confidence_accuracy")
            if confidence_accuracy in ["overconfident", "underconfident"]:
                mod = await self._create_confidence_calibration_modification(
                    confidence_accuracy,
                    f"Calibrate confidence based on {confidence_accuracy} pattern",
                    0.7
                )
                if mod:
                    modifications.append(mod)
            
        except Exception as e:
            self.logger.error("Error analyzing confidence calibrations", exception=e)
        
        return modifications
    
    async def _create_confidence_adjustment_modification(self, target: str, reasoning: str, confidence: float) -> Optional[CodeModification]:
        """Create a confidence adjustment modification."""
        try:
            modification_id = f"conf_adj_{int(time.time())}"
            
            # This is a simplified example - in practice, you'd analyze actual code
            original_code = "confidence_threshold = 0.8"
            modified_code = "confidence_threshold = 0.7"
            
            return CodeModification(
                modification_id=modification_id,
                improvement_type=ImprovementType.CONFIDENCE_CALIBRATION,
                safety_level=SafetyLevel.SAFE,
                target_file="src/modules/ai_controller/controller.py",
                target_function="calculate_confidence",
                original_code=original_code,
                modified_code=modified_code,
                reasoning=reasoning,
                expected_improvement="Reduced overconfidence in trading decisions",
                confidence=confidence,
                timestamp=datetime.now(),
                status=ModificationStatus.PROPOSED,
                validation_results={},
                test_results={},
                performance_metrics={}
            )
            
        except Exception as e:
            self.logger.error("Error creating confidence adjustment modification", exception=e)
            return None
    
    async def _create_risk_adjustment_modification(self, target: str, reasoning: str, confidence: float) -> Optional[CodeModification]:
        """Create a risk adjustment modification."""
        try:
            modification_id = f"risk_adj_{int(time.time())}"
            
            # This is a simplified example
            original_code = "risk_multiplier = 1.0"
            modified_code = "risk_multiplier = 0.8"
            
            return CodeModification(
                modification_id=modification_id,
                improvement_type=ImprovementType.RISK_ADJUSTMENT,
                safety_level=SafetyLevel.SAFE,
                target_file="src/modules/verifier_executor/executor.py",
                target_function="calculate_position_size",
                original_code=original_code,
                modified_code=modified_code,
                reasoning=reasoning,
                expected_improvement="Improved risk management and reduced losses",
                confidence=confidence,
                timestamp=datetime.now(),
                status=ModificationStatus.PROPOSED,
                validation_results={},
                test_results={},
                performance_metrics={}
            )
            
        except Exception as e:
            self.logger.error("Error creating risk adjustment modification", exception=e)
            return None
    
    async def _create_strategy_enhancement_modification(self, target: str, reasoning: str, confidence: float) -> Optional[CodeModification]:
        """Create a strategy enhancement modification."""
        try:
            modification_id = f"strat_enh_{int(time.time())}"
            
            # This is a simplified example
            original_code = "signal_strength_threshold = 0.6"
            modified_code = "signal_strength_threshold = 0.7"
            
            return CodeModification(
                modification_id=modification_id,
                improvement_type=ImprovementType.STRATEGY_REFINEMENT,
                safety_level=SafetyLevel.MODERATE,
                target_file="src/modules/combiner/combiner.py",
                target_function="combine_signals",
                original_code=original_code,
                modified_code=modified_code,
                reasoning=reasoning,
                expected_improvement="Enhanced detection of high-quality trading signals",
                confidence=confidence,
                timestamp=datetime.now(),
                status=ModificationStatus.PROPOSED,
                validation_results={},
                test_results={},
                performance_metrics={}
            )
            
        except Exception as e:
            self.logger.error("Error creating strategy enhancement modification", exception=e)
            return None
    
    async def _create_confidence_calibration_modification(self, pattern: str, reasoning: str, confidence: float) -> Optional[CodeModification]:
        """Create a confidence calibration modification."""
        try:
            modification_id = f"conf_cal_{int(time.time())}"
            
            # Adjust based on pattern
            if pattern == "overconfident":
                original_code = "confidence *= 1.0"
                modified_code = "confidence *= 0.9"
            else:  # underconfident
                original_code = "confidence *= 1.0"
                modified_code = "confidence *= 1.1"
            
            return CodeModification(
                modification_id=modification_id,
                improvement_type=ImprovementType.CONFIDENCE_CALIBRATION,
                safety_level=SafetyLevel.SAFE,
                target_file="src/modules/ai_controller/controller.py",
                target_function="calculate_confidence",
                original_code=original_code,
                modified_code=modified_code,
                reasoning=reasoning,
                expected_improvement=f"Better confidence calibration for {pattern} patterns",
                confidence=confidence,
                timestamp=datetime.now(),
                status=ModificationStatus.PROPOSED,
                validation_results={},
                test_results={},
                performance_metrics={}
            )
            
        except Exception as e:
            self.logger.error("Error creating confidence calibration modification", exception=e)
            return None
    
    async def _filter_and_prioritize_modifications(self, modifications: List[CodeModification]) -> List[CodeModification]:
        """Filter and prioritize modifications based on safety and impact."""
        try:
            # Filter out low-confidence modifications
            filtered = [m for m in modifications if m.confidence >= 0.5]
            
            # Sort by confidence and safety level
            def sort_key(mod):
                safety_weight = {
                    SafetyLevel.SAFE: 4,
                    SafetyLevel.MODERATE: 3,
                    SafetyLevel.RISKY: 2,
                    SafetyLevel.CRITICAL: 1
                }
                return (safety_weight[mod.safety_level], mod.confidence)
            
            filtered.sort(key=sort_key, reverse=True)
            
            # Limit to max concurrent modifications
            return filtered[:self.max_concurrent_modifications]
            
        except Exception as e:
            self.logger.error("Error filtering modifications", exception=e)
            return modifications
    
    async def _validate_modification(self, modification: CodeModification) -> Dict[str, Any]:
        """Validate a code modification for safety and correctness."""
        try:
            validation_results = {
                "is_valid": True,
                "errors": [],
                "warnings": [],
                "safety_score": 1.0
            }
            
            # Syntax validation
            try:
                ast.parse(modification.modified_code)
            except SyntaxError as e:
                validation_results["is_valid"] = False
                validation_results["errors"].append(f"Syntax error: {str(e)}")
            
            # Safety level validation
            if modification.safety_level == SafetyLevel.CRITICAL:
                validation_results["warnings"].append("Critical modification requires manual approval")
            
            # File existence validation
            if not os.path.exists(modification.target_file):
                validation_results["is_valid"] = False
                validation_results["errors"].append(f"Target file not found: {modification.target_file}")
            
            return validation_results
            
        except Exception as e:
            self.logger.error("Error validating modification", exception=e)
            return {"is_valid": False, "errors": [str(e)]}
    
    async def _should_auto_apply(self, modification: CodeModification) -> bool:
        """Determine if a modification should be automatically applied."""
        try:
            # Check confidence threshold
            if modification.confidence < self.safety_threshold:
                return False
            
            # Check safety level
            if modification.safety_level in [SafetyLevel.RISKY, SafetyLevel.CRITICAL]:
                return False
            
            # Check if too many modifications are active
            if len(self.active_modifications) >= self.max_concurrent_modifications:
                return False
            
            return True
            
        except Exception as e:
            self.logger.error("Error checking auto-apply conditions", exception=e)
            return False
    
    async def _create_backup(self, file_path: str) -> str:
        """Create a backup of a file before modification."""
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            file_name = os.path.basename(file_path)
            backup_name = f"{file_name}_{timestamp}.backup"
            backup_path = self.backup_directory / backup_name
            
            shutil.copy2(file_path, backup_path)
            
            self.logger.debug("Backup created", {
                "original_file": file_path,
                "backup_path": str(backup_path)
            })
            
            return str(backup_path)
            
        except Exception as e:
            self.logger.error("Error creating backup", exception=e)
            raise
    
    async def _apply_code_change(self, modification: CodeModification) -> bool:
        """Apply the actual code change to the target file."""
        try:
            # Read the current file
            with open(modification.target_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Apply the modification (simplified - in practice, you'd use AST manipulation)
            modified_content = content.replace(
                modification.original_code,
                modification.modified_code
            )
            
            # Write the modified content
            with open(modification.target_file, 'w', encoding='utf-8') as f:
                f.write(modified_content)
            
            self.logger.debug("Code change applied", {
                "file": modification.target_file,
                "modification_id": modification.modification_id
            })
            
            return True
            
        except Exception as e:
            self.logger.error("Error applying code change", exception=e)
            return False
    
    async def _restore_from_backup(self, modification: CodeModification) -> bool:
        """Restore a file from its backup."""
        try:
            if not modification.backup_path or not os.path.exists(modification.backup_path):
                return False
            
            shutil.copy2(modification.backup_path, modification.target_file)
            
            self.logger.debug("File restored from backup", {
                "file": modification.target_file,
                "backup_path": modification.backup_path
            })
            
            return True
            
        except Exception as e:
            self.logger.error("Error restoring from backup", exception=e)
            return False
    
    async def _start_modification_testing(self, modification: CodeModification):
        """Start testing phase for an applied modification."""
        try:
            modification.status = ModificationStatus.TESTING
            
            # In a real implementation, you would:
            # 1. Run automated tests
            # 2. Monitor performance metrics
            # 3. Set up rollback triggers
            
            self.logger.learning("Modification testing started", {
                "modification_id": modification.modification_id
            })
            
        except Exception as e:
            self.logger.error("Error starting modification testing", exception=e)
    
    async def _load_modification_history(self):
        """Load modification history from database."""
        try:
            # Load from database if available
            history_data = db_manager.get_learning_data(
                category="self_improvement",
                limit=100
            )
            
            for data in history_data:
                # Convert database record to CodeModification
                # This is simplified - you'd implement proper deserialization
                pass
            
            self.logger.debug(f"Loaded {len(self.modification_history)} modifications from history")
            
        except Exception as e:
            self.logger.error("Error loading modification history", exception=e)
    
    async def _cleanup_old_backups(self):
        """Clean up old backup files."""
        try:
            cutoff_date = datetime.now() - timedelta(days=self.backup_retention_days)
            
            for backup_file in self.backup_directory.glob("*.backup"):
                if backup_file.stat().st_mtime < cutoff_date.timestamp():
                    backup_file.unlink()
                    self.logger.debug(f"Removed old backup: {backup_file}")
            
        except Exception as e:
            self.logger.error("Error cleaning up old backups", exception=e)
    
    def get_improvement_statistics(self) -> Dict[str, Any]:
        """Get self-improvement statistics."""
        stats = self.improvement_stats.copy()
        
        # Add current state
        stats["active_modifications"] = len(self.active_modifications)
        stats["total_history"] = len(self.modification_history)
        
        # Calculate success rate
        total = stats["successful_modifications"] + stats["failed_modifications"]
        if total > 0:
            stats["success_rate"] = stats["successful_modifications"] / total
        else:
            stats["success_rate"] = 0.0
        
        return stats