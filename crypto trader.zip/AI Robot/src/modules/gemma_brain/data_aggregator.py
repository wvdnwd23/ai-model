"""
Data Aggregator - Real-time data collection and correlation for Gemma Brain.

This module implements intelligent data aggregation from all trading modules:
- Real-time data collection from coin scanner, chart checker, combiner, verifier
- Data correlation and analysis
- Caching mechanisms for performance
- Data validation and quality checks
- Market context enrichment
"""

import asyncio
import json
import time
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple, Union
from dataclasses import dataclass, asdict
from enum import Enum
from collections import defaultdict, deque
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed

from src.utils.communication import ModuleCommunicator, Priority, CommunicationProtocol
from src.utils.database import db_manager
from src.utils.logging import get_logger, get_performance_logger, TimedOperation
from src.utils.config import config_manager

class DataSource(Enum):
    """Available data sources."""
    COIN_SCANNER = "coin_scanner"
    CHART_CHECKER = "chart_checker"
    COMBINER = "combiner"
    VERIFIER_EXECUTOR = "verifier_executor"
    MARKET_DATA = "market_data"
    NEWS_FEED = "news_feed"
    SOCIAL_SENTIMENT = "social_sentiment"

class DataQuality(Enum):
    """Data quality levels."""
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INVALID = "invalid"

@dataclass
class DataPoint:
    """Represents a single data point from a source."""
    source: DataSource
    timestamp: datetime
    symbol: Optional[str]
    data_type: str
    content: Dict[str, Any]
    quality: DataQuality
    confidence: float
    metadata: Dict[str, Any]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "source": self.source.value,
            "timestamp": self.timestamp.isoformat(),
            "symbol": self.symbol,
            "data_type": self.data_type,
            "content": self.content,
            "quality": self.quality.value,
            "confidence": self.confidence,
            "metadata": self.metadata
        }

@dataclass
class AggregatedData:
    """Represents aggregated data from multiple sources."""
    timestamp: datetime
    symbols: List[str]
    data_points: List[DataPoint]
    correlations: Dict[str, float]
    quality_score: float
    completeness: float
    market_context: Dict[str, Any]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "timestamp": self.timestamp.isoformat(),
            "symbols": self.symbols,
            "data_points": [dp.to_dict() for dp in self.data_points],
            "correlations": self.correlations,
            "quality_score": self.quality_score,
            "completeness": self.completeness,
            "market_context": self.market_context
        }

class RealTimeCollector:
    """
    Real-time data collector that gathers data from all trading modules.
    """
    
    def __init__(self, parent_aggregator):
        self.parent_aggregator = parent_aggregator
        self.logger = get_logger("real_time_collector")
        
        # Data collection state
        self.active_collections: Dict[str, asyncio.Task] = {}
        self.collection_intervals = {
            DataSource.COIN_SCANNER: 30,  # 30 seconds
            DataSource.CHART_CHECKER: 60,  # 1 minute
            DataSource.COMBINER: 45,  # 45 seconds
            DataSource.VERIFIER_EXECUTOR: 120,  # 2 minutes
            DataSource.MARKET_DATA: 15,  # 15 seconds
        }
        
        # Data buffers
        self.data_buffers: Dict[DataSource, deque] = {
            source: deque(maxlen=100) for source in DataSource
        }
        
        # Collection statistics
        self.collection_stats = {
            "total_collections": 0,
            "successful_collections": 0,
            "failed_collections": 0,
            "average_collection_time": 0.0,
            "last_collection_time": None
        }
        
    async def start_collection(self):
        """Start real-time data collection from all sources."""
        try:
            self.logger.system("Starting real-time data collection")
            
            # Start collection tasks for each source
            for source, interval in self.collection_intervals.items():
                task = asyncio.create_task(
                    self._collection_loop(source, interval)
                )
                self.active_collections[source.value] = task
            
            self.logger.system(f"Started {len(self.active_collections)} collection tasks")
            
        except Exception as e:
            self.logger.error("Error starting data collection", exception=e)
    
    async def stop_collection(self):
        """Stop all data collection tasks."""
        try:
            # Cancel all active collection tasks
            for task in self.active_collections.values():
                task.cancel()
            
            # Wait for tasks to complete
            if self.active_collections:
                await asyncio.gather(*self.active_collections.values(), return_exceptions=True)
            
            self.active_collections.clear()
            self.logger.system("Data collection stopped")
            
        except Exception as e:
            self.logger.error("Error stopping data collection", exception=e)
    
    async def _collection_loop(self, source: DataSource, interval: int):
        """Collection loop for a specific data source."""
        while True:
            try:
                start_time = time.time()
                
                # Collect data from source
                data_point = await self._collect_from_source(source)
                
                if data_point:
                    # Add to buffer
                    self.data_buffers[source].append(data_point)
                    
                    # Update statistics
                    self.collection_stats["successful_collections"] += 1
                    collection_time = time.time() - start_time
                    self._update_collection_stats(collection_time)
                    
                    self.logger.debug(f"Collected data from {source.value}", {
                        "data_type": data_point.data_type,
                        "quality": data_point.quality.value,
                        "confidence": data_point.confidence
                    })
                else:
                    self.collection_stats["failed_collections"] += 1
                
                self.collection_stats["total_collections"] += 1
                
                # Wait for next collection
                await asyncio.sleep(interval)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Error in collection loop for {source.value}", exception=e)
                await asyncio.sleep(interval)
    
    async def _collect_from_source(self, source: DataSource) -> Optional[DataPoint]:
        """Collect data from a specific source."""
        try:
            if source == DataSource.COIN_SCANNER:
                return await self._collect_coin_scanner_data()
            elif source == DataSource.CHART_CHECKER:
                return await self._collect_chart_checker_data()
            elif source == DataSource.COMBINER:
                return await self._collect_combiner_data()
            elif source == DataSource.VERIFIER_EXECUTOR:
                return await self._collect_verifier_data()
            elif source == DataSource.MARKET_DATA:
                return await self._collect_market_data()
            else:
                self.logger.warning(f"Unknown data source: {source}")
                return None
                
        except Exception as e:
            self.logger.error(f"Error collecting from {source.value}", exception=e)
            return None
    
    async def _collect_coin_scanner_data(self) -> Optional[DataPoint]:
        """Collect data from coin scanner module."""
        try:
            # Request recent scan results
            response = self.parent_aggregator.communicator.send_request(
                "coin_scanner",
                "get_recent_results",
                {"limit": 5},
                Priority.MEDIUM,
                timeout=10.0
            )
            
            if response:
                return DataPoint(
                    source=DataSource.COIN_SCANNER,
                    timestamp=datetime.now(),
                    symbol=response.get("primary_symbol"),
                    data_type="scan_results",
                    content=response,
                    quality=self._assess_data_quality(response),
                    confidence=response.get("confidence", 0.5),
                    metadata={"collection_method": "module_request"}
                )
            
            return None
            
        except Exception as e:
            self.logger.error("Error collecting coin scanner data", exception=e)
            return None
    
    async def _collect_chart_checker_data(self) -> Optional[DataPoint]:
        """Collect data from chart checker module."""
        try:
            # Request recent analysis results
            response = self.parent_aggregator.communicator.send_request(
                "chart_checker",
                "get_recent_analysis",
                {"limit": 3},
                Priority.MEDIUM,
                timeout=15.0
            )
            
            if response:
                return DataPoint(
                    source=DataSource.CHART_CHECKER,
                    timestamp=datetime.now(),
                    symbol=response.get("symbol"),
                    data_type="technical_analysis",
                    content=response,
                    quality=self._assess_data_quality(response),
                    confidence=response.get("confidence", 0.5),
                    metadata={"collection_method": "module_request"}
                )
            
            return None
            
        except Exception as e:
            self.logger.error("Error collecting chart checker data", exception=e)
            return None
    
    async def _collect_combiner_data(self) -> Optional[DataPoint]:
        """Collect data from combiner module."""
        try:
            # Request recent decisions
            response = self.parent_aggregator.communicator.send_request(
                "combiner",
                "get_recent_decisions",
                {"limit": 3},
                Priority.MEDIUM,
                timeout=10.0
            )
            
            if response:
                return DataPoint(
                    source=DataSource.COMBINER,
                    timestamp=datetime.now(),
                    symbol=response.get("symbol"),
                    data_type="trading_decisions",
                    content=response,
                    quality=self._assess_data_quality(response),
                    confidence=response.get("confidence", 0.5),
                    metadata={"collection_method": "module_request"}
                )
            
            return None
            
        except Exception as e:
            self.logger.error("Error collecting combiner data", exception=e)
            return None
    
    async def _collect_verifier_data(self) -> Optional[DataPoint]:
        """Collect data from verifier/executor module."""
        try:
            # Request recent execution results
            response = self.parent_aggregator.communicator.send_request(
                "verifier_executor",
                "get_recent_executions",
                {"limit": 5},
                Priority.MEDIUM,
                timeout=10.0
            )
            
            if response:
                return DataPoint(
                    source=DataSource.VERIFIER_EXECUTOR,
                    timestamp=datetime.now(),
                    symbol=response.get("symbol"),
                    data_type="execution_results",
                    content=response,
                    quality=self._assess_data_quality(response),
                    confidence=response.get("success_rate", 0.5),
                    metadata={"collection_method": "module_request"}
                )
            
            return None
            
        except Exception as e:
            self.logger.error("Error collecting verifier data", exception=e)
            return None
    
    async def _collect_market_data(self) -> Optional[DataPoint]:
        """Collect general market data."""
        try:
            # Get market data from database cache
            market_data = {}
            
            # Get recent performance metrics
            performance = db_manager.get_performance_metrics(days=1)
            if performance:
                market_data["performance"] = performance
            
            # Get system health
            market_data["system_health"] = {
                "timestamp": datetime.now().isoformat(),
                "active_modules": len(self.parent_aggregator.communicator.communicator.subscribers)
            }
            
            if market_data:
                return DataPoint(
                    source=DataSource.MARKET_DATA,
                    timestamp=datetime.now(),
                    symbol=None,
                    data_type="market_context",
                    content=market_data,
                    quality=DataQuality.MEDIUM,
                    confidence=0.8,
                    metadata={"collection_method": "database_query"}
                )
            
            return None
            
        except Exception as e:
            self.logger.error("Error collecting market data", exception=e)
            return None
    
    def _assess_data_quality(self, data: Dict[str, Any]) -> DataQuality:
        """Assess the quality of collected data."""
        try:
            quality_score = 0
            
            # Check data completeness
            if data and isinstance(data, dict):
                quality_score += 1
                
                # Check for required fields
                if "timestamp" in data or "time" in data:
                    quality_score += 1
                
                if "confidence" in data and isinstance(data["confidence"], (int, float)):
                    quality_score += 1
                
                # Check data freshness
                timestamp_field = data.get("timestamp") or data.get("time")
                if timestamp_field:
                    try:
                        if isinstance(timestamp_field, str):
                            data_time = datetime.fromisoformat(timestamp_field.replace('Z', '+00:00'))
                        else:
                            data_time = timestamp_field
                        
                        age = datetime.now() - data_time.replace(tzinfo=None)
                        if age < timedelta(minutes=5):
                            quality_score += 1
                    except:
                        pass
                
                # Check data size
                if len(str(data)) > 100:  # Substantial data
                    quality_score += 1
            
            # Map score to quality level
            if quality_score >= 4:
                return DataQuality.HIGH
            elif quality_score >= 2:
                return DataQuality.MEDIUM
            elif quality_score >= 1:
                return DataQuality.LOW
            else:
                return DataQuality.INVALID
                
        except Exception as e:
            self.logger.error("Error assessing data quality", exception=e)
            return DataQuality.LOW
    
    def _update_collection_stats(self, collection_time: float):
        """Update collection statistics."""
        try:
            # Update average collection time
            total = self.collection_stats["total_collections"]
            current_avg = self.collection_stats["average_collection_time"]
            
            self.collection_stats["average_collection_time"] = (
                (current_avg * (total - 1) + collection_time) / total
            )
            
            self.collection_stats["last_collection_time"] = datetime.now()
            
        except Exception as e:
            self.logger.error("Error updating collection stats", exception=e)
    
    def get_recent_data(self, source: DataSource, limit: int = 10) -> List[DataPoint]:
        """Get recent data points from a specific source."""
        try:
            buffer = self.data_buffers.get(source, deque())
            return list(buffer)[-limit:]
        except Exception as e:
            self.logger.error(f"Error getting recent data for {source.value}", exception=e)
            return []
    
    def get_collection_statistics(self) -> Dict[str, Any]:
        """Get collection statistics."""
        return self.collection_stats.copy()


class DataAggregator:
    """
    Main data aggregator that coordinates real-time data collection and analysis.
    """
    
    def __init__(self, parent_brain):
        self.parent_brain = parent_brain
        self.logger = get_logger("data_aggregator")
        self.perf_logger = get_performance_logger("data_aggregator")
        
        # Communication
        self.communicator = parent_brain.communicator
        
        # Components
        self.real_time_collector = RealTimeCollector(self)
        
        # Data storage
        self.aggregated_data_cache: Dict[str, AggregatedData] = {}
        self.cache_ttl = timedelta(minutes=10)
        
        # Correlation analysis
        self.correlation_history: deque = deque(maxlen=1000)
        
        # Aggregation statistics
        self.aggregation_stats = {
            "total_aggregations": 0,
            "successful_aggregations": 0,
            "average_aggregation_time": 0.0,
            "data_quality_average": 0.0,
            "completeness_average": 0.0
        }
        
    async def initialize(self):
        """Initialize the data aggregator."""
        try:
            # Start real-time collection
            await self.real_time_collector.start_collection()
            
            self.logger.system("Data Aggregator initialized and collection started")
            
        except Exception as e:
            self.logger.error("Error initializing data aggregator", exception=e)
            raise
    
    async def shutdown(self):
        """Shutdown the data aggregator."""
        try:
            # Stop real-time collection
            await self.real_time_collector.stop_collection()
            
            self.logger.system("Data Aggregator shutdown completed")
            
        except Exception as e:
            self.logger.error("Error shutting down data aggregator", exception=e)
    
    async def collect_all_data(self, symbols: Optional[List[str]] = None) -> AggregatedData:
        """
        Collect and aggregate data from all sources.
        
        Args:
            symbols: Optional list of symbols to focus on
            
        Returns:
            AggregatedData object with all collected and correlated data
        """
        try:
            with TimedOperation(self.perf_logger, "data_aggregation"):
                start_time = time.time()
                
                # Collect data from all sources
                all_data_points = []
                
                for source in DataSource:
                    recent_data = self.real_time_collector.get_recent_data(source, limit=5)
                    all_data_points.extend(recent_data)
                
                # Filter by symbols if specified
                if symbols:
                    all_data_points = [
                        dp for dp in all_data_points 
                        if dp.symbol is None or dp.symbol in symbols
                    ]
                
                # Perform correlation analysis
                correlations = self._analyze_correlations(all_data_points)
                
                # Calculate quality metrics
                quality_score = self._calculate_quality_score(all_data_points)
                completeness = self._calculate_completeness(all_data_points)
                
                # Get market context
                market_context = await self._get_market_context()
                
                # Create aggregated data
                aggregated = AggregatedData(
                    timestamp=datetime.now(),
                    symbols=symbols or self._extract_symbols(all_data_points),
                    data_points=all_data_points,
                    correlations=correlations,
                    quality_score=quality_score,
                    completeness=completeness,
                    market_context=market_context
                )
                
                # Update statistics
                aggregation_time = time.time() - start_time
                self._update_aggregation_stats(aggregation_time, quality_score, completeness)
                
                # Cache the result
                cache_key = f"{datetime.now().strftime('%Y%m%d_%H%M')}_{hash(str(symbols))}"
                self.aggregated_data_cache[cache_key] = aggregated
                
                self.logger.system("Data aggregation completed", {
                    "data_points": len(all_data_points),
                    "symbols": len(aggregated.symbols),
                    "quality_score": quality_score,
                    "completeness": completeness,
                    "aggregation_time": aggregation_time
                })
                
                return aggregated
                
        except Exception as e:
            self.logger.error("Error in data aggregation", exception=e)
            
            # Return empty aggregated data on error
            return AggregatedData(
                timestamp=datetime.now(),
                symbols=symbols or [],
                data_points=[],
                correlations={},
                quality_score=0.0,
                completeness=0.0,
                market_context={}
            )
    
    def _analyze_correlations(self, data_points: List[DataPoint]) -> Dict[str, float]:
        """Analyze correlations between different data sources."""
        try:
            correlations = {}
            
            # Group data points by source
            source_data = defaultdict(list)
            for dp in data_points:
                source_data[dp.source].append(dp)
            
            # Calculate correlations between sources
            sources = list(source_data.keys())
            for i, source1 in enumerate(sources):
                for source2 in sources[i+1:]:
                    correlation = self._calculate_source_correlation(
                        source_data[source1], 
                        source_data[source2]
                    )
                    correlations[f"{source1.value}_{source2.value}"] = correlation
            
            # Calculate temporal correlations
            temporal_correlation = self._calculate_temporal_correlation(data_points)
            correlations["temporal_alignment"] = temporal_correlation
            
            return correlations
            
        except Exception as e:
            self.logger.error("Error analyzing correlations", exception=e)
            return {}
    
    def _calculate_source_correlation(self, data1: List[DataPoint], data2: List[DataPoint]) -> float:
        """Calculate correlation between two data sources."""
        try:
            if not data1 or not data2:
                return 0.0
            
            # Simple correlation based on confidence scores and timing
            conf1 = [dp.confidence for dp in data1]
            conf2 = [dp.confidence for dp in data2]
            
            if len(conf1) != len(conf2):
                # Align by taking minimum length
                min_len = min(len(conf1), len(conf2))
                conf1 = conf1[:min_len]
                conf2 = conf2[:min_len]
            
            if len(conf1) < 2:
                return 0.5  # Neutral correlation for insufficient data
            
            # Calculate Pearson correlation coefficient
            import statistics
            
            mean1 = statistics.mean(conf1)
            mean2 = statistics.mean(conf2)
            
            numerator = sum((x - mean1) * (y - mean2) for x, y in zip(conf1, conf2))
            
            sum_sq1 = sum((x - mean1) ** 2 for x in conf1)
            sum_sq2 = sum((x - mean2) ** 2 for x in conf2)
            
            denominator = (sum_sq1 * sum_sq2) ** 0.5
            
            if denominator == 0:
                return 0.0
            
            correlation = numerator / denominator
            return max(-1.0, min(1.0, correlation))  # Clamp to [-1, 1]
            
        except Exception as e:
            self.logger.error("Error calculating source correlation", exception=e)
            return 0.0
    
    def _calculate_temporal_correlation(self, data_points: List[DataPoint]) -> float:
        """Calculate temporal correlation of data points."""
        try:
            if len(data_points) < 2:
                return 0.0
            
            # Sort by timestamp
            sorted_points = sorted(data_points, key=lambda dp: dp.timestamp)
            
            # Calculate time gaps
            time_gaps = []
            for i in range(1, len(sorted_points)):
                gap = (sorted_points[i].timestamp - sorted_points[i-1].timestamp).total_seconds()
                time_gaps.append(gap)
            
            if not time_gaps:
                return 1.0
            
            # Calculate consistency of time gaps (lower variance = higher correlation)
            import statistics
            
            if len(time_gaps) == 1:
                return 1.0
            
            mean_gap = statistics.mean(time_gaps)
            variance = statistics.variance(time_gaps)
            
            # Normalize variance to correlation score
            if mean_gap == 0:
                return 1.0
            
            coefficient_of_variation = (variance ** 0.5) / mean_gap
            correlation = max(0.0, 1.0 - min(1.0, coefficient_of_variation))
            
            return correlation
            
        except Exception as e:
            self.logger.error("Error calculating temporal correlation", exception=e)
            return 0.0
    
    def _calculate_quality_score(self, data_points: List[DataPoint]) -> float:
        """Calculate overall quality score for data points."""
        try:
            if not data_points:
                return 0.0
            
            quality_values = {
                DataQuality.HIGH: 1.0,
                DataQuality.MEDIUM: 0.7,
                DataQuality.LOW: 0.4,
                DataQuality.INVALID: 0.0
            }
            
            total_score = sum(quality_values[dp.quality] for dp in data_points)
            return total_score / len(data_points)
            
        except Exception as e:
            self.logger.error("Error calculating quality score", exception=e)
            return 0.0
    
    def _calculate_completeness(self, data_points: List[DataPoint]) -> float:
        """Calculate data completeness score."""
        try:
            # Check how many expected sources we have data from
            expected_sources = {DataSource.COIN_SCANNER, DataSource.CHART_CHECKER, 
                              DataSource.COMBINER, DataSource.VERIFIER_EXECUTOR}
            
            present_sources = {dp.source for dp in data_points}
            coverage = len(present_sources & expected_sources) / len(expected_sources)
            
            # Factor in data freshness
            if data_points:
                now = datetime.now()
                freshness_scores = []
                
                for dp in data_points:
                    age = (now - dp.timestamp).total_seconds()
                    # Data is considered fresh if less than 5 minutes old
                    freshness = max(0.0, 1.0 - (age / 300))
                    freshness_scores.append(freshness)
                
                avg_freshness = sum(freshness_scores) / len(freshness_scores)
                completeness = (coverage + avg_freshness) / 2
            else:
                completeness = coverage
            
            return completeness
            
        except Exception as e:
            self.logger.error("Error calculating completeness", exception=e)
            return 0.0
    
    def _extract_symbols(self, data_points: List[DataPoint]) -> List[str]:
        """Extract unique symbols from data points."""
        try:
            symbols = set()
            for dp in data_points:
                if dp.symbol:
                    symbols.add(dp.symbol)
            return list(symbols)
        except Exception as e:
            self.logger.error("Error extracting symbols", exception=e)
            return []
    
    async def _get_market_context(self) -> Dict[str, Any]:
        """Get current market context."""
        try:
            context = {
                "timestamp": datetime.now().isoformat(),
                "collection_stats": self.real_time_collector.get_collection_statistics(),
                "aggregation_stats": self.aggregation_stats.copy()
            }
            
            # Add system health information
            try:
                import psutil
                context["system_resources"] = {
                    "cpu_percent": psutil.cpu_percent(),
                    "memory_percent": psutil.virtual_memory().percent,
                    "disk_percent": psutil.disk_usage('/').percent
                }
            except ImportError:
                context["system_resources"] = {"available": False}
            
            return context
            
        except Exception as e:
            self.logger.error("Error getting market context", exception=e)
            return {}
    
    def _update_aggregation_stats(self, aggregation_time: float, quality_score: float, completeness: float):
        """Update aggregation statistics."""
        try:
            self.aggregation_stats["total_aggregations"] += 1
            self.aggregation_stats["successful_aggregations"] += 1
            
            # Update averages
            total = self.aggregation_stats["total_aggregations"]
            
            current_avg_time = self.aggregation_stats["average_aggregation_time"]
            self.aggregation_stats["average_aggregation_time"] = (
                (current_avg_time * (total - 1) + aggregation_time) / total
            )
            
            current_avg_quality = self.aggregation_stats["data_quality_average"]
            self.aggregation_stats["data_quality_average"] = (
                (current_avg_quality * (total - 1) + quality_score) / total
            )
            
            current_avg_completeness = self.aggregation_stats["completeness_average"]
            self.aggregation_stats["completeness_average"] = (
                (current_avg_completeness * (total - 1) + completeness) / total
            )
            
        except Exception as e:
            self.logger.error("Error updating aggregation stats", exception=e)
    
    def get_aggregation_statistics(self) -> Dict[str, Any]:
        """Get aggregation statistics."""
        stats = self.aggregation_stats.copy()
        stats["collection_stats"] = self.real_time_collector.get_collection_statistics()
        stats["cache_size"] = len(self.aggregated_data_cache)
        return stats
    
    def cleanup_cache(self):
        """Clean up expired cache entries."""
        try:
            current_time = datetime.now()
            expired_keys = []
            
            for key, aggregated_data in self.aggregated_data_cache.items():
                if current_time - aggregated_data.timestamp > self.cache_ttl:
                    expired_keys.append(key)
            
            for key in expired_keys:
                del self.aggregated_data_cache[key]
            
            if expired_keys:
                self.logger.debug(f"Cleaned up {len(expired_keys)} expired cache entries")
                
        except Exception as e:
            self.logger.error("Error cleaning up cache", exception=e)