"""
Coin Scanner module - Identifies breakout opportunities through sentiment and volume analysis.

Performs sentiment analysis and volume anomaly detection, web scraping for 
Twitter/X, Reddit, Cointelegraph, pattern matching for breakout identification,
and outputs JSON with confidence scores.
"""

from .scanner import CoinScanner, SentimentAnalyzer, VolumeDetector, PatternMatcher

__all__ = [
    "CoinScanner",
    "SentimentAnalyzer", 
    "VolumeDetector",
    "PatternMatcher"
]