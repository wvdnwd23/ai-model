"""
AI Coin Scanner - Identifies breakout opportunities through sentiment and volume analysis.
Scrapes social media, news sources, and market data for trading signals.
Enhanced with OpenAI gpt-4o-mini for advanced AI-powered analysis.
"""

import asyncio
import json
import re
import time
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass
import statistics

import requests
from bs4 import BeautifulSoup
import pandas as pd
import numpy as np
from textblob import TextBlob

from src.utils.communication import ModuleCommunicator, message_bus, Priority
from src.utils.browser_automation import BrowserManager, WebScraper
from src.utils.database import db_manager
from src.utils.config import config_manager
from src.utils.logging import get_logger, get_performance_logger, TimedOperation
from src.utils.openai_client import openai_client, TaskType
from src.utils.ai_prompt_templates import prompt_templates

@dataclass
class CoinSignal:
    """Represents a trading signal for a cryptocurrency."""
    symbol: str
    exchange: str
    volume_anomaly: float
    sentiment_score: float
    breakout_probability: float
    social_mentions: int
    price_change_24h: float
    market_cap_rank: int
    confidence: float
    reasoning: str
    timestamp: datetime

class SentimentAnalyzer:
    """Analyzes sentiment from social media and news sources."""
    
    def __init__(self):
        self.logger = get_logger("sentiment_analyzer")
        
        # Sentiment keywords
        self.bullish_keywords = [
            "moon", "bullish", "pump", "breakout", "rally", "surge", "rocket",
            "buy", "long", "hodl", "diamond hands", "to the moon", "bull run"
        ]
        
        self.bearish_keywords = [
            "dump", "crash", "bearish", "sell", "short", "drop", "fall",
            "bear", "panic", "liquidation", "correction", "dip"
        ]
    
    def analyze_text(self, text: str) -> float:
        """Analyze sentiment of text. Returns score between -1 (bearish) and 1 (bullish)."""
        try:
            # Clean text
            text = text.lower().strip()
            
            # Use TextBlob for basic sentiment
            blob = TextBlob(text)
            base_sentiment = blob.sentiment.polarity
            
            # Enhance with crypto-specific keywords
            bullish_count = sum(1 for keyword in self.bullish_keywords if keyword in text)
            bearish_count = sum(1 for keyword in self.bearish_keywords if keyword in text)
            
            # Calculate keyword sentiment
            keyword_sentiment = 0
            if bullish_count + bearish_count > 0:
                keyword_sentiment = (bullish_count - bearish_count) / (bullish_count + bearish_count)
            
            # Combine sentiments (weighted average)
            final_sentiment = (base_sentiment * 0.6) + (keyword_sentiment * 0.4)
            
            # Normalize to [-1, 1]
            return max(-1, min(1, final_sentiment))
            
        except Exception as e:
            self.logger.error(f"Error analyzing sentiment: {e}")
            return 0.0
    
    def analyze_multiple_texts(self, texts: List[str]) -> Dict[str, float]:
        """Analyze sentiment of multiple texts and return aggregated metrics."""
        if not texts:
            return {"average": 0.0, "positive_ratio": 0.0, "confidence": 0.0, "sample_size": 0}
        
        sentiments = [self.analyze_text(text) for text in texts]
        
        # Calculate metrics
        average_sentiment = statistics.mean(sentiments)
        positive_count = len([s for s in sentiments if s > 0.1])
        positive_ratio = positive_count / len(sentiments)
        
        # Confidence based on consistency
        sentiment_std = statistics.stdev(sentiments) if len(sentiments) > 1 else 0
        confidence = max(0, 1 - sentiment_std)
        
        return {
            "average": average_sentiment,
            "positive_ratio": positive_ratio,
            "confidence": confidence,
            "sample_size": len(texts)
        }
    
    async def analyze_with_ai(self, symbol: str, texts: List[str], market_data: Dict[str, Any]) -> Dict[str, float]:
        """Use AI (Gemma-2-2B-IT) for advanced sentiment analysis."""
        try:
            if not texts:
                return {"average": 0.0, "positive_ratio": 0.0, "confidence": 0.0, "sample_size": 0}
            
            # Get optimized prompt for sentiment analysis
            prompt_data = prompt_templates.get_coin_scanner_sentiment_prompt(
                symbol=symbol,
                social_data=texts,
                price=market_data.get("price", 0),
                volume=market_data.get("volume_24h", 0),
                price_change_24h=market_data.get("price_change_24h", 0)
            )
            
            # Use OpenRouter with Gemma-2-2B-IT for fast sentiment analysis
            response = await openai_client.generate_response(
                prompt=prompt_data["prompt"],
                task_type=TaskType.MARKET_SCANNING,
                context={
                    "role": "crypto sentiment analyzer",
                    "output_format": "JSON with sentiment_score, confidence, key_factors, recommendation",
                    "constraints": "Be fast and accurate, focus on actionable insights"
                },
                
            )
            
            if response.success:
                try:
                    ai_result = json.loads(response.content)
                    
                    # Validate and normalize AI response
                    sentiment_score = max(-1.0, min(1.0, ai_result.get("sentiment_score", 0.0)))
                    confidence = max(0.0, min(1.0, ai_result.get("confidence", 0.5)))
                    
                    # Calculate positive ratio from sentiment score
                    positive_ratio = (sentiment_score + 1) / 2
                    
                    self.logger.decision("AI sentiment analysis completed", {
                        "symbol": symbol,
                        "sentiment_score": sentiment_score,
                        "confidence": confidence,
                        "model_used": response.model_used,
                        "tokens_used": response.tokens_used,
                        "cost": response.cost
                    })
                    
                    return {
                        "average": sentiment_score,
                        "positive_ratio": positive_ratio,
                        "confidence": confidence,
                        "sample_size": len(texts),
                        "ai_insights": ai_result.get("key_factors", []),
                        "ai_recommendation": ai_result.get("recommendation", "neutral")
                    }
                    
                except json.JSONDecodeError:
                    self.logger.warning("Failed to parse AI sentiment response, falling back to traditional analysis")
                    return self.analyze_multiple_texts(texts)
            else:
                self.logger.warning(f"AI sentiment analysis failed: {response.error_message}, falling back to traditional analysis")
                return self.analyze_multiple_texts(texts)
                
        except Exception as e:
            self.logger.error(f"Error in AI sentiment analysis: {e}, falling back to traditional analysis")
            return self.analyze_multiple_texts(texts)

class VolumeDetector:
    """Detects volume anomalies and trading patterns."""
    
    def __init__(self):
        self.logger = get_logger("volume_detector")
    
    def detect_volume_anomaly(self, current_volume: float, historical_volumes: List[float]) -> float:
        """Detect volume anomaly. Returns multiplier (e.g., 2.5 = 2.5x normal volume)."""
        try:
            if not historical_volumes or current_volume <= 0:
                return 1.0
            
            # Calculate average historical volume
            avg_volume = statistics.mean(historical_volumes)
            
            if avg_volume <= 0:
                return 1.0
            
            # Calculate volume multiplier
            volume_multiplier = current_volume / avg_volume
            
            return volume_multiplier
            
        except Exception as e:
            self.logger.error(f"Error detecting volume anomaly: {e}")
            return 1.0
    
    def analyze_price_volume_relationship(self, prices: List[float], volumes: List[float]) -> Dict[str, float]:
        """Analyze relationship between price and volume movements."""
        try:
            if len(prices) != len(volumes) or len(prices) < 2:
                return {"correlation": 0.0, "strength": 0.0}
            
            # Calculate price changes
            price_changes = [prices[i] - prices[i-1] for i in range(1, len(prices))]
            volume_changes = [volumes[i] - volumes[i-1] for i in range(1, len(volumes))]
            
            # Calculate correlation
            if len(price_changes) > 1:
                correlation = np.corrcoef(price_changes, volume_changes)[0, 1]
                if np.isnan(correlation):
                    correlation = 0.0
            else:
                correlation = 0.0
            
            # Calculate strength (how significant the volume is)
            avg_volume = statistics.mean(volumes)
            recent_volume = volumes[-1] if volumes else 0
            strength = min(recent_volume / avg_volume, 5.0) if avg_volume > 0 else 0.0
            
            return {
                "correlation": correlation,
                "strength": strength
            }
            
        except Exception as e:
            self.logger.error(f"Error analyzing price-volume relationship: {e}")
            return {"correlation": 0.0, "strength": 0.0}

class PatternMatcher:
    """Identifies breakout patterns and technical signals."""
    
    def __init__(self):
        self.logger = get_logger("pattern_matcher")
    
    def detect_breakout_pattern(self, prices: List[float], volumes: List[float]) -> Dict[str, Any]:
        """Detect potential breakout patterns."""
        try:
            if len(prices) < 10:
                return {"pattern": "insufficient_data", "probability": 0.0}
            
            # Calculate moving averages
            short_ma = statistics.mean(prices[-5:])  # 5-period MA
            long_ma = statistics.mean(prices[-10:])  # 10-period MA
            
            # Current price
            current_price = prices[-1]
            
            # Volume analysis
            recent_volume = statistics.mean(volumes[-3:]) if len(volumes) >= 3 else 0
            avg_volume = statistics.mean(volumes[:-3]) if len(volumes) > 3 else recent_volume
            
            volume_ratio = recent_volume / avg_volume if avg_volume > 0 else 1.0
            
            # Pattern detection
            patterns = []
            
            # Bullish breakout
            if (current_price > short_ma > long_ma and 
                volume_ratio > 1.5 and 
                prices[-1] > prices[-2]):
                patterns.append({
                    "pattern": "bullish_breakout",
                    "probability": min(0.9, 0.5 + (volume_ratio - 1.5) * 0.2),
                    "reasoning": f"Price above MAs with {volume_ratio:.1f}x volume"
                })
            
            # Volume spike
            if volume_ratio > 2.0:
                patterns.append({
                    "pattern": "volume_spike",
                    "probability": min(0.8, volume_ratio * 0.2),
                    "reasoning": f"Volume spike: {volume_ratio:.1f}x normal"
                })
            
            # Price momentum
            if len(prices) >= 5:
                price_momentum = (prices[-1] - prices[-5]) / prices[-5] if prices[-5] > 0 else 0
                if price_momentum > 0.05:  # 5% gain
                    patterns.append({
                        "pattern": "price_momentum",
                        "probability": min(0.7, price_momentum * 10),
                        "reasoning": f"Strong momentum: {price_momentum*100:.1f}%"
                    })
            
            # Return best pattern
            if patterns:
                best_pattern = max(patterns, key=lambda x: x["probability"])
                return best_pattern
            else:
                return {"pattern": "no_pattern", "probability": 0.0, "reasoning": "No significant patterns detected"}
                
        except Exception as e:
            self.logger.error(f"Error detecting breakout pattern: {e}")
            return {"pattern": "error", "probability": 0.0, "reasoning": str(e)}

class CoinScanner:
    """Main coin scanner that coordinates all analysis components."""
    
    def __init__(self):
        self.logger = get_logger("coin_scanner")
        self.perf_logger = get_performance_logger("coin_scanner")
        
        # Communication
        self.communicator = ModuleCommunicator("coin_scanner", message_bus)
        self._setup_request_handlers()
        
        # Analysis components
        self.sentiment_analyzer = SentimentAnalyzer()
        self.volume_detector = VolumeDetector()
        self.pattern_matcher = PatternMatcher()
        
        # Browser automation
        self.browser_manager = BrowserManager(headless=True)
        self.web_scraper = WebScraper(self.browser_manager)
        
        # Data sources
        self.data_sources = {
            "coingecko": "https://api.coingecko.com/api/v3",
            "coinmarketcap": "https://pro-api.coinmarketcap.com/v1",
            "reddit": "https://www.reddit.com/r/cryptocurrency",
            "twitter": "https://twitter.com/search"
        }
        
        # Cache for market data
        self.market_data_cache = {}
        self.cache_expiry = timedelta(minutes=5)
        
        self.logger.system("Coin Scanner initialized with AI capabilities")
    
    def _setup_request_handlers(self):
        """Set up request handlers for inter-module communication."""
        handlers = {
            "scan_coins": self._handle_scan_coins,
            "get_coin_data": self._handle_get_coin_data,
            "analyze_sentiment": self._handle_analyze_sentiment,
            "health_check": self._handle_health_check
        }
        
        for request_type, handler in handlers.items():
            self.communicator.register_request_handler(request_type, handler)
    
    async def start(self):
        """Start the coin scanner."""
        try:
            await self.browser_manager.start()
            self.logger.system("Coin Scanner started successfully")
        except Exception as e:
            self.logger.error("Failed to start Coin Scanner", exception=e)
            raise
    
    async def stop(self):
        """Stop the coin scanner."""
        try:
            await self.browser_manager.stop()
            self.logger.system("Coin Scanner stopped")
        except Exception as e:
            self.logger.error("Error stopping Coin Scanner", exception=e)
    
    async def scan_coins(self, symbols: List[str], timeframe: str = "1h") -> Dict[str, Any]:
        """Scan coins for trading opportunities with AI enhancement."""
        try:
            with TimedOperation(self.perf_logger, "coin_scan", {"symbols": symbols}):
                self.logger.system(f"Starting AI-enhanced coin scan for {len(symbols)} symbols")
                
                signals = []
                
                for symbol in symbols:
                    try:
                        signal = await self._analyze_coin_with_ai(symbol, timeframe)
                        if signal and signal.confidence > 0.5:  # Only include confident signals
                            signals.append(signal)
                    except Exception as e:
                        self.logger.error(f"Error analyzing {symbol}", exception=e)
                
                # Sort by confidence
                signals.sort(key=lambda x: x.confidence, reverse=True)
                
                # Convert to dict format
                result = {
                    "coins": [self._signal_to_dict(signal) for signal in signals],
                    "scan_duration": time.time(),  # Will be updated by TimedOperation
                    "total_coins_analyzed": len(symbols),
                    "signals_found": len(signals),
                    "ai_enhanced": True,
                    "timestamp": datetime.now().isoformat()
                }
                
                self.logger.decision("AI-enhanced coin scan completed", {
                    "symbols_scanned": len(symbols),
                    "signals_found": len(signals),
                    "top_signal": signals[0].symbol if signals else None
                })
                
                return result
                
        except Exception as e:
            self.logger.error("Error in coin scan", exception=e)
            return {"coins": [], "error": str(e)}
    
    async def _analyze_coin_with_ai(self, symbol: str, timeframe: str) -> Optional[CoinSignal]:
        """Analyze a single coin with AI enhancement."""
        try:
            # Get market data
            market_data = await self._get_market_data(symbol)
            if not market_data:
                return None
            
            # Get social sentiment with AI enhancement
            sentiment_data = await self._get_ai_enhanced_sentiment(symbol, market_data)
            
            # Analyze volume
            volume_analysis = self._analyze_volume(market_data)
            
            # Detect patterns
            pattern_analysis = self._analyze_patterns(market_data)
            
            # Calculate overall confidence
            confidence = self._calculate_confidence(
                market_data, sentiment_data, volume_analysis, pattern_analysis
            )
            
            # Create signal
            signal = CoinSignal(
                symbol=symbol,
                exchange="MEXC",  # Default exchange
                volume_anomaly=volume_analysis.get("anomaly_multiplier", 1.0),
                sentiment_score=sentiment_data.get("average", 0.0),
                breakout_probability=pattern_analysis.get("probability", 0.0),
                social_mentions=sentiment_data.get("sample_size", 0),
                price_change_24h=market_data.get("price_change_24h", 0.0),
                market_cap_rank=market_data.get("market_cap_rank", 999),
                confidence=confidence,
                reasoning=self._generate_ai_reasoning(sentiment_data, volume_analysis, pattern_analysis),
                timestamp=datetime.now()
            )
            
            return signal
            
        except Exception as e:
            self.logger.error(f"Error analyzing coin {symbol} with AI", exception=e)
            return None
    
    async def _get_ai_enhanced_sentiment(self, symbol: str, market_data: Dict[str, Any]) -> Dict[str, Any]:
        """Get AI-enhanced social sentiment data for a symbol."""
        try:
            # Scrape Reddit for mentions
            reddit_texts = await self._scrape_reddit_sentiment(symbol)
            
            # Scrape Twitter (simplified - would need API access)
            twitter_texts = await self._scrape_twitter_sentiment(symbol)
            
            # Combine all texts
            all_texts = reddit_texts + twitter_texts
            
            # Use AI for sentiment analysis if OpenRouter is available
            if openai_client.is_available() and all_texts:
                sentiment_analysis = await self.sentiment_analyzer.analyze_with_ai(symbol, all_texts, market_data)
            else:
                # Fallback to traditional analysis
                sentiment_analysis = self.sentiment_analyzer.analyze_multiple_texts(all_texts)
            
            return sentiment_analysis
            
        except Exception as e:
            self.logger.error(f"Error getting AI-enhanced sentiment for {symbol}", exception=e)
            return {"average": 0.0, "positive_ratio": 0.0, "confidence": 0.0, "sample_size": 0}
    
    async def _get_market_data(self, symbol: str) -> Optional[Dict[str, Any]]:
        """Get market data for a symbol."""
        try:
            # Check cache first
            cache_key = f"{symbol}_market_data"
            if (cache_key in self.market_data_cache and 
                datetime.now() - self.market_data_cache[cache_key]["timestamp"] < self.cache_expiry):
                return self.market_data_cache[cache_key]["data"]
            
            # Fetch from CoinGecko API
            url = f"{self.data_sources['coingecko']}/simple/price"
            params = {
                "ids": symbol.lower(),
                "vs_currencies": "usd",
                "include_24hr_change": "true",
                "include_24hr_vol": "true",
                "include_market_cap": "true"
            }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            
            if symbol.lower() in data:
                coin_data = data[symbol.lower()]
                
                # Get historical data for volume analysis
                historical_data = await self._get_historical_data(symbol, days=7)
                
                market_data = {
                    "price": coin_data.get("usd", 0),
                    "price_change_24h": coin_data.get("usd_24h_change", 0),
                    "volume_24h": coin_data.get("usd_24h_vol", 0),
                    "market_cap": coin_data.get("usd_market_cap", 0),
                    "market_cap_rank": 999,  # Would need separate API call
                    "historical_prices": historical_data.get("prices", []),
                    "historical_volumes": historical_data.get("volumes", [])
                }
                
                # Cache the data
                self.market_data_cache[cache_key] = {
                    "data": market_data,
                    "timestamp": datetime.now()
                }
                
                return market_data
            
            return None
            
        except Exception as e:
            self.logger.error(f"Error getting market data for {symbol}", exception=e)
            return None
    
    async def _get_historical_data(self, symbol: str, days: int = 7) -> Dict[str, List]:
        """Get historical price and volume data."""
        try:
            url = f"{self.data_sources['coingecko']}/coins/{symbol.lower()}/market_chart"
            params = {
                "vs_currency": "usd",
                "days": days,
                "interval": "hourly"
            }
            
            response = requests.get(url, params=params, timeout=15)
            response.raise_for_status()
            
            data = response.json()
            
            return {
                "prices": [point[1] for point in data.get("prices", [])],
                "volumes": [point[1] for point in data.get("total_volumes", [])]
            }
            
        except Exception as e:
            self.logger.error(f"Error getting historical data for {symbol}", exception=e)
            return {"prices": [], "volumes": []}
    
    async def _scrape_reddit_sentiment(self, symbol: str) -> List[str]:
        """Scrape Reddit for sentiment about a symbol."""
        try:
            # Use browser automation to scrape Reddit
            page = await self.browser_manager.get_page("reddit")
            
            # Search for the symbol
            search_url = f"https://www.reddit.com/r/CryptoCurrency/search/?q={symbol}&restrict_sr=1&sort=new"
            await page.goto(search_url)
            
            # Wait for content to load
            await asyncio.sleep(3)
            
            # Extract post titles and comments
            texts = await page.evaluate("""
                () => {
                    const posts = document.querySelectorAll('[data-testid="post-content"]');
                    const texts = [];
                    posts.forEach(post => {
                        const title = post.querySelector('h3');
                        if (title) texts.push(title.textContent);
                    });
                    return texts.slice(0, 20); // Limit to 20 posts
                }
            """)
            
            return texts or []
            
        except Exception as e:
            self.logger.error(f"Error scraping Reddit sentiment for {symbol}", exception=e)
            return []
    
    async def _scrape_twitter_sentiment(self, symbol: str) -> List[str]:
        """Scrape Twitter for sentiment about a symbol."""
        try:
            # Simplified Twitter scraping (would need proper API access)
            # For now, return empty list
            return []
            
        except Exception as e:
            self.logger.error(f"Error scraping Twitter sentiment for {symbol}", exception=e)
            return []
    
    def _analyze_volume(self, market_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze volume patterns."""
        try:
            current_volume = market_data.get("volume_24h", 0)
            historical_volumes = market_data.get("historical_volumes", [])
            
            if not historical_volumes:
                return {"anomaly_multiplier": 1.0, "strength": 0.0}
            
            # Detect volume anomaly
            anomaly_multiplier = self.volume_detector.detect_volume_anomaly(
                current_volume, historical_volumes[:-1]  # Exclude current volume
            )
            
            # Analyze price-volume relationship
            historical_prices = market_data.get("historical_prices", [])
            pv_analysis = self.volume_detector.analyze_price_volume_relationship(
                historical_prices, historical_volumes
            )
            
            return {
                "anomaly_multiplier": anomaly_multiplier,
                "strength": pv_analysis.get("strength", 0.0),
                "correlation": pv_analysis.get("correlation", 0.0)
            }
            
        except Exception as e:
            self.logger.error("Error analyzing volume", exception=e)
            return {"anomaly_multiplier": 1.0, "strength": 0.0}
    
    def _analyze_patterns(self, market_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze price patterns."""
        try:
            historical_prices = market_data.get("historical_prices", [])
            historical_volumes = market_data.get("historical_volumes", [])
            
            if len(historical_prices) < 10:
                return {"pattern": "insufficient_data", "probability": 0.0}
            
            # Detect breakout patterns
            pattern_analysis = self.pattern_matcher.detect_breakout_pattern(
                historical_prices, historical_volumes
            )
            
            return pattern_analysis
            
        except Exception as e:
            self.logger.error("Error analyzing patterns", exception=e)
            return {"pattern": "error", "probability": 0.0}
    
    def _calculate_confidence(self, market_data: Dict[str, Any], sentiment_data: Dict[str, Any],
                            volume_analysis: Dict[str, Any], pattern_analysis: Dict[str, Any]) -> float:
        """Calculate overall confidence score."""
        try:
            # Weight factors
            weights = {
                "sentiment": 0.25,
                "volume": 0.35,
                "pattern": 0.30,
                "market_cap": 0.10
            }
            
            # Sentiment score (normalize to 0-1)
            sentiment_score = (sentiment_data.get("average", 0) + 1) / 2
            sentiment_confidence = sentiment_data.get("confidence", 0)
            sentiment_factor = sentiment_score * sentiment_confidence
            
            # Volume factor
            volume_anomaly = volume_analysis.get("anomaly_multiplier", 1.0)
            volume_factor = min(1.0, max(0.0, (volume_anomaly - 1.0) / 2.0))  # Normalize
            
            # Pattern factor
            pattern_factor = pattern_analysis.get("probability", 0.0)
            
            # Market cap factor (prefer higher market cap for stability)
            market_cap_rank = market_data.get("market_cap_rank", 999)
            market_cap_factor = max(0.0, 1.0 - (market_cap_rank / 1000))
            
            # Calculate weighted confidence
            confidence = (
                sentiment_factor * weights["sentiment"] +
                volume_factor * weights["volume"] +
                pattern_factor * weights["pattern"] +
                market_cap_factor * weights["market_cap"]
            )
            
            return min(1.0, max(0.0, confidence))
            
        except Exception as e:
            self.logger.error("Error calculating confidence", exception=e)
            return 0.0
    
    def _generate_ai_reasoning(self, sentiment_data: Dict[str, Any], volume_analysis: Dict[str, Any],
                              pattern_analysis: Dict[str, Any]) -> str:
        """Generate human-readable reasoning for the signal with AI insights."""
        reasons = []
        
        # AI insights if available
        if "ai_insights" in sentiment_data:
            ai_insights = sentiment_data.get("ai_insights", [])
            if ai_insights:
                reasons.append(f"AI insights: {', '.join(ai_insights[:3])}")
        
        # Sentiment reasoning
        sentiment_avg = sentiment_data.get("average", 0)
        if sentiment_avg > 0.3:
            reasons.append(f"Positive sentiment ({sentiment_avg:.2f})")
        elif sentiment_avg < -0.3:
            reasons.append(f"Negative sentiment ({sentiment_avg:.2f})")
        
        # Volume reasoning
        volume_anomaly = volume_analysis.get("anomaly_multiplier", 1.0)
        if volume_anomaly > 1.5:
            reasons.append(f"Volume spike ({volume_anomaly:.1f}x normal)")
        
        # Pattern reasoning
        pattern_prob = pattern_analysis.get("probability", 0.0)
        pattern_type = pattern_analysis.get("pattern", "")
        if pattern_prob > 0.5:
            reasons.append(f"{pattern_type} pattern ({pattern_prob:.1f} probability)")
        
        return "; ".join(reasons) if reasons else "No significant signals"
    
    def _signal_to_dict(self, signal: CoinSignal) -> Dict[str, Any]:
        """Convert CoinSignal to dictionary format."""
        return {
            "symbol": signal.symbol,
            "exchange": signal.exchange,
            "volume_anomaly": signal.volume_anomaly,
            "sentiment_score": signal.sentiment_score,
            "breakout_probability": signal.breakout_probability,
            "social_mentions": signal.social_mentions,
            "price_change_24h": signal.price_change_24h,
            "market_cap_rank": signal.market_cap_rank,
            "confidence": signal.confidence,
            "reasoning": signal.reasoning,
            "timestamp": signal.timestamp.isoformat()
        }
    
    # Request handlers
    def _handle_scan_coins(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle coin scan requests."""
        symbols = data.get("symbols", ["BTC", "ETH", "BNB"])
        timeframe = data.get("timeframe", "1h")
        
        # Run scan in async context
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result = loop.run_until_complete(self.scan_coins(symbols, timeframe))
            return result
        except Exception as e:
            self.logger.error("Error in scan_coins handler", exception=e)
            return {"coins": [], "error": str(e)}
        finally:
            loop.close()
    
    def _handle_get_coin_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle requests for specific coin data."""
        symbol = data.get("symbol")
        if not symbol:
            return {"error": "Symbol required"}
        
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            market_data = loop.run_until_complete(self._get_market_data(symbol))
            return market_data or {"error": "No data found"}
        except Exception as e:
            self.logger.error(f"Error getting coin data for {symbol}", exception=e)
            return {"error": str(e)}
        finally:
            loop.close()
    
    def _handle_analyze_sentiment(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle sentiment analysis requests."""
        symbol = data.get("symbol")
        texts = data.get("texts", [])
        
        if not symbol:
            return {"error": "Symbol required"}
        
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            market_data = loop.run_until_complete(self._get_market_data(symbol)) or {}
            sentiment_data = loop.run_until_complete(
                self.sentiment_analyzer.analyze_with_ai(symbol, texts, market_data)
            )
            return sentiment_data
        except Exception as e:
            self.logger.error(f"Error analyzing sentiment for {symbol}", exception=e)
            return {"error": str(e)}
        finally:
            loop.close()
    
    def _handle_health_check(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle health check requests."""
        return {
            "status": "healthy",
            "module": "coin_scanner",
            "ai_enabled": openai_client.is_available(),
            "cache_size": len(self.market_data_cache),
            "timestamp": datetime.now().isoformat()
        }

# Global scanner instance
scanner = CoinScanner()