"""
AI Chart Checker - Multi-timeframe technical analysis module.
Analyzes RSI, MACD, Bollinger Bands, Wyckoff, FVG, and IFVG patterns.
Enhanced with OpenAI gpt-4o-mini for advanced technical analysis.
"""

import asyncio
import json
import time
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass
import statistics

import numpy as np
import pandas as pd
# Try to import talib with fallback
try:
    import talib
    TALIB_AVAILABLE = True
except ImportError:
    TALIB_AVAILABLE = False
    # Create mock talib functions for fallback
    class MockTalib:
        @staticmethod
        def RSI(prices, timeperiod=14):
            return np.full_like(prices, 50.0)  # Neutral RSI
        
        @staticmethod
        def MACD(prices, fastperiod=12, slowperiod=26, signalperiod=9):
            zeros = np.zeros_like(prices)
            return zeros, zeros, zeros
        
        @staticmethod
        def BBANDS(prices, timeperiod=20, nbdevup=2, nbdevdn=2):
            avg = np.mean(prices)
            return np.full_like(prices, avg), np.full_like(prices, avg), np.full_like(prices, avg)
        
        @staticmethod
        def SMA(prices, timeperiod=20):
            return np.full_like(prices, np.mean(prices))
    
    talib = MockTalib()
import requests

from src.utils.communication import ModuleCommunicator, message_bus, Priority
from src.utils.browser_automation import BrowserManager, WebScraper
from src.utils.database import db_manager
from src.utils.config import config_manager
from src.utils.logging import get_logger, get_performance_logger, TimedOperation
from src.utils.openai_client import openai_client, TaskType
from src.utils.ai_prompt_templates import AIPromptTemplates

@dataclass
class TechnicalIndicators:
    """Technical indicators for a specific timeframe."""
    rsi: float
    macd_line: float
    macd_signal: float
    macd_histogram: float
    bb_upper: float
    bb_middle: float
    bb_lower: float
    bb_position: str  # "upper", "middle", "lower"
    bb_squeeze: bool
    volume_sma: float
    price_sma_20: float
    price_sma_50: float

@dataclass
class TimeframeAnalysis:
    """Analysis results for a specific timeframe."""
    timeframe: str
    trend: str  # "bullish", "bearish", "neutral"
    indicators: TechnicalIndicators
    support: float
    resistance: float
    confidence: float
    signals: List[str]
    ai_analysis: Optional[Dict[str, Any]] = None

@dataclass
class ChartAnalysis:
    """Complete chart analysis for a symbol."""
    symbol: str
    timeframes: Dict[str, TimeframeAnalysis]
    wyckoff_phase: str
    fvg_gaps: List[Dict[str, Any]]
    ifvg_gaps: List[Dict[str, Any]]
    overall_bias: str
    overall_confidence: float
    timestamp: datetime
    ai_enhanced: bool = False

class TechnicalAnalyzer:
    """Performs technical analysis calculations."""
    
    def __init__(self):
        self.logger = get_logger("technical_analyzer")
    
    def calculate_rsi(self, prices: List[float], period: int = 14) -> float:
        """Calculate RSI indicator."""
        try:
            if len(prices) < period + 1:
                return 50.0  # Neutral RSI
            
            prices_array = np.array(prices, dtype=float)
            rsi = talib.RSI(prices_array, timeperiod=period)
            
            # Return the last valid RSI value
            valid_rsi = rsi[~np.isnan(rsi)]
            return float(valid_rsi[-1]) if len(valid_rsi) > 0 else 50.0
            
        except Exception as e:
            self.logger.error(f"Error calculating RSI: {e}")
            return 50.0
    
    def calculate_macd(self, prices: List[float], fast: int = 12, slow: int = 26, signal: int = 9) -> Tuple[float, float, float]:
        """Calculate MACD indicator."""
        try:
            if len(prices) < slow + signal:
                return 0.0, 0.0, 0.0
            
            prices_array = np.array(prices, dtype=float)
            macd_line, macd_signal, macd_hist = talib.MACD(prices_array, fastperiod=fast, slowperiod=slow, signalperiod=signal)
            
            # Get last valid values
            valid_indices = ~(np.isnan(macd_line) | np.isnan(macd_signal) | np.isnan(macd_hist))
            if np.any(valid_indices):
                last_valid_idx = np.where(valid_indices)[0][-1]
                return float(macd_line[last_valid_idx]), float(macd_signal[last_valid_idx]), float(macd_hist[last_valid_idx])
            
            return 0.0, 0.0, 0.0
            
        except Exception as e:
            self.logger.error(f"Error calculating MACD: {e}")
            return 0.0, 0.0, 0.0
    
    def calculate_bollinger_bands(self, prices: List[float], period: int = 20, std_dev: float = 2.0) -> Tuple[float, float, float]:
        """Calculate Bollinger Bands."""
        try:
            if len(prices) < period:
                avg_price = statistics.mean(prices) if prices else 0.0
                return avg_price, avg_price, avg_price
            
            prices_array = np.array(prices, dtype=float)
            bb_upper, bb_middle, bb_lower = talib.BBANDS(prices_array, timeperiod=period, nbdevup=std_dev, nbdevdn=std_dev)
            
            # Get last valid values
            valid_indices = ~(np.isnan(bb_upper) | np.isnan(bb_middle) | np.isnan(bb_lower))
            if np.any(valid_indices):
                last_valid_idx = np.where(valid_indices)[0][-1]
                return float(bb_upper[last_valid_idx]), float(bb_middle[last_valid_idx]), float(bb_lower[last_valid_idx])
            
            avg_price = statistics.mean(prices)
            return avg_price, avg_price, avg_price
            
        except Exception as e:
            self.logger.error(f"Error calculating Bollinger Bands: {e}")
            avg_price = statistics.mean(prices) if prices else 0.0
            return avg_price, avg_price, avg_price
    
    def calculate_sma(self, prices: List[float], period: int) -> float:
        """Calculate Simple Moving Average."""
        try:
            if len(prices) < period:
                return statistics.mean(prices) if prices else 0.0
            
            prices_array = np.array(prices, dtype=float)
            sma = talib.SMA(prices_array, timeperiod=period)
            
            valid_sma = sma[~np.isnan(sma)]
            return float(valid_sma[-1]) if len(valid_sma) > 0 else 0.0
            
        except Exception as e:
            self.logger.error(f"Error calculating SMA: {e}")
            return statistics.mean(prices[-period:]) if len(prices) >= period else 0.0
    
    def find_support_resistance(self, prices: List[float], volumes: List[float] = None) -> Tuple[float, float]:
        """Find support and resistance levels."""
        try:
            if len(prices) < 10:
                min_price = min(prices) if prices else 0.0
                max_price = max(prices) if prices else 0.0
                return min_price, max_price
            
            # Use recent price data (last 50 periods)
            recent_prices = prices[-50:] if len(prices) > 50 else prices
            
            # Find local minima and maxima
            prices_array = np.array(recent_prices)
            
            # Simple support/resistance using percentiles
            support = np.percentile(prices_array, 20)  # 20th percentile as support
            resistance = np.percentile(prices_array, 80)  # 80th percentile as resistance
            
            return float(support), float(resistance)
            
        except Exception as e:
            self.logger.error(f"Error finding support/resistance: {e}")
            min_price = min(prices) if prices else 0.0
            max_price = max(prices) if prices else 0.0
            return min_price, max_price

class AIChartAnalyzer:
    """AI-enhanced chart analysis using GPT-4o."""
    
    def __init__(self):
        self.logger = get_logger("ai_chart_analyzer")
        # Using global openai_client instead of instance variable
        self.prompt_templates = AIPromptTemplates()
    
    async def analyze_with_ai(self, symbol: str, timeframe: str, 
                            indicators: TechnicalIndicators, 
                            chart_data: Dict[str, List[float]],
                            support: float, resistance: float) -> Optional[Dict[str, Any]]:
        """Perform AI-enhanced chart analysis using GPT-4o."""
        try:
            # Prepare chart data for AI analysis
            analysis_data = self._prepare_chart_data_for_ai(
                symbol, timeframe, indicators, chart_data, support, resistance
            )
            
            # Generate AI prompt
            prompt = self.prompt_templates.get_chart_analysis_prompt(analysis_data)
            
            # Get AI analysis
            ai_response = await openai_client.generate_response(
                prompt=prompt,
                
                task_type=TaskType.CHART_ANALYSIS,
                max_tokens=800
            )
            
            if ai_response and ai_response.get("success"):
                analysis = self._parse_ai_analysis(ai_response.get("content", ""))
                if analysis:
                    self.logger.decision("AI chart analysis completed", {
                        "symbol": symbol,
                        "timeframe": timeframe,
                        "ai_confidence": analysis.get("confidence", 0),
                        "ai_trend": analysis.get("trend", "unknown")
                    })
                    return analysis
            
            return None
            
        except Exception as e:
            self.logger.error(f"Error in AI chart analysis for {symbol} {timeframe}", exception=e)
            return None
    
    def _prepare_chart_data_for_ai(self, symbol: str, timeframe: str,
                                 indicators: TechnicalIndicators,
                                 chart_data: Dict[str, List[float]],
                                 support: float, resistance: float) -> Dict[str, Any]:
        """Prepare chart data for AI analysis."""
        try:
            closes = chart_data.get("closes", [])
            volumes = chart_data.get("volumes", [])
            
            # Calculate price changes and trends
            price_change_1 = ((closes[-1] - closes[-2]) / closes[-2] * 100) if len(closes) >= 2 else 0
            price_change_5 = ((closes[-1] - closes[-6]) / closes[-6] * 100) if len(closes) >= 6 else 0
            price_change_20 = ((closes[-1] - closes[-21]) / closes[-21] * 100) if len(closes) >= 21 else 0
            
            # Volume analysis
            avg_volume = statistics.mean(volumes[-20:]) if len(volumes) >= 20 else 0
            current_volume = volumes[-1] if volumes else 0
            volume_ratio = (current_volume / avg_volume) if avg_volume > 0 else 1
            
            return {
                "symbol": symbol,
                "timeframe": timeframe,
                "current_price": closes[-1] if closes else 0,
                "price_changes": {
                    "1_period": round(price_change_1, 2),
                    "5_periods": round(price_change_5, 2),
                    "20_periods": round(price_change_20, 2)
                },
                "technical_indicators": {
                    "rsi": round(indicators.rsi, 2),
                    "macd_signal": "bullish" if indicators.macd_line > indicators.macd_signal else "bearish",
                    "macd_histogram": round(indicators.macd_histogram, 4),
                    "bb_position": indicators.bb_position,
                    "price_vs_sma20": "above" if closes[-1] > indicators.price_sma_20 else "below",
                    "price_vs_sma50": "above" if closes[-1] > indicators.price_sma_50 else "below"
                },
                "support_resistance": {
                    "support": round(support, 4),
                    "resistance": round(resistance, 4),
                    "distance_to_support": round(abs(closes[-1] - support) / support * 100, 2) if support > 0 else 0,
                    "distance_to_resistance": round(abs(resistance - closes[-1]) / closes[-1] * 100, 2) if resistance > 0 else 0
                },
                "volume_analysis": {
                    "volume_ratio": round(volume_ratio, 2),
                    "volume_trend": "high" if volume_ratio > 1.5 else "normal" if volume_ratio > 0.5 else "low"
                }
            }
            
        except Exception as e:
            self.logger.error(f"Error preparing chart data for AI: {e}")
            return {}
    
    def _parse_ai_analysis(self, ai_content: str) -> Optional[Dict[str, Any]]:
        """Parse AI analysis response."""
        try:
            # Try to parse as JSON first
            if ai_content.strip().startswith('{'):
                return json.loads(ai_content)
            
            # If not JSON, extract key information using text parsing
            analysis = {
                "trend": "neutral",
                "confidence": 0.5,
                "signals": [],
                "key_levels": {},
                "risk_assessment": "medium",
                "ai_reasoning": ai_content[:500]  # First 500 chars
            }
            
            content_lower = ai_content.lower()
            
            # Extract trend
            if "bullish" in content_lower or "uptrend" in content_lower:
                analysis["trend"] = "bullish"
            elif "bearish" in content_lower or "downtrend" in content_lower:
                analysis["trend"] = "bearish"
            
            # Extract confidence indicators
            if "high confidence" in content_lower or "strong" in content_lower:
                analysis["confidence"] = 0.8
            elif "low confidence" in content_lower or "weak" in content_lower:
                analysis["confidence"] = 0.3
            
            # Extract signals
            signals = []
            if "buy" in content_lower:
                signals.append("AI suggests buy signal")
            if "sell" in content_lower:
                signals.append("AI suggests sell signal")
            if "hold" in content_lower:
                signals.append("AI suggests hold")
            
            analysis["signals"] = signals
            
            return analysis
            
        except Exception as e:
            self.logger.error(f"Error parsing AI analysis: {e}")
            return None

class ChartChecker:
    """Main chart checker that coordinates technical analysis."""
    
    def __init__(self):
        self.logger = get_logger("chart_checker")
        self.perf_logger = get_performance_logger("chart_checker")
        
        # Communication
        self.communicator = ModuleCommunicator("chart_checker", message_bus)
        self._setup_request_handlers()
        
        # Analysis components
        self.technical_analyzer = TechnicalAnalyzer()
        
        # AI components
        
        self.ai_analyzer = AIChartAnalyzer()
        
        # Browser automation for TradingView data
        self.browser_manager = BrowserManager(headless=True)
        
        # Data cache
        self.chart_data_cache = {}
        self.cache_expiry = timedelta(minutes=5)
        
        self.logger.system("Chart Checker initialized with GPT-4o integration")
    
    def _setup_request_handlers(self):
        """Set up request handlers for inter-module communication."""
        handlers = {
            "analyze_chart": self._handle_analyze_chart,
            "get_technical_indicators": self._handle_get_technical_indicators,
            "health_check": self._handle_health_check
        }
        
        for request_type, handler in handlers.items():
            self.communicator.register_request_handler(request_type, handler)
    
    async def start(self):
        """Start the chart checker."""
        try:
            await self.browser_manager.start()
            self.logger.system("Chart Checker started successfully")
        except Exception as e:
            self.logger.error("Failed to start Chart Checker", exception=e)
            raise
    
    async def stop(self):
        """Stop the chart checker."""
        try:
            await self.browser_manager.stop()
            self.logger.system("Chart Checker stopped")
        except Exception as e:
            self.logger.error("Error stopping Chart Checker", exception=e)
    
    async def analyze_chart(self, symbol: str, timeframes: List[str], use_ai: bool = True) -> Dict[str, Any]:
        """Analyze chart for multiple timeframes with optional AI enhancement."""
        try:
            with TimedOperation(self.perf_logger, "chart_analysis", {"symbol": symbol, "timeframes": timeframes}):
                self.logger.system(f"Starting chart analysis for {symbol} on timeframes: {timeframes}")
                
                timeframe_analyses = {}
                ai_enhanced = False
                
                for timeframe in timeframes:
                    try:
                        analysis = await self._analyze_timeframe(symbol, timeframe, use_ai)
                        if analysis:
                            timeframe_analyses[timeframe] = analysis
                            if analysis.ai_analysis:
                                ai_enhanced = True
                    except Exception as e:
                        self.logger.error(f"Error analyzing {symbol} on {timeframe}", exception=e)
                
                if not timeframe_analyses:
                    return {"error": "No timeframe analysis completed"}
                
                # Calculate overall bias and confidence
                overall_bias, overall_confidence = self._calculate_overall_bias(timeframe_analyses, ai_enhanced)
                
                result = {
                    "symbol": symbol,
                    "timeframes": {tf: self._timeframe_analysis_to_dict(analysis) 
                                 for tf, analysis in timeframe_analyses.items()},
                    "wyckoff_phase": "accumulation",  # Simplified
                    "fvg_gaps": [],  # Simplified
                    "overall_bias": overall_bias,
                    "overall_confidence": overall_confidence,
                    "ai_enhanced": ai_enhanced,
                    "timestamp": datetime.now().isoformat()
                }
                
                self.logger.decision("Chart analysis completed", {
                    "symbol": symbol,
                    "timeframes_analyzed": len(timeframe_analyses),
                    "overall_bias": overall_bias,
                    "overall_confidence": overall_confidence,
                    "ai_enhanced": ai_enhanced
                })
                
                return result
                
        except Exception as e:
            self.logger.error(f"Error in chart analysis for {symbol}", exception=e)
            return {"error": str(e)}
    
    async def _analyze_timeframe(self, symbol: str, timeframe: str, use_ai: bool = True) -> Optional[TimeframeAnalysis]:
        """Analyze a specific timeframe with optional AI enhancement."""
        try:
            # Get chart data
            chart_data = await self._get_chart_data(symbol, timeframe)
            if not chart_data:
                return None
            
            closes = chart_data.get("closes", [])
            highs = chart_data.get("highs", [])
            lows = chart_data.get("lows", [])
            volumes = chart_data.get("volumes", [])
            
            if len(closes) < 20:  # Need sufficient data
                return None
            
            # Calculate technical indicators
            indicators = self._calculate_indicators(closes, highs, lows, volumes)
            
            # Determine trend
            trend = self._determine_trend(closes, indicators)
            
            # Find support and resistance
            support, resistance = self.technical_analyzer.find_support_resistance(closes, volumes)
            
            # Generate signals
            signals = self._generate_signals(indicators, closes[-1], support, resistance)
            
            # Calculate confidence
            confidence = self._calculate_timeframe_confidence(indicators, signals, trend)
            
            # AI enhancement
            ai_analysis = None
            if use_ai and openai_client.is_available():
                try:
                    ai_analysis = await self.ai_analyzer.analyze_with_ai(
                        symbol, timeframe, indicators, chart_data, support, resistance
                    )
                    
                    # Enhance traditional analysis with AI insights
                    if ai_analysis:
                        # Adjust confidence based on AI analysis
                        ai_confidence = ai_analysis.get("confidence", 0.5)
                        confidence = (confidence + ai_confidence) / 2
                        
                        # Add AI signals
                        ai_signals = ai_analysis.get("signals", [])
                        signals.extend(ai_signals)
                        
                        # Consider AI trend assessment
                        ai_trend = ai_analysis.get("trend", "neutral")
                        if ai_trend != "neutral" and trend == "neutral":
                            trend = ai_trend
                        
                except Exception as e:
                    self.logger.warning(f"AI analysis failed for {symbol} {timeframe}, using traditional analysis", exception=e)
            
            return TimeframeAnalysis(
                timeframe=timeframe,
                trend=trend,
                indicators=indicators,
                support=support,
                resistance=resistance,
                confidence=confidence,
                signals=signals,
                ai_analysis=ai_analysis
            )
            
        except Exception as e:
            self.logger.error(f"Error analyzing timeframe {timeframe} for {symbol}", exception=e)
            return None
    
    async def _get_chart_data(self, symbol: str, timeframe: str) -> Optional[Dict[str, List[float]]]:
        """Get chart data for analysis."""
        try:
            # Check cache first
            cache_key = f"{symbol}_{timeframe}_chart_data"
            if (cache_key in self.chart_data_cache and 
                datetime.now() - self.chart_data_cache[cache_key]["timestamp"] < self.cache_expiry):
                return self.chart_data_cache[cache_key]["data"]
            
            # Fetch chart data from API
            chart_data = await self._fetch_chart_data_from_api(symbol, timeframe)
            
            if chart_data:
                # Cache the data
                self.chart_data_cache[cache_key] = {
                    "data": chart_data,
                    "timestamp": datetime.now()
                }
            
            return chart_data
            
        except Exception as e:
            self.logger.error(f"Error getting chart data for {symbol} {timeframe}", exception=e)
            return None
    
    async def _fetch_chart_data_from_api(self, symbol: str, timeframe: str) -> Optional[Dict[str, List[float]]]:
        """Fetch chart data from API (simplified implementation)."""
        try:
            # Map timeframes to days
            timeframe_days = {
                "15m": 1,
                "1h": 7,
                "4h": 30,
                "1d": 90
            }
            
            days = timeframe_days.get(timeframe, 7)
            
            # Fetch from CoinGecko
            url = f"https://api.coingecko.com/api/v3/coins/{symbol.lower()}/market_chart"
            params = {
                "vs_currency": "usd",
                "days": days,
                "interval": "hourly" if timeframe in ["1h", "4h"] else "daily"
            }
            
            response = requests.get(url, params=params, timeout=15)
            response.raise_for_status()
            
            data = response.json()
            
            prices = [point[1] for point in data.get("prices", [])]
            volumes = [point[1] for point in data.get("total_volumes", [])]
            
            # Create approximate OHLC from price data
            if len(prices) < 4:
                return None
            
            highs = []
            lows = []
            closes = []
            
            # Group prices into periods based on timeframe
            period_size = 1  # Simplified - use 1 data point per period
            
            for i in range(0, len(prices), period_size):
                period_prices = prices[i:i+period_size]
                if period_prices:
                    highs.append(max(period_prices))
                    lows.append(min(period_prices))
                    closes.append(period_prices[-1])
            
            return {
                "highs": highs,
                "lows": lows,
                "closes": closes,
                "volumes": volumes[:len(closes)]  # Match length
            }
            
        except Exception as e:
            self.logger.error(f"Error fetching chart data from API: {e}")
            return None
    
    def _calculate_indicators(self, closes: List[float], highs: List[float], 
                            lows: List[float], volumes: List[float]) -> TechnicalIndicators:
        """Calculate technical indicators."""
        try:
            current_price = closes[-1]
            
            # RSI
            rsi = self.technical_analyzer.calculate_rsi(closes)
            
            # MACD
            macd_line, macd_signal, macd_histogram = self.technical_analyzer.calculate_macd(closes)
            
            # Bollinger Bands
            bb_upper, bb_middle, bb_lower = self.technical_analyzer.calculate_bollinger_bands(closes)
            
            # Bollinger Band position
            bb_position = "middle"
            if current_price > bb_upper:
                bb_position = "upper"
            elif current_price < bb_lower:
                bb_position = "lower"
            
            # Moving averages
            sma_20 = self.technical_analyzer.calculate_sma(closes, 20)
            sma_50 = self.technical_analyzer.calculate_sma(closes, 50)
            
            # Volume SMA
            volume_sma = self.technical_analyzer.calculate_sma(volumes, 20) if volumes else 0.0
            
            return TechnicalIndicators(
                rsi=rsi,
                macd_line=macd_line,
                macd_signal=macd_signal,
                macd_histogram=macd_histogram,
                bb_upper=bb_upper,
                bb_middle=bb_middle,
                bb_lower=bb_lower,
                bb_position=bb_position,
                bb_squeeze=False,  # Simplified
                volume_sma=volume_sma,
                price_sma_20=sma_20,
                price_sma_50=sma_50
            )
            
        except Exception as e:
            self.logger.error(f"Error calculating indicators: {e}")
            # Return neutral indicators on error
            current_price = closes[-1] if closes else 0.0
            return TechnicalIndicators(
                rsi=50.0, macd_line=0.0, macd_signal=0.0, macd_histogram=0.0,
                bb_upper=current_price, bb_middle=current_price, bb_lower=current_price,
                bb_position="middle", bb_squeeze=False, volume_sma=0.0,
                price_sma_20=current_price, price_sma_50=current_price
            )
    
    def _determine_trend(self, closes: List[float], indicators: TechnicalIndicators) -> str:
        """Determine trend direction."""
        try:
            current_price = closes[-1]
            
            # Multiple trend indicators
            trend_signals = []
            
            # Price vs moving averages
            if current_price > indicators.price_sma_20 > indicators.price_sma_50:
                trend_signals.append("bullish")
            elif current_price < indicators.price_sma_20 < indicators.price_sma_50:
                trend_signals.append("bearish")
            else:
                trend_signals.append("neutral")
            
            # MACD trend
            if indicators.macd_line > indicators.macd_signal and indicators.macd_histogram > 0:
                trend_signals.append("bullish")
            elif indicators.macd_line < indicators.macd_signal and indicators.macd_histogram < 0:
                trend_signals.append("bearish")
            else:
                trend_signals.append("neutral")
            
            # RSI trend
            if 30 < indicators.rsi < 70:
                if indicators.rsi > 50:
                    trend_signals.append("bullish")
                else:
                    trend_signals.append("bearish")
            else:
                trend_signals.append("neutral")
            
            # Determine overall trend
            bullish_count = trend_signals.count("bullish")
            bearish_count = trend_signals.count("bearish")
            
            if bullish_count > bearish_count:
                return "bullish"
            elif bearish_count > bullish_count:
                return "bearish"
            else:
                return "neutral"
                
        except Exception as e:
            self.logger.error(f"Error determining trend: {e}")
            return "neutral"
    
    def _generate_signals(self, indicators: TechnicalIndicators, current_price: float,
                         support: float, resistance: float) -> List[str]:
        """Generate trading signals based on technical indicators."""
        try:
            signals = []
            
            # RSI signals
            if indicators.rsi > 70:
                signals.append("RSI overbought")
            elif indicators.rsi < 30:
                signals.append("RSI oversold")
            elif indicators.rsi > 50:
                signals.append("RSI bullish")
            else:
                signals.append("RSI bearish")
            
            # MACD signals
            if indicators.macd_line > indicators.macd_signal:
                signals.append("MACD bullish")
            else:
                signals.append("MACD bearish")
            
            # Bollinger Band signals
            if indicators.bb_position == "upper":
                signals.append("Price above upper BB")
            elif indicators.bb_position == "lower":
                signals.append("Price below lower BB")
            
            # Support/Resistance signals
            if support > 0:
                price_to_support = abs(current_price - support) / support * 100
                if price_to_support < 2:  # Within 2% of support
                    signals.append("Near support")
            
            if resistance > 0:
                price_to_resistance = abs(resistance - current_price) / current_price * 100
                if price_to_resistance < 2:  # Within 2% of resistance
                    signals.append("Near resistance")
            
            # Moving average signals
            if current_price > indicators.price_sma_20:
                signals.append("Above 20 SMA")
            else:
                signals.append("Below 20 SMA")
            
            return signals
            
        except Exception as e:
            self.logger.error(f"Error generating signals: {e}")
            return ["Error generating signals"]
    
    def _calculate_timeframe_confidence(self, indicators: TechnicalIndicators, 
                                      signals: List[str], trend: str) -> float:
        """Calculate confidence for timeframe analysis."""
        try:
            confidence_factors = []
            
            # RSI confidence (higher when not in extreme zones)
            if 30 < indicators.rsi < 70:
                confidence_factors.append(0.8)
            else:
                confidence_factors.append(0.4)
            
            # MACD confidence
            if abs(indicators.macd_histogram) > 0.001:
                confidence_factors.append(0.7)
            else:
                confidence_factors.append(0.3)
            
            # Trend consistency confidence
            bullish_signals = len([s for s in signals if any(word in s.lower() for word in ["bullish", "above", "oversold"])])
            bearish_signals = len([s for s in signals if any(word in s.lower() for word in ["bearish", "below", "overbought"])])
            
            if trend == "bullish" and bullish_signals > bearish_signals:
                confidence_factors.append(0.8)
            elif trend == "bearish" and bearish_signals > bullish_signals:
                confidence_factors.append(0.8)
            else:
                confidence_factors.append(0.5)
            
            return statistics.mean(confidence_factors)
            
        except Exception as e:
            self.logger.error(f"Error calculating timeframe confidence: {e}")
            return 0.5
    
    def _calculate_overall_bias(self, timeframe_analyses: Dict[str, TimeframeAnalysis], ai_enhanced: bool = False) -> Tuple[str, float]:
        """Calculate overall bias and confidence from multiple timeframes."""
        try:
            if not timeframe_analyses:
                return "neutral", 0.0
            
            # Weight timeframes (longer timeframes have more weight)
            timeframe_weights = {
                "15m": 0.2,
                "1h": 0.3,
                "4h": 0.5,
                "1d": 0.7
            }
            
            weighted_scores = []
            weighted_confidences = []
            
            for timeframe, analysis in timeframe_analyses.items():
                weight = timeframe_weights.get(timeframe, 0.3)
                
                # Convert trend to score
                trend_score = 0
                if analysis.trend == "bullish":
                    trend_score = 1
                elif analysis.trend == "bearish":
                    trend_score = -1
                
                # Boost confidence if AI enhanced
                confidence = analysis.confidence
                if ai_enhanced and analysis.ai_analysis:
                    confidence = min(confidence * 1.1, 1.0)  # 10% boost, max 1.0
                
                weighted_scores.append(trend_score * weight * confidence)
                weighted_confidences.append(confidence * weight)
            
            # Calculate overall bias
            overall_score = sum(weighted_scores)
            overall_confidence = statistics.mean(weighted_confidences) if weighted_confidences else 0.0
            
            if overall_score > 0.2:
                bias = "bullish"
            elif overall_score < -0.2:
                bias = "bearish"
            else:
                bias = "neutral"
            
            return bias, overall_confidence
            
        except Exception as e:
            self.logger.error(f"Error calculating overall bias: {e}")
            return "neutral", 0.0
    
    def _timeframe_analysis_to_dict(self, analysis: TimeframeAnalysis) -> Dict[str, Any]:
        """Convert TimeframeAnalysis to dictionary."""
        result = {
            "trend": analysis.trend,
            "rsi": analysis.indicators.rsi,
            "macd": {
                "signal": "buy" if analysis.indicators.macd_line > analysis.indicators.macd_signal else "sell",
                "histogram": analysis.indicators.macd_histogram
            },
            "bollinger": {
                "position": analysis.indicators.bb_position,
                "squeeze": analysis.indicators.bb_squeeze
            },
            "support": analysis.support,
            "resistance": analysis.resistance,
            "confidence": analysis.confidence,
            "signals": analysis.signals
        }
        
        # Add AI analysis if available
        if analysis.ai_analysis:
            result["ai_analysis"] = {
                "trend": analysis.ai_analysis.get("trend", "neutral"),
                "confidence": analysis.ai_analysis.get("confidence", 0.5),
                "signals": analysis.ai_analysis.get("signals", []),
                "risk_assessment": analysis.ai_analysis.get("risk_assessment", "medium")
            }
        
        return result
    
    # Request handlers
    def _handle_analyze_chart(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle chart analysis requests."""
        symbol = data.get("symbol")
        timeframes = data.get("timeframes", ["1h"])
        use_ai = data.get("use_ai", True)
        
        if not symbol:
            return {"error": "Symbol required"}
        
        # Run analysis in async context
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result = loop.run_until_complete(self.analyze_chart(symbol, timeframes, use_ai))
            return result
        finally:
            loop.close()
    
    def _handle_get_technical_indicators(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle technical indicators requests."""
        symbol = data.get("symbol")
        timeframe = data.get("timeframe", "1h")
        
        if not symbol:
            return {"error": "Symbol required"}
        
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            chart_data = loop.run_until_complete(self._get_chart_data(symbol, timeframe))
            if not chart_data:
                return {"error": "No chart data available"}
            
            indicators = self._calculate_indicators(
                chart_data.get("closes", []),
                chart_data.get("highs", []),
                chart_data.get("lows", []),
                chart_data.get("volumes", [])
            )
            
            return {
                "symbol": symbol,
                "timeframe": timeframe,
                "indicators": {
                    "rsi": indicators.rsi,
                    "macd_line": indicators.macd_line,
                    "macd_signal": indicators.macd_signal,
                    "macd_histogram": indicators.macd_histogram,
                    "bb_upper": indicators.bb_upper,
                    "bb_middle": indicators.bb_middle,
                    "bb_lower": indicators.bb_lower,
                    "sma_20": indicators.price_sma_20,
                    "sma_50": indicators.price_sma_50
                }
            }
        finally:
            loop.close()
    
    def _handle_health_check(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle health check requests."""
        return {
            "status": "healthy",
            "module": "chart_checker",
            "timestamp": datetime.now().isoformat(),
            "cache_size": len(self.chart_data_cache),
            "browser_active": self.browser_manager.browser is not None,
            "ai_enabled": openai_client.is_available(),
            
        }

# Main entry point
async def main():
    """Main entry point for Chart Checker."""
    checker = ChartChecker()
    
    try:
        await checker.start()
        
        # Keep running
        while True:
            await asyncio.sleep(60)
            
    except KeyboardInterrupt:
        print("Shutting down Chart Checker...")
    finally:
        await checker.stop()

if __name__ == "__main__":
    asyncio.run(main())
            