"""
AI Verifier & Executor - Final validation and trade execution module.
Performs macro environment checks, order book analysis, and executes trades.
Enhanced with OpenAI gpt-4o-mini for advanced risk assessment and validation.
"""

import asyncio
import json
import time
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass
import statistics

import requests
from bs4 import BeautifulSoup

from src.utils.communication import ModuleCommunicator, message_bus, Priority
from src.utils.browser_automation import BrowserManager, WebScraper, session_manager
from src.utils.database import db_manager
from src.utils.config import config_manager
from src.utils.logging import get_logger, get_performance_logger, TimedOperation, get_audit_logger
from src.utils.openai_client import openai_client, TaskType
from src.utils.ai_prompt_templates import AIPromptTemplates

@dataclass
class MacroEnvironment:
    """Macro environment assessment."""
    risk_score: float  # 0-1, higher = more risky
    news_sentiment: float  # -1 to 1
    volatility_index: float
    market_hours: bool
    major_events: List[str]
    recommendation: str  # "proceed", "caution", "halt"
    ai_analysis: Optional[str] = None  # AI-enhanced analysis

@dataclass
class LiquidityAnalysis:
    """Order book liquidity analysis."""
    bid_depth: float
    ask_depth: float
    spread_percentage: float
    liquidity_score: float  # 0-1, higher = better liquidity
    slippage_estimate: float
    ai_assessment: Optional[str] = None  # AI-enhanced assessment

@dataclass
class ExecutionResult:
    """Trade execution result."""
    success: bool
    trade_id: Optional[str]
    executed_price: float
    executed_quantity: float
    fees: float
    slippage: float
    execution_time: float
    error_message: Optional[str]
    ai_validation: Optional[str] = None  # AI validation result

@dataclass
class RiskValidation:
    """AI-enhanced risk validation result."""
    approved: bool
    risk_level: str  # "low", "medium", "high", "critical"
    confidence_score: float  # 0-1
    risk_factors: List[str]
    recommendations: List[str]
    position_adjustments: Dict[str, float]

class AIRiskValidator:
    """AI-powered risk validation using OpenAI gpt-4o-mini."""
    
    def __init__(self):
        self.logger = get_logger("ai_risk_validator")
        
        self.prompt_templates = AIPromptTemplates()
    
    async def validate_trade_risk(self, decision: Dict[str, Any], macro_env: MacroEnvironment, 
                                 liquidity: LiquidityAnalysis) -> RiskValidation:
        """Perform AI-enhanced risk validation for trade execution."""
        try:
            self.logger.system("Performing AI risk validation")
            
            # Prepare context for AI analysis
            context = {
                "trading_decision": decision,
                "macro_environment": {
                    "risk_score": macro_env.risk_score,
                    "news_sentiment": macro_env.news_sentiment,
                    "volatility_index": macro_env.volatility_index,
                    "market_hours": macro_env.market_hours,
                    "major_events": macro_env.major_events,
                    "recommendation": macro_env.recommendation
                },
                "liquidity_analysis": {
                    "liquidity_score": liquidity.liquidity_score,
                    "spread_percentage": liquidity.spread_percentage,
                    "slippage_estimate": liquidity.slippage_estimate
                }
            }
            
            # Generate AI prompt for risk validation
            prompt = self.prompt_templates.get_verifier_prompt(
                "risk_validation", context
            )
            
            # Get AI analysis
            ai_response = await openai_client.generate_response(prompt, TaskType.VERIFICATION)
            
            if ai_response and ai_response.get("success"):
                validation = self._parse_risk_validation(ai_response["content"])
                
                self.logger.system("AI risk validation completed", {
                    "approved": validation.approved,
                    "risk_level": validation.risk_level,
                    "confidence": validation.confidence_score
                })
                
                return validation
            else:
                # Fallback to traditional risk assessment
                return self._fallback_risk_validation(decision, macro_env, liquidity)
                
        except Exception as e:
            self.logger.error(f"Error in AI risk validation: {e}")
            return self._fallback_risk_validation(decision, macro_env, liquidity)
    
    def _parse_risk_validation(self, ai_content: str) -> RiskValidation:
        """Parse AI response into RiskValidation object."""
        try:
            # Try to parse as JSON first
            if ai_content.strip().startswith('{'):
                data = json.loads(ai_content)
                return RiskValidation(
                    approved=data.get("approved", False),
                    risk_level=data.get("risk_level", "medium"),
                    confidence_score=data.get("confidence_score", 0.5),
                    risk_factors=data.get("risk_factors", []),
                    recommendations=data.get("recommendations", []),
                    position_adjustments=data.get("position_adjustments", {})
                )
            else:
                # Parse text response
                approved = "approve" in ai_content.lower() and "reject" not in ai_content.lower()
                
                risk_level = "medium"
                if "high risk" in ai_content.lower() or "critical" in ai_content.lower():
                    risk_level = "high"
                elif "low risk" in ai_content.lower():
                    risk_level = "low"
                
                return RiskValidation(
                    approved=approved,
                    risk_level=risk_level,
                    confidence_score=0.7,
                    risk_factors=["AI analysis completed"],
                    recommendations=["Follow AI recommendations"],
                    position_adjustments={}
                )
                
        except Exception as e:
            self.logger.error(f"Error parsing AI risk validation: {e}")
            return self._fallback_risk_validation({}, MacroEnvironment(0.5, 0, 0.5, True, [], "proceed"), 
                                                LiquidityAnalysis(100, 100, 0.1, 0.8, 0.05))
    
    def _fallback_risk_validation(self, decision: Dict[str, Any], macro_env: MacroEnvironment,
                                 liquidity: LiquidityAnalysis) -> RiskValidation:
        """Fallback risk validation using traditional methods."""
        self.logger.warning("Using fallback risk validation")
        
        # Calculate risk based on traditional factors
        risk_score = (macro_env.risk_score + (1 - liquidity.liquidity_score)) / 2
        
        if risk_score > 0.7:
            risk_level = "high"
            approved = False
        elif risk_score > 0.4:
            risk_level = "medium"
            approved = True
        else:
            risk_level = "low"
            approved = True
        
        risk_factors = []
        if macro_env.risk_score > 0.5:
            risk_factors.append("High macro environment risk")
        if liquidity.liquidity_score < 0.5:
            risk_factors.append("Low liquidity")
        if not macro_env.market_hours:
            risk_factors.append("Off-market hours")
        
        return RiskValidation(
            approved=approved,
            risk_level=risk_level,
            confidence_score=0.6,
            risk_factors=risk_factors,
            recommendations=["Apply standard risk management"],
            position_adjustments={"size_multiplier": 0.8 if risk_score > 0.5 else 1.0}
        )

class AIExecutionVerifier:
    """AI-powered execution verification using OpenAI gpt-4o-mini."""
    
    def __init__(self):
        self.logger = get_logger("ai_execution_verifier")
        
        self.prompt_templates = AIPromptTemplates()
    
    async def verify_execution_conditions(self, decision: Dict[str, Any], 
                                        market_data: Dict[str, Any]) -> Dict[str, Any]:
        """Verify execution conditions using AI analysis."""
        try:
            self.logger.system("Performing AI execution verification")
            
            # Prepare context for AI analysis
            context = {
                "trading_decision": decision,
                "market_data": market_data,
                "timestamp": datetime.now().isoformat()
            }
            
            # Generate AI prompt for execution verification
            prompt = self.prompt_templates.get_verifier_prompt(
                "execution_verification", context
            )
            
            # Get AI analysis
            ai_response = await openai_client.generate_response(prompt, TaskType.VERIFICATION)
            
            if ai_response and ai_response.get("success"):
                verification = self._parse_execution_verification(ai_response["content"])
                
                self.logger.system("AI execution verification completed", {
                    "approved": verification.get("approved", False),
                    "confidence": verification.get("confidence", 0.5)
                })
                
                return verification
            else:
                # Fallback to traditional verification
                return self._fallback_execution_verification(decision, market_data)
                
        except Exception as e:
            self.logger.error(f"Error in AI execution verification: {e}")
            return self._fallback_execution_verification(decision, market_data)
    
    def _parse_execution_verification(self, ai_content: str) -> Dict[str, Any]:
        """Parse AI execution verification response."""
        try:
            # Try to parse as JSON first
            if ai_content.strip().startswith('{'):
                return json.loads(ai_content)
            else:
                # Parse text response
                approved = "approve" in ai_content.lower() and "reject" not in ai_content.lower()
                
                return {
                    "approved": approved,
                    "confidence": 0.7,
                    "analysis": ai_content,
                    "recommendations": ["Follow AI guidance"]
                }
                
        except Exception as e:
            self.logger.error(f"Error parsing AI execution verification: {e}")
            return {"approved": True, "confidence": 0.5, "analysis": "Fallback verification"}
    
    def _fallback_execution_verification(self, decision: Dict[str, Any], 
                                       market_data: Dict[str, Any]) -> Dict[str, Any]:
        """Fallback execution verification using traditional methods."""
        self.logger.warning("Using fallback execution verification")
        
        # Basic verification checks
        symbol = decision.get("symbol")
        side = decision.get("decision")
        
        approved = bool(symbol and side and side in ["buy", "sell"])
        
        return {
            "approved": approved,
            "confidence": 0.6,
            "analysis": "Traditional verification completed",
            "recommendations": ["Standard execution parameters"]
        }

class MacroChecker:
    """Checks macro environment conditions with AI enhancement."""
    
    def __init__(self):
        self.logger = get_logger("macro_checker")
        
        self.prompt_templates = AIPromptTemplates()
    
    async def assess_macro_environment(self) -> MacroEnvironment:
        """Assess current macro environment for trading with AI enhancement."""
        try:
            self.logger.system("Assessing macro environment")
            
            # Check market hours
            market_hours = self._is_market_hours()
            
            # Get basic macro data
            news_sentiment = 0.0
            major_events = []
            volatility_index = 0.5
            risk_score = 0.3
            
            # Try AI-enhanced analysis
            ai_analysis = await self._get_ai_macro_analysis({
                "market_hours": market_hours,
                "current_time": datetime.now().isoformat()
            })
            
            # Adjust risk score based on AI analysis if available
            if ai_analysis and "high_risk" in ai_analysis.lower():
                risk_score = min(0.8, risk_score + 0.3)
            elif ai_analysis and "low_risk" in ai_analysis.lower():
                risk_score = max(0.1, risk_score - 0.2)
            
            # Generate recommendation
            recommendation = "proceed" if risk_score < 0.5 else "caution"
            if risk_score > 0.7:
                recommendation = "halt"
            
            macro_env = MacroEnvironment(
                risk_score=risk_score,
                news_sentiment=news_sentiment,
                volatility_index=volatility_index,
                market_hours=market_hours,
                major_events=major_events,
                recommendation=recommendation,
                ai_analysis=ai_analysis
            )
            
            self.logger.system("Macro environment assessed", {
                "risk_score": risk_score,
                "recommendation": recommendation,
                "ai_enhanced": bool(ai_analysis)
            })
            
            return macro_env
            
        except Exception as e:
            self.logger.error(f"Error assessing macro environment: {e}")
            return MacroEnvironment(
                risk_score=0.8,
                news_sentiment=0.0,
                volatility_index=0.5,
                market_hours=True,
                major_events=["Error in assessment"],
                recommendation="caution"
            )
    
    async def _get_ai_macro_analysis(self, context: Dict[str, Any]) -> Optional[str]:
        """Get AI-enhanced macro environment analysis."""
        try:
            prompt = self.prompt_templates.get_verifier_prompt(
                "macro_analysis", context
            )
            
            ai_response = await openai_client.generate_response(prompt, TaskType.ANALYSIS)
            
            if ai_response and ai_response.get("success"):
                return ai_response["content"]
            
            return None
            
        except Exception as e:
            self.logger.error(f"Error in AI macro analysis: {e}")
            return None
    
    def _is_market_hours(self) -> bool:
        """Check if it's during major market hours."""
        try:
            now = datetime.now()
            hour = now.hour
            weekday = now.weekday()
            
            # Weekend has lower liquidity
            if weekday >= 5:  # Saturday = 5, Sunday = 6
                return False
            
            # Consider it market hours if any major market is open
            if 7 <= hour <= 21:  # Covers EU and US hours
                return True
            
            return False
            
        except Exception as e:
            self.logger.error(f"Error checking market hours: {e}")
            return True

class LiquidityAnalyzer:
    """Analyzes order book liquidity and market depth with AI enhancement."""
    
    def __init__(self):
        self.logger = get_logger("liquidity_analyzer")
        
        self.prompt_templates = AIPromptTemplates()
    
    async def analyze_liquidity(self, symbol: str, exchange: str) -> LiquidityAnalysis:
        """Analyze liquidity for a trading pair with AI enhancement."""
        try:
            self.logger.system(f"Analyzing liquidity for {symbol} on {exchange}")
            
            # Basic liquidity analysis (simplified)
            bid_depth = 100.0
            ask_depth = 100.0
            spread_percentage = 0.1
            liquidity_score = 0.8
            slippage_estimate = 0.05
            
            # Try AI-enhanced analysis
            ai_assessment = await self._get_ai_liquidity_assessment({
                "symbol": symbol,
                "exchange": exchange,
                "bid_depth": bid_depth,
                "ask_depth": ask_depth,
                "spread_percentage": spread_percentage
            })
            
            # Adjust liquidity score based on AI assessment if available
            if ai_assessment and "poor_liquidity" in ai_assessment.lower():
                liquidity_score = max(0.2, liquidity_score - 0.3)
                slippage_estimate = min(2.0, slippage_estimate + 0.5)
            elif ai_assessment and "excellent_liquidity" in ai_assessment.lower():
                liquidity_score = min(1.0, liquidity_score + 0.2)
                slippage_estimate = max(0.01, slippage_estimate - 0.02)
            
            analysis = LiquidityAnalysis(
                bid_depth=bid_depth,
                ask_depth=ask_depth,
                spread_percentage=spread_percentage,
                liquidity_score=liquidity_score,
                slippage_estimate=slippage_estimate,
                ai_assessment=ai_assessment
            )
            
            self.logger.system("Liquidity analysis completed", {
                "symbol": symbol,
                "liquidity_score": analysis.liquidity_score,
                "ai_enhanced": bool(ai_assessment)
            })
            
            return analysis
            
        except Exception as e:
            self.logger.error(f"Error analyzing liquidity for {symbol}: {e}")
            return LiquidityAnalysis(
                bid_depth=0.0,
                ask_depth=0.0,
                spread_percentage=1.0,
                liquidity_score=0.3,
                slippage_estimate=2.0
            )
    
    async def _get_ai_liquidity_assessment(self, context: Dict[str, Any]) -> Optional[str]:
        """Get AI-enhanced liquidity assessment."""
        try:
            prompt = self.prompt_templates.get_verifier_prompt(
                "liquidity_analysis", context
            )
            
            ai_response = await openai_client.generate_response(prompt, TaskType.ANALYSIS)
            
            if ai_response and ai_response.get("success"):
                return ai_response["content"]
            
            return None
            
        except Exception as e:
            self.logger.error(f"Error in AI liquidity assessment: {e}")
            return None

class TradeExecutor:
    """Executes trades on exchanges via browser automation with AI validation."""
    
    def __init__(self):
        self.logger = get_logger("trade_executor")
        self.audit_logger = get_audit_logger("trade_executor")
        self.ai_verifier = AIExecutionVerifier()
    
    async def execute_trade(self, decision: Dict[str, Any]) -> ExecutionResult:
        """Execute a trade based on the trading decision with AI validation."""
        try:
            symbol = decision.get("symbol")
            side = decision.get("decision")  # "buy" or "sell"
            quantity = decision.get("position_size", 0.01)
            multiplier = decision.get("multiplier", 1)
            
            self.logger.trade(f"Executing {side} order for {symbol}", {
                "symbol": symbol,
                "side": side,
                "quantity": quantity,
                "multiplier": multiplier
            })
            
            # AI pre-execution verification
            market_data = {
                "symbol": symbol,
                "current_price": 100.0,  # Mock price
                "volume": 1000000
            }
            
            ai_verification = await self.ai_verifier.verify_execution_conditions(
                decision, market_data
            )
            
            if not ai_verification.get("approved", True):
                return ExecutionResult(
                    success=False,
                    trade_id=None,
                    executed_price=0.0,
                    executed_quantity=0.0,
                    fees=0.0,
                    slippage=0.0,
                    execution_time=0.0,
                    error_message="AI verification failed",
                    ai_validation=ai_verification.get("analysis", "Verification failed")
                )
            
            start_time = time.time()
            
            # Simplified execution - in production, use real exchange APIs
            executed_price = 100.0  # Mock price
            executed_quantity = quantity
            fees = executed_price * executed_quantity * 0.001  # 0.1% fee
            slippage = 0.05  # 0.05% slippage
            
            execution_time = time.time() - start_time
            
            result = ExecutionResult(
                success=True,
                trade_id=f"{side}_{int(time.time())}",
                executed_price=executed_price,
                executed_quantity=executed_quantity,
                fees=fees,
                slippage=slippage,
                execution_time=execution_time,
                error_message=None,
                ai_validation=ai_verification.get("analysis", "AI verification passed")
            )
            
            # Log execution result
            self.audit_logger.log_trade_execution({
                "symbol": symbol,
                "side": side,
                "quantity": result.executed_quantity,
                "price": result.executed_price,
                "exchange": "mexc",
                "trade_id": result.trade_id,
                "ai_verified": True
            })
            
            # Store in database
            trade_data = {
                "symbol": symbol,
                "exchange": "mexc",
                "side": side,
                "entry_price": result.executed_price,
                "quantity": result.executed_quantity,
                "leverage": multiplier,
                "status": "open",
                "entry_time": datetime.now(),
                "strategy_version": "v1.0",
                "metadata": {**decision, "ai_verification": ai_verification}
            }
            
            trade_id = db_manager.insert_trade(trade_data)
            result.trade_id = str(trade_id)
            
            self.logger.trade("Trade executed successfully", {
                "trade_id": trade_id,
                "executed_price": result.executed_price,
                "ai_verified": True
            })
            
            return result
            
        except Exception as e:
            self.logger.error(f"Error executing trade: {e}")
            return ExecutionResult(
                success=False,
                trade_id=None,
                executed_price=0.0,
                executed_quantity=0.0,
                fees=0.0,
                slippage=0.0,
                execution_time=0.0,
                error_message=str(e)
            )

class VerifierExecutor:
    """Main verifier and executor that coordinates all verification and execution with AI enhancement."""
    
    def __init__(self):
        self.logger = get_logger("verifier_executor")
        self.perf_logger = get_performance_logger("verifier_executor")
        
        # Communication
        self.communicator = ModuleCommunicator("verifier_executor", message_bus)
        self._setup_request_handlers()
        
        # Core components with AI enhancement
        self.macro_checker = MacroChecker()
        self.liquidity_analyzer = LiquidityAnalyzer()
        self.trade_executor = TradeExecutor()
        self.ai_risk_validator = AIRiskValidator()
        
        self.logger.system("Verifier Executor initialized with AI enhancement")
    
    def _setup_request_handlers(self):
        """Set up request handlers for inter-module communication."""
        handlers = {
            "execute_trade": self._handle_execute_trade,
            "verify_conditions": self._handle_verify_conditions,
            "close_trade": self._handle_close_trade,
            "emergency_close_trade": self._handle_emergency_close_trade,
            "health_check": self._handle_health_check
        }
        
        for request_type, handler in handlers.items():
            self.communicator.register_request_handler(request_type, handler)
    
    async def verify_and_execute(self, decision: Dict[str, Any]) -> Dict[str, Any]:
        """Verify conditions and execute trade if approved with AI enhancement."""
        try:
            with TimedOperation(self.perf_logger, "verify_and_execute"):
                symbol = decision.get("symbol")
                
                self.logger.system(f"Verifying and executing trade for {symbol} with AI enhancement")
                
                # Step 1: Macro environment check with AI
                macro_env = await self.macro_checker.assess_macro_environment()
                
                if macro_env.recommendation == "halt":
                    return {
                        "approved": False,
                        "reason": "Macro environment unfavorable",
                        "macro_risk_score": macro_env.risk_score,
                        "major_events": macro_env.major_events,
                        "ai_analysis": macro_env.ai_analysis
                    }
                
                # Step 2: Liquidity analysis with AI
                exchange = "mexc"  # Default exchange
                liquidity = await self.liquidity_analyzer.analyze_liquidity(symbol, exchange)
                
                if liquidity.liquidity_score < 0.3:
                    return {
                        "approved": False,
                        "reason": "Insufficient liquidity",
                        "liquidity_score": liquidity.liquidity_score,
                        "spread_percentage": liquidity.spread_percentage,
                        "ai_assessment": liquidity.ai_assessment
                    }
                
                # Step 3: AI-powered risk validation
                risk_validation = await self.ai_risk_validator.validate_trade_risk(
                    decision, macro_env, liquidity
                )
                
                if not risk_validation.approved:
                    return {
                        "approved": False,
                        "reason": f"AI risk validation failed: {risk_validation.risk_level} risk",
                        "risk_level": risk_validation.risk_level,
                        "risk_factors": risk_validation.risk_factors,
                        "ai_recommendations": risk_validation.recommendations,
                        "confidence_score": risk_validation.confidence_score
                    }
                
                # Step 4: Apply AI-recommended adjustments
                adjusted_decision = self._apply_ai_risk_adjustments(
                    decision, macro_env, liquidity, risk_validation
                )
                
                # Step 5: Execute trade with AI verification
                execution_result = await self.trade_executor.execute_trade(adjusted_decision)
                
                # Prepare comprehensive response
                result = {
                    "approved": execution_result.success,
                    "symbol": symbol,
                    "trade_id": execution_result.trade_id,
                    "executed_price": execution_result.executed_price,
                    "executed_quantity": execution_result.executed_quantity,
                    "fees": execution_result.fees,
                    "slippage": execution_result.slippage,
                    "execution_time": execution_result.execution_time,
                    "macro_risk_score": macro_env.risk_score,
                    "liquidity_score": liquidity.liquidity_score,
                    "ai_risk_level": risk_validation.risk_level,
                    "ai_confidence": risk_validation.confidence_score,
                    "final_position_size": adjusted_decision.get("position_size"),
                    "adjusted_multiplier": adjusted_decision.get("multiplier"),
                    "ai_enhancements": {
                        "macro_analysis": macro_env.ai_analysis,
                        "liquidity_assessment": liquidity.ai_assessment,
                        "execution_validation": execution_result.ai_validation,
                        "risk_factors": risk_validation.risk_factors,
                        "recommendations": risk_validation.recommendations
                    }
                }
                
                if not execution_result.success:
                    result["error_message"] = execution_result.error_message
                
                self.logger.trade("AI-enhanced verification and execution completed", {
                    "symbol": symbol,
                    "approved": execution_result.success,
                    "trade_id": execution_result.trade_id,
                    "ai_risk_level": risk_validation.risk_level
                })
                
                return result
                
        except Exception as e:
            self.logger.error(f"Error in AI-enhanced verify and execute: {e}")
            return {
                "approved": False,
                "reason": f"Verification error: {str(e)}",
                "error": str(e)
            }
    
    def _apply_ai_risk_adjustments(self, decision: Dict[str, Any], macro_env: MacroEnvironment,
                                  liquidity: LiquidityAnalysis, risk_validation: RiskValidation) -> Dict[str, Any]:
        """Apply AI-recommended risk adjustments."""
        try:
            adjusted_decision = decision.copy()
            
            # Apply AI-recommended position adjustments
            for adjustment_type, multiplier in risk_validation.position_adjustments.items():
                if adjustment_type == "size_multiplier":
                    adjusted_decision["position_size"] *= multiplier
                elif adjustment_type == "leverage_multiplier":
                    current_multiplier = adjusted_decision.get("multiplier", 1)
                    adjusted_decision["multiplier"] = max(1, int(current_multiplier * multiplier))
            
            # Apply traditional risk adjustments
            if macro_env.risk_score > 0.5:
                size_reduction = macro_env.risk_score * 0.5
                adjusted_decision["position_size"] *= (1 - size_reduction)
            
            if liquidity.liquidity_score < 0.7:
                multiplier_reduction = (0.7 - liquidity.liquidity_score) * 2
                current_multiplier = adjusted_decision.get("multiplier", 1)
                adjusted_decision["multiplier"] = max(1, int(current_multiplier * (1 - multiplier_reduction)))
            
            if not macro_env.market_hours:
                adjusted_decision["position_size"] *= 0.7
                adjusted_decision["multiplier"] = max(1, adjusted_decision.get("multiplier", 1) // 2)
            
            # Apply additional AI risk level adjustments
            if risk_validation.risk_level == "high":
                adjusted_decision["position_size"] *= 0.5
                adjusted_decision["multiplier"] = max(1, adjusted_decision.get("multiplier", 1) // 2)
            elif risk_validation.risk_level == "critical":
                adjusted_decision["position_size"] *= 0.3
                adjusted_decision["multiplier"] = 1
            
            return adjusted_decision
            
        except Exception as e:
            self.logger.error(f"Error applying AI risk adjustments: {e}")
            return decision
    
    # Request handlers
    def _handle_execute_trade(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle trade execution requests."""
        decision = data.get("decision", {})
        
        if not decision:
            return {"error": "Trading decision required"}
        
        # Run verification and execution in async context
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result = loop.run_until_complete(self.verify_and_execute(decision))
            return result
        finally:
            loop.close()
    
    def _handle_verify_conditions(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle condition verification requests."""
        symbol = data.get("symbol")
        
        if not symbol:
            return {"error": "Symbol required"}
        
        
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            # Run verification without execution
            macro_env = loop.run_until_complete(self.macro_checker.assess_macro_environment())
            liquidity = loop.run_until_complete(self.liquidity_analyzer.analyze_liquidity(symbol, "mexc"))
            
            return {
                "macro_environment": {
                    "risk_score": macro_env.risk_score,
                    "recommendation": macro_env.recommendation,
                    "major_events": macro_env.major_events,
                    "market_hours": macro_env.market_hours,
                    "ai_analysis": macro_env.ai_analysis
                },
                "liquidity_analysis": {
                    "liquidity_score": liquidity.liquidity_score,
                    "spread_percentage": liquidity.spread_percentage,
                    "slippage_estimate": liquidity.slippage_estimate,
                    "ai_assessment": liquidity.ai_assessment
                }
            }
        finally:
            loop.close()
    
    def _handle_close_trade(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle trade closure requests."""
        trade_id = data.get("trade_id")
        
        if not trade_id:
            return {"error": "Trade ID required"}
        
        try:
            # Get trade from database
            trades = db_manager.get_trades(limit=1000)
            trade = next((t for t in trades if str(t.get("id")) == str(trade_id)), None)
            
            if not trade:
                return {"error": "Trade not found"}
            
            # Update trade status to closed
            db_manager.update_trade(int(trade_id), {
                "status": "closed",
                "exit_time": datetime.now(),
                "exit_price": trade.get("entry_price", 0) * 1.02  # Mock 2% profit
            })
            
            self.logger.trade("Trade closed", {"trade_id": trade_id})
            
            return {
                "success": True,
                "trade_id": trade_id,
                "status": "closed"
            }
            
        except Exception as e:
            self.logger.error(f"Error closing trade {trade_id}: {e}")
            return {"error": str(e)}
    
    def _handle_emergency_close_trade(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle emergency trade closure requests."""
        trade_id = data.get("trade_id")
        
        if not trade_id:
            return {"error": "Trade ID required"}
        
        try:
            # Emergency close - immediate execution
            trades = db_manager.get_trades(limit=1000)
            trade = next((t for t in trades if str(t.get("id")) == str(trade_id)), None)
            
            if not trade:
                return {"error": "Trade not found"}
            
            # Update trade status to closed with emergency flag
            db_manager.update_trade(int(trade_id), {
                "status": "closed",
                "exit_time": datetime.now(),
                "exit_price": trade.get("entry_price", 0) * 0.98,  # Mock 2% loss
                "metadata": {**trade.get("metadata", {}), "emergency_close": True}
            })
            
            self.logger.security("Emergency trade closure", {
                "trade_id": trade_id,
                "reason": "Emergency stop triggered"
            })
            
            return {
                "success": True,
                "trade_id": trade_id,
                "status": "emergency_closed"
            }
            
        except Exception as e:
            self.logger.error(f"Error emergency closing trade {trade_id}: {e}")
            return {"error": str(e)}
    
    def _handle_health_check(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle health check requests."""
        return {
            "status": "healthy",
            "module": "verifier_executor",
            "timestamp": datetime.now().isoformat(),
            "components": {
                "macro_checker": "active",
                "liquidity_analyzer": "active", 
                "trade_executor": "active",
                "ai_risk_validator": "active"
            },
            "ai_enhancement": "enabled"
        }

# Main entry point
async def main():
    """Main entry point for AI-enhanced Verifier Executor."""
    verifier_executor = VerifierExecutor()
    
    try:
        # Keep running
        while True:
            await asyncio.sleep(60)
            
    except KeyboardInterrupt:
        print("Shutting down AI-enhanced Verifier Executor...")

if __name__ == "__main__":
    asyncio.run(main())