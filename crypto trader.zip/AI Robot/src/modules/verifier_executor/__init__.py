"""
Verifier Executor module - Final validation and trade execution.

Performs macro environment checks (FOMC, CPI news), order book depth analysis,
trade execution via browser automation on MEXC/XT.com, and position sizing 
with risk management.
"""

from .executor import VerifierExecutor, MacroChecker, LiquidityAnalyzer, TradeExecutor

__all__ = [
    "VerifierExecutor",
    "MacroChecker",
    "LiquidityAnalyzer",
    "TradeExecutor"
]