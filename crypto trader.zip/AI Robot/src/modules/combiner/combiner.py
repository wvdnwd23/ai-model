"""
AI Combiner - Decision fusion engine for the AI Crypto Trading System.
Combines Scanner and Chart Checker outputs to make trading decisions.
Enhanced with GPT-4o for intelligent decision fusion.
"""

import asyncio
import json
from datetime import datetime
from typing import Dict, Any, List, Optional
from dataclasses import dataclass

from src.utils.communication import ModuleCommunicator, message_bus, Priority
from src.utils.config import config_manager
from src.utils.logging import get_logger, get_performance_logger, TimedOperation
from src.utils.openai_client import openai_client, TaskType
from src.utils.ai_prompt_templates import AIPromptTemplates

@dataclass
class TradingDecision:
    """Represents a trading decision with all parameters."""
    symbol: str
    decision: str  # "buy", "sell", "hold"
    multiplier: int
    position_size: float
    entry_price: float
    stop_loss: float
    take_profit: List[float]
    risk_reward_ratio: float
    confidence: float
    reasoning: str
    max_risk_percentage: float
    expected_duration: str
    timestamp: datetime
    ai_enhanced: bool = False

class AIDecisionEngine:
    """AI-enhanced decision engine using GPT-4o for intelligent signal fusion."""
    
    def __init__(self):
        self.logger = get_logger("ai_decision_engine")
        # Using global openai_client instead of instance variable
        self.prompt_templates = AIPromptTemplates()
    
    async def enhance_decision_with_ai(self, scanner_data: Dict[str, Any], 
                                     chart_data: Dict[str, Any],
                                     traditional_decision: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Enhance traditional decision making with AI analysis using GPT-4o."""
        try:
            # Prepare decision data for AI analysis
            decision_data = self._prepare_decision_data_for_ai(
                scanner_data, chart_data, traditional_decision
            )
            
            # Generate AI prompt
            prompt = self.prompt_templates.get_decision_fusion_prompt(decision_data)
            
            # Get AI analysis
            ai_response = await openai_client.generate_response(
                prompt=prompt,
                
                task_type=TaskType.DECISION_FUSION,
                max_tokens=1000
            )
            
            if ai_response and ai_response.get("success"):
                ai_analysis = self._parse_ai_decision(ai_response.get("content", ""))
                if ai_analysis:
                    self.logger.decision("AI decision enhancement completed", {
                        "symbol": decision_data.get("symbol", "unknown"),
                        "ai_decision": ai_analysis.get("decision", "unknown"),
                        "ai_confidence": ai_analysis.get("confidence", 0)
                    })
                    return ai_analysis
            
            return None
            
        except Exception as e:
            self.logger.error(f"Error in AI decision enhancement", exception=e)
            return None
    
    def _prepare_decision_data_for_ai(self, scanner_data: Dict[str, Any],
                                    chart_data: Dict[str, Any],
                                    traditional_decision: Dict[str, Any]) -> Dict[str, Any]:
        """Prepare decision data for AI analysis."""
        try:
            symbol = scanner_data.get("symbol") or chart_data.get("symbol", "unknown")
            
            return {
                "symbol": symbol,
                "scanner_insights": {
                    "sentiment_score": scanner_data.get("sentiment_score", 0.0),
                    "confidence": scanner_data.get("confidence", 0.0),
                    "volume_anomaly": scanner_data.get("volume_anomaly", 1.0),
                    "breakout_probability": scanner_data.get("breakout_probability", 0.0)
                },
                "chart_insights": {
                    "overall_bias": chart_data.get("overall_bias", "neutral"),
                    "overall_confidence": chart_data.get("overall_confidence", 0.0)
                },
                "traditional_decision": {
                    "direction": traditional_decision.get("direction", "hold"),
                    "confidence": traditional_decision.get("confidence", 0.0),
                    "signal_strength": traditional_decision.get("signal_strength", 0.0)
                }
            }
            
        except Exception as e:
            self.logger.error(f"Error preparing decision data for AI: {e}")
            return {}
    
    def _parse_ai_decision(self, ai_content: str) -> Optional[Dict[str, Any]]:
        """Parse AI decision response."""
        try:
            # Try to parse as JSON first
            if ai_content.strip().startswith('{'):
                return json.loads(ai_content)
            
            # If not JSON, extract key information using text parsing
            decision = {
                "decision": "hold",
                "confidence": 0.5,
                "reasoning": ai_content[:800],
                "position_adjustment": 1.0
            }
            
            content_lower = ai_content.lower()
            
            # Extract decision
            if "buy" in content_lower and "strong" in content_lower:
                decision["decision"] = "buy"
            elif "sell" in content_lower and "strong" in content_lower:
                decision["decision"] = "sell"
            elif "buy" in content_lower:
                decision["decision"] = "buy"
            elif "sell" in content_lower:
                decision["decision"] = "sell"
            
            # Extract confidence
            if "high confidence" in content_lower:
                decision["confidence"] = 0.9
            elif "confident" in content_lower:
                decision["confidence"] = 0.8
            elif "moderate" in content_lower:
                decision["confidence"] = 0.6
            elif "low confidence" in content_lower:
                decision["confidence"] = 0.3
            
            return decision
            
        except Exception as e:
            self.logger.error(f"Error parsing AI decision: {e}")
            return None

class DecisionEngine:
    """Core decision-making engine that combines multiple signals."""
    
    def __init__(self):
        self.logger = get_logger("decision_engine")
    
    def combine_signals(self, scanner_data: Dict[str, Any], chart_data: Dict[str, Any]) -> Dict[str, Any]:
        """Combine scanner and chart signals into a unified decision."""
        try:
            # Extract key metrics
            scanner_confidence = scanner_data.get("confidence", 0.0)
            scanner_sentiment = scanner_data.get("sentiment_score", 0.0)
            chart_confidence = chart_data.get("overall_confidence", 0.0)
            chart_bias = chart_data.get("overall_bias", "neutral")
            
            # Calculate combined confidence
            combined_confidence = (scanner_confidence * 0.4) + (chart_confidence * 0.6)
            
            # Determine trading direction
            direction = self._determine_direction(scanner_sentiment, chart_bias)
            
            # Calculate signal strength
            signal_strength = (abs(scanner_sentiment) + combined_confidence) / 2
            
            return {
                "direction": direction,
                "confidence": combined_confidence,
                "signal_strength": signal_strength,
                "volume_factor": scanner_data.get("volume_anomaly", 1.0),
                "sentiment_factor": (scanner_sentiment + 1) / 2
            }
            
        except Exception as e:
            self.logger.error(f"Error combining signals: {e}")
            return {
                "direction": "hold",
                "confidence": 0.0,
                "signal_strength": 0.0,
                "error": str(e)
            }
    
    def _determine_direction(self, sentiment: float, chart_bias: str) -> str:
        """Determine trading direction based on signals."""
        try:
            signals = []
            
            if sentiment > 0.3:
                signals.append("buy")
            elif sentiment < -0.3:
                signals.append("sell")
            else:
                signals.append("hold")
            
            if chart_bias == "bullish":
                signals.append("buy")
            elif chart_bias == "bearish":
                signals.append("sell")
            else:
                signals.append("hold")
            
            buy_count = signals.count("buy")
            sell_count = signals.count("sell")
            
            if buy_count > sell_count:
                return "buy"
            elif sell_count > buy_count:
                return "sell"
            else:
                return "hold"
                
        except Exception as e:
            self.logger.error(f"Error determining direction: {e}")
            return "hold"

class RiskCalculator:
    """Calculates risk/reward ratios and position sizing."""
    
    def __init__(self):
        self.logger = get_logger("risk_calculator")
    
    def calculate_position_parameters(self, entry_price: float, confidence: float, 
                                    signal_strength: float, ai_adjustment: float = 1.0) -> Dict[str, Any]:
        """Calculate position size, stop loss, and take profit levels."""
        try:
            # Simple calculations
            stop_loss = entry_price * 0.98  # 2% stop loss
            take_profits = [entry_price * 1.03, entry_price * 1.06, entry_price * 1.10]
            
            risk = entry_price - stop_loss
            reward = take_profits[0] - entry_price
            risk_reward_ratio = reward / risk if risk > 0 else 1.0
            
            base_size = config_manager.trading.max_position_size
            position_size = base_size * confidence * signal_strength * ai_adjustment
            position_size = max(0.01, min(base_size, position_size))
            
            multiplier = 1
            if confidence > 0.8 and signal_strength > 0.7:
                multiplier = min(3, int(confidence * signal_strength * 5))
            
            return {
                "position_size": position_size,
                "stop_loss": stop_loss,
                "take_profit": take_profits,
                "risk_reward_ratio": risk_reward_ratio,
                "multiplier": multiplier,
                "max_risk_percentage": 2.0,
                "expected_duration": "2-6 hours"
            }
            
        except Exception as e:
            self.logger.error(f"Error calculating position parameters: {e}")
            return {
                "position_size": 0.01,
                "stop_loss": entry_price * 0.98,
                "take_profit": [entry_price * 1.03],
                "risk_reward_ratio": 1.5,
                "multiplier": 1,
                "max_risk_percentage": 1.0,
                "expected_duration": "2-4 hours"
            }

class Combiner:
    """Main combiner that coordinates decision making and learning."""
    
    def __init__(self):
        self.logger = get_logger("combiner")
        self.perf_logger = get_performance_logger("combiner")
        
        # Communication
        self.communicator = ModuleCommunicator("combiner", message_bus)
        self._setup_request_handlers()
        
        # Core components
        self.decision_engine = DecisionEngine()
        self.risk_calculator = RiskCalculator()
        
        # AI components
        
        self.ai_decision_engine = AIDecisionEngine()
        
        self.logger.system("Combiner initialized with GPT-4o integration")
    
    def _setup_request_handlers(self):
        """Set up request handlers for inter-module communication."""
        handlers = {
            "make_decision": self._handle_make_decision,
            "health_check": self._handle_health_check
        }
        
        for request_type, handler in handlers.items():
            self.communicator.register_request_handler(request_type, handler)
    
    async def make_trading_decision(self, scanner_data: Dict[str, Any], 
                                  chart_data: Dict[str, Any], use_ai: bool = True) -> Dict[str, Any]:
        """Make a complete trading decision based on scanner and chart data."""
        try:
            with TimedOperation(self.perf_logger, "trading_decision"):
                symbol = scanner_data.get("symbol") or chart_data.get("symbol")
                
                if not symbol:
                    return {"error": "Symbol not found in input data"}
                
                self.logger.system(f"Making trading decision for {symbol}")
                
                # Combine signals using traditional method
                combined_signals = self.decision_engine.combine_signals(scanner_data, chart_data)
                
                direction = combined_signals.get("direction", "hold")
                confidence = combined_signals.get("confidence", 0.0)
                signal_strength = combined_signals.get("signal_strength", 0.0)
                
                # AI enhancement
                ai_enhanced = False
                ai_adjustment = 1.0
                final_decision = direction
                final_confidence = confidence
                
                if use_ai and openai_client.is_available():
                    try:
                        ai_analysis = await self.ai_decision_engine.enhance_decision_with_ai(
                            scanner_data, chart_data, combined_signals
                        )
                        
                        if ai_analysis:
                            ai_enhanced = True
                            ai_decision = ai_analysis.get("decision", "hold")
                            ai_confidence = ai_analysis.get("confidence", 0.5)
                            ai_adjustment = ai_analysis.get("position_adjustment", 1.0)
                            
                            # Combine AI and traditional decisions
                            final_confidence = (confidence * 0.6 + ai_confidence * 0.4)
                            if ai_decision != "hold" and ai_confidence > 0.7:
                                final_decision = ai_decision
                            
                            self.logger.decision("AI decision enhancement applied", {
                                "symbol": symbol,
                                "traditional_decision": direction,
                                "ai_decision": ai_decision,
                                "final_decision": final_decision
                            })
                        
                    except Exception as e:
                        self.logger.warning(f"AI decision enhancement failed for {symbol}, using traditional decision", exception=e)
                
                # Check if we should trade
                if final_decision == "hold" or final_confidence < 0.6:
                    return {
                        "symbol": symbol,
                        "decision": "hold",
                        "reasoning": "Signal does not meet trading criteria",
                        "confidence": final_confidence,
                        "ai_enhanced": ai_enhanced,
                        "timestamp": datetime.now().isoformat()
                    }
                
                # Get current price (simplified)
                entry_price = 100.0  # Placeholder
                
                # Calculate position parameters with AI adjustment
                position_params = self.risk_calculator.calculate_position_parameters(
                    entry_price, final_confidence, signal_strength, ai_adjustment
                )
                
                # Create trading decision
                decision = TradingDecision(
                    symbol=symbol,
                    decision=final_decision,
                    multiplier=position_params["multiplier"],
                    position_size=position_params["position_size"],
                    entry_price=entry_price,
                    stop_loss=position_params["stop_loss"],
                    take_profit=position_params["take_profit"],
                    risk_reward_ratio=position_params["risk_reward_ratio"],
                    confidence=final_confidence,
                    reasoning=self._generate_reasoning(combined_signals, ai_enhanced),
                    max_risk_percentage=position_params["max_risk_percentage"],
                    expected_duration=position_params["expected_duration"],
                    timestamp=datetime.now(),
                    ai_enhanced=ai_enhanced
                )
                
                # Convert to dictionary
                result = self._decision_to_dict(decision)
                
                self.logger.decision("Trading decision made", {
                    "symbol": symbol,
                    "decision": final_decision,
                    "confidence": final_confidence,
                    "ai_enhanced": ai_enhanced
                })
                
                return result
                
        except Exception as e:
            self.logger.error(f"Error making trading decision: {e}")
            return {"error": str(e)}
    
    def _generate_reasoning(self, combined_signals: Dict[str, Any], ai_enhanced: bool = False) -> str:
        """Generate human-readable reasoning for the decision."""
        try:
            reasons = []
            
            if ai_enhanced:
                reasons.append("AI-enhanced decision")
            
            signal_strength = combined_signals.get("signal_strength", 0)
            if signal_strength > 0.8:
                reasons.append("Very strong signal confluence")
            elif signal_strength > 0.6:
                reasons.append("Strong signal confluence")
            else:
                reasons.append("Moderate signal confluence")
            
            volume_factor = combined_signals.get("volume_factor", 1.0)
            if volume_factor > 1.5:
                reasons.append(f"High volume ({volume_factor:.1f}x normal)")
            
            return "; ".join(reasons) if reasons else "Standard trading criteria met"
            
        except Exception as e:
            self.logger.error(f"Error generating reasoning: {e}")
            return "Decision based on combined analysis"
    
    def _decision_to_dict(self, decision: TradingDecision) -> Dict[str, Any]:
        """Convert TradingDecision to dictionary format."""
        return {
            "symbol": decision.symbol,
            "decision": decision.decision,
            "multiplier": decision.multiplier,
            "position_size": decision.position_size,
            "entry_price": decision.entry_price,
            "stop_loss": decision.stop_loss,
            "take_profit": decision.take_profit,
            "risk_reward_ratio": decision.risk_reward_ratio,
            "confidence": decision.confidence,
            "reasoning": decision.reasoning,
            "max_risk_percentage": decision.max_risk_percentage,
            "expected_duration": decision.expected_duration,
            "ai_enhanced": decision.ai_enhanced,
            "timestamp": decision.timestamp.isoformat()
        }
    
    # Request handlers
    def _handle_make_decision(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle trading decision requests."""
        scanner_data = data.get("scanner_data", {})
        chart_data = data.get("chart_data", {})
        use_ai = data.get("use_ai", True)
        
        if not scanner_data and not chart_data:
            return {"error": "Scanner data or chart data required"}
        
        # Run decision making in async context
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result = loop.run_until_complete(self.make_trading_decision(scanner_data, chart_data, use_ai))
            return result
        finally:
            loop.close()
    
    def _handle_health_check(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle health check requests."""
        return {
            "status": "healthy",
            "module": "combiner",
            "timestamp": datetime.now().isoformat(),
            "ai_enabled": openai_client.is_available(),
            "openai_available": openai_client.is_available()
        }

# Main entry point
async def main():
    """Main entry point for Combiner."""
    combiner = Combiner()
    
    try:
        # Keep running
        while True:
            await asyncio.sleep(3600)  # Update every hour
            
    except KeyboardInterrupt:
        print("Shutting down Combiner...")

if __name__ == "__main__":
    asyncio.run(main())