"""
Dependency injection container implementation for the monitoring system.
Provides concrete implementations and manages component lifecycle.
"""

import os
import sys
import logging
import sqlite3
import json
from typing import Dict, Any, Optional, List, Union
from datetime import datetime
from pathlib import Path
from contextlib import contextmanager

from .interfaces import (
    ILogger, IDatabaseManager, IConfigManager, IMetricsCollector,
    IAlertManager, ISystemMonitor, INotificationSystem, IDependencyContainer,
    IMonitoringComponentFactory, LogLevel, AlertLevel
)


# Standalone Implementations (No AI System Dependencies)

class StandaloneLogger(ILogger):
    """Standalone logger implementation that doesn't depend on AI system."""
    
    def __init__(self, name: str = "monitoring", level: str = "INFO"):
        self.name = name
        self.level = getattr(logging, level.upper(), logging.INFO)
        
        # Create simple logger
        self.logger = logging.getLogger(name)
        self.logger.setLevel(self.level)
        
        # Add console handler if not already present
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
    
    def debug(self, message: str, **kwargs) -> None:
        self.logger.debug(message, extra=kwargs)
    
    def info(self, message: str, **kwargs) -> None:
        self.logger.info(message, extra=kwargs)
    
    def warning(self, message: str, **kwargs) -> None:
        self.logger.warning(message, extra=kwargs)
    
    def error(self, message: str, **kwargs) -> None:
        self.logger.error(message, extra=kwargs)
    
    def critical(self, message: str, **kwargs) -> None:
        self.logger.critical(message, extra=kwargs)


class StandaloneDatabaseManager(IDatabaseManager):
    """Standalone database manager for monitoring data."""
    
    def __init__(self, db_path: str = None):
        if db_path is None:
            # Default to monitoring-specific database
            db_path = "src/data/database/monitoring.db"
        
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Initialize database
        self._initialize_database()
    
    def _initialize_database(self):
        """Initialize monitoring database schema."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("PRAGMA foreign_keys = ON")
            
            # Create basic monitoring tables
            conn.execute("""
                CREATE TABLE IF NOT EXISTS monitoring_metrics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    value REAL NOT NULL,
                    timestamp TIMESTAMP NOT NULL,
                    tags TEXT,
                    source TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            conn.execute("""
                CREATE TABLE IF NOT EXISTS monitoring_alerts (
                    id TEXT PRIMARY KEY,
                    timestamp TIMESTAMP NOT NULL,
                    alert_type TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    title TEXT NOT NULL,
                    message TEXT NOT NULL,
                    source TEXT NOT NULL,
                    status TEXT DEFAULT 'active',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            conn.execute("""
                CREATE TABLE IF NOT EXISTS monitoring_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TIMESTAMP NOT NULL,
                    level TEXT NOT NULL,
                    logger TEXT NOT NULL,
                    message TEXT NOT NULL,
                    module TEXT,
                    function TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Create indexes
            conn.execute("CREATE INDEX IF NOT EXISTS idx_metrics_name_timestamp ON monitoring_metrics(name, timestamp)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_alerts_timestamp ON monitoring_alerts(timestamp)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_logs_timestamp ON monitoring_logs(timestamp)")
            
            conn.commit()
    
    @contextmanager
    def get_cursor(self):
        """Get database cursor context manager."""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            cursor = conn.cursor()
            yield cursor
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()
    
    def execute_query(self, query: str, params: tuple = None) -> List[Dict[str, Any]]:
        """Execute query and return results."""
        with self.get_cursor() as cursor:
            if params:
                cursor.execute(query, params)
            else:
                cursor.execute(query)
            return [dict(row) for row in cursor.fetchall()]
    
    def execute_command(self, command: str, params: tuple = None) -> int:
        """Execute command and return affected rows."""
        with self.get_cursor() as cursor:
            if params:
                cursor.execute(command, params)
            else:
                cursor.execute(command)
            return cursor.rowcount


class StandaloneConfigManager(IConfigManager):
    """Standalone configuration manager for monitoring."""
    
    def __init__(self, config_path: str = None):
        self.monitoring_only_mode = os.getenv('MONITORING_ONLY_MODE', 'false').lower() == 'true'
        
        # Default monitoring configuration
        self.monitoring_config = {
            'dashboard_host': os.getenv('MONITORING_DASHBOARD_HOST', '0.0.0.0'),
            'dashboard_port': int(os.getenv('MONITORING_DASHBOARD_PORT', '5050')),
            'collection_interval': int(os.getenv('MONITORING_COLLECTION_INTERVAL', '60')),
            'retention_days': int(os.getenv('MONITORING_RETENTION_DAYS', '30')),
            'alerts_enabled': os.getenv('MONITORING_ALERTS_ENABLED', 'true').lower() == 'true',
            'telegram_enabled': os.getenv('MONITORING_TELEGRAM_ENABLED', 'false').lower() == 'true',
            'email_enabled': os.getenv('MONITORING_EMAIL_ENABLED', 'false').lower() == 'true',
            'log_level': os.getenv('MONITORING_LOG_LEVEL', 'INFO'),
            'max_metrics_buffer': int(os.getenv('MONITORING_MAX_BUFFER', '10000')),
            'health_check_interval': int(os.getenv('MONITORING_HEALTH_INTERVAL', '60'))
        }
        
        self.dashboard_config = {
            'host': self.monitoring_config['dashboard_host'],
            'port': self.monitoring_config['dashboard_port'],
            'debug': os.getenv('MONITORING_DASHBOARD_DEBUG', 'false').lower() == 'true',
            'auto_refresh_interval': int(os.getenv('MONITORING_REFRESH_INTERVAL', '30')),
            'max_data_points': int(os.getenv('MONITORING_MAX_DATA_POINTS', '1000'))
        }
        
        self.alert_config = {
            'enabled': self.monitoring_config['alerts_enabled'],
            'rate_limit_window': int(os.getenv('MONITORING_ALERT_RATE_WINDOW', '300')),
            'max_alerts_per_window': int(os.getenv('MONITORING_MAX_ALERTS', '10')),
            'channels': ['console'],  # Default to console only in standalone mode
            'severity_channels': {
                'info': ['console'],
                'warning': ['console'],
                'critical': ['console'],
                'emergency': ['console']
            }
        }
        
        # Add Telegram if enabled
        if self.monitoring_config['telegram_enabled']:
            telegram_token = os.getenv('TELEGRAM_BOT_TOKEN')
            telegram_chat_id = os.getenv('TELEGRAM_CHAT_ID')
            if telegram_token and telegram_chat_id:
                self.alert_config['channels'].append('telegram')
                for severity in self.alert_config['severity_channels']:
                    self.alert_config['severity_channels'][severity].append('telegram')
        
        # Load from file if provided
        if config_path and Path(config_path).exists():
            self._load_config_file(config_path)
    
    def _load_config_file(self, config_path: str):
        """Load configuration from file."""
        try:
            with open(config_path, 'r') as f:
                file_config = json.load(f)
            
            # Update configurations with file values
            self.monitoring_config.update(file_config.get('monitoring', {}))
            self.dashboard_config.update(file_config.get('dashboard', {}))
            self.alert_config.update(file_config.get('alerts', {}))
            
        except Exception as e:
            # Use default configuration if file loading fails
            pass
    
    def get_monitoring_config(self) -> Dict[str, Any]:
        return self.monitoring_config.copy()
    
    def get_dashboard_config(self) -> Dict[str, Any]:
        return self.dashboard_config.copy()
    
    def get_alert_config(self) -> Dict[str, Any]:
        return self.alert_config.copy()
    
    def is_monitoring_only_mode(self) -> bool:
        return self.monitoring_only_mode


class MonitoringDependencyContainer(IDependencyContainer):
    """Dependency injection container for monitoring components."""
    
    def __init__(self):
        self._logger: Optional[ILogger] = None
        self._database_manager: Optional[IDatabaseManager] = None
        self._config_manager: Optional[IConfigManager] = None
        self._metrics_collector: Optional[IMetricsCollector] = None
        self._alert_manager: Optional[IAlertManager] = None
        self._system_monitor: Optional[ISystemMonitor] = None
        self._notification_system: Optional[INotificationSystem] = None
        
        # Initialize with standalone implementations
        self._initialize_standalone_components()
    
    def _initialize_standalone_components(self):
        """Initialize with standalone implementations."""
        # Create config manager first
        self._config_manager = StandaloneConfigManager()
        config = self._config_manager.get_monitoring_config()
        
        # Create logger
        self._logger = StandaloneLogger("monitoring", config.get('log_level', 'INFO'))
        
        # Create database manager
        self._database_manager = StandaloneDatabaseManager()
        
        self._logger.info("Initialized standalone monitoring components")
    
    def register_logger(self, logger: ILogger) -> None:
        self._logger = logger
    
    def register_database_manager(self, db_manager: IDatabaseManager) -> None:
        self._database_manager = db_manager
    
    def register_config_manager(self, config_manager: IConfigManager) -> None:
        self._config_manager = config_manager
    
    def register_metrics_collector(self, metrics_collector: IMetricsCollector) -> None:
        self._metrics_collector = metrics_collector
    
    def register_alert_manager(self, alert_manager: IAlertManager) -> None:
        self._alert_manager = alert_manager
    
    def register_system_monitor(self, system_monitor: ISystemMonitor) -> None:
        self._system_monitor = system_monitor
    
    def register_notification_system(self, notification_system: INotificationSystem) -> None:
        self._notification_system = notification_system
    
    def get_logger(self, name: str = None) -> ILogger:
        if self._logger is None:
            raise RuntimeError("Logger not registered")
        return self._logger
    
    def get_database_manager(self) -> IDatabaseManager:
        if self._database_manager is None:
            raise RuntimeError("Database manager not registered")
        return self._database_manager
    
    def get_config_manager(self) -> IConfigManager:
        if self._config_manager is None:
            raise RuntimeError("Config manager not registered")
        return self._config_manager
    
    def get_metrics_collector(self) -> Optional[IMetricsCollector]:
        return self._metrics_collector
    
    def get_alert_manager(self) -> Optional[IAlertManager]:
        return self._alert_manager
    
    def get_system_monitor(self) -> Optional[ISystemMonitor]:
        return self._system_monitor
    
    def get_notification_system(self) -> Optional[INotificationSystem]:
        return self._notification_system


# Simple implementations for basic monitoring

class SimpleMetricsCollector(IMetricsCollector):
    """Simple metrics collector for standalone monitoring."""
    
    def __init__(self, container: IDependencyContainer):
        self.container = container
        self.logger = container.get_logger("metrics_collector")
        self.db_manager = container.get_database_manager()
        self.config = container.get_config_manager().get_monitoring_config()
        
        self.metrics_buffer = []
        self.max_buffer_size = self.config.get('max_metrics_buffer', 10000)
    
    def collect_metric(self, name: str, value: Union[int, float], 
                      tags: Dict[str, str] = None, timestamp: str = None) -> bool:
        try:
            if timestamp is None:
                timestamp = datetime.now().isoformat()
            
            metric = {
                'name': name,
                'value': float(value),
                'timestamp': timestamp,
                'tags': json.dumps(tags or {}),
                'source': 'standalone_monitoring'
            }
            
            # Add to buffer
            self.metrics_buffer.append(metric)
            
            # Flush if buffer is full
            if len(self.metrics_buffer) >= self.max_buffer_size:
                self._flush_metrics()
            
            # Store in database
            self.db_manager.execute_command(
                "INSERT INTO monitoring_metrics (name, value, timestamp, tags, source) VALUES (?, ?, ?, ?, ?)",
                (metric['name'], metric['value'], metric['timestamp'], metric['tags'], metric['source'])
            )
            
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to collect metric {name}: {e}")
            return False
    
    def _flush_metrics(self):
        """Flush metrics buffer."""
        self.logger.debug(f"Flushing {len(self.metrics_buffer)} metrics from buffer")
        self.metrics_buffer.clear()
    
    def get_metrics_summary(self) -> Dict[str, Any]:
        try:
            # Get recent metrics count
            recent_count = self.db_manager.execute_query(
                "SELECT COUNT(*) as count FROM monitoring_metrics WHERE timestamp >= datetime('now', '-1 hour')"
            )
            
            return {
                'timestamp': datetime.now().isoformat(),
                'buffer_size': len(self.metrics_buffer),
                'recent_metrics_count': recent_count[0]['count'] if recent_count else 0,
                'status': 'running'
            }
        except Exception as e:
            self.logger.error(f"Failed to get metrics summary: {e}")
            return {'status': 'error', 'error': str(e)}


class SimpleAlertManager(IAlertManager):
    """Simple alert manager for standalone monitoring."""
    
    def __init__(self, container: IDependencyContainer):
        self.container = container
        self.logger = container.get_logger("alert_manager")
        self.db_manager = container.get_database_manager()
        self.config = container.get_config_manager().get_alert_config()
        
        self.active_alerts = {}
    
    def create_alert(self, alert_type: str, severity: AlertLevel, title: str,
                    message: str, source: str, **kwargs) -> str:
        try:
            alert_id = f"alert_{int(datetime.now().timestamp() * 1000)}"
            timestamp = datetime.now().isoformat()
            
            alert = {
                'id': alert_id,
                'timestamp': timestamp,
                'alert_type': alert_type,
                'severity': severity.value,
                'title': title,
                'message': message,
                'source': source,
                'status': 'active'
            }
            
            # Store in database
            self.db_manager.execute_command(
                "INSERT INTO monitoring_alerts (id, timestamp, alert_type, severity, title, message, source, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (alert['id'], alert['timestamp'], alert['alert_type'], alert['severity'], 
                 alert['title'], alert['message'], alert['source'], alert['status'])
            )
            
            # Add to active alerts
            self.active_alerts[alert_id] = alert
            
            # Log alert
            self.logger.warning(f"Alert created: [{severity.value.upper()}] {title} - {message}")
            
            return alert_id
            
        except Exception as e:
            self.logger.error(f"Failed to create alert: {e}")
            raise
    
    def get_active_alerts(self) -> List[Dict[str, Any]]:
        try:
            alerts = self.db_manager.execute_query(
                "SELECT * FROM monitoring_alerts WHERE status = 'active' ORDER BY timestamp DESC LIMIT 100"
            )
            return alerts
        except Exception as e:
            self.logger.error(f"Failed to get active alerts: {e}")
            return []


# Global container instance
_container = None

def get_container() -> IDependencyContainer:
    """Get the global dependency container."""
    global _container
    if _container is None:
        _container = MonitoringDependencyContainer()
    return _container

def initialize_monitoring_container(config_path: str = None) -> IDependencyContainer:
    """Initialize monitoring container with optional config file."""
    global _container
    _container = MonitoringDependencyContainer()
    
    if config_path:
        config_manager = StandaloneConfigManager(config_path)
        _container.register_config_manager(config_manager)
    
    return _container