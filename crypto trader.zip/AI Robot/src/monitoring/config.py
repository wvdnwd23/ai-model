"""
Monitoring configuration management for the AI Crypto Trading System.
Handles monitoring settings, alert thresholds, and system parameters.
"""

import os
import json
import logging
from typing import Dict, Any, Optional, List
from pathlib import Path
from dataclasses import dataclass, asdict, field
from enum import Enum

class AlertLevel(Enum):
    """Alert severity levels."""
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"
    EMERGENCY = "emergency"

class MetricType(Enum):
    """Types of metrics to collect."""
    SYSTEM = "system"
    TRADING = "trading"
    AI_PERFORMANCE = "ai_performance"
    HEALTH = "health"
    CUSTOM = "custom"

@dataclass
class SystemThresholds:
    """System resource monitoring thresholds."""
    cpu_warning: float = 80.0  # CPU usage percentage
    cpu_critical: float = 95.0
    memory_warning: float = 85.0  # Memory usage percentage
    memory_critical: float = 95.0
    disk_warning: float = 90.0  # Disk usage percentage
    disk_critical: float = 98.0
    temperature_warning: float = 70.0  # Temperature in Celsius
    temperature_critical: float = 85.0
    network_latency_warning: float = 500.0  # Latency in ms
    network_latency_critical: float = 2000.0
    process_restart_threshold: int = 3  # Max restarts per hour

@dataclass
class TradingThresholds:
    """Trading performance monitoring thresholds."""
    max_drawdown_warning: float = 5.0  # Percentage
    max_drawdown_critical: float = 10.0
    win_rate_warning: float = 40.0  # Minimum win rate percentage
    win_rate_critical: float = 30.0
    daily_loss_warning: float = 2.0  # Daily loss percentage
    daily_loss_critical: float = 5.0
    consecutive_losses_warning: int = 5
    consecutive_losses_critical: int = 10
    position_size_warning: float = 15.0  # Position size percentage
    position_size_critical: float = 25.0

@dataclass
class AIThresholds:
    """AI performance monitoring thresholds."""
    confidence_warning: float = 60.0  # Minimum confidence percentage
    confidence_critical: float = 40.0
    accuracy_warning: float = 65.0  # Minimum accuracy percentage
    accuracy_critical: float = 50.0
    response_time_warning: float = 5.0  # Response time in seconds
    response_time_critical: float = 15.0
    error_rate_warning: float = 5.0  # Error rate percentage
    error_rate_critical: float = 15.0
    model_drift_warning: float = 10.0  # Performance drift percentage
    model_drift_critical: float = 25.0

@dataclass
class AlertConfig:
    """Alert configuration settings."""
    enabled: bool = True
    rate_limit_window: int = 300  # Rate limit window in seconds
    max_alerts_per_window: int = 10
    escalation_delay: int = 1800  # Escalation delay in seconds
    auto_acknowledge: bool = False
    acknowledgment_timeout: int = 3600  # Auto-ack timeout in seconds
    channels: List[str] = field(default_factory=lambda: ["telegram", "email"])
    severity_channels: Dict[str, List[str]] = field(default_factory=lambda: {
        "info": ["telegram"],
        "warning": ["telegram", "email"],
        "critical": ["telegram", "email", "webhook"],
        "emergency": ["telegram", "email", "webhook", "sms"]
    })

@dataclass
class MetricsConfig:
    """Metrics collection configuration."""
    collection_interval: int = 60  # Collection interval in seconds
    retention_days: int = 90  # Data retention in days
    aggregation_intervals: List[int] = field(default_factory=lambda: [300, 900, 3600, 86400])  # 5m, 15m, 1h, 1d
    batch_size: int = 1000  # Batch size for database operations
    compression_enabled: bool = True
    export_enabled: bool = False
    export_formats: List[str] = field(default_factory=lambda: ["json", "csv"])
    custom_metrics: Dict[str, Dict[str, Any]] = field(default_factory=dict)

@dataclass
class DashboardConfig:
    """Dashboard configuration settings."""
    enabled: bool = True
    host: str = "0.0.0.0"
    port: int = 8080
    debug: bool = False
    auto_refresh_interval: int = 30  # Auto-refresh interval in seconds
    max_data_points: int = 1000  # Max data points per chart
    cache_timeout: int = 300  # Cache timeout in seconds
    authentication_enabled: bool = True
    session_timeout: int = 3600  # Session timeout in seconds
    rate_limit_requests: int = 100  # Requests per minute
    websocket_enabled: bool = True

@dataclass
class MonitoringOnlyConfig:
    """Configuration specific to monitoring-only mode."""
    enabled: bool = False
    dashboard_port: int = 5050  # Different port for standalone monitoring
    dashboard_host: str = "0.0.0.0"
    collection_interval: int = 60  # Metrics collection interval in seconds
    log_level: str = "INFO"
    simple_alerts: bool = True  # Use simple alerting without external dependencies
    basic_metrics_only: bool = True  # Collect only basic system metrics
    disable_ai_monitoring: bool = True  # Disable AI-specific monitoring
    disable_trading_monitoring: bool = True  # Disable trading-specific monitoring
    lightweight_dashboard: bool = True  # Use lightweight dashboard
    minimal_logging: bool = True  # Minimal logging configuration
    auto_cleanup: bool = True  # Auto-cleanup old data
    cleanup_days: int = 7  # Days to keep data in monitoring-only mode

@dataclass
class LoggingConfig:
    """Logging configuration for monitoring."""
    level: str = "INFO"
    structured_logging: bool = True
    log_rotation: bool = True
    max_file_size: int = 50 * 1024 * 1024  # 50MB
    backup_count: int = 10
    compression: bool = True
    real_time_streaming: bool = True
    pattern_detection: bool = True
    anomaly_detection: bool = True
    correlation_window: int = 300  # Correlation window in seconds

@dataclass
class HealthCheckConfig:
    """Health check configuration."""
    enabled: bool = True
    check_interval: int = 60  # Health check interval in seconds
    timeout: int = 30  # Health check timeout in seconds
    retry_attempts: int = 3
    failure_threshold: int = 3  # Consecutive failures before alert
    recovery_threshold: int = 2  # Consecutive successes for recovery
    deep_check_interval: int = 300  # Deep health check interval
    dependency_checks: bool = True
    external_service_checks: bool = True

@dataclass
class NotificationConfig:
    """Notification system configuration."""
    telegram_enabled: bool = True
    email_enabled: bool = False
    webhook_enabled: bool = False
    sms_enabled: bool = False
    message_templates: Dict[str, str] = field(default_factory=lambda: {
        "system_alert": "🚨 System Alert: {message}",
        "trading_alert": "📈 Trading Alert: {message}",
        "ai_alert": "🤖 AI Alert: {message}",
        "health_alert": "❤️ Health Alert: {message}"
    })
    rate_limiting: bool = True
    duplicate_suppression: bool = True
    quiet_hours: Dict[str, str] = field(default_factory=lambda: {
        "start": "22:00",
        "end": "08:00"
    })

@dataclass
class ProfilerConfig:
    """Performance profiler configuration."""
    enabled: bool = True
    sampling_interval: float = 0.1  # Sampling interval in seconds
    memory_profiling: bool = True
    cpu_profiling: bool = True
    io_profiling: bool = True
    database_profiling: bool = True
    api_profiling: bool = True
    profile_duration: int = 300  # Profile duration in seconds
    auto_optimization: bool = False
    bottleneck_detection: bool = True
    regression_detection: bool = True

class MonitoringConfig:
    """Main monitoring configuration manager."""
    
    def __init__(self, config_dir: str = "src/config/monitoring"):
        self.config_dir = Path(config_dir)
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.logger = logging.getLogger(__name__)
        
        # Check if we're in monitoring-only mode
        self.is_monitoring_only = os.getenv('MONITORING_ONLY_MODE', 'false').lower() == 'true'
        
        # Configuration instances
        self.system_thresholds = SystemThresholds()
        self.trading_thresholds = TradingThresholds()
        self.ai_thresholds = AIThresholds()
        self.alerts = AlertConfig()
        self.metrics = MetricsConfig()
        self.dashboard = DashboardConfig()
        self.monitoring_only = MonitoringOnlyConfig()
        self.logging_config = LoggingConfig()
        self.health_checks = HealthCheckConfig()
        self.notifications = NotificationConfig()
        self.profiler = ProfilerConfig()
        
        # Configure for monitoring-only mode if enabled
        if self.is_monitoring_only:
            self.monitoring_only.enabled = True
            self._configure_monitoring_only_mode()
        
        # Load configurations
        self._load_configurations()
    
    def _configure_monitoring_only_mode(self):
        """Configure settings for monitoring-only mode."""
        # Override dashboard settings for monitoring-only mode
        self.dashboard.port = self.monitoring_only.dashboard_port
        self.dashboard.host = self.monitoring_only.dashboard_host
        self.dashboard.authentication_enabled = False  # Simplified for monitoring-only
        self.dashboard.websocket_enabled = False  # Reduce complexity
        
        # Override metrics settings
        self.metrics.collection_interval = self.monitoring_only.collection_interval
        self.metrics.retention_days = self.monitoring_only.cleanup_days
        
        # Override logging settings
        self.logging_config.level = self.monitoring_only.log_level
        if self.monitoring_only.minimal_logging:
            self.logging_config.structured_logging = False
            self.logging_config.pattern_detection = False
            self.logging_config.anomaly_detection = False
        
        # Simplify notifications
        if self.monitoring_only.simple_alerts:
            self.notifications.email_enabled = False
            self.notifications.webhook_enabled = False
            self.notifications.sms_enabled = False
            self.notifications.telegram_enabled = False  # Use simple console alerts instead
    
    def _load_configurations(self):
        """Load configurations from files and environment variables."""
        try:
            # Load from config files
            self._load_from_files()
            
            # Override with environment variables
            self._load_from_environment()
            
            # Validate configurations
            self._validate_configurations()
            
            self.logger.info("Monitoring configuration loaded successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to load monitoring configuration: {e}")
            raise
    
    def _load_from_files(self):
        """Load configuration from JSON files."""
        config_files = {
            "system_thresholds.json": self._load_system_thresholds,
            "trading_thresholds.json": self._load_trading_thresholds,
            "ai_thresholds.json": self._load_ai_thresholds,
            "alerts.json": self._load_alerts_config,
            "metrics.json": self._load_metrics_config,
            "dashboard.json": self._load_dashboard_config,
            "monitoring_only.json": self._load_monitoring_only_config,
            "logging.json": self._load_logging_config,
            "health_checks.json": self._load_health_checks_config,
            "notifications.json": self._load_notifications_config,
            "profiler.json": self._load_profiler_config
        }
        
        for filename, loader in config_files.items():
            file_path = self.config_dir / filename
            if file_path.exists():
                try:
                    with open(file_path, 'r') as f:
                        data = json.load(f)
                    loader(data)
                    self.logger.debug(f"Loaded monitoring config from {filename}")
                except Exception as e:
                    self.logger.warning(f"Failed to load {filename}: {e}")
    
    def _load_system_thresholds(self, data: Dict[str, Any]):
        """Load system thresholds configuration."""
        for key, value in data.items():
            if hasattr(self.system_thresholds, key):
                setattr(self.system_thresholds, key, value)
    
    def _load_trading_thresholds(self, data: Dict[str, Any]):
        """Load trading thresholds configuration."""
        for key, value in data.items():
            if hasattr(self.trading_thresholds, key):
                setattr(self.trading_thresholds, key, value)
    
    def _load_ai_thresholds(self, data: Dict[str, Any]):
        """Load AI thresholds configuration."""
        for key, value in data.items():
            if hasattr(self.ai_thresholds, key):
                setattr(self.ai_thresholds, key, value)
    
    def _load_alerts_config(self, data: Dict[str, Any]):
        """Load alerts configuration."""
        for key, value in data.items():
            if hasattr(self.alerts, key):
                setattr(self.alerts, key, value)
    
    def _load_metrics_config(self, data: Dict[str, Any]):
        """Load metrics configuration."""
        for key, value in data.items():
            if hasattr(self.metrics, key):
                setattr(self.metrics, key, value)
    
    def _load_dashboard_config(self, data: Dict[str, Any]):
        """Load dashboard configuration."""
        for key, value in data.items():
            if hasattr(self.dashboard, key):
                setattr(self.dashboard, key, value)
    
    def _load_monitoring_only_config(self, data: Dict[str, Any]):
        """Load monitoring-only configuration."""
        for key, value in data.items():
            if hasattr(self.monitoring_only, key):
                setattr(self.monitoring_only, key, value)
    
    def _load_logging_config(self, data: Dict[str, Any]):
        """Load logging configuration."""
        for key, value in data.items():
            if hasattr(self.logging_config, key):
                setattr(self.logging_config, key, value)
    
    def _load_health_checks_config(self, data: Dict[str, Any]):
        """Load health checks configuration."""
        for key, value in data.items():
            if hasattr(self.health_checks, key):
                setattr(self.health_checks, key, value)
    
    def _load_notifications_config(self, data: Dict[str, Any]):
        """Load notifications configuration."""
        for key, value in data.items():
            if hasattr(self.notifications, key):
                setattr(self.notifications, key, value)
    
    def _load_profiler_config(self, data: Dict[str, Any]):
        """Load profiler configuration."""
        for key, value in data.items():
            if hasattr(self.profiler, key):
                setattr(self.profiler, key, value)
    
    def _load_from_environment(self):
        """Load configuration from environment variables."""
        # Monitoring-only mode settings
        if self.is_monitoring_only:
            self.monitoring_only.dashboard_host = os.getenv("MONITORING_DASHBOARD_HOST", self.monitoring_only.dashboard_host)
            self.monitoring_only.dashboard_port = int(os.getenv("MONITORING_DASHBOARD_PORT", self.monitoring_only.dashboard_port))
            self.monitoring_only.collection_interval = int(os.getenv("MONITORING_COLLECTION_INTERVAL", self.monitoring_only.collection_interval))
            self.monitoring_only.log_level = os.getenv("MONITORING_LOG_LEVEL", self.monitoring_only.log_level)
        
        # System thresholds
        self.system_thresholds.cpu_warning = float(os.getenv("MONITORING_CPU_WARNING", self.system_thresholds.cpu_warning))
        self.system_thresholds.cpu_critical = float(os.getenv("MONITORING_CPU_CRITICAL", self.system_thresholds.cpu_critical))
        self.system_thresholds.memory_warning = float(os.getenv("MONITORING_MEMORY_WARNING", self.system_thresholds.memory_warning))
        self.system_thresholds.memory_critical = float(os.getenv("MONITORING_MEMORY_CRITICAL", self.system_thresholds.memory_critical))
        
        # Trading thresholds
        self.trading_thresholds.max_drawdown_warning = float(os.getenv("MONITOR_DRAWDOWN_WARNING", self.trading_thresholds.max_drawdown_warning))
        self.trading_thresholds.max_drawdown_critical = float(os.getenv("MONITOR_DRAWDOWN_CRITICAL", self.trading_thresholds.max_drawdown_critical))
        
        # Dashboard configuration
        if not self.is_monitoring_only:
            self.dashboard.host = os.getenv("MONITOR_DASHBOARD_HOST", self.dashboard.host)
            self.dashboard.port = int(os.getenv("MONITOR_DASHBOARD_PORT", self.dashboard.port))
            self.dashboard.debug = os.getenv("MONITOR_DASHBOARD_DEBUG", "false").lower() == "true"
        
        # Alerts configuration
        self.alerts.enabled = os.getenv("MONITOR_ALERTS_ENABLED", "true").lower() == "true"
        
        # Notifications configuration
        self.notifications.telegram_enabled = os.getenv("MONITOR_TELEGRAM_ENABLED", "true").lower() == "true"
        self.notifications.email_enabled = os.getenv("MONITOR_EMAIL_ENABLED", "false").lower() == "true"
    
    def _validate_configurations(self):
        """Validate configuration values."""
        # Validate system thresholds
        if not (0 <= self.system_thresholds.cpu_warning <= 100):
            raise ValueError(f"Invalid CPU warning threshold: {self.system_thresholds.cpu_warning}")
        
        if not (0 <= self.system_thresholds.memory_warning <= 100):
            raise ValueError(f"Invalid memory warning threshold: {self.system_thresholds.memory_warning}")
        
        # Validate trading thresholds (only if not in monitoring-only mode)
        if not self.is_monitoring_only or not self.monitoring_only.disable_trading_monitoring:
            if self.trading_thresholds.max_drawdown_warning >= self.trading_thresholds.max_drawdown_critical:
                raise ValueError("Trading drawdown warning must be less than critical threshold")
        
        # Validate dashboard configuration
        dashboard_port = self.monitoring_only.dashboard_port if self.is_monitoring_only else self.dashboard.port
        if not (1024 <= dashboard_port <= 65535):
            raise ValueError(f"Invalid dashboard port: {dashboard_port}")
        
        # Validate metrics configuration
        collection_interval = self.monitoring_only.collection_interval if self.is_monitoring_only else self.metrics.collection_interval
        if collection_interval < 1:
            raise ValueError(f"Invalid collection interval: {collection_interval}")
    
    def get_dashboard_config(self) -> Dict[str, Any]:
        """Get dashboard configuration for current mode."""
        if self.is_monitoring_only:
            return {
                'enabled': True,
                'host': self.monitoring_only.dashboard_host,
                'port': self.monitoring_only.dashboard_port,
                'debug': False,
                'lightweight': self.monitoring_only.lightweight_dashboard
            }
        else:
            return asdict(self.dashboard)
    
    def get_monitoring_config(self) -> Dict[str, Any]:
        """Get monitoring configuration for current mode."""
        if self.is_monitoring_only:
            return {
                'collection_interval': self.monitoring_only.collection_interval,
                'log_level': self.monitoring_only.log_level,
                'basic_metrics_only': self.monitoring_only.basic_metrics_only,
                'auto_cleanup': self.monitoring_only.auto_cleanup,
                'cleanup_days': self.monitoring_only.cleanup_days
            }
        else:
            return asdict(self.metrics)
    
    def save_configuration(self, config_name: str):
        """Save current configuration to file."""
        config_data = {}
        
        if config_name == "system_thresholds":
            config_data = asdict(self.system_thresholds)
        elif config_name == "trading_thresholds":
            config_data = asdict(self.trading_thresholds)
        elif config_name == "ai_thresholds":
            config_data = asdict(self.ai_thresholds)
        elif config_name == "alerts":
            config_data = asdict(self.alerts)
        elif config_name == "metrics":
            config_data = asdict(self.metrics)
        elif config_name == "dashboard":
            config_data = asdict(self.dashboard)
        elif config_name == "monitoring_only":
            config_data = asdict(self.monitoring_only)
        elif config_name == "logging":
            config_data = asdict(self.logging_config)
        elif config_name == "health_checks":
            config_data = asdict(self.health_checks)
        elif config_name == "notifications":
            config_data = asdict(self.notifications)
        elif config_name == "profiler":
            config_data = asdict(self.profiler)
        else:
            raise ValueError(f"Unknown configuration: {config_name}")
        
        file_path = self.config_dir / f"{config_name}.json"
        with open(file_path, 'w') as f:
            json.dump(config_data, f, indent=2)
        
        self.logger.info(f"Saved {config_name} configuration to {file_path}")
    
    def get_alert_threshold(self, metric_type: str, metric_name: str, level: AlertLevel) -> Optional[float]:
        """Get alert threshold for a specific metric."""
        threshold_map = {
            "system": self.system_thresholds,
            "trading": self.trading_thresholds,
            "ai": self.ai_thresholds
        }
        
        thresholds = threshold_map.get(metric_type)
        if not thresholds:
            return None
        
        threshold_name = f"{metric_name}_{level.value}"
        return getattr(thresholds, threshold_name, None)
    
    def update_threshold(self, metric_type: str, metric_name: str, level: AlertLevel, value: float):
        """Update a specific threshold value."""
        threshold_map = {
            "system": self.system_thresholds,
            "trading": self.trading_thresholds,
            "ai": self.ai_thresholds
        }
        
        thresholds = threshold_map.get(metric_type)
        if not thresholds:
            raise ValueError(f"Unknown metric type: {metric_type}")
        
        threshold_name = f"{metric_name}_{level.value}"
        if not hasattr(thresholds, threshold_name):
            raise ValueError(f"Unknown threshold: {threshold_name}")
        
        setattr(thresholds, threshold_name, value)
        self.save_configuration(f"{metric_type}_thresholds")
    
    def get_all_config(self) -> Dict[str, Any]:
        """Get all configuration as dictionary."""
        config = {
            "system_thresholds": asdict(self.system_thresholds),
            "trading_thresholds": asdict(self.trading_thresholds),
            "ai_thresholds": asdict(self.ai_thresholds),
            "alerts": asdict(self.alerts),
            "metrics": asdict(self.metrics),
            "dashboard": asdict(self.dashboard),
            "monitoring_only": asdict(self.monitoring_only),
            "logging": asdict(self.logging_config),
            "health_checks": asdict(self.health_checks),
            "notifications": asdict(self.notifications),
            "profiler": asdict(self.profiler),
            "is_monitoring_only": self.is_monitoring_only
        }
        return config
    
    def create_default_configs(self):
        """Create default configuration files."""
        configs = {
            "system_thresholds": self.system_thresholds,
            "trading_thresholds": self.trading_thresholds,
            "ai_thresholds": self.ai_thresholds,
            "alerts": self.alerts,
            "metrics": self.metrics,
            "dashboard": self.dashboard,
            "monitoring_only": self.monitoring_only,
            "logging": self.logging_config,
            "health_checks": self.health_checks,
            "notifications": self.notifications,
            "profiler": self.profiler
        }
        
        for config_name, config_obj in configs.items():
            file_path = self.config_dir / f"{config_name}.json"
            if not file_path.exists():
                with open(file_path, 'w') as f:
                    json.dump(asdict(config_obj), f, indent=2)
                self.logger.info(f"Created default {config_name} configuration")

# Global monitoring configuration instance
monitoring_config = MonitoringConfig()
