"""
Notification System for the AI Crypto Trading System.
Handles multi-channel notifications with templates, user management, delivery tracking, and rate limiting.
"""
import os

import time
import threading
import logging
import json
import hashlib
import smtplib
import requests
import asyncio
import aiohttp
import aiosmtplib
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List, Callable, Set, Tuple, Union
from dataclasses import dataclass, asdict, field
from collections import defaultdict, deque
from enum import Enum
from email.mime.text import MimeText
from email.mime.multipart import MimeMultipart
from email.mime.base import MimeBase
from email import encoders
import sqlite3
import re
import html
from pathlib import Path
import queue
import concurrent.futures
from jinja2 import Template, Environment, BaseLoader

from .config import monitoring_config, AlertLevel
from ..utils.logging import get_logger
from ..utils.database import db_manager

class NotificationChannel(Enum):
    """Notification delivery channels."""
    TELEGRAM = "telegram"
    EMAIL = "email"
    WEBHOOK = "webhook"
    SMS = "sms"

class NotificationPriority(Enum):
    """Notification priority levels."""
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4

class DeliveryStatus(Enum):
    """Notification delivery status."""
    PENDING = "pending"
    SENT = "sent"
    DELIVERED = "delivered"
    FAILED = "failed"
    RETRYING = "retrying"
    RATE_LIMITED = "rate_limited"

class TemplateType(Enum):
    """Template types for different notification scenarios."""
    SYSTEM_ALERT = "system_alert"
    TRADING_ALERT = "trading_alert"
    AI_ALERT = "ai_alert"
    HEALTH_ALERT = "health_alert"
    DAILY_REPORT = "daily_report"
    WEEKLY_REPORT = "weekly_report"
    STATUS_UPDATE = "status_update"
    CUSTOM = "custom"

@dataclass
class NotificationTemplate:
    """Notification template structure."""
    id: str
    name: str
    template_type: TemplateType
    channel: NotificationChannel
    subject_template: str
    body_template: str
    format_type: str = "text"  # text, html, markdown
    variables: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())

@dataclass
class Subscriber:
    """Notification subscriber structure."""
    id: str
    name: str
    email: Optional[str] = None
    telegram_chat_id: Optional[str] = None
    phone_number: Optional[str] = None
    webhook_url: Optional[str] = None
    preferences: Dict[str, Any] = field(default_factory=dict)
    subscription_groups: List[str] = field(default_factory=list)
    enabled_channels: List[str] = field(default_factory=list)
    notification_types: List[str] = field(default_factory=list)
    quiet_hours: Dict[str, str] = field(default_factory=dict)
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())

@dataclass
class NotificationRequest:
    """Notification request structure."""
    id: str
    channel: NotificationChannel
    priority: NotificationPriority
    recipient_id: str
    template_id: Optional[str]
    subject: str
    message: str
    variables: Dict[str, Any] = field(default_factory=dict)
    attachments: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    scheduled_at: Optional[str] = None
    expires_at: Optional[str] = None
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())

@dataclass
class DeliveryRecord:
    """Notification delivery tracking record."""
    id: str
    notification_id: str
    channel: NotificationChannel
    recipient_id: str
    status: DeliveryStatus
    attempts: int = 0
    last_attempt_at: Optional[str] = None
    delivered_at: Optional[str] = None
    error_message: Optional[str] = None
    response_data: Dict[str, Any] = field(default_factory=dict)
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())

class TemplateManager:
    """Manages notification templates and rendering."""
    
    def __init__(self):
        self.logger = get_logger(f"{__name__}.TemplateManager")
        self.templates: Dict[str, NotificationTemplate] = {}
        self.jinja_env = Environment(loader=BaseLoader())
        self._load_default_templates()
        self._load_custom_templates()
    
    def _load_default_templates(self):
        """Load default notification templates."""
        try:
            default_templates = [
                NotificationTemplate(
                    id="system_alert_telegram",
                    name="System Alert - Telegram",
                    template_type=TemplateType.SYSTEM_ALERT,
                    channel=NotificationChannel.TELEGRAM,
                    subject_template="🚨 System Alert",
                    body_template="""🚨 **SYSTEM ALERT**

**Severity:** {{ severity | upper }}
**Source:** {{ source }}
**Time:** {{ timestamp }}

**Message:** {{ message }}

{% if metric_name %}**Metric:** {{ metric_name }} = {{ metric_value }}{% if threshold_value %} (threshold: {{ threshold_value }}){% endif %}{% endif %}

**Alert ID:** {{ alert_id }}""",
                    format_type="markdown",
                    variables=["severity", "source", "timestamp", "message", "metric_name", "metric_value", "threshold_value", "alert_id"]
                ),
                NotificationTemplate(
                    id="system_alert_email",
                    name="System Alert - Email",
                    template_type=TemplateType.SYSTEM_ALERT,
                    channel=NotificationChannel.EMAIL,
                    subject_template="[{{ severity | upper }}] System Alert: {{ title }}",
                    body_template="""<html>
<body>
<h2 style="color: #d32f2f;">🚨 System Alert</h2>
<table style="border-collapse: collapse; width: 100%;">
<tr><td style="padding: 8px; border: 1px solid #ddd;"><strong>Severity:</strong></td><td style="padding: 8px; border: 1px solid #ddd;">{{ severity | upper }}</td></tr>
<tr><td style="padding: 8px; border: 1px solid #ddd;"><strong>Source:</strong></td><td style="padding: 8px; border: 1px solid #ddd;">{{ source }}</td></tr>
<tr><td style="padding: 8px; border: 1px solid #ddd;"><strong>Time:</strong></td><td style="padding: 8px; border: 1px solid #ddd;">{{ timestamp }}</td></tr>
<tr><td style="padding: 8px; border: 1px solid #ddd;"><strong>Message:</strong></td><td style="padding: 8px; border: 1px solid #ddd;">{{ message }}</td></tr>
{% if metric_name %}<tr><td style="padding: 8px; border: 1px solid #ddd;"><strong>Metric:</strong></td><td style="padding: 8px; border: 1px solid #ddd;">{{ metric_name }} = {{ metric_value }}{% if threshold_value %} (threshold: {{ threshold_value }}){% endif %}</td></tr>{% endif %}
<tr><td style="padding: 8px; border: 1px solid #ddd;"><strong>Alert ID:</strong></td><td style="padding: 8px; border: 1px solid #ddd;">{{ alert_id }}</td></tr>
</table>
</body>
</html>""",
                    format_type="html",
                    variables=["severity", "source", "timestamp", "message", "title", "metric_name", "metric_value", "threshold_value", "alert_id"]
                ),
                NotificationTemplate(
                    id="trading_alert_telegram",
                    name="Trading Alert - Telegram",
                    template_type=TemplateType.TRADING_ALERT,
                    channel=NotificationChannel.TELEGRAM,
                    subject_template="📈 Trading Alert",
                    body_template="""📈 **TRADING ALERT**

**Type:** {{ alert_type }}
**Severity:** {{ severity | upper }}
**Time:** {{ timestamp }}

**Message:** {{ message }}

{% if symbol %}**Symbol:** {{ symbol }}{% endif %}
{% if price %}**Price:** ${{ price }}{% endif %}
{% if change %}**Change:** {{ change }}%{% endif %}

**Alert ID:** {{ alert_id }}""",
                    format_type="markdown",
                    variables=["alert_type", "severity", "timestamp", "message", "symbol", "price", "change", "alert_id"]
                ),
                NotificationTemplate(
                    id="daily_report_email",
                    name="Daily Report - Email",
                    template_type=TemplateType.DAILY_REPORT,
                    channel=NotificationChannel.EMAIL,
                    subject_template="Daily Trading Report - {{ date }}",
                    body_template="""<html>
<body>
<h2 style="color: #1976d2;">📊 Daily Trading Report</h2>
<h3>{{ date }}</h3>

<h4>Summary</h4>
<ul>
<li><strong>Total Trades:</strong> {{ total_trades }}</li>
<li><strong>Successful Trades:</strong> {{ successful_trades }}</li>
<li><strong>Win Rate:</strong> {{ win_rate }}%</li>
<li><strong>Total P&L:</strong> ${{ total_pnl }}</li>
</ul>

<h4>System Health</h4>
<ul>
<li><strong>CPU Usage:</strong> {{ cpu_usage }}%</li>
<li><strong>Memory Usage:</strong> {{ memory_usage }}%</li>
<li><strong>Uptime:</strong> {{ uptime }}</li>
</ul>

<h4>AI Performance</h4>
<ul>
<li><strong>Prediction Accuracy:</strong> {{ ai_accuracy }}%</li>
<li><strong>Confidence Score:</strong> {{ ai_confidence }}%</li>
<li><strong>Response Time:</strong> {{ ai_response_time }}ms</li>
</ul>

<p><em>Generated at {{ timestamp }}</em></p>
</body>
</html>""",
                    format_type="html",
                    variables=["date", "total_trades", "successful_trades", "win_rate", "total_pnl", "cpu_usage", "memory_usage", "uptime", "ai_accuracy", "ai_confidence", "ai_response_time", "timestamp"]
                )
            ]
            
            for template in default_templates:
                self.templates[template.id] = template
            
            self.logger.info(f"Loaded {len(default_templates)} default templates")
            
        except Exception as e:
            self.logger.error(f"Failed to load default templates: {e}")
    
    def _load_custom_templates(self):
        """Load custom templates from database."""
        try:
            with db_manager.get_cursor() as cursor:
                cursor.execute("SELECT * FROM notification_templates")
                rows = cursor.fetchall()
                
                for row in rows:
                    template_data = dict(row)
                    template_data['template_type'] = TemplateType(template_data['template_type'])
                    template_data['channel'] = NotificationChannel(template_data['channel'])
                    template_data['variables'] = json.loads(template_data['variables']) if template_data['variables'] else []
                    template_data['metadata'] = json.loads(template_data['metadata']) if template_data['metadata'] else {}
                    
                    template = NotificationTemplate(**template_data)
                    self.templates[template.id] = template
                
                self.logger.info(f"Loaded {len(rows)} custom templates from database")
                
        except Exception as e:
            self.logger.warning(f"Failed to load custom templates: {e}")
    
    def render_template(self, template_id: str, variables: Dict[str, Any]) -> Tuple[str, str]:
        """Render a template with provided variables."""
        try:
            template = self.templates.get(template_id)
            if not template:
                raise ValueError(f"Template not found: {template_id}")
            
            # Render subject
            subject_template = self.jinja_env.from_string(template.subject_template)
            subject = subject_template.render(**variables)
            
            # Render body
            body_template = self.jinja_env.from_string(template.body_template)
            body = body_template.render(**variables)
            
            return subject, body
            
        except Exception as e:
            self.logger.error(f"Failed to render template {template_id}: {e}")
            raise
    
    def add_template(self, template: NotificationTemplate) -> bool:
        """Add a new template."""
        try:
            # Store in database
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    INSERT OR REPLACE INTO notification_templates (
                        id, name, template_type, channel, subject_template, body_template,
                        format_type, variables, metadata, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    template.id, template.name, template.template_type.value, template.channel.value,
                    template.subject_template, template.body_template, template.format_type,
                    json.dumps(template.variables), json.dumps(template.metadata),
                    template.created_at, template.updated_at
                ))
            
            # Add to memory
            self.templates[template.id] = template
            
            self.logger.info(f"Added template: {template.id}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to add template {template.id}: {e}")
            return False
    
    def get_template(self, template_id: str) -> Optional[NotificationTemplate]:
        """Get a template by ID."""
        return self.templates.get(template_id)
    
    def list_templates(self, channel: Optional[NotificationChannel] = None, 
                      template_type: Optional[TemplateType] = None) -> List[NotificationTemplate]:
        """List templates with optional filtering."""
        templates = list(self.templates.values())
        
        if channel:
            templates = [t for t in templates if t.channel == channel]
        
        if template_type:
            templates = [t for t in templates if t.template_type == template_type]
        
        return templates

class SubscriberManager:
    """Manages notification subscribers and their preferences."""
    
    def __init__(self):
        self.logger = get_logger(f"{__name__}.SubscriberManager")
        self.subscribers: Dict[str, Subscriber] = {}
        self._load_subscribers()
    
    def _load_subscribers(self):
        """Load subscribers from database."""
        try:
            with db_manager.get_cursor() as cursor:
                cursor.execute("SELECT * FROM notification_subscribers")
                rows = cursor.fetchall()
                
                for row in rows:
                    subscriber_data = dict(row)
                    subscriber_data['preferences'] = json.loads(subscriber_data['preferences']) if subscriber_data['preferences'] else {}
                    subscriber_data['subscription_groups'] = json.loads(subscriber_data['subscription_groups']) if subscriber_data['subscription_groups'] else []
                    subscriber_data['enabled_channels'] = json.loads(subscriber_data['enabled_channels']) if subscriber_data['enabled_channels'] else []
                    subscriber_data['notification_types'] = json.loads(subscriber_data['notification_types']) if subscriber_data['notification_types'] else []
                    subscriber_data['quiet_hours'] = json.loads(subscriber_data['quiet_hours']) if subscriber_data['quiet_hours'] else {}
                    
                    subscriber = Subscriber(**subscriber_data)
                    self.subscribers[subscriber.id] = subscriber
                
                self.logger.info(f"Loaded {len(rows)} subscribers from database")
                
        except Exception as e:
            self.logger.warning(f"Failed to load subscribers: {e}")
    
    def add_subscriber(self, subscriber: Subscriber) -> bool:
        """Add a new subscriber."""
        try:
            # Store in database
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    INSERT OR REPLACE INTO notification_subscribers (
                        id, name, email, telegram_chat_id, phone_number, webhook_url,
                        preferences, subscription_groups, enabled_channels, notification_types,
                        quiet_hours, created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    subscriber.id, subscriber.name, subscriber.email, subscriber.telegram_chat_id,
                    subscriber.phone_number, subscriber.webhook_url, json.dumps(subscriber.preferences),
                    json.dumps(subscriber.subscription_groups), json.dumps(subscriber.enabled_channels),
                    json.dumps(subscriber.notification_types), json.dumps(subscriber.quiet_hours),
                    subscriber.created_at, subscriber.updated_at
                ))
            
            # Add to memory
            self.subscribers[subscriber.id] = subscriber
            
            self.logger.info(f"Added subscriber: {subscriber.id}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to add subscriber {subscriber.id}: {e}")
            return False
    
    def get_subscriber(self, subscriber_id: str) -> Optional[Subscriber]:
        """Get a subscriber by ID."""
        return self.subscribers.get(subscriber_id)
    
    def get_subscribers_for_channel(self, channel: NotificationChannel) -> List[Subscriber]:
        """Get all subscribers for a specific channel."""
        return [
            subscriber for subscriber in self.subscribers.values()
            if channel.value in subscriber.enabled_channels
        ]
    
    def is_in_quiet_hours(self, subscriber: Subscriber) -> bool:
        """Check if subscriber is in quiet hours."""
        try:
            if not subscriber.quiet_hours:
                return False
            
            current_time = datetime.now().time()
            start_time = datetime.strptime(subscriber.quiet_hours.get('start', '22:00'), '%H:%M').time()
            end_time = datetime.strptime(subscriber.quiet_hours.get('end', '08:00'), '%H:%M').time()
            
            if start_time <= end_time:
                return start_time <= current_time <= end_time
            else:
                return current_time >= start_time or current_time <= end_time
                
        except Exception as e:
            self.logger.warning(f"Failed to check quiet hours for {subscriber.id}: {e}")
            return False

class RateLimiter:
    """Rate limiting for notifications to prevent spam."""
    
    def __init__(self):
        self.logger = get_logger(f"{__name__}.RateLimiter")
        self.rate_limits: Dict[str, deque] = defaultdict(deque)
        self.last_cleanup = time.time()
    
    def is_rate_limited(self, subscriber_id: str, channel: NotificationChannel, 
                       window_seconds: int = 300, max_notifications: int = 10) -> bool:
        """Check if subscriber is rate limited for a channel."""
        try:
            current_time = time.time()
            
            # Cleanup old entries periodically
            if current_time - self.last_cleanup > 60:
                self._cleanup_old_entries(current_time)
                self.last_cleanup = current_time
            
            # Create rate limit key
            key = f"{subscriber_id}:{channel.value}"
            
            # Get timestamps for this key
            timestamps = self.rate_limits[key]
            
            # Remove old timestamps
            cutoff_time = current_time - window_seconds
            while timestamps and timestamps[0] < cutoff_time:
                timestamps.popleft()
            
            # Check if rate limited
            if len(timestamps) >= max_notifications:
                self.logger.warning(f"Rate limit exceeded for {subscriber_id} on {channel.value}")
                return True
            
            # Add current timestamp
            timestamps.append(current_time)
            return False
            
        except Exception as e:
            self.logger.error(f"Failed to check rate limit: {e}")
            return False
    
    def _cleanup_old_entries(self, current_time: float):
        """Remove old rate limit entries."""
        try:
            cutoff_time = current_time - 3600  # Keep 1 hour of history
            
            keys_to_remove = []
            for key, timestamps in self.rate_limits.items():
                # Remove old timestamps
                while timestamps and timestamps[0] < cutoff_time:
                    timestamps.popleft()
                
                # Remove empty entries
                if not timestamps:
                    keys_to_remove.append(key)
            
            for key in keys_to_remove:
                del self.rate_limits[key]
                
        except Exception as e:
            self.logger.error(f"Failed to cleanup rate limit entries: {e}")

class DeliveryTracker:
    """Tracks notification delivery status and metrics."""
    
    def __init__(self):
        self.logger = get_logger(f"{__name__}.DeliveryTracker")
        self.delivery_records: Dict[str, DeliveryRecord] = {}
    
    def create_delivery_record(self, notification_id: str, channel: NotificationChannel, 
                             recipient_id: str) -> str:
        """Create a new delivery record."""
        try:
            record_id = f"{notification_id}_{channel.value}_{recipient_id}"
            
            record = DeliveryRecord(
                id=record_id,
                notification_id=notification_id,
                channel=channel,
                recipient_id=recipient_id,
                status=DeliveryStatus.PENDING
            )
            
            # Store in database
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    INSERT INTO notification_deliveries (
                        id, notification_id, channel, recipient_id, status, attempts,
                        last_attempt_at, delivered_at, error_message, response_data,
                        created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    record.id, record.notification_id, record.channel.value, record.recipient_id,
                    record.status.value, record.attempts, record.last_attempt_at, record.delivered_at,
                    record.error_message, json.dumps(record.response_data),
                    record.created_at, record.updated_at
                ))
            
            # Add to memory
            self.delivery_records[record_id] = record
            
            return record_id
            
        except Exception as e:
            self.logger.error(f"Failed to create delivery record: {e}")
            raise
    
    def update_delivery_status(self, record_id: str, status: DeliveryStatus, 
                             error_message: Optional[str] = None, 
                             response_data: Optional[Dict[str, Any]] = None):
        """Update delivery record status."""
        try:
            record = self.delivery_records.get(record_id)
            if not record:
                self.logger.warning(f"Delivery record not found: {record_id}")
                return
            
            # Update record
            record.status = status
            record.attempts += 1
            record.last_attempt_at = datetime.now().isoformat()
            record.updated_at = datetime.now().isoformat()
            
            if status == DeliveryStatus.DELIVERED:
                record.delivered_at = record.last_attempt_at
            
            if error_message:
                record.error_message = error_message
            
            if response_data:
                record.response_data.update(response_data)
            
            # Update in database
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    UPDATE notification_deliveries SET
                        status = ?, attempts = ?, last_attempt_at = ?, delivered_at = ?,
                        error_message = ?, response_data = ?, updated_at = ?
                    WHERE id = ?
                """, (
                    record.status.value, record.attempts, record.last_attempt_at,
                    record.delivered_at, record.error_message, json.dumps(record.response_data),
                    record.updated_at, record_id
                ))
            
        except Exception as e:
            self.logger.error(f"Failed to update delivery status for {record_id}: {e}")
    
    def get_delivery_metrics(self, hours: int = 24) -> Dict[str, Any]:
        """Get delivery metrics for specified time period."""
        try:
            cutoff_time = datetime.now() - timedelta(hours=hours)
            
            with db_manager.get_cursor() as cursor:
                # Total deliveries by status
                cursor.execute("""
                    SELECT status, COUNT(*) as count 
                    FROM notification_deliveries 
                    WHERE created_at >= ? 
                    GROUP BY status
                """, (cutoff_time.isoformat(),))
                
                status_counts = {row['status']: row['count'] for row in cursor.fetchall()}
                
                # Deliveries by channel
                cursor.execute("""
                    SELECT channel, COUNT(*) as count 
                    FROM notification_deliveries 
                    WHERE created_at >= ? 
                    GROUP BY channel
                """, (cutoff_time.isoformat(),))
                
                channel_counts = {row['channel']: row['count'] for row in cursor.fetchall()}
                
                # Average delivery time
                cursor.execute("""
                    SELECT AVG(
                        (julianday(delivered_at) - julianday(created_at)) * 24 * 60 * 60
                    ) as avg_delivery_time_seconds
                    FROM notification_deliveries 
                    WHERE created_at >= ? AND status = 'delivered'
                """, (cutoff_time.isoformat(),))
                
                row = cursor.fetchone()
                avg_delivery_time = row['avg_delivery_time_seconds'] if row else 0
                
                return {
                    'time_period_hours': hours,
                    'total_deliveries': sum(status_counts.values()),
                    'status_breakdown': status_counts,
                    'channel_breakdown': channel_counts,
                    'success_rate': (status_counts.get('delivered', 0) / max(sum(status_counts.values()), 1)) * 100,
                    'avg_delivery_time_seconds': avg_delivery_time or 0
                }
                
        except Exception as e:
            self.logger.error(f"Failed to get delivery metrics: {e}")
            return {}

class TelegramNotifier:
    """Telegram Bot API integration for notifications."""
    
    def __init__(self, bot_token: str):
        self.bot_token = bot_token
        self.logger = get_logger(f"{__name__}.TelegramNotifier")
        self.base_url = f"https://api.telegram.org/bot{bot_token}"
    
    async def send_notification(self, chat_id: str, message: str, 
                              parse_mode: str = "Markdown") -> Dict[str, Any]:
        """Send notification via Telegram."""
        try:
            url = f"{self.base_url}/sendMessage"
            data = {
                'chat_id': chat_id,
                'text': message,
                'parse_mode': parse_mode
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(url, data=data, timeout=10) as response:
                    result = await response.json()
                    
                    if response.status == 200 and result.get('ok'):
                        self.logger.debug(f"Sent Telegram notification to {chat_id}")
                        return {'success': True, 'response': result}
                    else:
                        error_msg = result.get('description', 'Unknown error')
                        self.logger.error(f"Telegram API error: {error_msg}")
                        return {'success': False, 'error': error_msg}
                        
        except Exception as e:
            self.logger.error(f"Failed to send Telegram notification: {e}")
            return {'success': False, 'error': str(e)}

class EmailNotifier:
    """SMTP email delivery with template support."""
    
    def __init__(self, smtp_server: str, smtp_port: int, username: str, 
                 password: str, from_email: str, use_tls: bool = True):
        self.smtp_server = smtp_server
        self.smtp_port = smtp_port
        self.username = username
        self.password = password
        self.from_email = from_email
        self.use_tls = use_tls
        self.logger = get_logger(f"{__name__}.EmailNotifier")
    
    async def send_notification(self, to_email: str, subject: str, body: str, 
                              is_html: bool = False, attachments: List[str] = None) -> Dict[str, Any]:
        """Send notification via email."""
        try:
            # Create message
            msg = MimeMultipart('alternative')
            msg['From'] = self.from_email
            msg['To'] = to_email
            msg['Subject'] = subject
            
            # Add body
            if is_html:
                msg.attach(MimeText(body, 'html'))
            else:
                msg.attach(MimeText(body, 'plain'))
            
            # Add attachments
            if attachments:
                for attachment_path in attachments:
                    if Path(attachment_path).exists():
                        with open(attachment_path, 'rb') as f:
                            part = MimeBase('application', 'octet-stream')
                            part.set_payload(f.read())
                            encoders.encode_base64(part)
                            part.add_header(
                                'Content-Disposition',
                                f'attachment; filename= {Path(attachment_path).name}'
                            )
                            msg.attach(part)
            
            # Send email
            if self.use_tls:
                await aiosmtplib.send(
                    msg,
                    hostname=self.smtp_server,
                    port=self.smtp_port,
                    username=self.username,
                    password=self.password,
                    use_tls=True
                )
            else:
                await aiosmtplib.send(
                    msg,
                    hostname=self.smtp_server,
                    port=self.smtp_port,
                    username=self.username,
                    password=self.password
                )
            
            self.logger.debug(f"Sent email notification to {to_email}")
            return {'success': True, 'message_id': 'email_sent'}
            
        except Exception as e:
            self.logger.error(f"Failed to send email notification: {e}")
            return {'success': False, 'error': str(e)}

class WebhookNotifier:
    """HTTP webhook notifications for integrations."""
    
    def __init__(self):
        self.logger = get_logger(f"{__name__}.WebhookNotifier")
    
    async def send_notification(self, webhook_url: str, payload: Dict[str, Any], 
                              headers: Optional[Dict[str, str]] = None,
                              method: str = "POST") -> Dict[str, Any]:
        """Send notification via webhook."""
        try:
            if not headers:
                headers = {'Content-Type': 'application/json'}
            
            async with aiohttp.ClientSession() as session:
                if method.upper() == "POST":
                    async with session.post(webhook_url, json=payload, headers=headers, timeout=10) as response:
                        response_text = await response.text()
                        
                        if response.status in [200, 201, 202]:
                            self.logger.debug(f"Sent webhook notification to {webhook_url}")
                            return {'success': True, 'status_code': response.status, 'response': response_text}
                        else:
                            self.logger.error(f"Webhook error: {response.status} - {response_text}")
                            return {'success': False, 'status_code': response.status, 'error': response_text}
                            
                elif method.upper() == "PUT":
                    async with session.put(webhook_url, json=payload, headers=headers, timeout=10) as response:
                        response_text = await response.text()
                        
                        if response.status in [200, 201, 202]:
                            self.logger.debug(f"Sent webhook notification to {webhook_url}")
                            return {'success': True, 'status_code': response.status, 'response': response_text}
                        else:
                            self.logger.error(f"Webhook error: {response.status} - {response_text}")
                            return {'success': False, 'status_code': response.status, 'error': response_text}
                else:
                    return {'success': False, 'error': f'Unsupported HTTP method: {method}'}
                    
        except Exception as e:
            self.logger.error(f"Failed to send webhook notification: {e}")
            return {'success': False, 'error': str(e)}

class SMSNotifier:
    """SMS notifications (placeholder for future implementation)."""
    
    def __init__(self, provider_config: Dict[str, Any]):
        self.provider_config = provider_config
        self.logger = get_logger(f"{__name__}.SMSNotifier")
    
    async def send_notification(self, phone_number: str, message: str) -> Dict[str, Any]:
        """Send notification via SMS."""
        # Placeholder for SMS implementation
        # Could integrate with Twilio, AWS SNS, or other SMS providers
        self.logger.warning("SMS notifications not implemented yet")
        return {'success': False, 'error': 'SMS notifications not implemented'}

class NotificationSystem:
    """Main notification system orchestrator."""
    
    def __init__(self):
        self.logger = get_logger(__name__)
        self.config = monitoring_config
        self.running = False
        self.worker_thread: Optional[threading.Thread] = None
        
        # Core components
        self.template_manager = TemplateManager()
        self.subscriber_manager = SubscriberManager()
        self.rate_limiter = RateLimiter()
        self.delivery_tracker = DeliveryTracker()
        
        # Notification channels
        self.telegram_notifier: Optional[TelegramNotifier] = None
        self.email_notifier: Optional[EmailNotifier] = None
        self.webhook_notifier = WebhookNotifier()
        self.sms_notifier: Optional[SMSNotifier] = None
        
        # Processing queue
        self.notification_queue = queue.PriorityQueue()
        self.batch_queue = deque()
        
        # Thread safety
        self._lock = threading.RLock()
        
        # Callbacks
        self.delivery_callbacks: List[Callable] = []
        
        self._initialize_notification_system()
    
    def _initialize_notification_system(self):
        """Initialize the notification system."""
        try:
            # Create database tables
            self._create_notification_tables()
            
            # Initialize notification channels
            self._initialize_channels()
            
            # Load pending notifications
            self._load_pending_notifications()
            
            self.logger.info("Notification system initialized successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize notification system: {e}")
            raise
    
    def _create_notification_tables(self):
        """Create database tables for notifications."""
        try:
            with db_manager.get_cursor() as cursor:
                # Notification templates table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS notification_templates (
                        id TEXT PRIMARY KEY,
                        name TEXT NOT NULL,
                        template_type TEXT NOT NULL,
                        channel TEXT NOT NULL,
                        subject_template TEXT NOT NULL,
                        body_template TEXT NOT NULL,
                        format_type TEXT DEFAULT 'text',
                        variables TEXT,
                        metadata TEXT,
                        created_at TIMESTAMP,
                        updated_at TIMESTAMP
                    )
                """)
                
                # Subscribers table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS notification_subscribers (
                        id TEXT PRIMARY KEY,
                        name TEXT NOT NULL,
                        email TEXT,
                        telegram_chat_id TEXT,
                        phone_number TEXT,
                        webhook_url TEXT,
                        preferences TEXT,
                        subscription_groups TEXT,
                        enabled_channels TEXT,
                        notification_types TEXT,
                        quiet_hours TEXT,
                        created_at TIMESTAMP,
                        updated_at TIMESTAMP
                    )
                """)
                
                # Notifications table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS notifications (
                        id TEXT PRIMARY KEY,
                        channel TEXT NOT NULL,
                        priority INTEGER NOT NULL,
                        recipient_id TEXT NOT NULL,
                        template_id TEXT,
                        subject TEXT NOT NULL,
                        message TEXT NOT NULL,
                        variables TEXT,
                        attachments TEXT,
                        metadata TEXT,
                        scheduled_at TIMESTAMP,
                        expires_at TIMESTAMP,
                        created_at TIMESTAMP
                    )
                """)
                
                # Delivery tracking table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS notification_deliveries (
                        id TEXT PRIMARY KEY,
                        notification_id TEXT NOT NULL,
                        channel TEXT NOT NULL,
                        recipient_id TEXT NOT NULL,
                        status TEXT NOT NULL,
                        attempts INTEGER DEFAULT 0,
                        last_attempt_at TIMESTAMP,
                        delivered_at TIMESTAMP,
                        error_message TEXT,
                        response_data TEXT,
                        created_at TIMESTAMP,
                        updated_at TIMESTAMP,
                        FOREIGN KEY (notification_id) REFERENCES notifications (id)
                    )
                """)
                
                # Create indexes
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_notifications_priority ON notifications(priority, created_at)")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_notifications_scheduled ON notifications(scheduled_at)")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_deliveries_status ON notification_deliveries(status)")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_deliveries_channel ON notification_deliveries(channel)")
                
        except Exception as e:
            self.logger.error(f"Failed to create notification tables: {e}")
            raise
    
    def _initialize_channels(self):
        """Initialize notification channels based on configuration."""
        try:
            # Initialize Telegram
            if self.config.notifications.telegram_enabled:
                bot_token = os.getenv('TELEGRAM_BOT_TOKEN')
                if bot_token:
                    self.telegram_notifier = TelegramNotifier(bot_token)
                    self.logger.info("Telegram notifier initialized")
                else:
                    self.logger.warning("Telegram enabled but no bot token provided")
            
            # Initialize Email
            if self.config.notifications.email_enabled:
                smtp_config = {
                    'smtp_server': os.getenv('SMTP_SERVER'),
                    'smtp_port': int(os.getenv('SMTP_PORT', 587)),
                    'username': os.getenv('SMTP_USERNAME'),
                    'password': os.getenv('SMTP_PASSWORD'),
                    'from_email': os.getenv('SMTP_FROM_EMAIL'),
                    'use_tls': os.getenv('SMTP_USE_TLS', 'true').lower() == 'true'
                }
                
                if all([smtp_config['smtp_server'], smtp_config['username'], 
                       smtp_config['password'], smtp_config['from_email']]):
                    self.email_notifier = EmailNotifier(**smtp_config)
                    self.logger.info("Email notifier initialized")
                else:
                    self.logger.warning("Email enabled but configuration incomplete")
            
            # Initialize SMS
            if self.config.notifications.sms_enabled:
                sms_config = {
                    'provider': os.getenv('SMS_PROVIDER', 'twilio'),
                    'api_key': os.getenv('SMS_API_KEY'),
                    'api_secret': os.getenv('SMS_API_SECRET'),
                    'from_number': os.getenv('SMS_FROM_NUMBER')
                }
                
                if sms_config['api_key'] and sms_config['api_secret']:
                    self.sms_notifier = SMSNotifier(sms_config)
                    self.logger.info("SMS notifier initialized")
                else:
                    self.logger.warning("SMS enabled but configuration incomplete")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize channels: {e}")
    
    def _load_pending_notifications(self):
        """Load pending notifications from database."""
        try:
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    SELECT * FROM notifications 
                    WHERE scheduled_at <= ? OR scheduled_at IS NULL
                    ORDER BY priority DESC, created_at ASC
                """, (datetime.now().isoformat(),))
                
                rows = cursor.fetchall()
                
                for row in rows:
                    notification_data = dict(row)
                    notification_data['channel'] = NotificationChannel(notification_data['channel'])
                    notification_data['priority'] = NotificationPriority(notification_data['priority'])
                    notification_data['variables'] = json.loads(notification_data['variables']) if notification_data['variables'] else {}
                    notification_data['attachments'] = json.loads(notification_data['attachments']) if notification_data['attachments'] else []
                    notification_data['metadata'] = json.loads(notification_data['metadata']) if notification_data['metadata'] else {}
                    
                    request = NotificationRequest(**notification_data)
                    
                    # Add to queue with priority
                    self.notification_queue.put((request.priority.value * -1, time.time(), request))
                
                self.logger.info(f"Loaded {len(rows)} pending notifications")
                
        except Exception as e:
            self.logger.warning(f"Failed to load pending notifications: {e}")
    
    def start(self):
        """Start the notification system."""
        if not self.running:
            self.running = True
            self.worker_thread = threading.Thread(target=self._worker_loop, daemon=True)
            self.worker_thread.start()
            self.logger.info("Notification system started")
    
    def stop(self):
        """Stop the notification system."""
        self.running = False
        if self.worker_thread:
            self.worker_thread.join(timeout=5)
        self.logger.info("Notification system stopped")
    
    def _worker_loop(self):
        """Main worker loop for processing notifications."""
        while self.running:
            try:
                # Process notification queue
                self._process_notification_queue()
                
                # Process batch notifications
                self._process_batch_queue()
                
                # Check for scheduled notifications
                self._check_scheduled_notifications()
                
                # Retry failed notifications
                self._retry_failed_notifications()
                
                time.sleep(1)  # Process every second
                
            except Exception as e:
                self.logger.error(f"Error in notification worker loop: {e}")
                time.sleep(5)
    
    def _process_notification_queue(self):
        """Process notifications in the priority queue."""
        try:
            while not self.notification_queue.empty():
                try:
                    priority, timestamp, request = self.notification_queue.get_nowait()
                    asyncio.run(self._process_notification_request(request))
                except queue.Empty:
                    break
                except Exception as e:
                    self.logger.error(f"Failed to process notification: {e}")
                    
        except Exception as e:
            self.logger.error(f"Error processing notification queue: {e}")
    
    async def _process_notification_request(self, request: NotificationRequest):
        """Process a single notification request."""
        try:
            # Get subscriber
            subscriber = self.subscriber_manager.get_subscriber(request.recipient_id)
            if not subscriber:
                self.logger.warning(f"Subscriber not found: {request.recipient_id}")
                return
            
            # Check if channel is enabled for subscriber
            if request.channel.value not in subscriber.enabled_channels:
                self.logger.debug(f"Channel {request.channel.value} not enabled for subscriber {request.recipient_id}")
                return
            
            # Check quiet hours
            if self.subscriber_manager.is_in_quiet_hours(subscriber) and request.priority != NotificationPriority.CRITICAL:
                self.logger.debug(f"Subscriber {request.recipient_id} is in quiet hours, skipping non-critical notification")
                return
            
            # Check rate limiting
            if self.rate_limiter.is_rate_limited(request.recipient_id, request.channel):
                self.logger.debug(f"Rate limited notification for {request.recipient_id} on {request.channel.value}")
                return
            
            # Create delivery record
            delivery_id = self.delivery_tracker.create_delivery_record(
                request.id, request.channel, request.recipient_id
            )
            
            # Send notification
            success = await self._send_notification(request, subscriber, delivery_id)
            
            if success:
                self.delivery_tracker.update_delivery_status(delivery_id, DeliveryStatus.DELIVERED)
            else:
                self.delivery_tracker.update_delivery_status(delivery_id, DeliveryStatus.FAILED)
            
            # Notify callbacks
            self._notify_delivery_callbacks(request, success)
            
        except Exception as e:
            self.logger.error(f"Failed to process notification request {request.id}: {e}")
    
    async def _send_notification(self, request: NotificationRequest, subscriber: Subscriber, 
                               delivery_id: str) -> bool:
        """Send notification through appropriate channel."""
        try:
            if request.channel == NotificationChannel.TELEGRAM:
                if self.telegram_notifier and subscriber.telegram_chat_id:
                    result = await self.telegram_notifier.send_notification(
                        subscriber.telegram_chat_id, request.message
                    )
                    return result['success']
                    
            elif request.channel == NotificationChannel.EMAIL:
                if self.email_notifier and subscriber.email:
                    is_html = request.template_id and 'html' in request.template_id
                    result = await self.email_notifier.send_notification(
                        subscriber.email, request.subject, request.message, 
                        is_html=is_html, attachments=request.attachments
                    )
                    return result['success']
                    
            elif request.channel == NotificationChannel.WEBHOOK:
                if subscriber.webhook_url:
                    payload = {
                        'notification_id': request.id,
                        'subject': request.subject,
                        'message': request.message,
                        'priority': request.priority.value,
                        'timestamp': datetime.now().isoformat(),
                        'metadata': request.metadata
                    }
                    result = await self.webhook_notifier.send_notification(
                        subscriber.webhook_url, payload
                    )
                    return result['success']
                    
            elif request.channel == NotificationChannel.SMS:
                if self.sms_notifier and subscriber.phone_number:
                    result = await self.sms_notifier.send_notification(
                        subscriber.phone_number, request.message
                    )
                    return result['success']
            
            return False
            
        except Exception as e:
            self.logger.error(f"Failed to send notification via {request.channel.value}: {e}")
            return False
    
    def _process_batch_queue(self):
        """Process batch notifications."""
        try:
            if not self.batch_queue:
                return
            
            # Process batches of notifications
            batch_size = 10
            batch = []
            
            for _ in range(min(batch_size, len(self.batch_queue))):
                if self.batch_queue:
                    batch.append(self.batch_queue.popleft())
            
            if batch:
                asyncio.run(self._process_notification_batch(batch))
                
        except Exception as e:
            self.logger.error(f"Error processing batch queue: {e}")
    
    async def _process_notification_batch(self, batch: List[NotificationRequest]):
        """Process a batch of notifications concurrently."""
        try:
            tasks = []
            for request in batch:
                task = self._process_notification_request(request)
                tasks.append(task)
            
            await asyncio.gather(*tasks, return_exceptions=True)
            
        except Exception as e:
            self.logger.error(f"Error processing notification batch: {e}")
    
    def _check_scheduled_notifications(self):
        """Check for scheduled notifications that are ready to send."""
        try:
            current_time = datetime.now()
            
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    SELECT * FROM notifications 
                    WHERE scheduled_at <= ? AND scheduled_at IS NOT NULL
                    ORDER BY priority DESC, scheduled_at ASC
                    LIMIT 50
                """, (current_time.isoformat(),))
                
                rows = cursor.fetchall()
                
                for row in rows:
                    notification_data = dict(row)
                    notification_data['channel'] = NotificationChannel(notification_data['channel'])
                    notification_data['priority'] = NotificationPriority(notification_data['priority'])
                    notification_data['variables'] = json.loads(notification_data['variables']) if notification_data['variables'] else {}
                    notification_data['attachments'] = json.loads(notification_data['attachments']) if notification_data['attachments'] else []
                    notification_data['metadata'] = json.loads(notification_data['metadata']) if notification_data['metadata'] else {}
                    
                    request = NotificationRequest(**notification_data)
                    
                    # Add to queue
                    self.notification_queue.put((request.priority.value * -1, time.time(), request))
                    
                    # Remove from scheduled notifications
                    cursor.execute("DELETE FROM notifications WHERE id = ?", (request.id,))
                
        except Exception as e:
            self.logger.error(f"Error checking scheduled notifications: {e}")
    
    def _retry_failed_notifications(self):
        """Retry failed notifications with exponential backoff."""
        try:
            current_time = datetime.now()
            
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    SELECT * FROM notification_deliveries 
                    WHERE status = 'failed' AND attempts < 3
                    AND (last_attempt_at IS NULL OR 
                         datetime(last_attempt_at, '+' || (attempts * 5) || ' minutes') <= ?)
                    ORDER BY created_at ASC
                    LIMIT 20
                """, (current_time.isoformat(),))
                
                rows = cursor.fetchall()
                
                for row in rows:
                    delivery_data = dict(row)
                    
                    # Get original notification
                    cursor.execute("SELECT * FROM notifications WHERE id = ?", 
                                 (delivery_data['notification_id'],))
                    notification_row = cursor.fetchone()
                    
                    if notification_row:
                        notification_data = dict(notification_row)
                        notification_data['channel'] = NotificationChannel(notification_data['channel'])
                        notification_data['priority'] = NotificationPriority(notification_data['priority'])
                        notification_data['variables'] = json.loads(notification_data['variables']) if notification_data['variables'] else {}
                        notification_data['attachments'] = json.loads(notification_data['attachments']) if notification_data['attachments'] else []
                        notification_data['metadata'] = json.loads(notification_data['metadata']) if notification_data['metadata'] else {}
                        
                        request = NotificationRequest(**notification_data)
                        
                        # Add to retry queue
                        self.notification_queue.put((request.priority.value * -1, time.time(), request))
                
        except Exception as e:
            self.logger.error(f"Error retrying failed notifications: {e}")
    
    def _notify_delivery_callbacks(self, request: NotificationRequest, success: bool):
        """Notify registered callbacks about delivery status."""
        for callback in self.delivery_callbacks:
            try:
                callback(request, success)
            except Exception as e:
                self.logger.error(f"Delivery callback failed: {e}")
    
    def send_notification(self, channel: NotificationChannel, recipient_id: str, 
                         subject: str, message: str, priority: NotificationPriority = NotificationPriority.MEDIUM,
                         template_id: Optional[str] = None, variables: Optional[Dict[str, Any]] = None,
                         attachments: Optional[List[str]] = None, 
                         scheduled_at: Optional[datetime] = None) -> str:
        """Send a notification."""
        try:
            notification_id = f"notif_{int(time.time() * 1000)}_{channel.value}_{recipient_id}"
            
            # Render template if provided
            if template_id and variables:
                try:
                    rendered_subject, rendered_message = self.template_manager.render_template(
                        template_id, variables
                    )
                    subject = rendered_subject
                    message = rendered_message
                except Exception as e:
                    self.logger.warning(f"Failed to render template {template_id}: {e}")
            
            request = NotificationRequest(
                id=notification_id,
                channel=channel,
                priority=priority,
                recipient_id=recipient_id,
                template_id=template_id,
                subject=subject,
                message=message,
                variables=variables or {},
                attachments=attachments or [],
                scheduled_at=scheduled_at.isoformat() if scheduled_at else None
            )
            
            # Store notification
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    INSERT INTO notifications (
                        id, channel, priority, recipient_id, template_id, subject, message,
                        variables, attachments, metadata, scheduled_at, created_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    request.id, request.channel.value, request.priority.value, request.recipient_id,
                    request.template_id, request.subject, request.message,
                    json.dumps(request.variables), json.dumps(request.attachments),
                    json.dumps(request.metadata), request.scheduled_at, request.created_at
                ))
            
            # Add to queue if not scheduled
            if not scheduled_at:
                self.notification_queue.put((request.priority.value * -1, time.time(), request))
            
            self.logger.info(f"Created notification: {notification_id}")
            return notification_id
            
        except Exception as e:
            self.logger.error(f"Failed to send notification: {e}")
            raise
    
    def send_batch_notification(self, requests: List[NotificationRequest]):
        """Send multiple notifications as a batch."""
        try:
            with self._lock:
                for request in requests:
                    self.batch_queue.append(request)
            
            self.logger.info(f"Added {len(requests)} notifications to batch queue")
            
        except Exception as e:
            self.logger.error(f"Failed to send batch notifications: {e}")
    
    def send_alert_notification(self, alert_data: Dict[str, Any]):
        """Send notification for an alert from the alert manager."""
        try:
            # Determine notification type and template
            alert_type = alert_data.get('alert_type', 'system')
            severity = alert_data.get('severity', 'info')
            
            # Map alert type to template
            template_mapping = {
                'system': 'system_alert',
                'trading': 'trading_alert',
                'ai': 'ai_alert',
                'health': 'health_alert'
            }
            
            base_template = template_mapping.get(alert_type, 'system_alert')
            
            # Get subscribers for this alert type
            subscribers = self.subscriber_manager.get_subscribers_for_channel(NotificationChannel.TELEGRAM)
            
            # Determine priority based on severity
            priority_mapping = {
                'info': NotificationPriority.LOW,
                'warning': NotificationPriority.MEDIUM,
                'critical': NotificationPriority.HIGH,
                'emergency': NotificationPriority.CRITICAL
            }
            
            priority = priority_mapping.get(severity, NotificationPriority.MEDIUM)
            
            # Send notifications to all subscribers
            for subscriber in subscribers:
                # Check if subscriber wants this type of alert
                if alert_type in subscriber.notification_types or not subscriber.notification_types:
                    
                    # Send via enabled channels
                    for channel_name in subscriber.enabled_channels:
                        try:
                            channel = NotificationChannel(channel_name)
                            template_id = f"{base_template}_{channel.value}"
                            
                            self.send_notification(
                                channel=channel,
                                recipient_id=subscriber.id,
                                subject=f"Alert: {alert_data.get('title', 'System Alert')}",
                                message=alert_data.get('message', ''),
                                priority=priority,
                                template_id=template_id,
                                variables=alert_data
                            )
                            
                        except Exception as e:
                            self.logger.error(f"Failed to send alert to {subscriber.id} via {channel_name}: {e}")
            
        except Exception as e:
            self.logger.error(f"Failed to send alert notification: {e}")
    
    def add_subscriber(self, subscriber: Subscriber) -> bool:
        """Add a new subscriber."""
        return self.subscriber_manager.add_subscriber(subscriber)
    
    def add_template(self, template: NotificationTemplate) -> bool:
        """Add a new template."""
        return self.template_manager.add_template(template)
    
    def add_delivery_callback(self, callback: Callable[[NotificationRequest, bool], None]):
        """Add a callback for delivery status updates."""
        self.delivery_callbacks.append(callback)
    
    def get_delivery_metrics(self, hours: int = 24) -> Dict[str, Any]:
        """Get delivery metrics."""
        return self.delivery_tracker.get_delivery_metrics(hours)
    
    def get_system_status(self) -> Dict[str, Any]:
        """Get notification system status."""
        try:
            return {
                'running': self.running,
                'queue_size': self.notification_queue.qsize(),
                'batch_queue_size': len(self.batch_queue),
                'subscribers_count': len(self.subscriber_manager.subscribers),
                'templates_count': len(self.template_manager.templates),
                'channels_status': {
                    'telegram': self.telegram_notifier is not None,
                    'email': self.email_notifier is not None,
                    'webhook': True,
                    'sms': self.sms_notifier is not None
                },
                'delivery_metrics': self.get_delivery_metrics(24)
            }
            
        except Exception as e:
            self.logger.error(f"Failed to get system status: {e}")
            return {'error': str(e)}

# Global notification system instance
notification_system = NotificationSystem()

# Integration with alert manager
def setup_alert_integration():
    """Setup integration with the alert manager."""
    try:
        from .alert_manager import alert_manager
        
        # Add callback to alert manager for notifications
        def alert_notification_callback(alert):
            try:
                alert_data = alert.to_dict() if hasattr(alert, 'to_dict') else alert
                notification_system.send_alert_notification(alert_data)
            except Exception as e:
                notification_system.logger.error(f"Failed to send alert notification: {e}")
        
        alert_manager.add_alert_callback(alert_notification_callback)
        notification_system.logger.info("Alert manager integration setup complete")
        
    except Exception as e:
        notification_system.logger.error(f"Failed to setup alert integration: {e}")

# Auto-setup integration when module is imported
try:
    setup_alert_integration()
except Exception as e:
    logging.getLogger(__name__).warning(f"Could not setup alert integration: {e}")