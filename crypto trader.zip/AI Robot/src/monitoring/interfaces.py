"""
Dependency injection interfaces for the monitoring system.
Provides abstractions to decouple monitoring components from AI system dependencies.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, List, Union, Protocol
from datetime import datetime
from enum import Enum


class LogLevel(Enum):
    """Log levels for monitoring."""
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


class AlertLevel(Enum):
    """Alert severity levels."""
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"
    EMERGENCY = "emergency"


# Core Interfaces

class ILogger(ABC):
    """Logger interface for monitoring components."""
    
    @abstractmethod
    def debug(self, message: str, **kwargs) -> None:
        """Log debug message."""
        pass
    
    @abstractmethod
    def info(self, message: str, **kwargs) -> None:
        """Log info message."""
        pass
    
    @abstractmethod
    def warning(self, message: str, **kwargs) -> None:
        """Log warning message."""
        pass
    
    @abstractmethod
    def error(self, message: str, **kwargs) -> None:
        """Log error message."""
        pass
    
    @abstractmethod
    def critical(self, message: str, **kwargs) -> None:
        """Log critical message."""
        pass


class IDatabaseManager(ABC):
    """Database manager interface for monitoring components."""
    
    @abstractmethod
    def get_cursor(self):
        """Get database cursor context manager."""
        pass
    
    @abstractmethod
    def execute_query(self, query: str, params: tuple = None) -> List[Dict[str, Any]]:
        """Execute query and return results."""
        pass
    
    @abstractmethod
    def execute_command(self, command: str, params: tuple = None) -> int:
        """Execute command and return affected rows."""
        pass


class IConfigManager(ABC):
    """Configuration manager interface."""
    
    @abstractmethod
    def get_monitoring_config(self) -> Dict[str, Any]:
        """Get monitoring configuration."""
        pass
    
    @abstractmethod
    def get_dashboard_config(self) -> Dict[str, Any]:
        """Get dashboard configuration."""
        pass
    
    @abstractmethod
    def get_alert_config(self) -> Dict[str, Any]:
        """Get alert configuration."""
        pass
    
    @abstractmethod
    def is_monitoring_only_mode(self) -> bool:
        """Check if running in monitoring-only mode."""
        pass


class IMetricsCollector(ABC):
    """Metrics collector interface."""
    
    @abstractmethod
    def collect_metric(self, name: str, value: Union[int, float], 
                      tags: Dict[str, str] = None, timestamp: str = None) -> bool:
        """Collect a metric."""
        pass
    
    @abstractmethod
    def get_metrics_summary(self) -> Dict[str, Any]:
        """Get metrics summary."""
        pass


class IAlertManager(ABC):
    """Alert manager interface."""
    
    @abstractmethod
    def create_alert(self, alert_type: str, severity: AlertLevel, title: str,
                    message: str, source: str, **kwargs) -> str:
        """Create an alert."""
        pass
    
    @abstractmethod
    def get_active_alerts(self) -> List[Dict[str, Any]]:
        """Get active alerts."""
        pass


class ISystemMonitor(ABC):
    """System monitor interface."""
    
    @abstractmethod
    def get_current_metrics(self) -> Optional[Dict[str, Any]]:
        """Get current system metrics."""
        pass
    
    @abstractmethod
    def get_system_health_score(self) -> float:
        """Get system health score."""
        pass
    
    @abstractmethod
    def start_monitoring(self) -> None:
        """Start monitoring."""
        pass
    
    @abstractmethod
    def stop_monitoring(self) -> None:
        """Stop monitoring."""
        pass


class INotificationSystem(ABC):
    """Notification system interface."""
    
    @abstractmethod
    def send_notification(self, channel: str, recipient_id: str, 
                         subject: str, message: str, **kwargs) -> str:
        """Send a notification."""
        pass
    
    @abstractmethod
    def get_system_status(self) -> Dict[str, Any]:
        """Get notification system status."""
        pass


# Dependency Container Interface

class IDependencyContainer(ABC):
    """Dependency injection container interface."""
    
    @abstractmethod
    def register_logger(self, logger: ILogger) -> None:
        """Register logger implementation."""
        pass
    
    @abstractmethod
    def register_database_manager(self, db_manager: IDatabaseManager) -> None:
        """Register database manager implementation."""
        pass
    
    @abstractmethod
    def register_config_manager(self, config_manager: IConfigManager) -> None:
        """Register configuration manager implementation."""
        pass
    
    @abstractmethod
    def register_metrics_collector(self, metrics_collector: IMetricsCollector) -> None:
        """Register metrics collector implementation."""
        pass
    
    @abstractmethod
    def register_alert_manager(self, alert_manager: IAlertManager) -> None:
        """Register alert manager implementation."""
        pass
    
    @abstractmethod
    def register_system_monitor(self, system_monitor: ISystemMonitor) -> None:
        """Register system monitor implementation."""
        pass
    
    @abstractmethod
    def register_notification_system(self, notification_system: INotificationSystem) -> None:
        """Register notification system implementation."""
        pass
    
    @abstractmethod
    def get_logger(self, name: str = None) -> ILogger:
        """Get logger instance."""
        pass
    
    @abstractmethod
    def get_database_manager(self) -> IDatabaseManager:
        """Get database manager instance."""
        pass
    
    @abstractmethod
    def get_config_manager(self) -> IConfigManager:
        """Get configuration manager instance."""
        pass
    
    @abstractmethod
    def get_metrics_collector(self) -> Optional[IMetricsCollector]:
        """Get metrics collector instance."""
        pass
    
    @abstractmethod
    def get_alert_manager(self) -> Optional[IAlertManager]:
        """Get alert manager instance."""
        pass
    
    @abstractmethod
    def get_system_monitor(self) -> Optional[ISystemMonitor]:
        """Get system monitor instance."""
        pass
    
    @abstractmethod
    def get_notification_system(self) -> Optional[INotificationSystem]:
        """Get notification system instance."""
        pass


# Factory Interfaces

class IMonitoringComponentFactory(ABC):
    """Factory for creating monitoring components."""
    
    @abstractmethod
    def create_system_monitor(self, container: IDependencyContainer) -> ISystemMonitor:
        """Create system monitor instance."""
        pass
    
    @abstractmethod
    def create_metrics_collector(self, container: IDependencyContainer) -> IMetricsCollector:
        """Create metrics collector instance."""
        pass
    
    @abstractmethod
    def create_alert_manager(self, container: IDependencyContainer) -> IAlertManager:
        """Create alert manager instance."""
        pass
    
    @abstractmethod
    def create_notification_system(self, container: IDependencyContainer) -> INotificationSystem:
        """Create notification system instance."""
        pass


# Component Lifecycle Interface

class IMonitoringComponent(ABC):
    """Base interface for monitoring components."""
    
    @abstractmethod
    def initialize(self, container: IDependencyContainer) -> None:
        """Initialize component with dependencies."""
        pass
    
    @abstractmethod
    def start(self) -> None:
        """Start component."""
        pass
    
    @abstractmethod
    def stop(self) -> None:
        """Stop component."""
        pass
    
    @abstractmethod
    def get_health_status(self) -> Dict[str, Any]:
        """Get component health status."""
        pass


# Configuration Protocols

class MonitoringConfig(Protocol):
    """Protocol for monitoring configuration."""
    
    dashboard_host: str
    dashboard_port: int
    collection_interval: int
    retention_days: int
    alerts_enabled: bool
    telegram_enabled: bool
    email_enabled: bool


class SystemThresholds(Protocol):
    """Protocol for system thresholds."""
    
    cpu_warning: float
    cpu_critical: float
    memory_warning: float
    memory_critical: float
    disk_warning: float
    disk_critical: float
    temperature_warning: float
    temperature_critical: float