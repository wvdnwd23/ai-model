"""
Metrics Collector framework for the AI Crypto Trading System.
Handles custom metrics collection, time-series data management, and performance metrics calculation.
"""

import time
import threading
import logging
import statistics
import json
import csv
import gzip
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List, Callable, Union
from dataclasses import dataclass, asdict, field
from collections import deque, defaultdict
from enum import Enum
from pathlib import Path
import queue
import concurrent.futures

from .config import monitoring_config, MetricType, AlertLevel
from ..utils.logging import get_logger
from ..utils.database import db_manager

class MetricUnit(Enum):
    """Units for metrics."""
    COUNT = "count"
    PERCENTAGE = "percentage"
    SECONDS = "seconds"
    MILLISECONDS = "milliseconds"
    BYTES = "bytes"
    CURRENCY = "currency"
    CUSTOM = "custom"

class AggregationType(Enum):
    """Types of metric aggregation."""
    SUM = "sum"
    AVERAGE = "average"
    MIN = "min"
    MAX = "max"
    COUNT = "count"

class MetricStatus(Enum):
    """Status of metric collection."""
    ACTIVE = "active"
    PAUSED = "paused"
    DISABLED = "disabled"

@dataclass
class MetricDefinition:
    """Definition of a custom metric."""
    name: str
    metric_type: MetricType
    unit: MetricUnit
    description: str
    tags: Dict[str, str] = field(default_factory=dict)
    aggregations: List[AggregationType] = field(default_factory=lambda: [AggregationType.AVERAGE])
    retention_days: int = 90
    collection_interval: int = 60
    alert_thresholds: Dict[str, float] = field(default_factory=dict)
    status: MetricStatus = MetricStatus.ACTIVE

@dataclass
class Metric:
    """Standard metric data structure."""
    name: str
    value: Union[float, int]
    timestamp: str
    tags: Dict[str, str] = field(default_factory=dict)
    unit: MetricUnit = MetricUnit.COUNT
    source: str = "unknown"
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class TimeSeriesData:
    """Time-series data point structure."""
    metric_name: str
    timestamp: str
    value: float
    aggregation_type: AggregationType
    interval_seconds: int
    tags: Dict[str, str] = field(default_factory=dict)
    sample_count: int = 1

class MetricsAggregator:
    """Metrics aggregation and calculation engine."""
    
    def __init__(self, config):
        self.config = config
        self.logger = get_logger(__name__)
        
    def aggregate_metrics(self, metrics: List[Metric], interval_seconds: int, 
                         aggregation_type: AggregationType) -> List[TimeSeriesData]:
        """Aggregate metrics over specified interval."""
        try:
            if not metrics:
                return []
            
            # Simple aggregation implementation
            values = [m.value for m in metrics]
            
            if aggregation_type == AggregationType.SUM:
                aggregated_value = sum(values)
            elif aggregation_type == AggregationType.AVERAGE:
                aggregated_value = statistics.mean(values)
            elif aggregation_type == AggregationType.MIN:
                aggregated_value = min(values)
            elif aggregation_type == AggregationType.MAX:
                aggregated_value = max(values)
            else:
                aggregated_value = statistics.mean(values)
            
            return [TimeSeriesData(
                metric_name=metrics[0].name,
                timestamp=datetime.now().isoformat(),
                value=aggregated_value,
                aggregation_type=aggregation_type,
                interval_seconds=interval_seconds,
                sample_count=len(metrics)
            )]
            
        except Exception as e:
            self.logger.error(f"Failed to aggregate metrics: {e}")
            return []

class MetricsExporter:
    """Export functionality for external tools."""
    
    def __init__(self, config):
        self.config = config
        self.logger = get_logger(__name__)
        self.export_dir = Path("src/data/exports/metrics")
        self.export_dir.mkdir(parents=True, exist_ok=True)
    
    def export_metrics(self, metrics: List[Metric], format_type: str, 
                      filename: Optional[str] = None) -> str:
        """Export metrics to specified format."""
        try:
            if not filename:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"metrics_export_{timestamp}.{format_type}"
            
            file_path = self.export_dir / filename
            
            if format_type.lower() == "json":
                return self._export_json(metrics, file_path)
            elif format_type.lower() == "csv":
                return self._export_csv(metrics, file_path)
            else:
                raise ValueError(f"Unsupported export format: {format_type}")
                
        except Exception as e:
            self.logger.error(f"Failed to export metrics: {e}")
            raise
    
    def _export_json(self, metrics: List[Metric], file_path: Path) -> str:
        """Export metrics to JSON format."""
        export_data = {
            "export_timestamp": datetime.now().isoformat(),
            "metrics_count": len(metrics),
            "metrics": [asdict(metric) for metric in metrics]
        }
        
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(export_data, f, indent=2, default=str)
        
        self.logger.info(f"Exported {len(metrics)} metrics to JSON: {file_path}")
        return str(file_path)
    
    def _export_csv(self, metrics: List[Metric], file_path: Path) -> str:
        """Export metrics to CSV format."""
        if not metrics:
            return str(file_path)
        
        headers = ['name', 'value', 'timestamp', 'unit', 'source', 'tags', 'metadata']
        
        with open(file_path, 'w', encoding='utf-8', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=headers)
            writer.writeheader()
            
            for metric in metrics:
                row = asdict(metric)
                # Convert complex fields to JSON strings
                for key in ['tags', 'metadata']:
                    if key in row and isinstance(row[key], dict):
                        row[key] = json.dumps(row[key])
                writer.writerow(row)
        
        self.logger.info(f"Exported {len(metrics)} metrics to CSV: {file_path}")
        return str(file_path)

class MetricsCollector:
    """Main metrics collection and management class."""
    
    def __init__(self):
        self.logger = get_logger(__name__)
        self.config = monitoring_config
        self.running = False
        self.collection_thread: Optional[threading.Thread] = None
        
        # Core components
        self.aggregator = MetricsAggregator(self.config)
        self.exporter = MetricsExporter(self.config)
        
        # Metrics storage
        self.metrics_buffer = deque(maxlen=10000)
        self.metric_definitions: Dict[str, MetricDefinition] = {}
        
        # Real-time streaming
        self.streaming_enabled = False
        self.stream_subscribers: List[Callable] = []
        
        # Alert integration
        self.alert_callbacks: List[Callable] = []
        self.alert_thresholds = {}
        
        self._initialize_collector()
    
    def _initialize_collector(self):
        """Initialize the metrics collector."""
        try:
            # Create database schema
            self._create_metrics_tables()
            
            # Load custom metric definitions
            self._load_custom_metrics()
            
            self.logger.info("Metrics collector initialized successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize metrics collector: {e}")
            raise
    
    def _create_metrics_tables(self):
        """Create database schema for metrics storage."""
        try:
            with db_manager.get_cursor() as cursor:
                # Raw metrics table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS metrics (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name TEXT NOT NULL,
                        value REAL NOT NULL,
                        timestamp TIMESTAMP NOT NULL,
                        unit TEXT,
                        source TEXT,
                        tags TEXT,
                        metadata TEXT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)
                
                # Time-series aggregated data table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS time_series_metrics (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        metric_name TEXT NOT NULL,
                        timestamp TIMESTAMP NOT NULL,
                        value REAL NOT NULL,
                        aggregation_type TEXT NOT NULL,
                        interval_seconds INTEGER NOT NULL,
                        sample_count INTEGER DEFAULT 1,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)
                
                # Create indexes
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_metrics_name_timestamp ON metrics(name, timestamp)")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_time_series_name_timestamp ON time_series_metrics(metric_name, timestamp)")
                
        except Exception as e:
            self.logger.error(f"Failed to create metrics tables: {e}")
            raise
    
    def _load_custom_metrics(self):
        """Load custom metric definitions from configuration."""
        try:
            # Load from configuration
            for metric_name, metric_config in self.config.metrics.custom_metrics.items():
                definition = MetricDefinition(
                    name=metric_name,
                    metric_type=MetricType(metric_config.get('type', 'custom')),
                    unit=MetricUnit(metric_config.get('unit', 'count')),
                    description=metric_config.get('description', ''),
                    tags=metric_config.get('tags', {}),
                    aggregations=[AggregationType(agg) for agg in metric_config.get('aggregations', ['average'])],
                    retention_days=metric_config.get('retention_days', 90),
                    collection_interval=metric_config.get('collection_interval', 60),
                    alert_thresholds=metric_config.get('alert_thresholds', {})
                )
                self.metric_definitions[metric_name] = definition
            
            self.logger.info(f"Loaded {len(self.metric_definitions)} custom metric definitions")
            
        except Exception as e:
            self.logger.error(f"Failed to load custom metrics: {e}")
    
    def start_collection(self):
        """Start metrics collection."""
        if not self.running:
            self.running = True
            self.collection_thread = threading.Thread(
                target=self._collection_loop, daemon=True, name="metrics_collector"
            )
            self.collection_thread.start()
            self.logger.info("Metrics collection started")
    
    def stop_collection(self):
        """Stop metrics collection."""
        self.running = False
        if self.collection_thread:
            self.collection_thread.join(timeout=5)
        self.logger.info("Metrics collection stopped")
    
    def collect_metric(self, metric: Metric) -> bool:
        """Collect a single metric."""
        try:
            # Validate metric
            if not metric.name or metric.value is None:
                raise ValueError("Invalid metric: name and value are required")
            
            # Add to buffer
            self.metrics_buffer.append(metric)
            
            # Store in database
            self._store_metric(metric)
            
            # Real-time streaming
            if self.streaming_enabled:
                self._stream_metric(metric)
            
            # Check alerts
            self._check_metric_alerts(metric)
            
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to collect metric {metric.name}: {e}")
            return False
    
    def _collection_loop(self):
        """Main collection loop."""
        while self.running:
            try:
                # Collect system health metrics
                self._collect_health_metrics()
                
                # Sleep for collection interval
                time.sleep(self.config.metrics.collection_interval)
                
            except Exception as e:
                self.logger.error(f"Error in collection loop: {e}")
                time.sleep(5)
    
    def _collect_health_metrics(self):
        """Collect system health metrics."""
        try:
            current_time = datetime.now().isoformat()
            
            # Import monitoring components
            from .system_monitor import system_monitor
            
            # Collect system metrics
            system_metrics = system_monitor.get_current_metrics()
            if system_metrics:
                # CPU metrics
                self.collect_metric(Metric(
                    name="system.cpu.usage",
                    value=system_metrics.cpu_usage,
                    timestamp=current_time,
                    unit=MetricUnit.PERCENTAGE,
                    source="system_monitor",
                    tags={"component": "system", "metric_type": "cpu"}
                ))
                
                # Memory metrics
                self.collect_metric(Metric(
                    name="system.memory.usage",
                    value=system_metrics.memory_usage,
                    timestamp=current_time,
                    unit=MetricUnit.PERCENTAGE,
                    source="system_monitor",
                    tags={"component": "system", "metric_type": "memory"}
                ))
            
        except Exception as e:
            self.logger.error(f"Failed to collect health metrics: {e}")
    
    def _store_metric(self, metric: Metric):
        """Store metric in database."""
        try:
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    INSERT INTO metrics (name, value, timestamp, unit, source, tags, metadata)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (
                    metric.name, metric.value, metric.timestamp,
                    metric.unit.value, metric.source,
                    json.dumps(metric.tags), json.dumps(metric.metadata)
                ))
        except Exception as e:
            self.logger.error(f"Failed to store metric: {e}")
    
    def _stream_metric(self, metric: Metric):
        """Stream metric to real-time subscribers."""
        try:
            if not self.stream_subscribers:
                return
            
            stream_data = {
                'type': 'metric',
                'data': asdict(metric),
                'timestamp': datetime.now().isoformat()
            }
            
            for subscriber in self.stream_subscribers:
                try:
                    subscriber(stream_data)
                except Exception as e:
                    self.logger.warning(f"Stream subscriber failed: {e}")
                    
        except Exception as e:
            self.logger.error(f"Failed to stream metric: {e}")
    
    def _check_metric_alerts(self, metric: Metric):
        """Check metric against alert thresholds."""
        try:
            if metric.name not in self.alert_thresholds:
                return
            
            thresholds = self.alert_thresholds[metric.name]
            
            for threshold_name, threshold_value in thresholds.items():
                if threshold_name.endswith('_warning') and metric.value >= threshold_value:
                    self._trigger_metric_alert(metric, threshold_name, threshold_value, AlertLevel.WARNING)
                elif threshold_name.endswith('_critical') and metric.value >= threshold_value:
                    self._trigger_metric_alert(metric, threshold_name, threshold_value, AlertLevel.CRITICAL)
                    
        except Exception as e:
            self.logger.error(f"Failed to check metric alerts for {metric.name}: {e}")
    
    def _trigger_metric_alert(self, metric: Metric, threshold_name: str, 
                            threshold_value: float, severity: AlertLevel):
        """Trigger a metric-based alert."""
        try:
            alert = {
                'timestamp': datetime.now().isoformat(),
                'alert_type': 'metric_threshold',
                'severity': severity.value,
                'metric_name': metric.name,
                'metric_value': metric.value,
                'threshold_name': threshold_name,
                'threshold_value': threshold_value,
                'message': f"Metric {metric.name} value {metric.value} exceeded {threshold_name} threshold {threshold_value}",
                'tags': metric.tags,
                'source': metric.source
            }
            
            # Notify alert callbacks
            for callback in self.alert_callbacks:
                try:
                    callback(alert)
                except Exception as e:
                    self.logger.error(f"Alert callback failed: {e}")
            
            self.logger.warning(f"Metric alert triggered: {alert['message']}")
            
        except Exception as e:
            self.logger.error(f"Failed to trigger metric alert: {e}")
    
    def enable_streaming(self):
        """Enable real-time metrics streaming."""
        self.streaming_enabled = True
        self.logger.info("Real-time metrics streaming enabled")
    
    def add_stream_subscriber(self, subscriber: Callable[[Dict[str, Any]], None]):
        """Add a subscriber for real-time metrics streaming."""
        self.stream_subscribers.append(subscriber)
        self.logger.info("Added metrics stream subscriber")
    
    def add_alert_callback(self, callback: Callable[[Dict[str, Any]], None]):
        """Add callback for metric-based alerts."""
        self.alert_callbacks.append(callback)
        self.logger.info("Added metrics alert callback")
    
    def get_metrics_summary(self) -> Dict[str, Any]:
        """Get comprehensive metrics summary."""
        try:
            summary = {
                'timestamp': datetime.now().isoformat(),
                'collection_status': 'running' if self.running else 'stopped',
                'streaming_enabled': self.streaming_enabled,
                'registered_metrics': len(self.metric_definitions),
                'stream_subscribers': len(self.stream_subscribers),
                'alert_callbacks': len(self.alert_callbacks),
                'buffer_size': len(self.metrics_buffer),
                'statistics': {}
            }
            
            # Get database statistics
            with db_manager.get_cursor() as cursor:
                cursor.execute("SELECT COUNT(*) as total_metrics FROM metrics")
                result = cursor.fetchone()
                summary['statistics']['total_metrics'] = result['total_metrics'] if result else 0
            
            return summary
            
        except Exception as e:
            self.logger.error(f"Failed to get metrics summary: {e}")
            return {
                'timestamp': datetime.now().isoformat(),
                'status': 'error',
                'error': str(e)
            }
    
    def cleanup_old_metrics(self, days_to_keep: int = None):
        """Clean up old metrics data."""
        try:
            if days_to_keep is None:
                days_to_keep = self.config.metrics.retention_days
            
            cutoff_date = datetime.now() - timedelta(days=days_to_keep)
            
            with db_manager.get_cursor() as cursor:
                cursor.execute("DELETE FROM metrics WHERE timestamp < ?", (cutoff_date.isoformat(),))
                deleted_metrics = cursor.rowcount
                
                cursor.execute("DELETE FROM time_series_metrics WHERE timestamp < ?", (cutoff_date.isoformat(),))
                deleted_time_series = cursor.rowcount
            
            self.logger.info(f"Cleaned up old metrics data: {deleted_metrics} metrics, {deleted_time_series} time-series points")
            
        except Exception as e:
            self.logger.error(f"Failed to cleanup old metrics: {e}")

# Global metrics collector instance
metrics_collector = MetricsCollector()