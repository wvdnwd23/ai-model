"""
Standalone Monitoring System Entry Point
========================================

This module provides a standalone monitoring system that can run independently
without loading the AI trading system. It implements the monitoring-only mode
specified in the technical specification.

Features:
- Independent system monitoring
- Basic metrics collection
- Simple alerting
- Flask dashboard backend
- No AI system dependencies

Usage:
    python -m src.monitoring.standalone_monitor

Environment Variables:
    MONITORING_ONLY_MODE=true
    MONITORING_DASHBOARD_HOST=0.0.0.0
    MONITORING_DASHBOARD_PORT=5050
    MONITORING_LOG_LEVEL=INFO
    MONITORING_COLLECTION_INTERVAL=60
"""

import os
import sys
import time
import signal
import threading
import psutil
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional

# Add project root to path for imports
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))

# Import monitoring interfaces and implementations
from src.monitoring.interfaces import ISystemMonitor, AlertLevel
from src.monitoring.dependency_injection import (
    get_container, initialize_monitoring_container,
    SimpleMetricsCollector, SimpleAlertManager
)


class StandaloneSystemMonitor(ISystemMonitor):
    """Standalone system monitor implementation."""
    
    def __init__(self, container):
        self.container = container
        self.logger = container.get_logger("system_monitor")
        self.db_manager = container.get_database_manager()
        self.config = container.get_config_manager().get_monitoring_config()
        
        self.running = False
        self.monitor_thread: Optional[threading.Thread] = None
        self.current_metrics = {}
        
        # System thresholds
        self.thresholds = {
            'cpu_warning': float(os.getenv('MONITORING_CPU_WARNING', '80.0')),
            'cpu_critical': float(os.getenv('MONITORING_CPU_CRITICAL', '95.0')),
            'memory_warning': float(os.getenv('MONITORING_MEMORY_WARNING', '85.0')),
            'memory_critical': float(os.getenv('MONITORING_MEMORY_CRITICAL', '95.0')),
            'disk_warning': float(os.getenv('MONITORING_DISK_WARNING', '90.0')),
            'disk_critical': float(os.getenv('MONITORING_DISK_CRITICAL', '98.0'))
        }
    
    def get_current_metrics(self) -> Optional[Dict[str, Any]]:
        """Get current system metrics."""
        try:
            # CPU metrics
            cpu_usage = psutil.cpu_percent(interval=1)
            cpu_count = psutil.cpu_count()
            
            # Memory metrics
            memory = psutil.virtual_memory()
            memory_usage = memory.percent
            memory_available = memory.available / (1024**3)  # GB
            
            # Disk metrics
            disk = psutil.disk_usage('/')
            disk_usage = (disk.used / disk.total) * 100
            disk_free = disk.free / (1024**3)  # GB
            
            # Network metrics
            net_io = psutil.net_io_counters()
            
            # Process metrics
            process_count = len(psutil.pids())
            
            # System uptime
            boot_time = psutil.boot_time()
            uptime = time.time() - boot_time
            
            # Temperature (if available)
            cpu_temperature = 0.0
            try:
                if hasattr(psutil, 'sensors_temperatures'):
                    temps = psutil.sensors_temperatures()
                    if temps:
                        for name, entries in temps.items():
                            if entries:
                                cpu_temperature = entries[0].current
                                break
            except:
                pass
            
            metrics = {
                'timestamp': datetime.now().isoformat(),
                'cpu_usage': cpu_usage,
                'cpu_count': cpu_count,
                'cpu_temperature': cpu_temperature,
                'memory_usage': memory_usage,
                'memory_available': memory_available,
                'memory_total': memory.total / (1024**3),
                'disk_usage': disk_usage,
                'disk_free': disk_free,
                'disk_total': disk.total / (1024**3),
                'network_rx_bytes': net_io.bytes_recv,
                'network_tx_bytes': net_io.bytes_sent,
                'process_count': process_count,
                'uptime': uptime
            }
            
            self.current_metrics = metrics
            return metrics
            
        except Exception as e:
            self.logger.error(f"Failed to collect system metrics: {e}")
            return None
    
    def get_system_health_score(self) -> float:
        """Calculate system health score (0-100)."""
        try:
            metrics = self.get_current_metrics()
            if not metrics:
                return 0.0
            
            score = 100.0
            
            # CPU score (inverted - lower usage is better)
            cpu_score = max(0, 100 - metrics['cpu_usage'])
            score = min(score, cpu_score)
            
            # Memory score (inverted)
            memory_score = max(0, 100 - metrics['memory_usage'])
            score = min(score, memory_score)
            
            # Disk score (inverted)
            disk_score = max(0, 100 - metrics['disk_usage'])
            score = min(score, disk_score)
            
            return score
            
        except Exception as e:
            self.logger.error(f"Failed to calculate health score: {e}")
            return 0.0
    
    def start_monitoring(self) -> None:
        """Start system monitoring."""
        if not self.running:
            self.running = True
            self.monitor_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
            self.monitor_thread.start()
            self.logger.info("Standalone system monitoring started")
    
    def stop_monitoring(self) -> None:
        """Stop system monitoring."""
        self.running = False
        if self.monitor_thread:
            self.monitor_thread.join(timeout=5)
        self.logger.info("Standalone system monitoring stopped")
    
    def _monitoring_loop(self):
        """Main monitoring loop."""
        collection_interval = self.config.get('collection_interval', 60)
        
        while self.running:
            try:
                # Collect metrics
                metrics = self.get_current_metrics()
                if metrics:
                    # Store metrics
                    self._store_metrics(metrics)
                    
                    # Check thresholds and create alerts
                    self._check_thresholds(metrics)
                
                # Sleep for collection interval
                time.sleep(collection_interval)
                
            except Exception as e:
                self.logger.error(f"Error in monitoring loop: {e}")
                time.sleep(5)
    
    def _store_metrics(self, metrics: Dict[str, Any]):
        """Store metrics using metrics collector."""
        try:
            metrics_collector = self.container.get_metrics_collector()
            if metrics_collector:
                timestamp = metrics['timestamp']
                
                # Store individual metrics
                metrics_collector.collect_metric('system.cpu.usage', metrics['cpu_usage'], 
                                                {'component': 'system'}, timestamp)
                metrics_collector.collect_metric('system.memory.usage', metrics['memory_usage'], 
                                                {'component': 'system'}, timestamp)
                metrics_collector.collect_metric('system.disk.usage', metrics['disk_usage'], 
                                                {'component': 'system'}, timestamp)
                metrics_collector.collect_metric('system.process.count', metrics['process_count'], 
                                                {'component': 'system'}, timestamp)
                
                if metrics['cpu_temperature'] > 0:
                    metrics_collector.collect_metric('system.cpu.temperature', metrics['cpu_temperature'], 
                                                    {'component': 'system'}, timestamp)
        except Exception as e:
            self.logger.error(f"Failed to store metrics: {e}")
    
    def _check_thresholds(self, metrics: Dict[str, Any]):
        """Check metrics against thresholds and create alerts."""
        try:
            alert_manager = self.container.get_alert_manager()
            if not alert_manager:
                return
            
            # Check CPU usage
            cpu_usage = metrics['cpu_usage']
            if cpu_usage >= self.thresholds['cpu_critical']:
                alert_manager.create_alert(
                    'system_threshold', AlertLevel.CRITICAL,
                    'Critical CPU Usage', 
                    f'CPU usage is {cpu_usage:.1f}% (threshold: {self.thresholds["cpu_critical"]}%)',
                    'standalone_monitor'
                )
            elif cpu_usage >= self.thresholds['cpu_warning']:
                alert_manager.create_alert(
                    'system_threshold', AlertLevel.WARNING,
                    'High CPU Usage',
                    f'CPU usage is {cpu_usage:.1f}% (threshold: {self.thresholds["cpu_warning"]}%)',
                    'standalone_monitor'
                )
            
            # Check memory usage
            memory_usage = metrics['memory_usage']
            if memory_usage >= self.thresholds['memory_critical']:
                alert_manager.create_alert(
                    'system_threshold', AlertLevel.CRITICAL,
                    'Critical Memory Usage',
                    f'Memory usage is {memory_usage:.1f}% (threshold: {self.thresholds["memory_critical"]}%)',
                    'standalone_monitor'
                )
            elif memory_usage >= self.thresholds['memory_warning']:
                alert_manager.create_alert(
                    'system_threshold', AlertLevel.WARNING,
                    'High Memory Usage',
                    f'Memory usage is {memory_usage:.1f}% (threshold: {self.thresholds["memory_warning"]}%)',
                    'standalone_monitor'
                )
            
            # Check disk usage
            disk_usage = metrics['disk_usage']
            if disk_usage >= self.thresholds['disk_critical']:
                alert_manager.create_alert(
                    'system_threshold', AlertLevel.CRITICAL,
                    'Critical Disk Usage',
                    f'Disk usage is {disk_usage:.1f}% (threshold: {self.thresholds["disk_critical"]}%)',
                    'standalone_monitor'
                )
            elif disk_usage >= self.thresholds['disk_warning']:
                alert_manager.create_alert(
                    'system_threshold', AlertLevel.WARNING,
                    'High Disk Usage',
                    f'Disk usage is {disk_usage:.1f}% (threshold: {self.thresholds["disk_warning"]}%)',
                    'standalone_monitor'
                )
                
        except Exception as e:
            self.logger.error(f"Failed to check thresholds: {e}")


class StandaloneMonitoringSystem:
    """Main standalone monitoring system orchestrator."""
    
    def __init__(self):
        # Set monitoring-only mode
        os.environ['MONITORING_ONLY_MODE'] = 'true'
        
        # Initialize dependency container
        self.container = initialize_monitoring_container()
        self.logger = self.container.get_logger("standalone_monitoring")
        self.config = self.container.get_config_manager()
        
        # Initialize components
        self.system_monitor = None
        self.metrics_collector = None
        self.alert_manager = None
        self.dashboard = None
        
        # System state
        self.running = False
        self.start_time = None
        
        # Setup signal handlers
        self._setup_signal_handlers()
        
        self.logger.info("Standalone monitoring system initialized")
    
    def _setup_signal_handlers(self):
        """Setup signal handlers for graceful shutdown."""
        def signal_handler(signum, frame):
            self.logger.info(f"Received signal {signum}, shutting down...")
            self.stop()
            sys.exit(0)
        
        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)
    
    def start(self):
        """Start the standalone monitoring system."""
        try:
            if self.running:
                self.logger.warning("Monitoring system is already running")
                return
            
            self.logger.info("Starting standalone monitoring system...")
            self.start_time = datetime.now()
            
            # Initialize and register components
            self._initialize_components()
            
            # Start components
            self._start_components()
            
            # Start dashboard if enabled
            self._start_dashboard()
            
            self.running = True
            self.logger.info("Standalone monitoring system started successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to start monitoring system: {e}")
            raise
    
    def _initialize_components(self):
        """Initialize monitoring components."""
        # Create and register metrics collector
        self.metrics_collector = SimpleMetricsCollector(self.container)
        self.container.register_metrics_collector(self.metrics_collector)
        
        # Create and register alert manager
        self.alert_manager = SimpleAlertManager(self.container)
        self.container.register_alert_manager(self.alert_manager)
        
        # Create and register system monitor
        self.system_monitor = StandaloneSystemMonitor(self.container)
        self.container.register_system_monitor(self.system_monitor)
        
        self.logger.info("Monitoring components initialized")
    
    def _start_components(self):
        """Start monitoring components."""
        # Start system monitoring
        if self.system_monitor:
            self.system_monitor.start_monitoring()
        
        self.logger.info("Monitoring components started")
    
    def _start_dashboard(self):
        """Start Flask dashboard backend."""
        try:
            dashboard_config = self.config.get_dashboard_config()
            
            if dashboard_config.get('enabled', True):
                # Import and start dashboard in a separate thread
                from src.monitoring.dashboard_backend import create_standalone_dashboard
                
                self.dashboard = create_standalone_dashboard(self.container)
                
                dashboard_thread = threading.Thread(
                    target=self._run_dashboard,
                    args=(dashboard_config,),
                    daemon=True
                )
                dashboard_thread.start()
                
                self.logger.info(f"Dashboard started on http://{dashboard_config['host']}:{dashboard_config['port']}")
            
        except Exception as e:
            self.logger.warning(f"Failed to start dashboard: {e}")
    
    def _run_dashboard(self, config):
        """Run Flask dashboard."""
        try:
            if self.dashboard:
                self.dashboard.run(
                    host=config['host'],
                    port=config['port'],
                    debug=config.get('debug', False),
                    use_reloader=False
                )
        except Exception as e:
            self.logger.error(f"Dashboard error: {e}")
    
    def stop(self):
        """Stop the monitoring system."""
        try:
            if not self.running:
                return
            
            self.logger.info("Stopping standalone monitoring system...")
            
            # Stop components
            if self.system_monitor:
                self.system_monitor.stop_monitoring()
            
            self.running = False
            self.logger.info("Standalone monitoring system stopped")
            
        except Exception as e:
            self.logger.error(f"Error stopping monitoring system: {e}")
    
    def get_status(self) -> Dict[str, Any]:
        """Get monitoring system status."""
        try:
            uptime = 0
            if self.start_time:
                uptime = (datetime.now() - self.start_time).total_seconds()
            
            status = {
                'running': self.running,
                'start_time': self.start_time.isoformat() if self.start_time else None,
                'uptime_seconds': uptime,
                'monitoring_only_mode': True,
                'components': {
                    'system_monitor': self.system_monitor is not None,
                    'metrics_collector': self.metrics_collector is not None,
                    'alert_manager': self.alert_manager is not None,
                    'dashboard': self.dashboard is not None
                }
            }
            
            # Add component health if available
            if self.system_monitor:
                current_metrics = self.system_monitor.get_current_metrics()
                if current_metrics:
                    status['current_metrics'] = current_metrics
                    status['health_score'] = self.system_monitor.get_system_health_score()
            
            return status
            
        except Exception as e:
            self.logger.error(f"Failed to get status: {e}")
            return {'running': False, 'error': str(e)}
    
    def run_forever(self):
        """Run monitoring system until interrupted."""
        try:
            self.start()
            
            self.logger.info("Monitoring system running. Press Ctrl+C to stop.")
            
            # Keep main thread alive
            while self.running:
                time.sleep(1)
                
        except KeyboardInterrupt:
            self.logger.info("Received keyboard interrupt")
        except Exception as e:
            self.logger.error(f"Unexpected error: {e}")
        finally:
            self.stop()


def main():
    """Main entry point for standalone monitoring."""
    print("AI Crypto Trading System - Standalone Monitoring")
    print("=" * 50)
    
    # Check if monitoring-only mode is enabled
    monitoring_only = os.getenv('MONITORING_ONLY_MODE', 'false').lower() == 'true'
    if not monitoring_only:
        print("Setting MONITORING_ONLY_MODE=true")
        os.environ['MONITORING_ONLY_MODE'] = 'true'
    
    # Create and run monitoring system
    monitoring_system = StandaloneMonitoringSystem()
    
    try:
        monitoring_system.run_forever()
    except Exception as e:
        print(f"Fatal error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()