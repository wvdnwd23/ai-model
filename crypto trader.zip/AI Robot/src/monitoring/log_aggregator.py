"""
Log Aggregator for the AI Crypto Trading System.
Handles centralized log collection, analysis, correlation, and real-time streaming.
"""

import json
import time
import threading
import logging
import hashlib
import re
import gzip
import asyncio
import websockets
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Set, Tuple, Callable, Union
from dataclasses import dataclass, field, asdict
from collections import defaultdict, deque
from enum import Enum
from pathlib import Path
import sqlite3
import statistics
from concurrent.futures import ThreadPoolExecutor
import queue

from .config import monitoring_config
from .alert_manager import alert_manager, AlertLevel
from ..utils.logging import get_logger, LogCategory, StructuredLogger
from ..utils.database import db_manager

class LogLevel(Enum):
    """Log level enumeration."""
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"

class PatternType(Enum):
    """Pattern detection types."""
    FREQUENCY = "frequency"
    SEQUENCE = "sequence"
    ANOMALY = "anomaly"
    ERROR_BURST = "error_burst"
    PERFORMANCE_DEGRADATION = "performance_degradation"
    CORRELATION = "correlation"

class CorrelationType(Enum):
    """Log correlation types."""
    TEMPORAL = "temporal"
    TRANSACTION = "transaction"
    MODULE = "module"
    ERROR_CASCADE = "error_cascade"
    PERFORMANCE = "performance"

@dataclass
class LogEntry:
    """Standardized log entry structure."""
    id: str
    timestamp: str
    level: LogLevel
    logger: str
    message: str
    module: str
    function: str
    line: int
    category: Optional[str] = None
    data: Dict[str, Any] = field(default_factory=dict)
    tags: Dict[str, str] = field(default_factory=dict)
    correlation_id: Optional[str] = None
    transaction_id: Optional[str] = None
    session_id: Optional[str] = None
    user_id: Optional[str] = None
    fingerprint: Optional[str] = None
    processed: bool = False
    archived: bool = False

    def __post_init__(self):
        """Generate fingerprint for deduplication."""
        if not self.fingerprint:
            content = f"{self.logger}:{self.module}:{self.function}:{self.message[:100]}"
            self.fingerprint = hashlib.md5(content.encode()).hexdigest()

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = asdict(self)
        result['level'] = self.level.value
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'LogEntry':
        """Create from dictionary."""
        data['level'] = LogLevel(data['level'])
        return cls(**data)

    @classmethod
    def from_log_record(cls, record: logging.LogRecord) -> 'LogEntry':
        """Create from logging record."""
        entry_id = f"{record.name}_{int(time.time() * 1000000)}"
        
        # Extract structured data
        data = {}
        category = None
        correlation_id = None
        transaction_id = None
        
        if hasattr(record, 'structured_data'):
            data = record.structured_data or {}
        
        if hasattr(record, 'category'):
            category = record.category
            
        if hasattr(record, 'correlation_id'):
            correlation_id = record.correlation_id
            
        if hasattr(record, 'transaction_id'):
            transaction_id = record.transaction_id

        return cls(
            id=entry_id,
            timestamp=datetime.fromtimestamp(record.created).isoformat(),
            level=LogLevel(record.levelname),
            logger=record.name,
            message=record.getMessage(),
            module=record.module,
            function=record.funcName,
            line=record.lineno,
            category=category,
            data=data,
            correlation_id=correlation_id,
            transaction_id=transaction_id
        )

@dataclass
class LogPattern:
    """Pattern detection results."""
    id: str
    pattern_type: PatternType
    description: str
    severity: AlertLevel
    first_occurrence: str
    last_occurrence: str
    occurrence_count: int
    affected_modules: List[str]
    sample_entries: List[str]  # Log entry IDs
    confidence_score: float
    metadata: Dict[str, Any] = field(default_factory=dict)
    resolved: bool = False
    resolved_at: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = asdict(self)
        result['pattern_type'] = self.pattern_type.value
        result['severity'] = self.severity.value
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'LogPattern':
        """Create from dictionary."""
        data['pattern_type'] = PatternType(data['pattern_type'])
        data['severity'] = AlertLevel(data['severity'])
        return cls(**data)

@dataclass
class LogCorrelation:
    """Log correlation result."""
    id: str
    correlation_type: CorrelationType
    primary_entry_id: str
    related_entry_ids: List[str]
    confidence_score: float
    time_window_seconds: float
    description: str
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = asdict(self)
        result['correlation_type'] = self.correlation_type.value
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'LogCorrelation':
        """Create from dictionary."""
        data['correlation_type'] = CorrelationType(data['correlation_type'])
        return cls(**data)

class LogAggregator:
    """Main log aggregation class with centralized collection and processing."""
    
    def __init__(self):
        self.logger = get_logger(__name__)
        self.config = monitoring_config
        self.running = False
        
        # Processing
        self.log_queue = queue.Queue(maxsize=10000)
        self.processed_entries: Dict[str, LogEntry] = {}
        self.active_patterns: Dict[str, LogPattern] = {}
        
        # Threading
        self.worker_threads = []
        self.thread_pool = ThreadPoolExecutor(max_workers=4)
        self._lock = threading.RLock()
        
        # Metrics
        self.metrics = {
            'entries_processed': 0,
            'patterns_detected': 0,
            'correlations_found': 0,
            'alerts_generated': 0
        }
        
        self._initialize_aggregator()
    
    def _initialize_aggregator(self):
        """Initialize the log aggregator."""
        try:
            # Create database tables
            self._create_log_tables()
            
            # Set up log handler
            self._setup_log_handler()
            
            # Load existing patterns
            self._load_active_patterns()
            
            self.logger.info("Log aggregator initialized successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize log aggregator: {e}")
            raise
    
    def _create_log_tables(self):
        """Create database tables for log aggregation."""
        try:
            with db_manager.get_cursor() as cursor:
                # Aggregated logs table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS aggregated_logs (
                        id TEXT PRIMARY KEY,
                        timestamp TIMESTAMP,
                        level TEXT,
                        logger TEXT,
                        message TEXT,
                        module TEXT,
                        function TEXT,
                        line INTEGER,
                        category TEXT,
                        data TEXT,
                        tags TEXT,
                        correlation_id TEXT,
                        transaction_id TEXT,
                        session_id TEXT,
                        user_id TEXT,
                        fingerprint TEXT,
                        processed BOOLEAN DEFAULT FALSE,
                        archived BOOLEAN DEFAULT FALSE,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)
                
                # Log patterns table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS log_patterns (
                        id TEXT PRIMARY KEY,
                        pattern_type TEXT,
                        description TEXT,
                        severity TEXT,
                        first_occurrence TIMESTAMP,
                        last_occurrence TIMESTAMP,
                        occurrence_count INTEGER,
                        affected_modules TEXT,
                        sample_entries TEXT,
                        confidence_score REAL,
                        metadata TEXT,
                        resolved BOOLEAN DEFAULT FALSE,
                        resolved_at TIMESTAMP,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    )
                """)
                
                # Create indexes
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_aggregated_logs_timestamp ON aggregated_logs(timestamp)")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_aggregated_logs_level ON aggregated_logs(level)")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_aggregated_logs_module ON aggregated_logs(module)")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_log_patterns_type ON log_patterns(pattern_type)")
                
        except Exception as e:
            self.logger.error(f"Failed to create log tables: {e}")
            raise
    
    def _setup_log_handler(self):
        """Set up custom log handler to capture all logs."""
        handler = LogAggregatorHandler(self)
        handler.setLevel(logging.DEBUG)
        
        # Add to root logger to capture all logs
        root_logger = logging.getLogger()
        root_logger.addHandler(handler)
        
        self.logger.info("Log aggregator handler installed")
    
    def _load_active_patterns(self):
        """Load active patterns from database."""
        try:
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    SELECT * FROM log_patterns 
                    WHERE resolved = FALSE 
                    AND last_occurrence >= datetime('now', '-24 hours')
                """)
                
                rows = cursor.fetchall()
                for row in rows:
                    pattern_data = dict(row)
                    pattern_data['affected_modules'] = json.loads(pattern_data['affected_modules']) if pattern_data['affected_modules'] else []
                    pattern_data['sample_entries'] = json.loads(pattern_data['sample_entries']) if pattern_data['sample_entries'] else []
                    pattern_data['metadata'] = json.loads(pattern_data['metadata']) if pattern_data['metadata'] else {}
                    
                    pattern = LogPattern.from_dict(pattern_data)
                    self.active_patterns[pattern.id] = pattern
                
                self.logger.info(f"Loaded {len(self.active_patterns)} active patterns")
                
        except Exception as e:
            self.logger.warning(f"Failed to load active patterns: {e}")
    
    def start(self):
        """Start the log aggregator."""
        if not self.running:
            self.running = True
            
            # Start worker threads
            self.worker_threads = [
                threading.Thread(target=self._log_processor_worker, daemon=True),
                threading.Thread(target=self._cleanup_worker, daemon=True)
            ]
            
            for thread in self.worker_threads:
                thread.start()
            
            self.logger.info("Log aggregator started")
    
    def stop(self):
        """Stop the log aggregator."""
        self.running = False
        
        # Wait for worker threads
        for thread in self.worker_threads:
            thread.join(timeout=5)
        
        # Shutdown thread pool
        self.thread_pool.shutdown(wait=True)
        
        self.logger.info("Log aggregator stopped")
    
    def add_log_entry(self, entry: LogEntry):
        """Add a log entry for processing."""
        try:
            if not self.log_queue.full():
                self.log_queue.put(entry, timeout=1)
            else:
                self.logger.warning("Log queue is full, dropping entry")
        except queue.Full:
            self.logger.warning("Failed to add log entry: queue full")
    
    def _log_processor_worker(self):
        """Worker thread for processing log entries."""
        while self.running:
            try:
                entry = self.log_queue.get(timeout=1)
                self._process_log_entry(entry)
                self.log_queue.task_done()
            except queue.Empty:
                continue
            except Exception as e:
                self.logger.error(f"Error in log processor worker: {e}")
    
    def _process_log_entry(self, entry: LogEntry):
        """Process a single log entry."""
        try:
            # Store in database
            self._store_log_entry(entry)
            
            # Add to processed entries
            with self._lock:
                self.processed_entries[entry.id] = entry
                self.metrics['entries_processed'] += 1
            
            # Mark as processed
            entry.processed = True
            
        except Exception as e:
            self.logger.error(f"Failed to process log entry {entry.id}: {e}")
    
    def _store_log_entry(self, entry: LogEntry):
        """Store log entry in database."""
        try:
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    INSERT OR REPLACE INTO aggregated_logs (
                        id, timestamp, level, logger, message, module, function, line,
                        category, data, tags, correlation_id, transaction_id, session_id,
                        user_id, fingerprint, processed, archived
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    entry.id, entry.timestamp, entry.level.value, entry.logger,
                    entry.message, entry.module, entry.function, entry.line,
                    entry.category, json.dumps(entry.data), json.dumps(entry.tags),
                    entry.correlation_id, entry.transaction_id, entry.session_id,
                    entry.user_id, entry.fingerprint, entry.processed, entry.archived
                ))
        except Exception as e:
            self.logger.error(f"Failed to store log entry {entry.id}: {e}")
    
    def _cleanup_worker(self):
        """Worker thread for cleanup tasks."""
        while self.running:
            try:
                time.sleep(3600)  # Run every hour
                self._perform_cleanup()
            except Exception as e:
                self.logger.error(f"Error in cleanup worker: {e}")
    
    def _perform_cleanup(self):
        """Perform cleanup tasks."""
        try:
            # Archive old logs
            self._archive_old_logs()
            
            # Clean up processed entries cache
            self._cleanup_processed_entries()
            
        except Exception as e:
            self.logger.error(f"Failed to perform cleanup: {e}")
    
    def _archive_old_logs(self):
        """Archive old log entries."""
        try:
            retention_days = self.config.logging_config.backup_count * 7  # Approximate retention
            cutoff_date = datetime.now() - timedelta(days=retention_days)
            
            with db_manager.get_cursor() as cursor:
                # Get logs to archive
                cursor.execute("""
                    SELECT COUNT(*) as count FROM aggregated_logs 
                    WHERE timestamp < ? AND archived = FALSE
                """, (cutoff_date.isoformat(),))
                
                count = cursor.fetchone()['count']
                
                if count > 0:
                    # Mark as archived
                    cursor.execute("""
                        UPDATE aggregated_logs 
                        SET archived = TRUE 
                        WHERE timestamp < ? AND archived = FALSE
                    """, (cutoff_date.isoformat(),))
                    
                    self.logger.info(f"Archived {count} old log entries")
            
        except Exception as e:
            self.logger.error(f"Failed to archive old logs: {e}")
    
    def _cleanup_processed_entries(self):
        """Clean up processed entries cache."""
        try:
            cutoff_time = datetime.now() - timedelta(hours=24)
            
            with self._lock:
                entries_to_remove = []
                for entry_id, entry in self.processed_entries.items():
                    entry_time = datetime.fromisoformat(entry.timestamp)
                    if entry_time < cutoff_time:
                        entries_to_remove.append(entry_id)
                
                for entry_id in entries_to_remove:
                    del self.processed_entries[entry_id]
                
                if entries_to_remove:
                    self.logger.debug(f"Cleaned up {len(entries_to_remove)} processed entries from cache")
            
        except Exception as e:
            self.logger.error(f"Failed to cleanup processed entries: {e}")
    
    def search_logs(self, query: Dict[str, Any], limit: int = 100) -> List[LogEntry]:
        """Search logs with advanced filtering."""
        try:
            conditions = ["1=1"]
            params = []
            
            # Time range filter
            if 'start_time' in query:
                conditions.append("timestamp >= ?")
                params.append(query['start_time'])
            
            if 'end_time' in query:
                conditions.append("timestamp <= ?")
                params.append(query['end_time'])
            
            # Level filter
            if 'levels' in query:
                level_placeholders = ','.join('?' * len(query['levels']))
                conditions.append(f"level IN ({level_placeholders})")
                params.extend(query['levels'])
            
            # Module filter
            if 'modules' in query:
                module_placeholders = ','.join('?' * len(query['modules']))
                conditions.append(f"module IN ({module_placeholders})")
                params.extend(query['modules'])
            
            # Text search
            if 'search_text' in query:
                conditions.append("message LIKE ?")
                params.append(f"%{query['search_text']}%")
            
            sql = f"""
                SELECT * FROM aggregated_logs 
                WHERE {' AND '.join(conditions)}
                ORDER BY timestamp DESC 
                LIMIT ?
            """
            params.append(limit)
            
            with db_manager.get_cursor() as cursor:
                cursor.execute(sql, params)
                rows = cursor.fetchall()
                
                entries = []
                for row in rows:
                    entry_data = dict(row)
                    entry_data['data'] = json.loads(entry_data['data']) if entry_data['data'] else {}
                    entry_data['tags'] = json.loads(entry_data['tags']) if entry_data['tags'] else {}
                    
                    entry = LogEntry.from_dict(entry_data)
                    entries.append(entry)
                
                return entries
            
        except Exception as e:
            self.logger.error(f"Failed to search logs: {e}")
            return []
    
    def get_log_statistics(self, hours: int = 24) -> Dict[str, Any]:
        """Get log statistics for specified time period."""
        try:
            cutoff_time = datetime.now() - timedelta(hours=hours)
            
            with db_manager.get_cursor() as cursor:
                # Total logs by level
                cursor.execute("""
                    SELECT level, COUNT(*) as count 
                    FROM aggregated_logs 
                    WHERE timestamp >= ? 
                    GROUP BY level
                """, (cutoff_time.isoformat(),))
                
                level_counts = {row['level']: row['count'] for row in cursor.fetchall()}
                
                # Total logs by module
                cursor.execute("""
                    SELECT module, COUNT(*) as count 
                    FROM aggregated_logs 
                    WHERE timestamp >= ? 
                    GROUP BY module 
                    ORDER BY count DESC 
                    LIMIT 10
                """, (cutoff_time.isoformat(),))
                
                module_counts = {row['module']: row['count'] for row in cursor.fetchall()}
                
                return {
                    'time_period_hours': hours,
                    'total_logs': sum(level_counts.values()),
                    'level_distribution': level_counts,
                    'top_modules': module_counts,
                    'metrics': self.metrics.copy()
                }
            
        except Exception as e:
            self.logger.error(f"Failed to get log statistics: {e}")
            return {}
    
    def get_health_status(self) -> Dict[str, Any]:
        """Get health status of the log aggregator."""
        try:
            return {
                'running': self.running,
                'queue_size': self.log_queue.qsize(),
                'processed_entries_count': len(self.processed_entries),
                'active_patterns_count': len(self.active_patterns),
                'metrics': self.metrics.copy(),
                'worker_threads_alive': sum(1 for t in self.worker_threads if t.is_alive())
            }
            
        except Exception as e:
            self.logger.error(f"Failed to get health status: {e}")
            return {'error': str(e)}

class LogAggregatorHandler(logging.Handler):
    """Custom logging handler that feeds logs to the aggregator."""
    
    def __init__(self, aggregator: LogAggregator):
        super().__init__()
        self.aggregator = aggregator
    
    def emit(self, record: logging.LogRecord):
        """Emit a log record to the aggregator."""
        try:
            # Skip our own logs to avoid recursion
            if record.name.startswith('src.monitoring.log_aggregator'):
                return
            
            # Convert to LogEntry
            entry = LogEntry.from_log_record(record)
            
            # Add to aggregator
            self.aggregator.add_log_entry(entry)
            
        except Exception:
            # Silently ignore errors to avoid logging loops
            pass

# Global log aggregator instance
log_aggregator = LogAggregator()