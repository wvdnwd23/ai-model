"""
Alert Manager for the AI Crypto Trading System.
Handles multi-channel alerting with rate limiting, escalation, acknowledgment, and resolution tracking.
"""

import time
import threading
import logging
import json
import hashlib
import smtplib
import requests
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List, Callable, Set, Tuple
from dataclasses import dataclass, asdict, field
from collections import defaultdict, deque
from enum import Enum
from email.mime.text import MimeText
from email.mime.multipart import MimeMultipart
import sqlite3

from .config import monitoring_config, AlertLevel
from ..utils.logging import get_logger
from ..utils.database import db_manager

class AlertStatus(Enum):
    """Alert status enumeration."""
    ACTIVE = "active"
    ACKNOWLEDGED = "acknowledged"
    RESOLVED = "resolved"
    ESCALATED = "escalated"
    SUPPRESSED = "suppressed"

class AlertChannel(Enum):
    """Alert delivery channels."""
    TELEGRAM = "telegram"
    EMAIL = "email"
    WEBHOOK = "webhook"
    SMS = "sms"

class AlertPriority(Enum):
    """Alert priority levels for processing."""
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4

@dataclass
class Alert:
    """Standard alert structure."""
    id: str
    timestamp: str
    alert_type: str
    severity: AlertLevel
    title: str
    message: str
    source: str
    metric_name: Optional[str] = None
    metric_value: Optional[float] = None
    threshold_value: Optional[float] = None
    tags: Dict[str, str] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    status: AlertStatus = AlertStatus.ACTIVE
    acknowledged_by: Optional[str] = None
    acknowledged_at: Optional[str] = None
    resolved_by: Optional[str] = None
    resolved_at: Optional[str] = None
    escalated_at: Optional[str] = None
    escalation_level: int = 0
    retry_count: int = 0
    channels_sent: List[str] = field(default_factory=list)
    fingerprint: Optional[str] = None

    def __post_init__(self):
        """Generate fingerprint for deduplication."""
        if not self.fingerprint:
            content = f"{self.alert_type}:{self.source}:{self.metric_name}:{self.severity.value}"
            self.fingerprint = hashlib.md5(content.encode()).hexdigest()

    def to_dict(self) -> Dict[str, Any]:
        """Convert alert to dictionary."""
        result = asdict(self)
        result['severity'] = self.severity.value
        result['status'] = self.status.value
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Alert':
        """Create alert from dictionary."""
        data['severity'] = AlertLevel(data['severity'])
        data['status'] = AlertStatus(data['status'])
        return cls(**data)

@dataclass
class AlertRule:
    """Custom alert rule definition."""
    id: str
    name: str
    description: str
    enabled: bool
    condition: str  # Python expression to evaluate
    severity: AlertLevel
    channels: List[str]
    rate_limit_window: int = 300  # seconds
    max_alerts_per_window: int = 5
    escalation_delay: int = 1800  # seconds
    auto_resolve: bool = False
    auto_resolve_timeout: int = 3600  # seconds
    tags: Dict[str, str] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        """Convert rule to dictionary."""
        result = asdict(self)
        result['severity'] = self.severity.value
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'AlertRule':
        """Create rule from dictionary."""
        data['severity'] = AlertLevel(data['severity'])
        return cls(**data)

class AlertAggregator:
    """Handles alert aggregation and deduplication."""
    
    def __init__(self, window_size: int = 300):
        self.window_size = window_size
        self.alert_groups = defaultdict(list)
        self.last_cleanup = time.time()
    
    def should_aggregate(self, alert: Alert) -> Tuple[bool, Optional[str]]:
        """Check if alert should be aggregated with existing alerts."""
        current_time = time.time()
        
        # Cleanup old alerts
        if current_time - self.last_cleanup > 60:  # Cleanup every minute
            self._cleanup_old_alerts(current_time)
            self.last_cleanup = current_time
        
        # Check for similar alerts in the window
        for group_key, alerts in self.alert_groups.items():
            if not alerts:
                continue
                
            # Check if this alert matches the group
            if self._alerts_match(alert, alerts[0]):
                # Check if within time window
                latest_alert_time = max(
                    datetime.fromisoformat(a.timestamp).timestamp() 
                    for a in alerts
                )
                
                if current_time - latest_alert_time < self.window_size:
                    alerts.append(alert)
                    return True, group_key
        
        # Create new group
        group_key = f"{alert.fingerprint}_{int(current_time)}"
        self.alert_groups[group_key] = [alert]
        return False, group_key
    
    def _alerts_match(self, alert1: Alert, alert2: Alert) -> bool:
        """Check if two alerts should be grouped together."""
        return (
            alert1.alert_type == alert2.alert_type and
            alert1.source == alert2.source and
            alert1.metric_name == alert2.metric_name and
            alert1.severity == alert2.severity
        )
    
    def _cleanup_old_alerts(self, current_time: float):
        """Remove old alert groups."""
        cutoff_time = current_time - self.window_size * 2
        
        groups_to_remove = []
        for group_key, alerts in self.alert_groups.items():
            if not alerts:
                groups_to_remove.append(group_key)
                continue
                
            latest_time = max(
                datetime.fromisoformat(a.timestamp).timestamp() 
                for a in alerts
            )
            
            if latest_time < cutoff_time:
                groups_to_remove.append(group_key)
        
        for group_key in groups_to_remove:
            del self.alert_groups[group_key]
    
    def get_aggregated_alert(self, group_key: str) -> Optional[Alert]:
        """Get aggregated alert for a group."""
        alerts = self.alert_groups.get(group_key, [])
        if not alerts:
            return None
        
        if len(alerts) == 1:
            return alerts[0]
        
        # Create aggregated alert
        base_alert = alerts[0]
        count = len(alerts)
        
        aggregated = Alert(
            id=f"agg_{base_alert.id}",
            timestamp=base_alert.timestamp,
            alert_type=base_alert.alert_type,
            severity=base_alert.severity,
            title=f"[{count}x] {base_alert.title}",
            message=f"Aggregated {count} similar alerts: {base_alert.message}",
            source=base_alert.source,
            metric_name=base_alert.metric_name,
            tags=base_alert.tags.copy(),
            metadata={
                **base_alert.metadata,
                "aggregated_count": count,
                "aggregated_alerts": [a.id for a in alerts]
            }
        )
        
        return aggregated

class RateLimiter:
    """Rate limiting for alerts."""
    
    def __init__(self):
        self.alert_counts = defaultdict(deque)
        self.last_cleanup = time.time()
    
    def is_rate_limited(self, alert: Alert, window: int, max_count: int) -> bool:
        """Check if alert is rate limited."""
        current_time = time.time()
        
        # Cleanup old entries
        if current_time - self.last_cleanup > 60:
            self._cleanup_old_entries(current_time)
            self.last_cleanup = current_time
        
        # Create rate limit key
        key = f"{alert.fingerprint}:{alert.severity.value}"
        
        # Get timestamps for this key
        timestamps = self.alert_counts[key]
        
        # Remove old timestamps
        cutoff_time = current_time - window
        while timestamps and timestamps[0] < cutoff_time:
            timestamps.popleft()
        
        # Check if rate limited
        if len(timestamps) >= max_count:
            return True
        
        # Add current timestamp
        timestamps.append(current_time)
        return False
    
    def _cleanup_old_entries(self, current_time: float):
        """Remove old rate limit entries."""
        cutoff_time = current_time - 3600  # Keep 1 hour of history
        
        keys_to_remove = []
        for key, timestamps in self.alert_counts.items():
            # Remove old timestamps
            while timestamps and timestamps[0] < cutoff_time:
                timestamps.popleft()
            
            # Remove empty entries
            if not timestamps:
                keys_to_remove.append(key)
        
        for key in keys_to_remove:
            del self.alert_counts[key]

class AlertChannel:
    """Base class for alert delivery channels."""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        self.name = name
        self.config = config
        self.logger = get_logger(f"{__name__}.{name}")
        self.enabled = config.get('enabled', True)
    
    def send_alert(self, alert: Alert) -> bool:
        """Send alert through this channel."""
        if not self.enabled:
            return False
        
        try:
            return self._send_alert_impl(alert)
        except Exception as e:
            self.logger.error(f"Failed to send alert via {self.name}: {e}")
            return False
    
    def _send_alert_impl(self, alert: Alert) -> bool:
        """Implementation-specific alert sending."""
        raise NotImplementedError
    
    def format_alert(self, alert: Alert) -> str:
        """Format alert message for this channel."""
        severity_emoji = {
            AlertLevel.INFO: "ℹ️",
            AlertLevel.WARNING: "⚠️",
            AlertLevel.CRITICAL: "🚨",
            AlertLevel.EMERGENCY: "🔥"
        }
        
        emoji = severity_emoji.get(alert.severity, "📢")
        
        message = f"{emoji} **{alert.severity.value.upper()}** Alert\n\n"
        message += f"**Title:** {alert.title}\n"
        message += f"**Source:** {alert.source}\n"
        message += f"**Time:** {alert.timestamp}\n\n"
        message += f"**Message:** {alert.message}\n"
        
        if alert.metric_name and alert.metric_value is not None:
            message += f"**Metric:** {alert.metric_name} = {alert.metric_value}"
            if alert.threshold_value is not None:
                message += f" (threshold: {alert.threshold_value})"
            message += "\n"
        
        if alert.tags:
            message += f"**Tags:** {', '.join(f'{k}={v}' for k, v in alert.tags.items())}\n"
        
        message += f"**Alert ID:** {alert.id}"
        
        return message

class TelegramChannel(AlertChannel):
    """Telegram alert delivery channel."""
    
    def _send_alert_impl(self, alert: Alert) -> bool:
        """Send alert via Telegram."""
        bot_token = self.config.get('bot_token')
        chat_id = self.config.get('chat_id')
        
        if not bot_token or not chat_id:
            self.logger.error("Telegram bot_token or chat_id not configured")
            return False
        
        message = self.format_alert(alert)
        
        url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
        data = {
            'chat_id': chat_id,
            'text': message,
            'parse_mode': 'Markdown'
        }
        
        response = requests.post(url, data=data, timeout=10)
        
        if response.status_code == 200:
            self.logger.debug(f"Sent Telegram alert: {alert.id}")
            return True
        else:
            self.logger.error(f"Telegram API error: {response.status_code} - {response.text}")
            return False

class EmailChannel(AlertChannel):
    """Email alert delivery channel."""
    
    def _send_alert_impl(self, alert: Alert) -> bool:
        """Send alert via email."""
        smtp_server = self.config.get('smtp_server')
        smtp_port = self.config.get('smtp_port', 587)
        username = self.config.get('username')
        password = self.config.get('password')
        from_email = self.config.get('from_email')
        to_emails = self.config.get('to_emails', [])
        
        if not all([smtp_server, username, password, from_email, to_emails]):
            self.logger.error("Email configuration incomplete")
            return False
        
        try:
            msg = MimeMultipart()
            msg['From'] = from_email
            msg['To'] = ', '.join(to_emails)
            msg['Subject'] = f"[{alert.severity.value.upper()}] {alert.title}"
            
            body = self.format_alert(alert)
            msg.attach(MimeText(body, 'plain'))
            
            server = smtplib.SMTP(smtp_server, smtp_port)
            server.starttls()
            server.login(username, password)
            
            text = msg.as_string()
            server.sendmail(from_email, to_emails, text)
            server.quit()
            
            self.logger.debug(f"Sent email alert: {alert.id}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to send email: {e}")
            return False

class WebhookChannel(AlertChannel):
    """Webhook alert delivery channel."""
    
    def _send_alert_impl(self, alert: Alert) -> bool:
        """Send alert via webhook."""
        url = self.config.get('url')
        method = self.config.get('method', 'POST').upper()
        headers = self.config.get('headers', {})
        
        if not url:
            self.logger.error("Webhook URL not configured")
            return False
        
        payload = {
            'alert': alert.to_dict(),
            'formatted_message': self.format_alert(alert)
        }
        
        try:
            if method == 'POST':
                response = requests.post(url, json=payload, headers=headers, timeout=10)
            elif method == 'PUT':
                response = requests.put(url, json=payload, headers=headers, timeout=10)
            else:
                self.logger.error(f"Unsupported webhook method: {method}")
                return False
            
            if response.status_code in [200, 201, 202]:
                self.logger.debug(f"Sent webhook alert: {alert.id}")
                return True
            else:
                self.logger.error(f"Webhook error: {response.status_code} - {response.text}")
                return False
                
        except Exception as e:
            self.logger.error(f"Failed to send webhook: {e}")
            return False

class SMSChannel(AlertChannel):
    """SMS alert delivery channel (placeholder for future implementation)."""
    
    def _send_alert_impl(self, alert: Alert) -> bool:
        """Send alert via SMS."""
        # Placeholder for SMS implementation
        # Could integrate with Twilio, AWS SNS, or other SMS providers
        self.logger.warning("SMS channel not implemented yet")
        return False

class AlertManager:
    """Main alert management class."""
    
    def __init__(self):
        self.logger = get_logger(__name__)
        self.config = monitoring_config
        self.running = False
        self.worker_thread: Optional[threading.Thread] = None
        
        # Alert processing
        self.alert_queue = deque()
        self.active_alerts: Dict[str, Alert] = {}
        self.alert_rules: Dict[str, AlertRule] = {}
        
        # Components
        self.aggregator = AlertAggregator()
        self.rate_limiter = RateLimiter()
        self.channels: Dict[str, AlertChannel] = {}
        
        # Callbacks
        self.alert_callbacks: List[Callable[[Alert], None]] = []
        
        # Thread safety
        self._lock = threading.RLock()
        
        self._initialize_alert_manager()
    
    def _initialize_alert_manager(self):
        """Initialize alert manager components."""
        try:
            # Create database tables
            self._create_alert_tables()
            
            # Initialize channels
            self._initialize_channels()
            
            # Load alert rules
            self._load_alert_rules()
            
            # Load active alerts
            self._load_active_alerts()
            
            self.logger.info("Alert manager initialized successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize alert manager: {e}")
            raise
    
    def _create_alert_tables(self):
        """Create database tables for alerts."""
        try:
            with db_manager.get_cursor() as cursor:
                # Alerts table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS alerts (
                        id TEXT PRIMARY KEY,
                        timestamp TIMESTAMP,
                        alert_type TEXT,
                        severity TEXT,
                        title TEXT,
                        message TEXT,
                        source TEXT,
                        metric_name TEXT,
                        metric_value REAL,
                        threshold_value REAL,
                        tags TEXT,
                        metadata TEXT,
                        status TEXT,
                        acknowledged_by TEXT,
                        acknowledged_at TIMESTAMP,
                        resolved_by TEXT,
                        resolved_at TIMESTAMP,
                        escalated_at TIMESTAMP,
                        escalation_level INTEGER,
                        retry_count INTEGER,
                        channels_sent TEXT,
                        fingerprint TEXT
                    )
                """)
                
                # Alert rules table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS alert_rules (
                        id TEXT PRIMARY KEY,
                        name TEXT,
                        description TEXT,
                        enabled BOOLEAN,
                        condition TEXT,
                        severity TEXT,
                        channels TEXT,
                        rate_limit_window INTEGER,
                        max_alerts_per_window INTEGER,
                        escalation_delay INTEGER,
                        auto_resolve BOOLEAN,
                        auto_resolve_timeout INTEGER,
                        tags TEXT,
                        metadata TEXT,
                        created_at TIMESTAMP,
                        updated_at TIMESTAMP
                    )
                """)
                
                # Alert acknowledgments table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS alert_acknowledgments (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        alert_id TEXT,
                        acknowledged_by TEXT,
                        acknowledged_at TIMESTAMP,
                        comment TEXT,
                        FOREIGN KEY (alert_id) REFERENCES alerts (id)
                    )
                """)
                
                # Alert escalations table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS alert_escalations (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        alert_id TEXT,
                        escalation_level INTEGER,
                        escalated_at TIMESTAMP,
                        escalated_to TEXT,
                        FOREIGN KEY (alert_id) REFERENCES alerts (id)
                    )
                """)
                
                # Create indexes
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_alerts_timestamp ON alerts(timestamp)")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_alerts_status ON alerts(status)")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_alerts_severity ON alerts(severity)")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_alerts_fingerprint ON alerts(fingerprint)")
                
        except Exception as e:
            self.logger.error(f"Failed to create alert tables: {e}")
            raise
    
    def _initialize_channels(self):
        """Initialize alert delivery channels."""
        try:
            # Telegram channel
            if self.config.notifications.telegram_enabled:
                telegram_config = {
                    'enabled': True,
                    'bot_token': self.config.notifications.message_templates.get('telegram_bot_token'),
                    'chat_id': self.config.notifications.message_templates.get('telegram_chat_id')
                }
                self.channels['telegram'] = TelegramChannel('telegram', telegram_config)
            
            # Email channel
            if self.config.notifications.email_enabled:
                email_config = {
                    'enabled': True,
                    'smtp_server': self.config.notifications.message_templates.get('smtp_server'),
                    'smtp_port': self.config.notifications.message_templates.get('smtp_port', 587),
                    'username': self.config.notifications.message_templates.get('smtp_username'),
                    'password': self.config.notifications.message_templates.get('smtp_password'),
                    'from_email': self.config.notifications.message_templates.get('from_email'),
                    'to_emails': self.config.notifications.message_templates.get('to_emails', [])
                }
                self.channels['email'] = EmailChannel('email', email_config)
            
            # Webhook channel
            if self.config.notifications.webhook_enabled:
                webhook_config = {
                    'enabled': True,
                    'url': self.config.notifications.message_templates.get('webhook_url'),
                    'method': self.config.notifications.message_templates.get('webhook_method', 'POST'),
                    'headers': self.config.notifications.message_templates.get('webhook_headers', {})
                }
                self.channels['webhook'] = WebhookChannel('webhook', webhook_config)
            
            # SMS channel
            if self.config.notifications.sms_enabled:
                sms_config = {
                    'enabled': True,
                    # SMS configuration would go here
                }
                self.channels['sms'] = SMSChannel('sms', sms_config)
            
            self.logger.info(f"Initialized {len(self.channels)} alert channels")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize channels: {e}")
    
    def _load_alert_rules(self):
        """Load alert rules from database."""
        try:
            with db_manager.get_cursor() as cursor:
                cursor.execute("SELECT * FROM alert_rules WHERE enabled = TRUE")
                rows = cursor.fetchall()
                
                for row in rows:
                    rule_data = dict(row)
                    rule_data['tags'] = json.loads(rule_data['tags']) if rule_data['tags'] else {}
                    rule_data['metadata'] = json.loads(rule_data['metadata']) if rule_data['metadata'] else {}
                    rule_data['channels'] = json.loads(rule_data['channels']) if rule_data['channels'] else []
                    
                    rule = AlertRule.from_dict(rule_data)
                    self.alert_rules[rule.id] = rule
                
                self.logger.info(f"Loaded {len(self.alert_rules)} alert rules")
                
        except Exception as e:
            self.logger.warning(f"Failed to load alert rules: {e}")
    
    def _load_active_alerts(self):
        """Load active alerts from database."""
        try:
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    SELECT * FROM alerts 
                    WHERE status IN ('active', 'acknowledged', 'escalated')
                """)
                rows = cursor.fetchall()
                
                for row in rows:
                    alert_data = dict(row)
                    alert_data['tags'] = json.loads(alert_data['tags']) if alert_data['tags'] else {}
                    alert_data['metadata'] = json.loads(alert_data['metadata']) if alert_data['metadata'] else {}
                    alert_data['channels_sent'] = json.loads(alert_data['channels_sent']) if alert_data['channels_sent'] else []
                    
                    alert = Alert.from_dict(alert_data)
                    self.active_alerts[alert.id] = alert
                
                self.logger.info(f"Loaded {len(self.active_alerts)} active alerts")
                
        except Exception as e:
            self.logger.warning(f"Failed to load active alerts: {e}")
    
    def start(self):
        """Start the alert manager."""
        if not self.running:
            self.running = True
            self.worker_thread = threading.Thread(target=self._worker_loop, daemon=True)
            self.worker_thread.start()
            self.logger.info("Alert manager started")
    
    def stop(self):
        """Stop the alert manager."""
        self.running = False
        if self.worker_thread:
            self.worker_thread.join(timeout=5)
        self.logger.info("Alert manager stopped")
    
    def _worker_loop(self):
        """Main worker loop for processing alerts."""
        while self.running:
            try:
                # Process alert queue
                self._process_alert_queue()
                
                # Check for escalations
                self._check_escalations()
                
                # Check for auto-resolutions
                self._check_auto_resolutions()
                
                # Cleanup old data
                self._periodic_cleanup()
                
                time.sleep(1)  # Process every second
                
            except Exception as e:
                self.logger.error(f"Error in alert worker loop: {e}")
                time.sleep(5)
    
    def _process_alert_queue(self):
        """Process alerts in the queue."""
        with self._lock:
            while self.alert_queue:
                alert = self.alert_queue.popleft()
                self._process_alert(alert)
    
    def _process_alert(self, alert: Alert):
        """Process a single alert."""
        try:
            # Check if alert should be aggregated
            should_aggregate, group_key = self.aggregator.should_aggregate(alert)
            
            if should_aggregate:
                # Get aggregated alert
                aggregated_alert = self.aggregator.get_aggregated_alert(group_key)
                if aggregated_alert:
                    alert = aggregated_alert
            
            # Check rate limiting
            if self._is_rate_limited(alert):
                self.logger.debug(f"Alert rate limited: {alert.id}")
                return
            
            # Store alert in database
            self._store_alert(alert)
            
            # Add to active alerts
            self.active_alerts[alert.id] = alert
            
            # Send alert through appropriate channels
            self._send_alert(alert)
            
            # Notify callbacks
            self._notify_callbacks(alert)
            
        except Exception as e:
            self.logger.error(f"Failed to process alert {alert.id}: {e}")
    
    def _is_rate_limited(self, alert: Alert) -> bool:
        """Check if alert is rate limited."""
        return self.rate_limiter.is_rate_limited(
            alert,
            self.config.alerts.rate_limit_window,
            self.config.alerts.max_alerts_per_window
        )
    
    def _send_alert(self, alert: Alert):
        """Send alert through appropriate channels."""
        try:
            # Determine channels based on severity
            channels_to_use = self.config.alerts.severity_channels.get(
                alert.severity.value,
                self.config.alerts.channels
            )
            
            sent_channels = []
            
            for channel_name in channels_to_use:
                channel = self.channels.get(channel_name)
                if channel and channel.send_alert(alert):
                    sent_channels.append(channel_name)
                    self.logger.debug(f"Sent alert {alert.id} via {channel_name}")
                else:
                    self.logger.warning(f"Failed to send alert {alert.id} via {channel_name}")
            
            # Update alert with sent channels
            alert.channels_sent = sent_channels
            self._update_alert(alert)
            
        except Exception as e:
            self.logger.error(f"Failed to send alert {alert.id}: {e}")
    
    def _store_alert(self, alert: Alert):
        """Store alert in database."""
        try:
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    INSERT OR REPLACE INTO alerts (
                        id, timestamp, alert_type, severity, title, message, source,
                        metric_name, metric_value, threshold_value, tags, metadata,
                        status, acknowledged_by, acknowledged_at, resolved_by, resolved_at,
                        escalated_at, escalation_level, retry_count, channels_sent, fingerprint
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    alert.id, alert.timestamp, alert.alert_type, alert.severity.value,
                    alert.title, alert.message, alert.source, alert.metric_name,
                    alert.metric_value, alert.threshold_value, json.dumps(alert.tags),
                    json.dumps(alert.metadata), alert.status.value, alert.acknowledged_by,
                    alert.acknowledged_at, alert.resolved_by, alert.resolved_at,
                    alert.escalated_at, alert.escalation_level, alert.retry_count,
                    json.dumps(alert.channels_sent), alert.fingerprint
                ))
        except Exception as e:
            self.logger.error(f"Failed to store alert {alert.id}: {e}")
    
    def _update_alert(self, alert: Alert):
        """Update existing alert in database."""
        try:
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    UPDATE alerts SET
                        status = ?, acknowledged_by = ?, acknowledged_at = ?,
                        resolved_by = ?, resolved_at = ?, escalated_at = ?,
                        escalation_level = ?, retry_count = ?, channels_sent = ?
                    WHERE id = ?
                """, (
                    alert.status.value, alert.acknowledged_by, alert.acknowledged_at,
                    alert.resolved_by, alert.resolved_at, alert.escalated_at,
                    alert.escalation_level, alert.retry_count, json.dumps(alert.channels_sent),
                    alert.id
                ))
        except Exception as e:
            self.logger.error(f"Failed to update alert {alert.id}: {e}")
    
    def _check_escalations(self):
        """Check for alerts that need escalation."""
        try:
            current_time = datetime.now()
            
            for alert in list(self.active_alerts.values()):
                if alert.status != AlertStatus.ACTIVE:
                    continue
                
                # Check if escalation is needed
                alert_time = datetime.fromisoformat(alert.timestamp)
                time_since_alert = (current_time - alert_time).total_seconds()
                
                if time_since_alert >= self.config.alerts.escalation_delay:
                    self._escalate_alert(alert)
                    
        except Exception as e:
            self.logger.error(f"Failed to check escalations: {e}")
    
    def _escalate_alert(self, alert: Alert):
        """Escalate an alert."""
        try:
            alert.escalation_level += 1
            alert.escalated_at = datetime.now().isoformat()
            alert.status = AlertStatus.ESCALATED
            
            # Store escalation record
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    INSERT INTO alert_escalations (
                        alert_id, escalation_level, escalated_at, escalated_to
                    ) VALUES (?, ?, ?, ?)
                """, (
                    alert.id, alert.escalation_level, alert.escalated_at, "system"
                ))
            
            # Update alert
            self._update_alert(alert)
            
            # Send escalated alert
            self._send_alert(alert)
            
            self.logger.warning(f"Escalated alert {alert.id} to level {alert.escalation_level}")
            
        except Exception as e:
            self.logger.error(f"Failed to escalate alert {alert.id}: {e}")
    
    def _check_auto_resolutions(self):
        """Check for alerts that should be auto-resolved."""
        try:
            current_time = datetime.now()
            
            for alert in list(self.active_alerts.values()):
                if alert.status not in [AlertStatus.ACTIVE, AlertStatus.ACKNOWLEDGED]:
                    continue
                
                # Check if auto-resolution is enabled for this alert type
                rule = self.alert_rules.get(alert.alert_type)
                if not rule or not rule.auto_resolve:
                    continue
                
                # Check if timeout has passed
                alert_time = datetime.fromisoformat(alert.timestamp)
                time_since_alert = (current_time - alert_time).total_seconds()
                
                if time_since_alert >= rule.auto_resolve_timeout:
                    self.resolve_alert(alert.id, "system", "Auto-resolved due to timeout")
                    
        except Exception as e:
            self.logger.error(f"Failed to check auto-resolutions: {e}")
    
    def _periodic_cleanup(self):
        """Perform periodic cleanup tasks."""
        try:
            # Run cleanup every hour
            if not hasattr(self, '_last_cleanup'):
                self._last_cleanup = time.time()
            
            if time.time() - self._last_cleanup < 3600:
                return
            
            self._last_cleanup = time.time()
            
            # Clean up resolved alerts older than 30 days
            cutoff_date = datetime.now() - timedelta(days=30)
            
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    DELETE FROM alerts 
                    WHERE status = 'resolved' AND resolved_at < ?
                """, (cutoff_date.isoformat(),))
                
                deleted_count = cursor.rowcount
                
            self.logger.info(f"Cleaned up {deleted_count} old resolved alerts")
            
        except Exception as e:
            self.logger.error(f"Failed to perform cleanup: {e}")
    
    def _notify_callbacks(self, alert: Alert):
        """Notify registered callbacks about the alert."""
        for callback in self.alert_callbacks:
            try:
                callback(alert)
            except Exception as e:
                self.logger.error(f"Alert callback failed: {e}")
    
    def create_alert(self, alert_type: str, severity: AlertLevel, title: str, 
                    message: str, source: str, metric_name: Optional[str] = None,
                    metric_value: Optional[float] = None, threshold_value: Optional[float] = None,
                    tags: Optional[Dict[str, str]] = None, metadata: Optional[Dict[str, Any]] = None) -> str:
        """Create a new alert."""
        try:
            alert_id = f"{alert_type}_{source}_{int(time.time() * 1000)}"
            
            alert = Alert(
                id=alert_id,
                timestamp=datetime.now().isoformat(),
                alert_type=alert_type,
                severity=severity,
                title=title,
                message=message,
                source=source,
                metric_name=metric_name,
                metric_value=metric_value,
                threshold_value=threshold_value,
                tags=tags or {},
                metadata=metadata or {}
            )
            
            # Add to processing queue
            with self._lock:
                self.alert_queue.append(alert)
            
            self.logger.info(f"Created alert: {alert_id}")
            return alert_id
            
        except Exception as e:
            self.logger.error(f"Failed to create alert: {e}")
            raise
    
    def acknowledge_alert(self, alert_id: str, acknowledged_by: str, comment: Optional[str] = None) -> bool:
        """Acknowledge an alert."""
        try:
            alert = self.active_alerts.get(alert_id)
            if not alert:
                self.logger.warning(f"Alert not found: {alert_id}")
                return False
            
            if alert.status == AlertStatus.RESOLVED:
                self.logger.warning(f"Cannot acknowledge resolved alert: {alert_id}")
                return False
            
            # Update alert
            alert.status = AlertStatus.ACKNOWLEDGED
            alert.acknowledged_by = acknowledged_by
            alert.acknowledged_at = datetime.now().isoformat()
            
            # Store acknowledgment record
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    INSERT INTO alert_acknowledgments (
                        alert_id, acknowledged_by, acknowledged_at, comment
                    ) VALUES (?, ?, ?, ?)
                """, (alert_id, acknowledged_by, alert.acknowledged_at, comment))
            
            # Update alert in database
            self._update_alert(alert)
            
            self.logger.info(f"Acknowledged alert {alert_id} by {acknowledged_by}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to acknowledge alert {alert_id}: {e}")
            return False
    
    def resolve_alert(self, alert_id: str, resolved_by: str, comment: Optional[str] = None) -> bool:
        """Resolve an alert."""
        try:
            alert = self.active_alerts.get(alert_id)
            if not alert:
                self.logger.warning(f"Alert not found: {alert_id}")
                return False
            
            if alert.status == AlertStatus.RESOLVED:
                self.logger.warning(f"Alert already resolved: {alert_id}")
                return False
            
            # Update alert
            alert.status = AlertStatus.RESOLVED
            alert.resolved_by = resolved_by
            alert.resolved_at = datetime.now().isoformat()
            
            # Update alert in database
            self._update_alert(alert)
            
            # Remove from active alerts
            del self.active_alerts[alert_id]
            
            self.logger.info(f"Resolved alert {alert_id} by {resolved_by}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to resolve alert {alert_id}: {e}")
            return False
    
    def add_alert_rule(self, rule: AlertRule) -> bool:
        """Add a custom alert rule."""
        try:
            # Store rule in database
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    INSERT OR REPLACE INTO alert_rules (
                        id, name, description, enabled, condition, severity, channels,
                        rate_limit_window, max_alerts_per_window, escalation_delay,
                        auto_resolve, auto_resolve_timeout, tags, metadata,
                        created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    rule.id, rule.name, rule.description, rule.enabled, rule.condition,
                    rule.severity.value, json.dumps(rule.channels), rule.rate_limit_window,
                    rule.max_alerts_per_window, rule.escalation_delay, rule.auto_resolve,
                    rule.auto_resolve_timeout, json.dumps(rule.tags), json.dumps(rule.metadata),
                    rule.created_at, rule.updated_at
                ))
            
            # Add to active rules
            self.alert_rules[rule.id] = rule
            
            self.logger.info(f"Added alert rule: {rule.id}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to add alert rule {rule.id}: {e}")
            return False
    
    def remove_alert_rule(self, rule_id: str) -> bool:
        """Remove an alert rule."""
        try:
            # Remove from database
            with db_manager.get_cursor() as cursor:
                cursor.execute("DELETE FROM alert_rules WHERE id = ?", (rule_id,))
            
            # Remove from active rules
            if rule_id in self.alert_rules:
                del self.alert_rules[rule_id]
            
            self.logger.info(f"Removed alert rule: {rule_id}")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to remove alert rule {rule_id}: {e}")
            return False
    
    def evaluate_custom_rules(self, context: Dict[str, Any]):
        """Evaluate custom alert rules against provided context."""
        try:
            for rule in self.alert_rules.values():
                if not rule.enabled:
                    continue
                
                try:
                    # Safely evaluate the condition
                    if self._evaluate_condition(rule.condition, context):
                        # Create alert based on rule
                        self.create_alert(
                            alert_type=f"custom_{rule.id}",
                            severity=rule.severity,
                            title=f"Custom Rule: {rule.name}",
                            message=f"Rule '{rule.name}' triggered: {rule.description}",
                            source="custom_rule",
                            tags=rule.tags,
                            metadata={
                                "rule_id": rule.id,
                                "rule_name": rule.name,
                                "context": context
                            }
                        )
                        
                except Exception as e:
                    self.logger.error(f"Failed to evaluate rule {rule.id}: {e}")
                    
        except Exception as e:
            self.logger.error(f"Failed to evaluate custom rules: {e}")
    
    def _evaluate_condition(self, condition: str, context: Dict[str, Any]) -> bool:
        """Safely evaluate a condition string."""
        try:
            # Create a safe evaluation environment
            safe_globals = {
                '__builtins__': {},
                'abs': abs,
                'max': max,
                'min': min,
                'len': len,
                'sum': sum,
                'any': any,
                'all': all,
            }
            
            # Add context variables
            safe_locals = context.copy()
            
            # Evaluate condition
            result = eval(condition, safe_globals, safe_locals)
            return bool(result)
            
        except Exception as e:
            self.logger.warning(f"Failed to evaluate condition '{condition}': {e}")
            return False
    
    def get_active_alerts(self, severity: Optional[AlertLevel] = None, 
                         source: Optional[str] = None) -> List[Alert]:
        """Get list of active alerts with optional filtering."""
        try:
            alerts = list(self.active_alerts.values())
            
            if severity:
                alerts = [a for a in alerts if a.severity == severity]
            
            if source:
                alerts = [a for a in alerts if a.source == source]
            
            # Sort by timestamp (newest first)
            alerts.sort(key=lambda a: a.timestamp, reverse=True)
            
            return alerts
            
        except Exception as e:
            self.logger.error(f"Failed to get active alerts: {e}")
            return []
    
    def get_alert_history(self, hours: int = 24, limit: int = 100) -> List[Alert]:
        """Get alert history for specified time period."""
        try:
            cutoff_time = datetime.now() - timedelta(hours=hours)
            
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    SELECT * FROM alerts 
                    WHERE timestamp >= ? 
                    ORDER BY timestamp DESC 
                    LIMIT ?
                """, (cutoff_time.isoformat(), limit))
                
                rows = cursor.fetchall()
                alerts = []
                
                for row in rows:
                    alert_data = dict(row)
                    alert_data['tags'] = json.loads(alert_data['tags']) if alert_data['tags'] else {}
                    alert_data['metadata'] = json.loads(alert_data['metadata']) if alert_data['metadata'] else {}
                    alert_data['channels_sent'] = json.loads(alert_data['channels_sent']) if alert_data['channels_sent'] else []
                    
                    alert = Alert.from_dict(alert_data)
                    alerts.append(alert)
                
                return alerts
                
        except Exception as e:
            self.logger.error(f"Failed to get alert history: {e}")
            return []
    
    def get_alert_statistics(self, hours: int = 24) -> Dict[str, Any]:
        """Get alert statistics for specified time period."""
        try:
            cutoff_time = datetime.now() - timedelta(hours=hours)
            
            with db_manager.get_cursor() as cursor:
                # Total alerts by severity
                cursor.execute("""
                    SELECT severity, COUNT(*) as count 
                    FROM alerts 
                    WHERE timestamp >= ? 
                    GROUP BY severity
                """, (cutoff_time.isoformat(),))
                
                severity_counts = {row['severity']: row['count'] for row in cursor.fetchall()}
                
                # Total alerts by status
                cursor.execute("""
                    SELECT status, COUNT(*) as count 
                    FROM alerts 
                    WHERE timestamp >= ? 
                    GROUP BY status
                """, (cutoff_time.isoformat(),))
                
                status_counts = {row['status']: row['count'] for row in cursor.fetchall()}
                
                # Total alerts by source
                cursor.execute("""
                    SELECT source, COUNT(*) as count 
                    FROM alerts 
                    WHERE timestamp >= ? 
                    GROUP BY source 
                    ORDER BY count DESC 
                    LIMIT 10
                """, (cutoff_time.isoformat(),))
                
                source_counts = {row['source']: row['count'] for row in cursor.fetchall()}
                
                # Resolution times
                cursor.execute("""
                    SELECT AVG(
                        (julianday(resolved_at) - julianday(timestamp)) * 24 * 60
                    ) as avg_resolution_time_minutes
                    FROM alerts 
                    WHERE timestamp >= ? AND status = 'resolved'
                """, (cutoff_time.isoformat(),))
                
                row = cursor.fetchone()
                avg_resolution_time = row['avg_resolution_time_minutes'] if row else 0
                
                return {
                    'time_period_hours': hours,
                    'total_alerts': sum(severity_counts.values()),
                    'active_alerts': len(self.active_alerts),
                    'severity_breakdown': severity_counts,
                    'status_breakdown': status_counts,
                    'top_sources': source_counts,
                    'avg_resolution_time_minutes': avg_resolution_time or 0
                }
                
        except Exception as e:
            self.logger.error(f"Failed to get alert statistics: {e}")
            return {}
    
    def add_alert_callback(self, callback: Callable[[Alert], None]):
        """Add a callback function to be called when alerts are created."""
        self.alert_callbacks.append(callback)
    
    def remove_alert_callback(self, callback: Callable[[Alert], None]):
        """Remove a callback function."""
        if callback in self.alert_callbacks:
            self.alert_callbacks.remove(callback)
    
    def test_channel(self, channel_name: str) -> bool:
        """Test an alert channel by sending a test message."""
        try:
            channel = self.channels.get(channel_name)
            if not channel:
                self.logger.error(f"Channel not found: {channel_name}")
                return False
            
            test_alert = Alert(
                id="test_alert",
                timestamp=datetime.now().isoformat(),
                alert_type="test",
                severity=AlertLevel.INFO,
                title="Test Alert",
                message="This is a test alert to verify channel functionality.",
                source="alert_manager_test"
            )
            
            return channel.send_alert(test_alert)
            
        except Exception as e:
            self.logger.error(f"Failed to test channel {channel_name}: {e}")
            return False
    
    def get_health_status(self) -> Dict[str, Any]:
        """Get health status of the alert manager."""
        try:
            return {
                'running': self.running,
                'active_alerts_count': len(self.active_alerts),
                'alert_rules_count': len(self.alert_rules),
                'channels_count': len(self.channels),
                'queue_size': len(self.alert_queue),
                'channels_status': {
                    name: channel.enabled for name, channel in self.channels.items()
                }
            }
            
        except Exception as e:
            self.logger.error(f"Failed to get health status: {e}")
            return {'error': str(e)}

# Global alert manager instance
alert_manager = AlertManager()