"""
System monitor for the AI Crypto Trading System.
Provides real-time monitoring of system resources, hardware health, and performance metrics.
Optimized for Raspberry Pi 5 with specific hardware monitoring capabilities.
"""

import os
import time
import psutil
import threading
import subprocess
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List, Callable
from dataclasses import dataclass, asdict
from pathlib import Path
import json
import socket
import requests
from collections import deque, defaultdict

from .config import monitoring_config, AlertLevel
from ..utils.logging import get_logger
from ..utils.database import db_manager

@dataclass
class SystemMetrics:
    """System metrics data structure."""
    timestamp: str
    cpu_usage: float
    cpu_temperature: float
    memory_usage: float
    memory_available: float
    disk_usage: float
    disk_free: float
    network_latency: float
    network_rx_bytes: int
    network_tx_bytes: int
    gpu_memory_usage: float
    voltage_core: float
    voltage_sdram: float
    throttling_status: bool
    process_count: int
    load_average: List[float]
    uptime: float

@dataclass
class ProcessMetrics:
    """Process-specific metrics."""
    pid: int
    name: str
    cpu_percent: float
    memory_percent: float
    memory_rss: int
    memory_vms: int
    status: str
    create_time: float
    num_threads: int
    num_fds: int
    io_read_bytes: int
    io_write_bytes: int

class SystemMonitor:
    """Real-time system resource and hardware monitor."""
    
    def __init__(self):
        self.logger = get_logger(__name__)
        self.config = monitoring_config
        self.running = False
        self.monitor_thread: Optional[threading.Thread] = None
        self.alert_callbacks: List[Callable] = []
        
        # Metrics storage
        self.metrics_history = deque(maxlen=1000)
        self.process_metrics = {}
        self.network_baseline = None
        self.alert_states = defaultdict(bool)
        
        # Raspberry Pi specific paths
        self.rpi_paths = {
            'temperature': '/sys/class/thermal/thermal_zone0/temp',
            'voltage_core': '/sys/devices/platform/soc/soc:firmware/get_throttled',
            'gpu_memory': '/opt/vc/bin/vcgencmd'
        }
        
        # Process monitoring
        self.monitored_processes = [
            'python',
            'ollama',
            'chromium',
            'firefox',
            'node'
        ]
        
        self._initialize_monitoring()
    
    def _initialize_monitoring(self):
        """Initialize monitoring components."""
        try:
            # Check if running on Raspberry Pi
            self.is_raspberry_pi = self._detect_raspberry_pi()
            
            # Initialize network baseline
            self._establish_network_baseline()
            
            # Create monitoring database tables
            self._create_monitoring_tables()
            
            self.logger.info(f"System monitor initialized (Raspberry Pi: {self.is_raspberry_pi})")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize system monitor: {e}")
            raise
    
    def _detect_raspberry_pi(self) -> bool:
        """Detect if running on Raspberry Pi."""
        try:
            with open('/proc/cpuinfo', 'r') as f:
                cpuinfo = f.read()
            return 'Raspberry Pi' in cpuinfo or 'BCM' in cpuinfo
        except:
            return False
    
    def _establish_network_baseline(self):
        """Establish network latency baseline."""
        try:
            # Test connectivity to major exchanges
            test_hosts = [
                'api.binance.com',
                'api.mexc.com',
                'sapi.xt.com',
                '8.8.8.8'
            ]
            
            latencies = []
            for host in test_hosts:
                try:
                    start_time = time.time()
                    socket.create_connection((host, 80), timeout=5)
                    latency = (time.time() - start_time) * 1000
                    latencies.append(latency)
                except:
                    continue
            
            if latencies:
                self.network_baseline = sum(latencies) / len(latencies)
            else:
                self.network_baseline = 100.0  # Default baseline
                
            self.logger.info(f"Network baseline established: {self.network_baseline:.2f}ms")
            
        except Exception as e:
            self.logger.warning(f"Failed to establish network baseline: {e}")
            self.network_baseline = 100.0
    
    def _create_monitoring_tables(self):
        """Create database tables for monitoring data."""
        try:
            with db_manager.get_cursor() as cursor:
                # System metrics table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS system_metrics (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        cpu_usage REAL,
                        cpu_temperature REAL,
                        memory_usage REAL,
                        memory_available REAL,
                        disk_usage REAL,
                        disk_free REAL,
                        network_latency REAL,
                        network_rx_bytes INTEGER,
                        network_tx_bytes INTEGER,
                        gpu_memory_usage REAL,
                        voltage_core REAL,
                        voltage_sdram REAL,
                        throttling_status BOOLEAN,
                        process_count INTEGER,
                        load_average TEXT,
                        uptime REAL
                    )
                """)
                
                # Process metrics table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS process_metrics (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        pid INTEGER,
                        name TEXT,
                        cpu_percent REAL,
                        memory_percent REAL,
                        memory_rss INTEGER,
                        memory_vms INTEGER,
                        status TEXT,
                        create_time REAL,
                        num_threads INTEGER,
                        num_fds INTEGER,
                        io_read_bytes INTEGER,
                        io_write_bytes INTEGER
                    )
                """)
                
                # System alerts table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS system_alerts (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        alert_type TEXT,
                        severity TEXT,
                        metric_name TEXT,
                        metric_value REAL,
                        threshold_value REAL,
                        message TEXT,
                        acknowledged BOOLEAN DEFAULT FALSE,
                        resolved BOOLEAN DEFAULT FALSE
                    )
                """)
                
                # Create indexes
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_system_metrics_timestamp ON system_metrics(timestamp)")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_process_metrics_timestamp ON process_metrics(timestamp)")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_system_alerts_timestamp ON system_alerts(timestamp)")
                
        except Exception as e:
            self.logger.error(f"Failed to create monitoring tables: {e}")
    
    def start_monitoring(self):
        """Start the system monitoring thread."""
        if not self.running:
            self.running = True
            self.monitor_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
            self.monitor_thread.start()
            self.logger.info("System monitoring started")
    
    def stop_monitoring(self):
        """Stop the system monitoring."""
        self.running = False
        if self.monitor_thread:
            self.monitor_thread.join(timeout=5)
        self.logger.info("System monitoring stopped")
    
    def add_alert_callback(self, callback: Callable):
        """Add callback for alert notifications."""
        self.alert_callbacks.append(callback)
    
    def _monitoring_loop(self):
        """Main monitoring loop."""
        while self.running:
            try:
                # Collect system metrics
                metrics = self._collect_system_metrics()
                
                # Store metrics
                self._store_metrics(metrics)
                
                # Check for alerts
                self._check_alerts(metrics)
                
                # Collect process metrics
                self._collect_process_metrics()
                
                # Sleep for collection interval
                time.sleep(self.config.metrics.collection_interval)
                
            except Exception as e:
                self.logger.error(f"Error in monitoring loop: {e}")
                time.sleep(5)  # Brief pause before retrying
    
    def _collect_system_metrics(self) -> SystemMetrics:
        """Collect comprehensive system metrics."""
        try:
            # CPU metrics
            cpu_usage = psutil.cpu_percent(interval=1)
            cpu_temp = self._get_cpu_temperature()
            
            # Memory metrics
            memory = psutil.virtual_memory()
            memory_usage = memory.percent
            memory_available = memory.available / (1024**3)  # GB
            
            # Disk metrics
            disk = psutil.disk_usage('/')
            disk_usage = (disk.used / disk.total) * 100
            disk_free = disk.free / (1024**3)  # GB
            
            # Network metrics
            network_latency = self._measure_network_latency()
            net_io = psutil.net_io_counters()
            
            # Raspberry Pi specific metrics
            gpu_memory = self._get_gpu_memory_usage()
            voltage_core, voltage_sdram = self._get_voltages()
            throttling = self._check_throttling()
            
            # System metrics
            process_count = len(psutil.pids())
            load_avg = os.getloadavg() if hasattr(os, 'getloadavg') else [0, 0, 0]
            uptime = time.time() - psutil.boot_time()
            
            metrics = SystemMetrics(
                timestamp=datetime.now().isoformat(),
                cpu_usage=cpu_usage,
                cpu_temperature=cpu_temp,
                memory_usage=memory_usage,
                memory_available=memory_available,
                disk_usage=disk_usage,
                disk_free=disk_free,
                network_latency=network_latency,
                network_rx_bytes=net_io.bytes_recv,
                network_tx_bytes=net_io.bytes_sent,
                gpu_memory_usage=gpu_memory,
                voltage_core=voltage_core,
                voltage_sdram=voltage_sdram,
                throttling_status=throttling,
                process_count=process_count,
                load_average=list(load_avg),
                uptime=uptime
            )
            
            # Add to history
            self.metrics_history.append(metrics)
            
            return metrics
            
        except Exception as e:
            self.logger.error(f"Failed to collect system metrics: {e}")
            raise
    
    def _get_cpu_temperature(self) -> float:
        """Get CPU temperature (Raspberry Pi specific)."""
        try:
            if self.is_raspberry_pi and os.path.exists(self.rpi_paths['temperature']):
                with open(self.rpi_paths['temperature'], 'r') as f:
                    temp = float(f.read().strip()) / 1000.0
                return temp
            else:
                # Fallback for other systems
                try:
                    temps = psutil.sensors_temperatures()
                    if temps:
                        for name, entries in temps.items():
                            if entries:
                                return entries[0].current
                except:
                    pass
                return 0.0
        except:
            return 0.0
    
    def _get_gpu_memory_usage(self) -> float:
        """Get GPU memory usage (Raspberry Pi specific)."""
        try:
            if self.is_raspberry_pi:
                result = subprocess.run(
                    ['vcgencmd', 'get_mem', 'gpu'],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                if result.returncode == 0:
                    # Parse output like "gpu=76M"
                    gpu_mem = result.stdout.strip().split('=')[1].rstrip('M')
                    return float(gpu_mem)
        except:
            pass
        return 0.0
    
    def _get_voltages(self) -> tuple:
        """Get core and SDRAM voltages (Raspberry Pi specific)."""
        try:
            if self.is_raspberry_pi:
                # Get core voltage
                result = subprocess.run(
                    ['vcgencmd', 'measure_volts', 'core'],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                core_voltage = 0.0
                if result.returncode == 0:
                    # Parse output like "volt=1.2000V"
                    core_voltage = float(result.stdout.strip().split('=')[1].rstrip('V'))
                
                # Get SDRAM voltage
                result = subprocess.run(
                    ['vcgencmd', 'measure_volts', 'sdram_c'],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                sdram_voltage = 0.0
                if result.returncode == 0:
                    sdram_voltage = float(result.stdout.strip().split('=')[1].rstrip('V'))
                
                return core_voltage, sdram_voltage
        except:
            pass
        return 0.0, 0.0
    
    def _check_throttling(self) -> bool:
        """Check if system is being throttled (Raspberry Pi specific)."""
        try:
            if self.is_raspberry_pi:
                result = subprocess.run(
                    ['vcgencmd', 'get_throttled'],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                if result.returncode == 0:
                    # Parse output like "throttled=0x0"
                    throttled_value = result.stdout.strip().split('=')[1]
                    return int(throttled_value, 16) != 0
        except:
            pass
        return False
    
    def _measure_network_latency(self) -> float:
        """Measure network latency to external services."""
        try:
            start_time = time.time()
            response = requests.get('https://api.binance.com/api/v3/ping', timeout=5)
            if response.status_code == 200:
                latency = (time.time() - start_time) * 1000
                return latency
        except:
            pass
        
        # Fallback to ping
        try:
            result = subprocess.run(
                ['ping', '-c', '1', '8.8.8.8'],
                capture_output=True,
                text=True,
                timeout=5
            )
            if result.returncode == 0:
                # Parse ping output for latency
                lines = result.stdout.split('\n')
                for line in lines:
                    if 'time=' in line:
                        latency = float(line.split('time=')[1].split(' ')[0])
                        return latency
        except:
            pass
        
        return self.network_baseline or 100.0
    
    def _collect_process_metrics(self):
        """Collect metrics for monitored processes."""
        try:
            current_processes = {}
            
            for proc in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent', 
                                           'memory_info', 'status', 'create_time', 
                                           'num_threads', 'num_fds', 'io_counters']):
                try:
                    proc_info = proc.info
                    proc_name = proc_info['name'].lower()
                    
                    # Check if this is a monitored process
                    if any(monitored in proc_name for monitored in self.monitored_processes):
                        metrics = ProcessMetrics(
                            pid=proc_info['pid'],
                            name=proc_info['name'],
                            cpu_percent=proc_info['cpu_percent'] or 0.0,
                            memory_percent=proc_info['memory_percent'] or 0.0,
                            memory_rss=proc_info['memory_info'].rss if proc_info['memory_info'] else 0,
                            memory_vms=proc_info['memory_info'].vms if proc_info['memory_info'] else 0,
                            status=proc_info['status'],
                            create_time=proc_info['create_time'] or 0.0,
                            num_threads=proc_info['num_threads'] or 0,
                            num_fds=proc_info['num_fds'] or 0,
                            io_read_bytes=proc_info['io_counters'].read_bytes if proc_info['io_counters'] else 0,
                            io_write_bytes=proc_info['io_counters'].write_bytes if proc_info['io_counters'] else 0
                        )
                        
                        current_processes[proc_info['pid']] = metrics
                        
                        # Store in database
                        self._store_process_metrics(metrics)
                
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            self.process_metrics = current_processes
            
        except Exception as e:
            self.logger.error(f"Failed to collect process metrics: {e}")
    
    def _store_metrics(self, metrics: SystemMetrics):
        """Store system metrics in database."""
        try:
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    INSERT INTO system_metrics (
                        timestamp, cpu_usage, cpu_temperature, memory_usage, memory_available,
                        disk_usage, disk_free, network_latency, network_rx_bytes, network_tx_bytes,
                        gpu_memory_usage, voltage_core, voltage_sdram, throttling_status,
                        process_count, load_average, uptime
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    metrics.timestamp, metrics.cpu_usage, metrics.cpu_temperature,
                    metrics.memory_usage, metrics.memory_available, metrics.disk_usage,
                    metrics.disk_free, metrics.network_latency, metrics.network_rx_bytes,
                    metrics.network_tx_bytes, metrics.gpu_memory_usage, metrics.voltage_core,
                    metrics.voltage_sdram, metrics.throttling_status, metrics.process_count,
                    json.dumps(metrics.load_average), metrics.uptime
                ))
        except Exception as e:
            self.logger.error(f"Failed to store system metrics: {e}")
    
    def _store_process_metrics(self, metrics: ProcessMetrics):
        """Store process metrics in database."""
        try:
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    INSERT INTO process_metrics (
                        pid, name, cpu_percent, memory_percent, memory_rss, memory_vms,
                        status, create_time, num_threads, num_fds, io_read_bytes, io_write_bytes
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    metrics.pid, metrics.name, metrics.cpu_percent, metrics.memory_percent,
                    metrics.memory_rss, metrics.memory_vms, metrics.status, metrics.create_time,
                    metrics.num_threads, metrics.num_fds, metrics.io_read_bytes, metrics.io_write_bytes
                ))
        except Exception as e:
            self.logger.error(f"Failed to store process metrics: {e}")
    
    def _check_alerts(self, metrics: SystemMetrics):
        """Check metrics against thresholds and trigger alerts."""
        try:
            thresholds = self.config.system_thresholds
            alerts = []
            
            # CPU usage alerts
            if metrics.cpu_usage >= thresholds.cpu_critical:
                alerts.append(self._create_alert("cpu_usage", metrics.cpu_usage, 
                                               thresholds.cpu_critical, AlertLevel.CRITICAL))
            elif metrics.cpu_usage >= thresholds.cpu_warning:
                alerts.append(self._create_alert("cpu_usage", metrics.cpu_usage, 
                                               thresholds.cpu_warning, AlertLevel.WARNING))
            
            # Memory usage alerts
            if metrics.memory_usage >= thresholds.memory_critical:
                alerts.append(self._create_alert("memory_usage", metrics.memory_usage, 
                                               thresholds.memory_critical, AlertLevel.CRITICAL))
            elif metrics.memory_usage >= thresholds.memory_warning:
                alerts.append(self._create_alert("memory_usage", metrics.memory_usage, 
                                               thresholds.memory_warning, AlertLevel.WARNING))
            
            # Disk usage alerts
            if metrics.disk_usage >= thresholds.disk_critical:
                alerts.append(self._create_alert("disk_usage", metrics.disk_usage, 
                                               thresholds.disk_critical, AlertLevel.CRITICAL))
            elif metrics.disk_usage >= thresholds.disk_warning:
                alerts.append(self._create_alert("disk_usage", metrics.disk_usage, 
                                               thresholds.disk_warning, AlertLevel.WARNING))
            
            # Temperature alerts
            if metrics.cpu_temperature >= thresholds.temperature_critical:
                alerts.append(self._create_alert("cpu_temperature", metrics.cpu_temperature, 
                                               thresholds.temperature_critical, AlertLevel.CRITICAL))
            elif metrics.cpu_temperature >= thresholds.temperature_warning:
                alerts.append(self._create_alert("cpu_temperature", metrics.cpu_temperature, 
                                               thresholds.temperature_warning, AlertLevel.WARNING))
            
            # Network latency alerts
            if metrics.network_latency >= thresholds.network_latency_critical:
                alerts.append(self._create_alert("network_latency", metrics.network_latency, 
                                               thresholds.network_latency_critical, AlertLevel.CRITICAL))
            elif metrics.network_latency >= thresholds.network_latency_warning:
                alerts.append(self._create_alert("network_latency", metrics.network_latency, 
                                               thresholds.network_latency_warning, AlertLevel.WARNING))
            
            # Throttling alert
            if metrics.throttling_status:
                alerts.append(self._create_alert("throttling", 1, 0, AlertLevel.WARNING))
            
            # Process alerts
            for alert in alerts:
                self._handle_alert(alert)
                
        except Exception as e:
            self.logger.error(f"Failed to check alerts: {e}")
    
    def _create_alert(self, metric_name: str, value: float, threshold: float, level: AlertLevel) -> Dict[str, Any]:
        """Create an alert dictionary."""
        return {
            "timestamp": datetime.now().isoformat(),
            "alert_type": "system",
            "severity": level.value,
            "metric_name": metric_name,
            "metric_value": value,
            "threshold_value": threshold,
            "message": f"System {metric_name} is {value:.2f} (threshold: {threshold:.2f})"
        }
    
    def _handle_alert(self, alert: Dict[str, Any]):
        """Handle and store alert."""
        try:
            alert_key = f"{alert['metric_name']}_{alert['severity']}"
            
            # Check if this alert is already active (rate limiting)
            if not self.alert_states.get(alert_key, False):
                self.alert_states[alert_key] = True
                
                # Store alert in database
                with db_manager.get_cursor() as cursor:
                    cursor.execute("""
                        INSERT INTO system_alerts (
                            alert_type, severity, metric_name, metric_value, 
                            threshold_value, message
                        ) VALUES (?, ?, ?, ?, ?, ?)
                    """, (
                        alert['alert_type'], alert['severity'], alert['metric_name'],
                        alert['metric_value'], alert['threshold_value'], alert['message']
                    ))
                
                # Notify callbacks
                for callback in self.alert_callbacks:
                    try:
                        callback(alert)
                    except Exception as e:
                        self.logger.error(f"Alert callback failed: {e}")
                
                # Reset alert state after some time
                threading.Timer(300, lambda: self.alert_states.pop(alert_key, None)).start()
                
        except Exception as e:
            self.logger.error(f"Failed to handle alert: {e}")
    
    def get_current_metrics(self) -> Optional[SystemMetrics]:
        """Get the most recent system metrics."""
        if self.metrics_history:
            return self.metrics_history[-1]
        return None
    
    def get_metrics_history(self, hours: int = 24) -> List[SystemMetrics]:
        """Get metrics history for specified hours."""
        try:
            cutoff_time = datetime.now() - timedelta(hours=hours)
            
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    SELECT * FROM system_metrics 
                    WHERE timestamp >= ? 
                    ORDER BY timestamp DESC
                """, (cutoff_time.isoformat(),))
                
                rows = cursor.fetchall()
                metrics_list = []
                
                for row in rows:
                    metrics = SystemMetrics(
                        timestamp=row['timestamp'],
                        cpu_usage=row['cpu_usage'],
                        cpu_temperature=row['cpu_temperature'],
                        memory_usage=row['memory_usage'],
                        memory_available=row['memory_available'],
                        disk_usage=row['disk_usage'],
                        disk_free=row['disk_free'],
                        network_latency=row['network_latency'],
                        network_rx_bytes=row['network_rx_bytes'],
                        network_tx_bytes=row['network_tx_bytes'],
                        gpu_memory_usage=row['gpu_memory_usage'],
                        voltage_core=row['voltage_core'],
                        voltage_sdram=row['voltage_sdram'],
                        throttling_status=row['throttling_status'],
                        process_count=row['process_count'],
                        load_average=json.loads(row['load_average']),
                        uptime=row['uptime']
                    )
                    metrics_list.append(metrics)
                
                return metrics_list
                
        except Exception as e:
            self.logger.error(f"Failed to get metrics history: {e}")
            return []
    
    def get_system_health_score(self) -> float:
        """Calculate overall system health score (0-100)."""
        try:
            current_metrics = self.get_current_metrics()
            if not current_metrics:
                return 0.0
            
            scores = []
            thresholds = self.config.system_thresholds
            
            # CPU score (inverted - lower usage is better)
            cpu_score = max(0, 100 - current_metrics.cpu_usage)
            scores.append(cpu_score)
            
            # Memory score (inverted)
            memory_score = max(0, 100 - current_metrics.memory_usage)
            scores.append(memory_score)
            
            # Disk score (inverted)
            disk_score = max(0, 100 - current_metrics.disk_usage)
            scores.append(disk_score)
            
            # Temperature score
            if current_metrics.cpu_temperature > 0:
                temp_score = max(0, 100 - (current_metrics.cpu_temperature / thresholds.temperature_critical * 100))
                scores.append(temp_score)
            
            # Network score
            if current_metrics.network_latency > 0:
                network_score = max(0, 100 - (current_metrics.network_latency / thresholds.network_latency_critical * 100))
                scores.append(network_score)
            
            # Throttling penalty
            if current_metrics.throttling_status:
                scores.append(0)  # Heavy penalty for throttling
            
            return sum(scores) / len(scores) if scores else 0.0
            
        except Exception as e:
            self.logger.error(f"Failed to calculate health score: {e}")
            return 0.0
    
    def cleanup_old_data(self, days: int = 30):
        """Clean up old monitoring data."""
        try:
            cutoff_date = datetime.now() - timedelta(days=days)
            
            with db_manager.get_cursor() as cursor:
                # Clean old system metrics
                cursor.execute("""
                    DELETE FROM system_metrics 
                    WHERE timestamp < ?
                """, (cutoff_date.isoformat(),))
                
                # Clean old process metrics
                cursor.execute("""
                    DELETE FROM process_metrics 
                    WHERE timestamp < ?
                """, (cutoff_date.isoformat(),))
                
                # Clean old resolved alerts
                cursor.execute("""
                    DELETE FROM system_alerts 
                    WHERE timestamp < ? AND resolved = TRUE
                """, (cutoff_date.isoformat(),))
                
            self.logger.info(f"Cleaned up monitoring data older than {days} days")
            
        except Exception as e:
            self.logger.error(f"Failed to cleanup old data: {e}")

# Global system monitor instance
system_monitor = SystemMonitor()