"""
Standalone Monitoring Dashboard Backend
======================================

Flask-based dashboard backend for the standalone monitoring system.
Provides REST API endpoints and web interface for monitoring system status.

Features:
- Real-time system metrics API
- Alert management endpoints
- Health status monitoring
- Simple web interface
- No AI system dependencies

Endpoints:
- GET /api/status - System status
- GET /api/metrics - Current metrics
- GET /api/alerts - Active alerts
- GET /api/health - Health check
- GET / - Dashboard web interface
"""

import os
import json
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
from flask import Flask, jsonify, render_template_string, request
from flask_cors import CORS


def create_standalone_dashboard(container) -> Flask:
    """Create Flask dashboard application for standalone monitoring."""
    
    app = Flask(__name__)
    CORS(app)  # Enable CORS for API access
    
    # Get components from container
    logger = container.get_logger("dashboard")
    system_monitor = container.get_system_monitor()
    metrics_collector = container.get_metrics_collector()
    alert_manager = container.get_alert_manager()
    
    @app.route('/api/health')
    def health_check():
        """Health check endpoint."""
        return jsonify({
            'status': 'healthy',
            'timestamp': datetime.now().isoformat(),
            'monitoring_only_mode': True
        })
    
    @app.route('/api/status')
    def get_status():
        """Get system status."""
        try:
            status = {
                'timestamp': datetime.now().isoformat(),
                'monitoring_only_mode': True,
                'components': {
                    'system_monitor': system_monitor is not None,
                    'metrics_collector': metrics_collector is not None,
                    'alert_manager': alert_manager is not None
                }
            }
            
            # Add system monitor status if available
            if system_monitor:
                current_metrics = system_monitor.get_current_metrics()
                if current_metrics:
                    status['current_metrics'] = current_metrics
                    status['health_score'] = system_monitor.get_system_health_score()
            
            return jsonify(status)
            
        except Exception as e:
            logger.error(f"Error getting status: {e}")
            return jsonify({'error': str(e)}), 500
    
    @app.route('/api/metrics')
    def get_metrics():
        """Get current system metrics."""
        try:
            if not system_monitor:
                return jsonify({'error': 'System monitor not available'}), 503
            
            metrics = system_monitor.get_current_metrics()
            if not metrics:
                return jsonify({'error': 'No metrics available'}), 503
            
            return jsonify(metrics)
            
        except Exception as e:
            logger.error(f"Error getting metrics: {e}")
            return jsonify({'error': str(e)}), 500
    
    @app.route('/api/metrics/history')
    def get_metrics_history():
        """Get historical metrics."""
        try:
            # Get time range from query parameters
            hours = int(request.args.get('hours', 24))
            end_time = datetime.now()
            start_time = end_time - timedelta(hours=hours)
            
            if not metrics_collector:
                return jsonify({'error': 'Metrics collector not available'}), 503
            
            # Get historical data (simplified for standalone mode)
            history = {
                'start_time': start_time.isoformat(),
                'end_time': end_time.isoformat(),
                'metrics': []
            }
            
            # In a full implementation, this would query stored metrics
            # For now, return current metrics as a single point
            if system_monitor:
                current = system_monitor.get_current_metrics()
                if current:
                    history['metrics'].append(current)
            
            return jsonify(history)
            
        except Exception as e:
            logger.error(f"Error getting metrics history: {e}")
            return jsonify({'error': str(e)}), 500
    
    @app.route('/api/alerts')
    def get_alerts():
        """Get active alerts."""
        try:
            if not alert_manager:
                return jsonify({'alerts': []})
            
            # Get active alerts (simplified for standalone mode)
            alerts = []
            
            # In a full implementation, this would query stored alerts
            # For now, return empty list or mock data
            
            return jsonify({'alerts': alerts})
            
        except Exception as e:
            logger.error(f"Error getting alerts: {e}")
            return jsonify({'error': str(e)}), 500
    
    @app.route('/api/alerts/<alert_id>/acknowledge', methods=['POST'])
    def acknowledge_alert(alert_id):
        """Acknowledge an alert."""
        try:
            if not alert_manager:
                return jsonify({'error': 'Alert manager not available'}), 503
            
            # Acknowledge alert (simplified)
            logger.info(f"Alert {alert_id} acknowledged")
            
            return jsonify({'status': 'acknowledged'})
            
        except Exception as e:
            logger.error(f"Error acknowledging alert: {e}")
            return jsonify({'error': str(e)}), 500
    
    @app.route('/')
    def dashboard():
        """Main dashboard page."""
        return render_template_string(DASHBOARD_HTML_TEMPLATE)
    
    @app.route('/dashboard.js')
    def dashboard_js():
        """Dashboard JavaScript."""
        return render_template_string(DASHBOARD_JS_TEMPLATE), 200, {'Content-Type': 'application/javascript'}
    
    @app.route('/dashboard.css')
    def dashboard_css():
        """Dashboard CSS."""
        return render_template_string(DASHBOARD_CSS_TEMPLATE), 200, {'Content-Type': 'text/css'}
    
    return app


# HTML Template for Dashboard
DASHBOARD_HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Crypto Trading - Standalone Monitoring</title>
    <link rel="stylesheet" href="/dashboard.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>🤖 AI Crypto Trading - Standalone Monitoring</h1>
            <div class="status-indicator" id="status-indicator">
                <span class="status-dot" id="status-dot"></span>
                <span id="status-text">Connecting...</span>
            </div>
        </header>

        <main>
            <div class="grid">
                <!-- System Overview -->
                <div class="card">
                    <h2>System Overview</h2>
                    <div class="metric-grid">
                        <div class="metric">
                            <span class="metric-label">Health Score</span>
                            <span class="metric-value" id="health-score">--</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Uptime</span>
                            <span class="metric-value" id="uptime">--</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Last Update</span>
                            <span class="metric-value" id="last-update">--</span>
                        </div>
                    </div>
                </div>

                <!-- CPU Metrics -->
                <div class="card">
                    <h2>CPU</h2>
                    <div class="metric-grid">
                        <div class="metric">
                            <span class="metric-label">Usage</span>
                            <span class="metric-value" id="cpu-usage">--</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Cores</span>
                            <span class="metric-value" id="cpu-cores">--</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Temperature</span>
                            <span class="metric-value" id="cpu-temp">--</span>
                        </div>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" id="cpu-progress"></div>
                    </div>
                </div>

                <!-- Memory Metrics -->
                <div class="card">
                    <h2>Memory</h2>
                    <div class="metric-grid">
                        <div class="metric">
                            <span class="metric-label">Usage</span>
                            <span class="metric-value" id="memory-usage">--</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Available</span>
                            <span class="metric-value" id="memory-available">--</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Total</span>
                            <span class="metric-value" id="memory-total">--</span>
                        </div>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" id="memory-progress"></div>
                    </div>
                </div>

                <!-- Disk Metrics -->
                <div class="card">
                    <h2>Disk</h2>
                    <div class="metric-grid">
                        <div class="metric">
                            <span class="metric-label">Usage</span>
                            <span class="metric-value" id="disk-usage">--</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Free</span>
                            <span class="metric-value" id="disk-free">--</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Total</span>
                            <span class="metric-value" id="disk-total">--</span>
                        </div>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" id="disk-progress"></div>
                    </div>
                </div>

                <!-- Network Metrics -->
                <div class="card">
                    <h2>Network</h2>
                    <div class="metric-grid">
                        <div class="metric">
                            <span class="metric-label">RX Bytes</span>
                            <span class="metric-value" id="network-rx">--</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">TX Bytes</span>
                            <span class="metric-value" id="network-tx">--</span>
                        </div>
                        <div class="metric">
                            <span class="metric-label">Processes</span>
                            <span class="metric-value" id="process-count">--</span>
                        </div>
                    </div>
                </div>

                <!-- Alerts -->
                <div class="card full-width">
                    <h2>Alerts</h2>
                    <div id="alerts-container">
                        <p class="no-alerts">No active alerts</p>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script src="/dashboard.js"></script>
</body>
</html>
"""

# CSS Template for Dashboard
DASHBOARD_CSS_TEMPLATE = """
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    background: #0f1419;
    color: #e6e6e6;
    line-height: 1.6;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}

header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 30px;
    padding-bottom: 20px;
    border-bottom: 1px solid #2d3748;
}

h1 {
    color: #4fd1c7;
    font-size: 1.8rem;
    font-weight: 600;
}

.status-indicator {
    display: flex;
    align-items: center;
    gap: 8px;
}

.status-dot {
    width: 12px;
    height: 12px;
    border-radius: 50%;
    background: #68d391;
    animation: pulse 2s infinite;
}

.status-dot.warning {
    background: #f6ad55;
}

.status-dot.error {
    background: #fc8181;
}

@keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
}

.grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
}

.card {
    background: #1a202c;
    border: 1px solid #2d3748;
    border-radius: 8px;
    padding: 20px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
}

.card.full-width {
    grid-column: 1 / -1;
}

.card h2 {
    color: #4fd1c7;
    margin-bottom: 15px;
    font-size: 1.2rem;
    font-weight: 500;
}

.metric-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
    gap: 15px;
    margin-bottom: 15px;
}

.metric {
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
}

.metric-label {
    font-size: 0.85rem;
    color: #a0aec0;
    margin-bottom: 5px;
}

.metric-value {
    font-size: 1.1rem;
    font-weight: 600;
    color: #e6e6e6;
}

.progress-bar {
    width: 100%;
    height: 8px;
    background: #2d3748;
    border-radius: 4px;
    overflow: hidden;
}

.progress-fill {
    height: 100%;
    background: linear-gradient(90deg, #4fd1c7, #38b2ac);
    border-radius: 4px;
    transition: width 0.3s ease;
    width: 0%;
}

.progress-fill.warning {
    background: linear-gradient(90deg, #f6ad55, #ed8936);
}

.progress-fill.critical {
    background: linear-gradient(90deg, #fc8181, #e53e3e);
}

.alert {
    background: #2d3748;
    border-left: 4px solid #4fd1c7;
    padding: 15px;
    margin-bottom: 10px;
    border-radius: 4px;
}

.alert.warning {
    border-left-color: #f6ad55;
}

.alert.critical {
    border-left-color: #fc8181;
}

.alert-title {
    font-weight: 600;
    margin-bottom: 5px;
}

.alert-message {
    color: #a0aec0;
    font-size: 0.9rem;
}

.no-alerts {
    text-align: center;
    color: #a0aec0;
    font-style: italic;
}

@media (max-width: 768px) {
    .container {
        padding: 15px;
    }
    
    header {
        flex-direction: column;
        gap: 15px;
        text-align: center;
    }
    
    .grid {
        grid-template-columns: 1fr;
    }
}
"""

# JavaScript Template for Dashboard
DASHBOARD_JS_TEMPLATE = """
class MonitoringDashboard {
    constructor() {
        this.updateInterval = 5000; // 5 seconds
        this.isConnected = false;
        this.init();
    }

    init() {
        this.updateStatus();
        setInterval(() => this.updateStatus(), this.updateInterval);
    }

    async updateStatus() {
        try {
            const response = await fetch('/api/status');
            const data = await response.json();
            
            if (response.ok) {
                this.isConnected = true;
                this.updateStatusIndicator('connected');
                this.updateMetrics(data);
            } else {
                throw new Error(data.error || 'Unknown error');
            }
        } catch (error) {
            console.error('Failed to update status:', error);
            this.isConnected = false;
            this.updateStatusIndicator('error');
        }
    }

    updateStatusIndicator(status) {
        const dot = document.getElementById('status-dot');
        const text = document.getElementById('status-text');
        
        dot.className = 'status-dot';
        
        switch (status) {
            case 'connected':
                dot.classList.add('connected');
                text.textContent = 'Connected';
                break;
            case 'warning':
                dot.classList.add('warning');
                text.textContent = 'Warning';
                break;
            case 'error':
                dot.classList.add('error');
                text.textContent = 'Disconnected';
                break;
        }
    }

    updateMetrics(data) {
        const metrics = data.current_metrics;
        if (!metrics) return;

        // Update timestamp
        const lastUpdate = new Date(metrics.timestamp);
        document.getElementById('last-update').textContent = lastUpdate.toLocaleTimeString();

        // Update health score
        const healthScore = data.health_score || 0;
        document.getElementById('health-score').textContent = `${healthScore.toFixed(1)}%`;

        // Update uptime
        if (metrics.uptime) {
            document.getElementById('uptime').textContent = this.formatUptime(metrics.uptime);
        }

        // Update CPU metrics
        document.getElementById('cpu-usage').textContent = `${metrics.cpu_usage.toFixed(1)}%`;
        document.getElementById('cpu-cores').textContent = metrics.cpu_count;
        document.getElementById('cpu-temp').textContent = metrics.cpu_temperature > 0 
            ? `${metrics.cpu_temperature.toFixed(1)}°C` : 'N/A';
        
        this.updateProgressBar('cpu-progress', metrics.cpu_usage);

        // Update memory metrics
        document.getElementById('memory-usage').textContent = `${metrics.memory_usage.toFixed(1)}%`;
        document.getElementById('memory-available').textContent = `${metrics.memory_available.toFixed(1)} GB`;
        document.getElementById('memory-total').textContent = `${metrics.memory_total.toFixed(1)} GB`;
        
        this.updateProgressBar('memory-progress', metrics.memory_usage);

        // Update disk metrics
        document.getElementById('disk-usage').textContent = `${metrics.disk_usage.toFixed(1)}%`;
        document.getElementById('disk-free').textContent = `${metrics.disk_free.toFixed(1)} GB`;
        document.getElementById('disk-total').textContent = `${metrics.disk_total.toFixed(1)} GB`;
        
        this.updateProgressBar('disk-progress', metrics.disk_usage);

        // Update network metrics
        document.getElementById('network-rx').textContent = this.formatBytes(metrics.network_rx_bytes);
        document.getElementById('network-tx').textContent = this.formatBytes(metrics.network_tx_bytes);
        document.getElementById('process-count').textContent = metrics.process_count;
    }

    updateProgressBar(elementId, percentage) {
        const progressBar = document.getElementById(elementId);
        progressBar.style.width = `${percentage}%`;
        
        // Update color based on percentage
        progressBar.className = 'progress-fill';
        if (percentage >= 95) {
            progressBar.classList.add('critical');
        } else if (percentage >= 80) {
            progressBar.classList.add('warning');
        }
    }

    formatUptime(seconds) {
        const days = Math.floor(seconds / 86400);
        const hours = Math.floor((seconds % 86400) / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        
        if (days > 0) {
            return `${days}d ${hours}h ${minutes}m`;
        } else if (hours > 0) {
            return `${hours}h ${minutes}m`;
        } else {
            return `${minutes}m`;
        }
    }

    formatBytes(bytes) {
        const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
        if (bytes === 0) return '0 B';
        
        const i = Math.floor(Math.log(bytes) / Math.log(1024));
        return `${(bytes / Math.pow(1024, i)).toFixed(1)} ${sizes[i]}`;
    }
}

// Initialize dashboard when page loads
document.addEventListener('DOMContentLoaded', () => {
    new MonitoringDashboard();
});
"""