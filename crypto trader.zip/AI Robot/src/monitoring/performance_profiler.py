"""
Performance Profiler for the AI Crypto Trading System.
Provides comprehensive code profiling, optimization analysis, and performance monitoring
with bottleneck detection, memory profiling, and AI-powered optimization suggestions.
"""

import os
import sys
import time
import threading
import logging
import cProfile
import pstats
import tracemalloc
import psutil
import gc
import inspect
import functools
import statistics
import json
import sqlite3
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List, Callable, Union, Tuple, Set
from dataclasses import dataclass, asdict, field
from collections import defaultdict, deque
from enum import Enum
from pathlib import Path
import io
import linecache
import weakref
from contextlib import contextmanager
import concurrent.futures
import queue

from .config import monitoring_config, AlertLevel
from ..utils.logging import get_logger
from ..utils.database import db_manager

class ProfilingType(Enum):
    """Types of profiling available."""
    FUNCTION = "function"
    MEMORY = "memory"
    IO = "io"
    DATABASE = "database"
    API = "api"
    MODULE = "module"
    CUSTOM = "custom"

class ProfilingMode(Enum):
    """Profiling execution modes."""
    REAL_TIME = "real_time"
    BATCH = "batch"
    SAMPLING = "sampling"
    TARGETED = "targeted"

class BottleneckType(Enum):
    """Types of performance bottlenecks."""
    CPU_INTENSIVE = "cpu_intensive"
    MEMORY_LEAK = "memory_leak"
    IO_BOUND = "io_bound"
    DATABASE_SLOW = "database_slow"
    NETWORK_LATENCY = "network_latency"
    ALGORITHM_INEFFICIENT = "algorithm_inefficient"
    CONCURRENCY_ISSUE = "concurrency_issue"

class OptimizationType(Enum):
    """Types of optimization suggestions."""
    ALGORITHM = "algorithm"
    CACHING = "caching"
    PARALLELIZATION = "parallelization"
    MEMORY = "memory"
    DATABASE = "database"
    CODE_REFACTORING = "code_refactoring"

@dataclass
class FunctionProfile:
    """Function profiling data structure."""
    function_name: str
    module_name: str
    filename: str
    line_number: int
    call_count: int
    total_time: float
    cumulative_time: float
    average_time: float
    min_time: float
    max_time: float
    memory_usage: float
    peak_memory: float
    io_operations: int
    database_queries: int
    timestamp: str
    session_id: str
    tags: Dict[str, str] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class MemoryProfile:
    """Memory profiling data structure."""
    timestamp: str
    session_id: str
    total_memory: int
    peak_memory: int
    memory_blocks: int
    memory_leaks: List[Dict[str, Any]]
    top_allocations: List[Dict[str, Any]]
    garbage_collections: int
    gc_time: float
    memory_growth_rate: float
    fragmentation_ratio: float
    tags: Dict[str, str] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class PerformanceBottleneck:
    """Performance bottleneck data structure."""
    id: str
    timestamp: str
    session_id: str
    bottleneck_type: BottleneckType
    severity: str
    function_name: str
    module_name: str
    description: str
    impact_score: float
    execution_time: float
    memory_usage: float
    call_frequency: int
    optimization_suggestions: List[str]
    code_snippet: str
    stack_trace: List[str]
    tags: Dict[str, str] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class OptimizationSuggestion:
    """Optimization suggestion data structure."""
    id: str
    timestamp: str
    session_id: str
    optimization_type: OptimizationType
    priority: str
    function_name: str
    module_name: str
    current_implementation: str
    suggested_implementation: str
    expected_improvement: float
    confidence_score: float
    implementation_complexity: str
    description: str
    code_example: str
    tags: Dict[str, str] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class ProfilingSession:
    """Profiling session management."""
    id: str
    name: str
    description: str
    profiling_types: List[ProfilingType]
    profiling_mode: ProfilingMode
    start_time: str
    end_time: Optional[str]
    duration: float
    target_components: List[str]
    sampling_interval: float
    status: str
    function_profiles: List[FunctionProfile] = field(default_factory=list)
    memory_profiles: List[MemoryProfile] = field(default_factory=list)
    bottlenecks: List[PerformanceBottleneck] = field(default_factory=list)
    optimizations: List[OptimizationSuggestion] = field(default_factory=list)
    statistics: Dict[str, Any] = field(default_factory=dict)
    tags: Dict[str, str] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

class PerformanceProfiler:
    """Main performance profiler orchestrator and session management."""
    
    def __init__(self):
        self.logger = get_logger(__name__)
        self.config = monitoring_config
        self.running = False
        
        # Session management
        self.active_sessions: Dict[str, ProfilingSession] = {}
        self.session_history: List[ProfilingSession] = []
        
        # Integration components
        self.metrics_collector = None
        self.alert_manager = None
        
        # Thread safety
        self._lock = threading.RLock()
        
        self._initialize_profiler()
    
    def _initialize_profiler(self):
        """Initialize the performance profiler."""
        try:
            # Create database schema
            self._create_profiling_tables()
            
            # Initialize integration components
            self._initialize_integrations()
            
            self.logger.info("Performance profiler initialized successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize performance profiler: {e}")
            raise
    
    def _create_profiling_tables(self):
        """Create database schema for profiling data storage."""
        try:
            with db_manager.get_cursor() as cursor:
                # Profiling sessions table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS profiling_sessions (
                        id TEXT PRIMARY KEY,
                        name TEXT NOT NULL,
                        description TEXT,
                        profiling_types TEXT,
                        profiling_mode TEXT,
                        start_time TIMESTAMP,
                        end_time TIMESTAMP,
                        duration REAL,
                        target_components TEXT,
                        sampling_interval REAL,
                        status TEXT,
                        statistics TEXT,
                        tags TEXT,
                        metadata TEXT
                    )
                """)
                
                # Function profiles table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS function_profiles (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        session_id TEXT,
                        function_name TEXT,
                        module_name TEXT,
                        filename TEXT,
                        line_number INTEGER,
                        call_count INTEGER,
                        total_time REAL,
                        cumulative_time REAL,
                        average_time REAL,
                        min_time REAL,
                        max_time REAL,
                        memory_usage REAL,
                        peak_memory REAL,
                        io_operations INTEGER,
                        database_queries INTEGER,
                        timestamp TIMESTAMP,
                        tags TEXT,
                        metadata TEXT,
                        FOREIGN KEY (session_id) REFERENCES profiling_sessions (id)
                    )
                """)
                
                # Create indexes
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_function_profiles_session ON function_profiles(session_id)")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_sessions_timestamp ON profiling_sessions(start_time)")
                
        except Exception as e:
            self.logger.error(f"Failed to create profiling tables: {e}")
            raise
    
    def _initialize_integrations(self):
        """Initialize integration with other monitoring components."""
        try:
            # Import and integrate with metrics collector
            from .metrics_collector import metrics_collector
            self.metrics_collector = metrics_collector
            
            # Import and integrate with alert manager
            from .alert_manager import alert_manager
            self.alert_manager = alert_manager
            
            self.logger.info("Initialized monitoring component integrations")
            
        except Exception as e:
            self.logger.warning(f"Failed to initialize integrations: {e}")
    
    def create_session(self, name: str, description: str = "", 
                      profiling_types: List[ProfilingType] = None,
                      profiling_mode: ProfilingMode = ProfilingMode.REAL_TIME,
                      target_components: List[str] = None,
                      sampling_interval: float = None,
                      tags: Dict[str, str] = None,
                      metadata: Dict[str, Any] = None) -> str:
        """Create a new profiling session."""
        try:
            session_id = f"prof_{int(time.time() * 1000)}"
            
            if profiling_types is None:
                profiling_types = [ProfilingType.FUNCTION, ProfilingType.MEMORY]
            
            if target_components is None:
                target_components = ["all"]
            
            if sampling_interval is None:
                sampling_interval = self.config.profiler.sampling_interval
            
            session = ProfilingSession(
                id=session_id,
                name=name,
                description=description,
                profiling_types=profiling_types,
                profiling_mode=profiling_mode,
                start_time=datetime.now().isoformat(),
                end_time=None,
                duration=0.0,
                target_components=target_components,
                sampling_interval=sampling_interval,
                status="active",
                tags=tags or {},
                metadata=metadata or {}
            )
            
            with self._lock:
                self.active_sessions[session_id] = session
            
            self.logger.info(f"Created profiling session: {session_id}")
            return session_id
            
        except Exception as e:
            self.logger.error(f"Failed to create profiling session: {e}")
            raise
    
    def end_session(self, session_id: str) -> ProfilingSession:
        """End a profiling session and return results."""
        try:
            with self._lock:
                if session_id not in self.active_sessions:
                    raise ValueError(f"Session not found: {session_id}")
                
                session = self.active_sessions[session_id]
                session.end_time = datetime.now().isoformat()
                session.duration = (datetime.fromisoformat(session.end_time) - 
                                  datetime.fromisoformat(session.start_time)).total_seconds()
                session.status = "completed"
                
                # Store session in database
                self._store_session(session)
                
                # Move to history
                self.session_history.append(session)
                del self.active_sessions[session_id]
                
                self.logger.info(f"Ended profiling session: {session_id}")
                return session
                
        except Exception as e:
            self.logger.error(f"Failed to end profiling session: {e}")
            raise
    
    def _store_session(self, session: ProfilingSession):
        """Store profiling session in database."""
        try:
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    INSERT OR REPLACE INTO profiling_sessions (
                        id, name, description, profiling_types, profiling_mode,
                        start_time, end_time, duration, target_components,
                        sampling_interval, status, statistics, tags, metadata
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    session.id, session.name, session.description,
                    json.dumps([pt.value for pt in session.profiling_types]),
                    session.profiling_mode.value, session.start_time, session.end_time,
                    session.duration, json.dumps(session.target_components),
                    session.sampling_interval, session.status,
                    json.dumps(session.statistics), json.dumps(session.tags),
                    json.dumps(session.metadata)
                ))
                
        except Exception as e:
            self.logger.error(f"Failed to store session: {e}")
    
    def get_session(self, session_id: str) -> Optional[ProfilingSession]:
        """Get a profiling session by ID."""
        with self._lock:
            # Check active sessions first
            if session_id in self.active_sessions:
                return self.active_sessions[session_id]
            
            # Check history
            for session in self.session_history:
                if session.id == session_id:
                    return session
            
            return None
    
    def list_sessions(self, status: str = None, limit: int = 50) -> List[ProfilingSession]:
        """List profiling sessions with optional filtering."""
        try:
            sessions = []
            
            # Add active sessions
            with self._lock:
                for session in self.active_sessions.values():
                    if status is None or session.status == status:
                        sessions.append(session)
            
            # Add historical sessions
            for session in self.session_history:
                if status is None or session.status == status:
                    sessions.append(session)
            
            # Sort by start time (newest first) and limit
            sessions.sort(key=lambda s: s.start_time, reverse=True)
            return sessions[:limit]
            
        except Exception as e:
            self.logger.error(f"Failed to list sessions: {e}")
            return []
    
    def get_health_status(self) -> Dict[str, Any]:
        """Get health status of the performance profiler."""
        try:
            return {
                'running': self.running,
                'active_sessions_count': len(self.active_sessions),
                'total_sessions_count': len(self.session_history) + len(self.active_sessions),
                'profiler_enabled': self.config.profiler.enabled,
                'sampling_interval': self.config.profiler.sampling_interval,
                'memory_profiling_enabled': self.config.profiler.memory_profiling,
                'cpu_profiling_enabled': self.config.profiler.cpu_profiling,
                'io_profiling_enabled': self.config.profiler.io_profiling,
                'database_profiling_enabled': self.config.profiler.database_profiling
            }
            
        except Exception as e:
            self.logger.error(f"Failed to get health status: {e}")
            return {'error': str(e)}

# Profiling Decorators
def profile_function(session_id: str = None, profiler_instance=None):
    """Decorator for function-level profiling."""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            if profiler_instance and session_id:
                start_time = time.time()
                try:
                    result = func(*args, **kwargs)
                    execution_time = time.time() - start_time
                    
                    # Record function execution (simplified)
                    profiler_instance.logger.debug(
                        f"Function {func.__name__} executed in {execution_time:.4f}s"
                    )
                    
                    return result
                except Exception as e:
                    execution_time = time.time() - start_time
                    profiler_instance.logger.warning(
                        f"Function {func.__name__} failed after {execution_time:.4f}s: {e}"
                    )
                    raise
            else:
                return func(*args, **kwargs)
        return wrapper
    return decorator

def profile_memory(session_id: str = None, profiler_instance=None):
    """Decorator for memory profiling."""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            if profiler_instance and session_id and tracemalloc.is_tracing():
                snapshot_before = tracemalloc.take_snapshot()
                
                try:
                    result = func(*args, **kwargs)
                    
                    snapshot_after = tracemalloc.take_snapshot()
                    top_stats = snapshot_after.compare_to(snapshot_before, 'lineno')
                    
                    if top_stats:
                        memory_diff = sum(stat.size_diff for stat in top_stats)
                        profiler_instance.logger.debug(
                            f"Function {func.__name__} memory change: {memory_diff} bytes"
                        )
                    
                    return result
                except Exception as e:
                    profiler_instance.logger.warning(
                        f"Memory profiling failed for {func.__name__}: {e}"
                    )
                    raise
            else:
                return func(*args, **kwargs)
        return wrapper
    return decorator

def profile_io(session_id: str = None, profiler_instance=None):
    """Decorator for I/O profiling."""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            if profiler_instance and session_id:
                start_time = time.time()
                try:
                    io_start = psutil.Process().io_counters()
                except:
                    io_start = None
                
                try:
                    result = func(*args, **kwargs)
                    
                    execution_time = time.time() - start_time
                    if io_start:
                        try:
                            io_end = psutil.Process().io_counters()
                            io_operations = (io_end.read_count - io_start.read_count + 
                                           io_end.write_count - io_start.write_count)
                            profiler_instance.logger.debug(
                                f"Function {func.__name__} I/O: {io_operations} operations in {execution_time:.4f}s"
                            )
                        except:
                            pass
                    
                    return result
                except Exception as e:
                    execution_time = time.time() - start_time
                    profiler_instance.logger.warning(
                        f"I/O profiling failed for {func.__name__}: {e}"
                    )
                    raise
            else:
                return func(*args, **kwargs)
        return wrapper
    return decorator

def profile_database(session_id: str = None, profiler_instance=None):
    """Decorator for database profiling."""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            if profiler_instance and session_id:
                start_time = time.time()
                
                try:
                    result = func(*args, **kwargs)
                    execution_time = time.time() - start_time
                    
                    # Estimate database queries (simplified)
                    query_count = 1 if 'query' in func.__name__.lower() or 'execute' in func.__name__.lower() else 0
                    
                    profiler_instance.logger.debug(
                        f"Database function {func.__name__}: {execution_time:.4f}s, {query_count} queries"
                    )
                    
                    return result
                except Exception as e:
                    execution_time = time.time() - start_time
                    profiler_instance.logger.warning(
                        f"Database profiling failed for {func.__name__}: {e}"
                    )
                    raise
            else:
                return func(*args, **kwargs)
        return wrapper
    return decorator

def profile_api(session_id: str = None, profiler_instance=None):
    """Decorator for API profiling."""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            if profiler_instance and session_id:
                start_time = time.time()
                
                try:
                    result = func(*args, **kwargs)
                    execution_time = time.time() - start_time
                    
                    response_size = len(str(result)) if result else 0
                    profiler_instance.logger.debug(
                        f"API function {func.__name__}: {execution_time:.4f}s, {response_size} bytes"
                    )
                    
                    return result
                except Exception as e:
                    execution_time = time.time() - start_time
                    profiler_instance.logger.warning(
                        f"API profiling failed for {func.__name__}: {e}"
                    )
                    raise
            else:
                return func(*args, **kwargs)
        return wrapper
    return decorator

def profile_custom(session_id: str = None, profiler_instance=None, metrics: List[str] = None):
    """Decorator for custom profiling with user-defined metrics."""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            if profiler_instance and session_id:
                start_time = time.time()
                custom_metrics = {}
                
                try:
                    result = func(*args, **kwargs)
                    execution_time = time.time() - start_time
                    
                    # Collect custom metrics
                    if metrics:
                        for metric in metrics:
                            if hasattr(result, metric):
                                custom_metrics[metric] = getattr(result, metric)
                    
                    profiler_instance.logger.debug(
                        f"Custom profiling {func.__name__}: {execution_time:.4f}s, metrics: {custom_metrics}"
                    )
                    
                    return result
                except Exception as e:
                    execution_time = time.time() - start_time
                    profiler_instance.logger.warning(
                        f"Custom profiling failed for {func.__name__}: {e}"
                    )
                    raise
            else:
                return func(*args, **kwargs)
        return wrapper
    return decorator

# Global performance profiler instance
performance_profiler = PerformanceProfiler()