"""
AI Performance Monitor for the AI Crypto Trading System.
Tracks trading performance, AI decision accuracy, model performance degradation,
and provides optimization suggestions.
"""

import time
import threading
import logging
import statistics
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List, Tuple
from dataclasses import dataclass, asdict
from collections import deque, defaultdict
import json
from enum import Enum

from .config import monitoring_config, AlertLevel
from ..utils.logging import get_logger
from ..utils.database import db_manager

class DecisionType(Enum):
    """Types of AI decisions."""
    SCAN = "scan"
    ANALYZE = "analyze"
    COMBINE = "combine"
    EXECUTE = "execute"
    CONTROL = "control"

class PerformanceMetric(Enum):
    """Performance metrics for AI modules."""
    ACCURACY = "accuracy"
    CONFIDENCE = "confidence"
    RESPONSE_TIME = "response_time"
    ERROR_RATE = "error_rate"
    THROUGHPUT = "throughput"

@dataclass
class TradingPerformance:
    """Trading performance metrics."""
    timestamp: str
    total_trades: int
    winning_trades: int
    losing_trades: int
    win_rate: float
    total_pnl: float
    avg_pnl: float
    max_drawdown: float
    current_drawdown: float
    sharpe_ratio: float
    profit_factor: float
    avg_trade_duration: float
    consecutive_wins: int
    consecutive_losses: int
    largest_win: float
    largest_loss: float
    risk_reward_ratio: float

@dataclass
class AIDecisionMetrics:
    """AI decision performance metrics."""
    timestamp: str
    module_name: str
    decision_type: str
    confidence_score: float
    execution_time: float
    success: bool
    accuracy_score: float
    input_complexity: float
    output_quality: float
    error_message: Optional[str]
    prediction_accuracy: Optional[float]

@dataclass
class ModelPerformance:
    """Model performance tracking."""
    timestamp: str
    module_name: str
    model_version: str
    accuracy_trend: float
    confidence_trend: float
    response_time_trend: float
    error_rate_trend: float
    drift_score: float
    degradation_score: float
    optimization_suggestions: List[str]

class AIPerformanceMonitor:
    """Monitor AI performance across all modules."""
    
    def __init__(self):
        self.logger = get_logger(__name__)
        self.config = monitoring_config
        self.running = False
        self.monitor_thread: Optional[threading.Thread] = None
        
        # Performance tracking
        self.decision_history = deque(maxlen=10000)
        self.trading_metrics = deque(maxlen=1000)
        self.model_performance = {}
        self.baseline_metrics = {}
        
        # Alert tracking
        self.alert_states = defaultdict(bool)
        self.alert_callbacks = []
        
        # Module tracking
        self.module_stats = defaultdict(lambda: {
            'decisions': deque(maxlen=1000),
            'response_times': deque(maxlen=100),
            'confidence_scores': deque(maxlen=100),
            'error_count': 0,
            'last_activity': None
        })
        
        self._initialize_monitoring()
    
    def _initialize_monitoring(self):
        """Initialize AI performance monitoring."""
        try:
            # Create monitoring tables
            self._create_ai_monitoring_tables()
            
            # Load baseline metrics
            self._load_baseline_metrics()
            
            self.logger.info("AI performance monitor initialized")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize AI monitor: {e}")
            raise
    
    def _create_ai_monitoring_tables(self):
        """Create database tables for AI monitoring."""
        try:
            with db_manager.get_cursor() as cursor:
                # Trading performance table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS trading_performance (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        total_trades INTEGER,
                        winning_trades INTEGER,
                        losing_trades INTEGER,
                        win_rate REAL,
                        total_pnl REAL,
                        avg_pnl REAL,
                        max_drawdown REAL,
                        current_drawdown REAL,
                        sharpe_ratio REAL,
                        profit_factor REAL,
                        avg_trade_duration REAL,
                        consecutive_wins INTEGER,
                        consecutive_losses INTEGER,
                        largest_win REAL,
                        largest_loss REAL,
                        risk_reward_ratio REAL
                    )
                """)
                
                # AI decision metrics table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS ai_decision_metrics (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        module_name TEXT,
                        decision_type TEXT,
                        confidence_score REAL,
                        execution_time REAL,
                        success BOOLEAN,
                        accuracy_score REAL,
                        input_complexity REAL,
                        output_quality REAL,
                        error_message TEXT,
                        prediction_accuracy REAL
                    )
                """)
                
                # AI alerts table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS ai_alerts (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        alert_type TEXT,
                        severity TEXT,
                        module_name TEXT,
                        metric_name TEXT,
                        metric_value REAL,
                        threshold_value REAL,
                        message TEXT,
                        acknowledged BOOLEAN DEFAULT FALSE,
                        resolved BOOLEAN DEFAULT FALSE
                    )
                """)
                
                # Create indexes
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_trading_performance_timestamp ON trading_performance(timestamp)")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_ai_decision_metrics_module ON ai_decision_metrics(module_name, timestamp)")
                
        except Exception as e:
            self.logger.error(f"Failed to create AI monitoring tables: {e}")
    
    def _load_baseline_metrics(self):
        """Load baseline performance metrics for comparison."""
        try:
            # Load recent performance data to establish baselines
            cutoff_time = datetime.now() - timedelta(days=7)
            
            with db_manager.get_cursor() as cursor:
                # Get baseline trading performance
                cursor.execute("""
                    SELECT AVG(win_rate) as avg_win_rate, AVG(sharpe_ratio) as avg_sharpe
                    FROM trading_performance 
                    WHERE timestamp >= ?
                """, (cutoff_time.isoformat(),))
                
                row = cursor.fetchone()
                if row and row['avg_win_rate']:
                    self.baseline_metrics['trading'] = {
                        'win_rate': row['avg_win_rate'],
                        'sharpe_ratio': row['avg_sharpe'] or 0.0
                    }
                
                # Get baseline AI metrics by module
                cursor.execute("""
                    SELECT module_name, 
                           AVG(confidence_score) as avg_confidence,
                           AVG(execution_time) as avg_response_time,
                           AVG(accuracy_score) as avg_accuracy
                    FROM ai_decision_metrics 
                    WHERE timestamp >= ? AND success = TRUE
                    GROUP BY module_name
                """, (cutoff_time.isoformat(),))
                
                for row in cursor.fetchall():
                    self.baseline_metrics[row['module_name']] = {
                        'confidence': row['avg_confidence'] or 0.0,
                        'response_time': row['avg_response_time'] or 0.0,
                        'accuracy': row['avg_accuracy'] or 0.0
                    }
            
            self.logger.info(f"Loaded baseline metrics for {len(self.baseline_metrics)} components")
            
        except Exception as e:
            self.logger.warning(f"Failed to load baseline metrics: {e}")
    
    def start_monitoring(self):
        """Start AI performance monitoring."""
        if not self.running:
            self.running = True
            self.monitor_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
            self.monitor_thread.start()
            self.logger.info("AI performance monitoring started")
    
    def stop_monitoring(self):
        """Stop AI performance monitoring."""
        self.running = False
        if self.monitor_thread:
            self.monitor_thread.join(timeout=5)
        self.logger.info("AI performance monitoring stopped")
    
    def add_alert_callback(self, callback):
        """Add callback for AI performance alerts."""
        self.alert_callbacks.append(callback)
    
    def _monitoring_loop(self):
        """Main AI monitoring loop."""
        while self.running:
            try:
                # Update trading performance metrics
                self._update_trading_performance()
                
                # Analyze AI decision patterns
                self._analyze_decision_patterns()
                
                # Check for model degradation
                self._check_model_degradation()
                
                # Generate optimization suggestions
                self._generate_optimization_suggestions()
                
                # Check for alerts
                self._check_ai_alerts()
                
                # Sleep for monitoring interval
                time.sleep(self.config.metrics.collection_interval)
                
            except Exception as e:
                self.logger.error(f"Error in AI monitoring loop: {e}")
                time.sleep(5)
    
    def record_decision(self, module_name: str, decision_type: DecisionType, 
                       confidence: float, execution_time: float, success: bool,
                       input_data: Dict[str, Any], output_data: Dict[str, Any],
                       error_message: Optional[str] = None):
        """Record an AI decision for performance tracking."""
        try:
            # Calculate complexity and quality scores
            input_complexity = self._calculate_input_complexity(input_data)
            output_quality = self._calculate_output_quality(output_data, success)
            
            # Create decision metrics
            metrics = AIDecisionMetrics(
                timestamp=datetime.now().isoformat(),
                module_name=module_name,
                decision_type=decision_type.value,
                confidence_score=confidence,
                execution_time=execution_time,
                success=success,
                accuracy_score=0.0,  # Will be updated later with actual results
                input_complexity=input_complexity,
                output_quality=output_quality,
                error_message=error_message,
                prediction_accuracy=None
            )
            
            # Store in history
            self.decision_history.append(metrics)
            
            # Update module stats
            self.module_stats[module_name]['decisions'].append(metrics)
            self.module_stats[module_name]['response_times'].append(execution_time)
            self.module_stats[module_name]['confidence_scores'].append(confidence)
            self.module_stats[module_name]['last_activity'] = datetime.now()
            
            if not success:
                self.module_stats[module_name]['error_count'] += 1
            
            # Store in database
            self._store_decision_metrics(metrics)
            
            self.logger.debug(f"Recorded decision for {module_name}: {decision_type.value}")
            
        except Exception as e:
            self.logger.error(f"Failed to record decision: {e}")
    
    def _calculate_input_complexity(self, input_data: Dict[str, Any]) -> float:
        """Calculate complexity score of input data."""
        try:
            complexity_score = 0.0
            
            # Count data points
            data_points = len(str(input_data))
            complexity_score += min(data_points / 1000, 1.0) * 30
            
            # Count nested structures
            nested_count = str(input_data).count('{') + str(input_data).count('[')
            complexity_score += min(nested_count / 10, 1.0) * 20
            
            # Check for time series data
            if any('price' in str(k).lower() or 'volume' in str(k).lower() 
                   for k in input_data.keys() if isinstance(k, str)):
                complexity_score += 25
            
            # Check for multiple symbols/markets
            if 'symbols' in input_data or 'markets' in input_data:
                symbol_count = len(input_data.get('symbols', input_data.get('markets', [])))
                complexity_score += min(symbol_count / 10, 1.0) * 25
            
            return min(complexity_score, 100.0)
            
        except:
            return 50.0  # Default complexity
    
    def _calculate_output_quality(self, output_data: Dict[str, Any], success: bool) -> float:
        """Calculate quality score of output data."""
        try:
            if not success:
                return 0.0
            
            quality_score = 50.0  # Base score for successful execution
            
            # Check for confidence scores
            if 'confidence' in output_data:
                confidence = output_data['confidence']
                if isinstance(confidence, (int, float)):
                    quality_score += (confidence / 100) * 20
            
            # Check for detailed analysis
            if 'analysis' in output_data or 'reasoning' in output_data:
                quality_score += 15
            
            # Check for risk assessment
            if 'risk' in output_data or 'risk_score' in output_data:
                quality_score += 10
            
            # Check for multiple recommendations
            if 'recommendations' in output_data:
                rec_count = len(output_data['recommendations'])
                quality_score += min(rec_count * 2, 10)
            
            return min(quality_score, 100.0)
            
        except:
            return 25.0  # Default quality for successful execution
    
    def _store_decision_metrics(self, metrics: AIDecisionMetrics):
        """Store decision metrics in database."""
        try:
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    INSERT INTO ai_decision_metrics (
                        timestamp, module_name, decision_type, confidence_score,
                        execution_time, success, accuracy_score, input_complexity,
                        output_quality, error_message, prediction_accuracy
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    metrics.timestamp, metrics.module_name, metrics.decision_type,
                    metrics.confidence_score, metrics.execution_time, metrics.success,
                    metrics.accuracy_score, metrics.input_complexity, metrics.output_quality,
                    metrics.error_message, metrics.prediction_accuracy
                ))
        except Exception as e:
            self.logger.error(f"Failed to store decision metrics: {e}")
    
    def _update_trading_performance(self):
        """Update trading performance metrics."""
        try:
            # Get recent trades from database
            cutoff_time = datetime.now() - timedelta(days=1)
            
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    SELECT * FROM trades 
                    WHERE entry_time >= ? AND status = 'closed'
                    ORDER BY entry_time DESC
                """, (cutoff_time.isoformat(),))
                
                trades = cursor.fetchall()
                
                if not trades:
                    return
                
                # Calculate performance metrics
                total_trades = len(trades)
                winning_trades = sum(1 for trade in trades if trade['pnl'] > 0)
                losing_trades = total_trades - winning_trades
                win_rate = (winning_trades / total_trades) * 100 if total_trades > 0 else 0
                
                total_pnl = sum(trade['pnl'] for trade in trades if trade['pnl'])
                avg_pnl = total_pnl / total_trades if total_trades > 0 else 0
                
                # Calculate drawdown
                running_pnl = 0
                peak_pnl = 0
                max_drawdown = 0
                current_drawdown = 0
                
                for trade in reversed(trades):
                    running_pnl += trade['pnl'] or 0
                    if running_pnl > peak_pnl:
                        peak_pnl = running_pnl
                    drawdown = peak_pnl - running_pnl
                    if drawdown > max_drawdown:
                        max_drawdown = drawdown
                
                current_drawdown = peak_pnl - running_pnl
                
                # Calculate other metrics
                pnl_values = [trade['pnl'] for trade in trades if trade['pnl']]
                sharpe_ratio = self._calculate_sharpe_ratio(pnl_values)
                profit_factor = self._calculate_profit_factor(pnl_values)
                
                # Calculate consecutive wins/losses
                consecutive_wins, consecutive_losses = self._calculate_consecutive_trades(trades)
                
                # Find largest win/loss
                largest_win = max(pnl_values) if pnl_values else 0
                largest_loss = min(pnl_values) if pnl_values else 0
                
                # Calculate risk-reward ratio
                avg_win = statistics.mean([pnl for pnl in pnl_values if pnl > 0]) if any(pnl > 0 for pnl in pnl_values) else 0
                avg_loss = abs(statistics.mean([pnl for pnl in pnl_values if pnl < 0])) if any(pnl < 0 for pnl in pnl_values) else 1
                risk_reward_ratio = avg_win / avg_loss if avg_loss > 0 else 0
                
                # Calculate average trade duration
                durations = []
                for trade in trades:
                    if trade['entry_time'] and trade['exit_time']:
                        entry_time = datetime.fromisoformat(trade['entry_time'])
                        exit_time = datetime.fromisoformat(trade['exit_time'])
                        duration = (exit_time - entry_time).total_seconds() / 3600  # hours
                        durations.append(duration)
                
                avg_trade_duration = statistics.mean(durations) if durations else 0
                
                # Create performance metrics
                performance = TradingPerformance(
                    timestamp=datetime.now().isoformat(),
                    total_trades=total_trades,
                    winning_trades=winning_trades,
                    losing_trades=losing_trades,
                    win_rate=win_rate,
                    total_pnl=total_pnl,
                    avg_pnl=avg_pnl,
                    max_drawdown=max_drawdown,
                    current_drawdown=current_drawdown,
                    sharpe_ratio=sharpe_ratio,
                    profit_factor=profit_factor,
                    avg_trade_duration=avg_trade_duration,
                    consecutive_wins=consecutive_wins,
                    consecutive_losses=consecutive_losses,
                    largest_win=largest_win,
                    largest_loss=largest_loss,
                    risk_reward_ratio=risk_reward_ratio
                )
                
                # Store performance metrics
                self.trading_metrics.append(performance)
                self._store_trading_performance(performance)
                
        except Exception as e:
            self.logger.error(f"Failed to update trading performance: {e}")
    
    def _calculate_sharpe_ratio(self, pnl_values: List[float]) -> float:
        """Calculate Sharpe ratio for trading performance."""
        try:
            if len(pnl_values) < 2:
                return 0.0
            
            mean_return = statistics.mean(pnl_values)
            std_return = statistics.stdev(pnl_values)
            
            if std_return == 0:
                return 0.0
            
            # Assuming risk-free rate of 0 for simplicity
            sharpe_ratio = mean_return / std_return
            return sharpe_ratio
            
        except:
            return 0.0
    
    def _calculate_profit_factor(self, pnl_values: List[float]) -> float:
        """Calculate profit factor (gross profit / gross loss)."""
        try:
            gross_profit = sum(pnl for pnl in pnl_values if pnl > 0)
            gross_loss = abs(sum(pnl for pnl in pnl_values if pnl < 0))
            
            if gross_loss == 0:
                return float('inf') if gross_profit > 0 else 0.0
            
            return gross_profit / gross_loss
            
        except:
            return 0.0
    
    def _calculate_consecutive_trades(self, trades: List[Dict]) -> Tuple[int, int]:
        """Calculate consecutive wins and losses."""
        try:
            consecutive_wins = 0
            consecutive_losses = 0
            current_wins = 0
            current_losses = 0
            
            for trade in trades:
                pnl = trade['pnl'] or 0
                if pnl > 0:
                    current_wins += 1
                    current_losses = 0
                    consecutive_wins = max(consecutive_wins, current_wins)
                elif pnl < 0:
                    current_losses += 1
                    current_wins = 0
                    consecutive_losses = max(consecutive_losses, current_losses)
            
            return consecutive_wins, consecutive_losses
            
        except:
            return 0, 0
    
    def _store_trading_performance(self, performance: TradingPerformance):
        """Store trading performance in database."""
        try:
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    INSERT INTO trading_performance (
                        timestamp, total_trades, winning_trades, losing_trades, win_rate,
                        total_pnl, avg_pnl, max_drawdown, current_drawdown, sharpe_ratio,
                        profit_factor, avg_trade_duration, consecutive_wins, consecutive_losses,
                        largest_win, largest_loss, risk_reward_ratio
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    performance.timestamp, performance.total_trades, performance.winning_trades,
                    performance.losing_trades, performance.win_rate, performance.total_pnl,
                    performance.avg_pnl, performance.max_drawdown, performance.current_drawdown,
                    performance.sharpe_ratio, performance.profit_factor, performance.avg_trade_duration,
                    performance.consecutive_wins, performance.consecutive_losses, performance.largest_win,
                    performance.largest_loss, performance.risk_reward_ratio
                ))
        except Exception as e:
            self.logger.error(f"Failed to store trading performance: {e}")
    
    def _analyze_decision_patterns(self):
        """Analyze AI decision patterns for insights."""
        try:
            for module_name, stats in self.module_stats.items():
                if len(stats['decisions']) < 10:
                    continue
                
                recent_decisions = list(stats['decisions'])[-50:]  # Last 50 decisions
                
                # Calculate trends
                confidence_trend = self._calculate_trend([d.confidence_score for d in recent_decisions])
                response_time_trend = self._calculate_trend([d.execution_time for d in recent_decisions])
                success_rate = sum(1 for d in recent_decisions if d.success) / len(recent_decisions)
                
                # Store analysis results
                self.model_performance[module_name] = {
                    'confidence_trend': confidence_trend,
                    'response_time_trend': response_time_trend,
                    'success_rate': success_rate,
                    'last_updated': datetime.now().isoformat()
                }
                
        except Exception as e:
            self.logger.error(f"Failed to analyze decision patterns: {e}")
    
    def _calculate_trend(self, values: List[float]) -> float:
        """Calculate trend direction (-1 to 1, negative = declining, positive = improving)."""
        try:
            if len(values) < 2:
                return 0.0
            
            # Simple linear regression slope
            n = len(values)
            x = list(range(n))
            
            sum_x = sum(x)
            sum_y = sum(values)
            sum_xy = sum(x[i] * values[i] for i in range(n))
            sum_x2 = sum(x[i] ** 2 for i in range(n))
            
            slope = (n * sum_xy - sum_x * sum_y) / (n * sum_x2 - sum_x ** 2)
            
            # Normalize slope to -1 to 1 range
            max_value = max(values)
            min_value = min(values)
            value_range = max_value - min_value
            
            if value_range == 0:
                return 0.0
            
            normalized_slope = slope / (value_range / n)
            return max(-1.0, min(1.0, normalized_slope))
            
        except:
            return 0.0
    
    def _check_model_degradation(self):
        """Check for model performance degradation."""
        try:
            for module_name, performance in self.model_performance.items():
                baseline = self.baseline_metrics.get(module_name, {})
                
                # Check for significant degradation
                degradation_score = 0.0
                
                if 'confidence' in baseline and self.module_stats[module_name]['confidence_scores']:
                    current_confidence = statistics.mean(list(self.module_stats[module_name]['confidence_scores']))
                    confidence_degradation = (baseline['confidence'] - current_confidence) / baseline['confidence']
                    degradation_score += max(0, confidence_degradation) * 40
                
                if 'response_time' in baseline and self.module_stats[module_name]['response_times']:
                    current_response_time = statistics.mean(list(self.module_stats[module_name]['response_times']))
                    response_time_degradation = (current_response_time - baseline['response_time']) / baseline['response_time']
                    degradation_score += max(0, response_time_degradation) * 30
                
                # Error rate degradation
                recent_decisions = list(self.module_stats[module_name]['decisions'])[-100:]
                if recent_decisions:
                    error_rate = sum(1 for d in recent_decisions if not d.success) / len(recent_decisions)
                    degradation_score += error_rate * 30
                
                # Store degradation score
                performance['degradation_score'] = degradation_score
                
                # Generate alerts if degradation is significant
                if degradation_score > 50:
                    self._create_degradation_alert(module_name, degradation_score)
                
        except Exception as e:
            self.logger.error(f"Failed to check model degradation: {e}")
    
    def _generate_optimization_suggestions(self):
        """Generate optimization suggestions based on performance analysis."""
        try:
            for module_name, performance in self.model_performance.items():
                suggestions = []
                
                # Response time optimization
                if performance.get('response_time_trend', 0) > 0.3:
                    suggestions.append("Consider optimizing model inference time")
                    suggestions.append("Review input data preprocessing efficiency")
                
                # Confidence optimization
                if performance.get('confidence_trend', 0) < -0.3:
                    suggestions.append("Review model training data quality")
                    suggestions.append("Consider model retraining with recent data")
                
                # Success rate optimization
                if performance.get('success_rate', 1.0) < 0.8:
                    suggestions.append("Investigate common failure patterns")
                    suggestions.append("Review error handling and retry logic")
                
                # Degradation optimization
                if performance.get('degradation_score', 0) > 30:
                    suggestions.append("Model performance degradation detected")
                    suggestions.append("Consider immediate model evaluation and retraining")
                
                performance['optimization_suggestions'] = suggestions
                
        except Exception as e:
            self.logger.error(f"Failed to generate optimization suggestions: {e}")
    
    def _check_ai_alerts(self):
        """Check AI performance metrics against thresholds."""
        try:
            thresholds = self.config.ai_thresholds
            alerts = []
            
            # Check each module's performance
            for module_name, stats in self.module_stats.items():
                if not stats['decisions']:
                    continue
                
                recent_decisions = list(stats['decisions'])[-10:]  # Last 10 decisions
                
                # Calculate current metrics
                avg_confidence = statistics.mean([d.confidence_score for d in recent_decisions])
                avg_response_time = statistics.mean([d.execution_time for d in recent_decisions])
                success_rate = sum(1 for d in recent_decisions if d.success) / len(recent_decisions)
                error_rate = (1 - success_rate) * 100
                
                # Check confidence alerts
                if avg_confidence <= thresholds.confidence_critical:
                    alerts.append(self._create_ai_alert(module_name, "confidence", avg_confidence, 
                                                      thresholds.confidence_critical, AlertLevel.CRITICAL))
                elif avg_confidence <= thresholds.confidence_warning:
                    alerts.append(self._create_ai_alert(module_name, "confidence", avg_confidence, 
                                                      thresholds.confidence_warning, AlertLevel.WARNING))
                
                # Check response time alerts
                if avg_response_time >= thresholds.response_time_critical:
                    alerts.append(self._create_ai_alert(module_name, "response_time", avg_response_time, 
                                                      thresholds.response_time_critical, AlertLevel.CRITICAL))
                elif avg_response_time >= thresholds.response_time_warning:
                    alerts.append(self._create_ai_alert(module_name, "response_time", avg_response_time, 
                                                      thresholds.response_time_warning, AlertLevel.WARNING))
                
                # Check error rate alerts
                if error_rate >= thresholds.error_rate_critical:
                    alerts.append(self._create_ai_alert(module_name, "error_rate", error_rate, 
                                                      thresholds.error_rate_critical, AlertLevel.CRITICAL))
                elif error_rate >= thresholds.error_rate_warning:
                    alerts.append(self._create_ai_alert(module_name, "error_rate", error_rate, 
                                                      thresholds.error_rate_warning, AlertLevel.WARNING))
            
            # Check trading performance alerts
            if self.trading_metrics:
                latest_performance = self.trading_metrics[-1]
                
                # Win rate alerts
                if latest_performance.win_rate <= self.config.trading_thresholds.win_rate_critical:
                    alerts.append(self._create_ai_alert("trading", "win_rate", latest_performance.win_rate,
                                                      self.config.trading_thresholds.win_rate_critical, AlertLevel.CRITICAL))
                elif latest_performance.win_rate <= self.config.trading_thresholds.win_rate_warning:
                    alerts.append(self._create_ai_alert("trading", "win_rate", latest_performance.win_rate,
                                                      self.config.trading_thresholds.win_rate_warning, AlertLevel.WARNING))
                
                # Drawdown alerts
                if latest_performance.current_drawdown >= self.config.trading_thresholds.max_drawdown_critical:
                    alerts.append(self._create_ai_alert("trading", "current_drawdown", latest_performance.current_drawdown,
                                                      self.config.trading_thresholds.max_drawdown_critical, AlertLevel.CRITICAL))
                elif latest_performance.current_drawdown >= self.config.trading_thresholds.max_drawdown_warning:
                    alerts.append(self._create_ai_alert("trading", "current_drawdown", latest_performance.current_drawdown,
                                                      self.config.trading_thresholds.max_drawdown_warning, AlertLevel.WARNING))
                
                # Consecutive losses alerts
                if latest_performance.consecutive_losses >= self.config.trading_thresholds.consecutive_losses_critical:
                    alerts.append(self._create_ai_alert("trading", "consecutive_losses", latest_performance.consecutive_losses,
                                                      self.config.trading_thresholds.consecutive_losses_critical, AlertLevel.CRITICAL))
                elif latest_performance.consecutive_losses >= self.config.trading_thresholds.consecutive_losses_warning:
                    alerts.append(self._create_ai_alert("trading", "consecutive_losses", latest_performance.consecutive_losses,
                                                      self.config.trading_thresholds.consecutive_losses_warning, AlertLevel.WARNING))
            
            # Process alerts
            for alert in alerts:
                self._handle_ai_alert(alert)
                
        except Exception as e:
            self.logger.error(f"Failed to check AI alerts: {e}")
    
    def _create_ai_alert(self, module_name: str, metric_name: str, metric_value: float, 
                        threshold_value: float, severity: AlertLevel) -> Dict[str, Any]:
        """Create an AI performance alert."""
        try:
            alert = {
                'timestamp': datetime.now().isoformat(),
                'alert_type': 'ai_performance',
                'severity': severity.value,
                'module_name': module_name,
                'metric_name': metric_name,
                'metric_value': metric_value,
                'threshold_value': threshold_value,
                'message': f"{module_name} {metric_name} is {metric_value:.2f} (threshold: {threshold_value:.2f})",
                'acknowledged': False,
                'resolved': False
            }
            
            return alert
            
        except Exception as e:
            self.logger.error(f"Failed to create AI alert: {e}")
            return {}
    
    def _create_degradation_alert(self, module_name: str, degradation_score: float):
        """Create a model degradation alert."""
        try:
            severity = AlertLevel.CRITICAL if degradation_score > 70 else AlertLevel.WARNING
            
            alert = {
                'timestamp': datetime.now().isoformat(),
                'alert_type': 'model_degradation',
                'severity': severity.value,
                'module_name': module_name,
                'metric_name': 'degradation_score',
                'metric_value': degradation_score,
                'threshold_value': 50.0,
                'message': f"Model degradation detected in {module_name}: {degradation_score:.1f}% degradation",
                'acknowledged': False,
                'resolved': False
            }
            
            self._handle_ai_alert(alert)
            
        except Exception as e:
            self.logger.error(f"Failed to create degradation alert: {e}")
    
    def _handle_ai_alert(self, alert: Dict[str, Any]):
        """Handle AI performance alert."""
        try:
            if not alert:
                return
            
            # Check if this alert should be suppressed (rate limiting)
            alert_key = f"{alert['module_name']}_{alert['metric_name']}_{alert['severity']}"
            
            if self.alert_states.get(alert_key, False):
                return  # Alert already active
            
            # Store alert in database
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    INSERT INTO ai_alerts (
                        timestamp, alert_type, severity, module_name, metric_name,
                        metric_value, threshold_value, message, acknowledged, resolved
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    alert['timestamp'], alert['alert_type'], alert['severity'],
                    alert['module_name'], alert['metric_name'], alert['metric_value'],
                    alert['threshold_value'], alert['message'], alert['acknowledged'],
                    alert['resolved']
                ))
            
            # Mark alert as active
            self.alert_states[alert_key] = True
            
            # Notify callbacks
            for callback in self.alert_callbacks:
                try:
                    callback(alert)
                except Exception as e:
                    self.logger.error(f"Alert callback failed: {e}")
            
            self.logger.warning(f"AI Alert: {alert['message']}")
            
        except Exception as e:
            self.logger.error(f"Failed to handle AI alert: {e}")
    
    def get_module_performance(self, module_name: str) -> Dict[str, Any]:
        """Get performance metrics for a specific module."""
        try:
            stats = self.module_stats.get(module_name, {})
            
            if not stats.get('decisions'):
                return {
                    'module_name': module_name,
                    'status': 'no_data',
                    'message': 'No performance data available'
                }
            
            recent_decisions = list(stats['decisions'])[-50:]  # Last 50 decisions
            
            # Calculate current metrics
            avg_confidence = statistics.mean([d.confidence_score for d in recent_decisions])
            avg_response_time = statistics.mean([d.execution_time for d in recent_decisions])
            success_rate = sum(1 for d in recent_decisions if d.success) / len(recent_decisions)
            error_rate = (1 - success_rate) * 100
            
            # Get trends
            confidence_trend = self._calculate_trend([d.confidence_score for d in recent_decisions])
            response_time_trend = self._calculate_trend([d.execution_time for d in recent_decisions])
            
            # Get baseline comparison
            baseline = self.baseline_metrics.get(module_name, {})
            
            performance = {
                'module_name': module_name,
                'current_metrics': {
                    'avg_confidence': avg_confidence,
                    'avg_response_time': avg_response_time,
                    'success_rate': success_rate,
                    'error_rate': error_rate,
                    'total_decisions': len(stats['decisions']),
                    'error_count': stats['error_count'],
                    'last_activity': stats['last_activity'].isoformat() if stats['last_activity'] else None
                },
                'trends': {
                    'confidence_trend': confidence_trend,
                    'response_time_trend': response_time_trend
                },
                'baseline_comparison': {},
                'optimization_suggestions': self.model_performance.get(module_name, {}).get('optimization_suggestions', [])
            }
            
            # Add baseline comparisons
            if baseline:
                if 'confidence' in baseline:
                    performance['baseline_comparison']['confidence_change'] = avg_confidence - baseline['confidence']
                if 'response_time' in baseline:
                    performance['baseline_comparison']['response_time_change'] = avg_response_time - baseline['response_time']
                if 'accuracy' in baseline:
                    performance['baseline_comparison']['accuracy_change'] = success_rate - baseline['accuracy']
            
            return performance
            
        except Exception as e:
            self.logger.error(f"Failed to get module performance for {module_name}: {e}")
            return {
                'module_name': module_name,
                'status': 'error',
                'message': f'Failed to retrieve performance data: {e}'
            }
    
    def get_trading_performance(self) -> Dict[str, Any]:
        """Get current trading performance metrics."""
        try:
            if not self.trading_metrics:
                return {
                    'status': 'no_data',
                    'message': 'No trading performance data available'
                }
            
            latest_performance = self.trading_metrics[-1]
            
            # Calculate performance trends if we have enough data
            trends = {}
            if len(self.trading_metrics) >= 5:
                recent_metrics = list(self.trading_metrics)[-10:]  # Last 10 data points
                
                trends = {
                    'win_rate_trend': self._calculate_trend([m.win_rate for m in recent_metrics]),
                    'pnl_trend': self._calculate_trend([m.total_pnl for m in recent_metrics]),
                    'drawdown_trend': self._calculate_trend([m.current_drawdown for m in recent_metrics]),
                    'sharpe_ratio_trend': self._calculate_trend([m.sharpe_ratio for m in recent_metrics])
                }
            
            # Get baseline comparison
            baseline = self.baseline_metrics.get('trading', {})
            baseline_comparison = {}
            
            if baseline:
                if 'win_rate' in baseline:
                    baseline_comparison['win_rate_change'] = latest_performance.win_rate - baseline['win_rate']
                if 'sharpe_ratio' in baseline:
                    baseline_comparison['sharpe_ratio_change'] = latest_performance.sharpe_ratio - baseline['sharpe_ratio']
            
            return {
                'status': 'success',
                'current_performance': asdict(latest_performance),
                'trends': trends,
                'baseline_comparison': baseline_comparison,
                'performance_grade': self._calculate_performance_grade(latest_performance),
                'risk_assessment': self._assess_trading_risk(latest_performance)
            }
            
        except Exception as e:
            self.logger.error(f"Failed to get trading performance: {e}")
            return {
                'status': 'error',
                'message': f'Failed to retrieve trading performance: {e}'
            }
    
    def _calculate_performance_grade(self, performance: TradingPerformance) -> str:
        """Calculate overall performance grade."""
        try:
            score = 0
            
            # Win rate scoring (40% weight)
            if performance.win_rate >= 70:
                score += 40
            elif performance.win_rate >= 60:
                score += 30
            elif performance.win_rate >= 50:
                score += 20
            elif performance.win_rate >= 40:
                score += 10
            
            # Profit factor scoring (30% weight)
            if performance.profit_factor >= 2.0:
                score += 30
            elif performance.profit_factor >= 1.5:
                score += 20
            elif performance.profit_factor >= 1.2:
                score += 15
            elif performance.profit_factor >= 1.0:
                score += 10
            
            # Sharpe ratio scoring (20% weight)
            if performance.sharpe_ratio >= 2.0:
                score += 20
            elif performance.sharpe_ratio >= 1.5:
                score += 15
            elif performance.sharpe_ratio >= 1.0:
                score += 10
            elif performance.sharpe_ratio >= 0.5:
                score += 5
            
            # Drawdown penalty (10% weight)
            if performance.current_drawdown <= 2:
                score += 10
            elif performance.current_drawdown <= 5:
                score += 5
            elif performance.current_drawdown <= 10:
                score += 2
            
            # Convert to grade
            if score >= 85:
                return "A+"
            elif score >= 75:
                return "A"
            elif score >= 65:
                return "B+"
            elif score >= 55:
                return "B"
            elif score >= 45:
                return "C+"
            elif score >= 35:
                return "C"
            elif score >= 25:
                return "D"
            else:
                return "F"
                
        except:
            return "N/A"
    
    def _assess_trading_risk(self, performance: TradingPerformance) -> Dict[str, Any]:
        """Assess current trading risk level."""
        try:
            risk_factors = []
            risk_score = 0
            
            # Drawdown risk
            if performance.current_drawdown > 10:
                risk_factors.append("High current drawdown")
                risk_score += 30
            elif performance.current_drawdown > 5:
                risk_factors.append("Moderate current drawdown")
                risk_score += 15
            
            # Consecutive losses risk
            if performance.consecutive_losses > 8:
                risk_factors.append("High consecutive losses")
                risk_score += 25
            elif performance.consecutive_losses > 5:
                risk_factors.append("Moderate consecutive losses")
                risk_score += 10
            
            # Win rate risk
            if performance.win_rate < 30:
                risk_factors.append("Very low win rate")
                risk_score += 20
            elif performance.win_rate < 40:
                risk_factors.append("Low win rate")
                risk_score += 10
            
            # Profit factor risk
            if performance.profit_factor < 0.8:
                risk_factors.append("Poor profit factor")
                risk_score += 15
            elif performance.profit_factor < 1.0:
                risk_factors.append("Negative profit factor")
                risk_score += 10
            
            # Determine risk level
            if risk_score >= 60:
                risk_level = "CRITICAL"
            elif risk_score >= 40:
                risk_level = "HIGH"
            elif risk_score >= 20:
                risk_level = "MODERATE"
            else:
                risk_level = "LOW"
            
            return {
                'risk_level': risk_level,
                'risk_score': risk_score,
                'risk_factors': risk_factors,
                'recommendations': self._get_risk_recommendations(risk_level, risk_factors)
            }
            
        except Exception as e:
            self.logger.error(f"Failed to assess trading risk: {e}")
            return {
                'risk_level': 'UNKNOWN',
                'risk_score': 0,
                'risk_factors': [],
                'recommendations': []
            }
    
    def _get_risk_recommendations(self, risk_level: str, risk_factors: List[str]) -> List[str]:
        """Get risk mitigation recommendations."""
        recommendations = []
        
        if risk_level == "CRITICAL":
            recommendations.append("Consider stopping trading immediately")
            recommendations.append("Review and adjust trading strategy")
            recommendations.append("Reduce position sizes significantly")
        elif risk_level == "HIGH":
            recommendations.append("Reduce position sizes")
            recommendations.append("Review recent trading decisions")
            recommendations.append("Consider tightening stop losses")
        elif risk_level == "MODERATE":
            recommendations.append("Monitor performance closely")
            recommendations.append("Consider minor position size adjustments")
        
        # Specific recommendations based on risk factors
        for factor in risk_factors:
            if "drawdown" in factor.lower():
                recommendations.append("Implement stricter drawdown controls")
            elif "consecutive losses" in factor.lower():
                recommendations.append("Review loss streak management")
            elif "win rate" in factor.lower():
                recommendations.append("Analyze entry/exit criteria")
            elif "profit factor" in factor.lower():
                recommendations.append("Review risk-reward ratios")
        
        return list(set(recommendations))  # Remove duplicates
    
    def get_performance_summary(self) -> Dict[str, Any]:
        """Get comprehensive performance summary."""
        try:
            summary = {
                'timestamp': datetime.now().isoformat(),
                'overall_status': 'healthy',
                'modules': {},
                'trading': {},
                'alerts': {
                    'active_count': 0,
                    'critical_count': 0,
                    'recent_alerts': []
                },
                'recommendations': []
            }
            
            # Get module performance summaries
            for module_name in self.module_stats.keys():
                module_perf = self.get_module_performance(module_name)
                summary['modules'][module_name] = {
                    'status': 'healthy' if module_perf.get('current_metrics', {}).get('success_rate', 0) > 0.8 else 'degraded',
                    'confidence': module_perf.get('current_metrics', {}).get('avg_confidence', 0),
                    'response_time': module_perf.get('current_metrics', {}).get('avg_response_time', 0),
                    'error_rate': module_perf.get('current_metrics', {}).get('error_rate', 0)
                }
            
            # Get trading performance summary
            trading_perf = self.get_trading_performance()
            if trading_perf.get('status') == 'success':
                current_perf = trading_perf['current_performance']
                summary['trading'] = {
                    'status': 'healthy' if current_perf['win_rate'] > 50 and current_perf['current_drawdown'] < 5 else 'at_risk',
                    'win_rate': current_perf['win_rate'],
                    'total_pnl': current_perf['total_pnl'],
                    'current_drawdown': current_perf['current_drawdown'],
                    'performance_grade': trading_perf.get('performance_grade', 'N/A'),
                    'risk_level': trading_perf.get('risk_assessment', {}).get('risk_level', 'UNKNOWN')
                }
            
            # Get recent alerts
            try:
                with db_manager.get_cursor() as cursor:
                    cursor.execute("""
                        SELECT * FROM ai_alerts 
                        WHERE timestamp >= ? AND resolved = FALSE
                        ORDER BY timestamp DESC LIMIT 10
                    """, ((datetime.now() - timedelta(hours=24)).isoformat(),))
                    
                    recent_alerts = cursor.fetchall()
                    summary['alerts']['active_count'] = len(recent_alerts)
                    summary['alerts']['critical_count'] = sum(1 for alert in recent_alerts if alert['severity'] == 'critical')
                    summary['alerts']['recent_alerts'] = [dict(alert) for alert in recent_alerts[:5]]
            except Exception as e:
                self.logger.warning(f"Failed to get recent alerts: {e}")
            
            # Determine overall status
            if summary['alerts']['critical_count'] > 0:
                summary['overall_status'] = 'critical'
            elif summary['trading'].get('status') == 'at_risk':
                summary['overall_status'] = 'at_risk'
            elif any(module['status'] == 'degraded' for module in summary['modules'].values()):
                summary['overall_status'] = 'degraded'
            
            # Generate recommendations
            summary['recommendations'] = self._generate_summary_recommendations(summary)
            
            return summary
            
        except Exception as e:
            self.logger.error(f"Failed to get performance summary: {e}")
            return {
                'timestamp': datetime.now().isoformat(),
                'overall_status': 'error',
                'error': str(e)
            }
    
    def _generate_summary_recommendations(self, summary: Dict[str, Any]) -> List[str]:
        """Generate recommendations based on performance summary."""
        recommendations = []
        
        # Critical alerts
        if summary['alerts']['critical_count'] > 0:
            recommendations.append("Address critical alerts immediately")
        
        # Trading performance
        trading = summary.get('trading', {})
        if trading.get('risk_level') in ['HIGH', 'CRITICAL']:
            recommendations.append("Review trading risk management")
        if trading.get('current_drawdown', 0) > 5:
            recommendations.append("Consider reducing position sizes due to drawdown")
        
        # Module performance
        degraded_modules = [name for name, module in summary.get('modules', {}).items() 
                          if module.get('status') == 'degraded']
        if degraded_modules:
            recommendations.append(f"Investigate performance issues in: {', '.join(degraded_modules)}")
        
        # High error rates
        high_error_modules = [name for name, module in summary.get('modules', {}).items() 
                            if module.get('error_rate', 0) > 10]
        if high_error_modules:
            recommendations.append(f"Address high error rates in: {', '.join(high_error_modules)}")
        
        return recommendations
    
    def cleanup_old_data(self, days_to_keep: int = 90):
        """Clean up old monitoring data."""
        try:
            cutoff_date = datetime.now() - timedelta(days=days_to_keep)
            
            with db_manager.get_cursor() as cursor:
                # Clean up old trading performance data
                cursor.execute("""
                    DELETE FROM trading_performance 
                    WHERE timestamp < ?
                """, (cutoff_date.isoformat(),))
                
                deleted_trading = cursor.rowcount
                
                # Clean up old AI decision metrics
                cursor.execute("""
                    DELETE FROM ai_decision_metrics 
                    WHERE timestamp < ?
                """, (cutoff_date.isoformat(),))
                
                deleted_decisions = cursor.rowcount
                
                # Clean up resolved alerts older than 30 days
                alert_cutoff = datetime.now() - timedelta(days=30)
                cursor.execute("""
                    DELETE FROM ai_alerts 
                    WHERE timestamp < ? AND resolved = TRUE
                """, (alert_cutoff.isoformat(),))
                
                deleted_alerts = cursor.rowcount
            
            # Clean up in-memory data
            self.decision_history.clear()
            self.trading_metrics.clear()
            
            # Reset module stats but keep structure
            for module_name in self.module_stats:
                self.module_stats[module_name]['decisions'].clear()
                self.module_stats[module_name]['response_times'].clear()
                self.module_stats[module_name]['confidence_scores'].clear()
                self.module_stats[module_name]['error_count'] = 0
            
            self.logger.info(f"Cleaned up old data: {deleted_trading} trading records, "
                           f"{deleted_decisions} decision records, {deleted_alerts} alerts")
            
        except Exception as e:
            self.logger.error(f"Failed to cleanup old data: {e}")

# Global AI monitor instance
ai_monitor = AIPerformanceMonitor()