"""
Health Check Framework for the AI Crypto Trading System.
Provides comprehensive health monitoring with automated scheduling, dependency tracking,
health scoring, trend analysis, and automated recovery actions.
"""

import time
import threading
import logging
import asyncio
import json
import hashlib
import statistics
import subprocess
import psutil
import requests
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List, Callable, Set, Tuple, Union
from dataclasses import dataclass, asdict, field
from collections import defaultdict, deque
from enum import Enum
from pathlib import Path
import concurrent.futures
from abc import ABC, abstractmethod

from .config import monitoring_config, AlertLevel
from ..utils.logging import get_logger
from ..utils.database import db_manager

class HealthStatus(Enum):
    """Health status levels."""
    HEALTHY = "healthy"
    WARNING = "warning"
    CRITICAL = "critical"
    UNKNOWN = "unknown"
    DEGRADED = "degraded"

class CheckType(Enum):
    """Types of health checks."""
    SYSTEM = "system"
    SERVICE = "service"
    AI_MODULE = "ai_module"
    DATA = "data"
    SECURITY = "security"
    PERFORMANCE = "performance"
    INTEGRATION = "integration"
    DEPENDENCY = "dependency"

class RecoveryAction(Enum):
    """Types of recovery actions."""
    RESTART_SERVICE = "restart_service"
    CLEAR_CACHE = "clear_cache"
    RESET_CONNECTION = "reset_connection"
    SCALE_RESOURCES = "scale_resources"
    NOTIFY_ADMIN = "notify_admin"
    CUSTOM_SCRIPT = "custom_script"

@dataclass
class HealthCheckResult:
    """Result of a health check."""
    check_name: str
    component: str
    status: HealthStatus
    score: float  # 0-100
    message: str
    timestamp: str
    execution_time: float
    metadata: Dict[str, Any] = field(default_factory=dict)
    recommendations: List[str] = field(default_factory=list)
    dependencies_checked: List[str] = field(default_factory=list)
    error_details: Optional[str] = None

@dataclass
class DependencyInfo:
    """Information about component dependencies."""
    name: str
    component: str
    dependency_type: str  # "service", "database", "api", "file"
    required: bool
    health_impact: float  # 0-1, impact on component health if dependency fails
    check_interval: int = 60
    timeout: int = 30
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class RecoveryActionConfig:
    """Configuration for recovery actions."""
    action_type: RecoveryAction
    component: str
    trigger_conditions: List[str]
    command: Optional[str] = None
    script_path: Optional[str] = None
    timeout: int = 300
    max_retries: int = 3
    cooldown_period: int = 1800  # 30 minutes
    enabled: bool = True
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class HealthTrend:
    """Health trend analysis data."""
    component: str
    metric_name: str
    current_value: float
    trend_direction: float  # -1 to 1, negative = declining, positive = improving
    trend_strength: float  # 0-1, strength of the trend
    prediction_24h: float
    confidence: float  # 0-1, confidence in prediction
    analysis_period_hours: int = 24
    data_points: int = 0

class BaseHealthCheck(ABC):
    """Base class for all health checks."""
    
    def __init__(self, name: str, component: str, check_type: CheckType, 
                 interval: int = 60, timeout: int = 30, enabled: bool = True):
        self.name = name
        self.component = component
        self.check_type = check_type
        self.interval = interval
        self.timeout = timeout
        self.enabled = enabled
        self.logger = get_logger(f"{__name__}.{name}")
        self.last_run = None
        self.last_result = None
        
    @abstractmethod
    async def execute_check(self) -> HealthCheckResult:
        """Execute the health check."""
        pass
    
    def should_run(self) -> bool:
        """Check if this health check should run now."""
        if not self.enabled:
            return False
        
        if self.last_run is None:
            return True
        
        return (datetime.now() - self.last_run).total_seconds() >= self.interval

class ComponentHealthCheck(BaseHealthCheck):
    """Health check for monitoring system components."""
    
    def __init__(self, name: str, component: str, check_config: Dict[str, Any]):
        super().__init__(
            name=name,
            component=component,
            check_type=CheckType(check_config.get('type', 'service')),
            interval=check_config.get('interval', 60),
            timeout=check_config.get('timeout', 30),
            enabled=check_config.get('enabled', True)
        )
        self.check_config = check_config
        
    async def execute_check(self) -> HealthCheckResult:
        """Execute component-specific health check."""
        start_time = time.time()
        
        try:
            if self.component == "system_monitor":
                return await self._check_system_monitor()
            elif self.component == "ai_monitor":
                return await self._check_ai_monitor()
            elif self.component == "alert_manager":
                return await self._check_alert_manager()
            elif self.component == "log_aggregator":
                return await self._check_log_aggregator()
            elif self.component == "metrics_collector":
                return await self._check_metrics_collector()
            elif self.component == "dashboard_backend":
                return await self._check_dashboard_backend()
            elif self.component == "notification_system":
                return await self._check_notification_system()
            else:
                return await self._check_generic_component()
                
        except Exception as e:
            execution_time = time.time() - start_time
            return HealthCheckResult(
                check_name=self.name,
                component=self.component,
                status=HealthStatus.CRITICAL,
                score=0.0,
                message=f"Health check failed: {str(e)}",
                timestamp=datetime.now().isoformat(),
                execution_time=execution_time,
                error_details=str(e)
            )
    
    async def _check_system_monitor(self) -> HealthCheckResult:
        """Check system monitor health."""
        try:
            from .system_monitor import system_monitor
            
            # Check if monitoring is running
            if not system_monitor.running:
                return HealthCheckResult(
                    check_name=self.name,
                    component=self.component,
                    status=HealthStatus.CRITICAL,
                    score=0.0,
                    message="System monitor is not running",
                    timestamp=datetime.now().isoformat(),
                    execution_time=0.0,
                    recommendations=["Start system monitoring", "Check system monitor configuration"]
                )
            
            # Get current metrics
            current_metrics = system_monitor.get_current_metrics()
            if not current_metrics:
                return HealthCheckResult(
                    check_name=self.name,
                    component=self.component,
                    status=HealthStatus.WARNING,
                    score=30.0,
                    message="No current metrics available",
                    timestamp=datetime.now().isoformat(),
                    execution_time=0.0,
                    recommendations=["Check metric collection", "Verify system monitor functionality"]
                )
            
            # Calculate health score based on system metrics
            score = 100.0
            issues = []
            
            # CPU health
            if current_metrics.cpu_usage > 90:
                score -= 30
                issues.append(f"High CPU usage: {current_metrics.cpu_usage}%")
            elif current_metrics.cpu_usage > 80:
                score -= 15
                issues.append(f"Elevated CPU usage: {current_metrics.cpu_usage}%")
            
            # Memory health
            if current_metrics.memory_usage > 95:
                score -= 25
                issues.append(f"Critical memory usage: {current_metrics.memory_usage}%")
            elif current_metrics.memory_usage > 85:
                score -= 10
                issues.append(f"High memory usage: {current_metrics.memory_usage}%")
            
            # Temperature health
            if current_metrics.cpu_temperature > 80:
                score -= 20
                issues.append(f"High CPU temperature: {current_metrics.cpu_temperature}°C")
            
            # Determine status
            if score >= 80:
                status = HealthStatus.HEALTHY
            elif score >= 60:
                status = HealthStatus.WARNING
            else:
                status = HealthStatus.CRITICAL
            
            message = "System monitor healthy" if not issues else f"Issues detected: {', '.join(issues)}"
            
            return HealthCheckResult(
                check_name=self.name,
                component=self.component,
                status=status,
                score=score,
                message=message,
                timestamp=datetime.now().isoformat(),
                execution_time=0.0,
                metadata={
                    "cpu_usage": current_metrics.cpu_usage,
                    "memory_usage": current_metrics.memory_usage,
                    "cpu_temperature": current_metrics.cpu_temperature,
                    "disk_usage": current_metrics.disk_usage
                }
            )
            
        except Exception as e:
            return HealthCheckResult(
                check_name=self.name,
                component=self.component,
                status=HealthStatus.CRITICAL,
                score=0.0,
                message=f"System monitor check failed: {str(e)}",
                timestamp=datetime.now().isoformat(),
                execution_time=0.0,
                error_details=str(e)
            )
    
    async def _check_ai_monitor(self) -> HealthCheckResult:
        """Check AI monitor health."""
        try:
            from .ai_monitor import ai_monitor
            
            if not ai_monitor.running:
                return HealthCheckResult(
                    check_name=self.name,
                    component=self.component,
                    status=HealthStatus.CRITICAL,
                    score=0.0,
                    message="AI monitor is not running",
                    timestamp=datetime.now().isoformat(),
                    execution_time=0.0,
                    recommendations=["Start AI monitoring", "Check AI monitor configuration"]
                )
            
            # Get performance summary
            performance_summary = ai_monitor.get_performance_summary()
            
            score = 100.0
            issues = []
            
            # Check overall status
            overall_status = performance_summary.get('overall_status', 'unknown')
            if overall_status == 'critical':
                score -= 40
                issues.append("Critical AI performance issues detected")
            elif overall_status == 'at_risk':
                score -= 25
                issues.append("AI performance at risk")
            elif overall_status == 'degraded':
                score -= 15
                issues.append("AI performance degraded")
            
            # Check active alerts
            alert_count = performance_summary.get('alerts', {}).get('active_count', 0)
            critical_count = performance_summary.get('alerts', {}).get('critical_count', 0)
            
            if critical_count > 0:
                score -= 30
                issues.append(f"{critical_count} critical AI alerts active")
            elif alert_count > 5:
                score -= 15
                issues.append(f"{alert_count} AI alerts active")
            
            # Determine status
            if score >= 80:
                status = HealthStatus.HEALTHY
            elif score >= 60:
                status = HealthStatus.WARNING
            else:
                status = HealthStatus.CRITICAL
            
            message = "AI monitor healthy" if not issues else f"Issues: {', '.join(issues)}"
            
            return HealthCheckResult(
                check_name=self.name,
                component=self.component,
                status=status,
                score=score,
                message=message,
                timestamp=datetime.now().isoformat(),
                execution_time=0.0,
                metadata=performance_summary
            )
            
        except Exception as e:
            return HealthCheckResult(
                check_name=self.name,
                component=self.component,
                status=HealthStatus.CRITICAL,
                score=0.0,
                message=f"AI monitor check failed: {str(e)}",
                timestamp=datetime.now().isoformat(),
                execution_time=0.0,
                error_details=str(e)
            )
    
    async def _check_alert_manager(self) -> HealthCheckResult:
        """Check alert manager health."""
        try:
            from .alert_manager import alert_manager
            
            if not alert_manager.running:
                return HealthCheckResult(
                    check_name=self.name,
                    component=self.component,
                    status=HealthStatus.CRITICAL,
                    score=0.0,
                    message="Alert manager is not running",
                    timestamp=datetime.now().isoformat(),
                    execution_time=0.0,
                    recommendations=["Start alert manager", "Check alert manager configuration"]
                )
            
            # Get health status
            health_status = alert_manager.get_health_status()
            
            score = 100.0
            issues = []
            
            # Check queue size
            queue_size = health_status.get('queue_size', 0)
            if queue_size > 100:
                score -= 20
                issues.append(f"Large alert queue: {queue_size} alerts")
            elif queue_size > 50:
                score -= 10
                issues.append(f"Growing alert queue: {queue_size} alerts")
            
            # Check active alerts
            active_count = health_status.get('active_alerts_count', 0)
            if active_count > 20:
                score -= 15
                issues.append(f"Many active alerts: {active_count}")
            
            # Check channel status
            channels_status = health_status.get('channels_status', {})
            disabled_channels = [name for name, enabled in channels_status.items() if not enabled]
            if disabled_channels:
                score -= 10
                issues.append(f"Disabled channels: {', '.join(disabled_channels)}")
            
            # Determine status
            if score >= 80:
                status = HealthStatus.HEALTHY
            elif score >= 60:
                status = HealthStatus.WARNING
            else:
                status = HealthStatus.CRITICAL
            
            message = "Alert manager healthy" if not issues else f"Issues: {', '.join(issues)}"
            
            return HealthCheckResult(
                check_name=self.name,
                component=self.component,
                status=status,
                score=score,
                message=message,
                timestamp=datetime.now().isoformat(),
                execution_time=0.0,
                metadata=health_status
            )
            
        except Exception as e:
            return HealthCheckResult(
                check_name=self.name,
                component=self.component,
                status=HealthStatus.CRITICAL,
                score=0.0,
                message=f"Alert manager check failed: {str(e)}",
                timestamp=datetime.now().isoformat(),
                execution_time=0.0,
                error_details=str(e)
            )
    
    async def _check_log_aggregator(self) -> HealthCheckResult:
        """Check log aggregator health."""
        try:
            from .log_aggregator import log_aggregator
            
            if not log_aggregator.running:
                return HealthCheckResult(
                    check_name=self.name,
                    component=self.component,
                    status=HealthStatus.CRITICAL,
                    score=0.0,
                    message="Log aggregator is not running",
                    timestamp=datetime.now().isoformat(),
                    execution_time=0.0,
                    recommendations=["Start log aggregator", "Check log aggregator configuration"]
                )
            
            # Get health status
            health_status = log_aggregator.get_health_status()
            
            score = 100.0
            issues = []
            
            # Check processing status
            if not health_status.get('processing_enabled', False):
                score -= 30
                issues.append("Log processing disabled")
            
            # Check queue size
            queue_size = health_status.get('queue_size', 0)
            if queue_size > 1000:
                score -= 25
                issues.append(f"Large log queue: {queue_size} entries")
            elif queue_size > 500:
                score -= 10
                issues.append(f"Growing log queue: {queue_size} entries")
            
            # Check error rate
            error_rate = health_status.get('error_rate', 0)
            if error_rate > 10:
                score -= 20
                issues.append(f"High error rate: {error_rate}%")
            elif error_rate > 5:
                score -= 10
                issues.append(f"Elevated error rate: {error_rate}%")
            
            # Determine status
            if score >= 80:
                status = HealthStatus.HEALTHY
            elif score >= 60:
                status = HealthStatus.WARNING
            else:
                status = HealthStatus.CRITICAL
            
            message = "Log aggregator healthy" if not issues else f"Issues: {', '.join(issues)}"
            
            return HealthCheckResult(
                check_name=self.name,
                component=self.component,
                status=status,
                score=score,
                message=message,
                timestamp=datetime.now().isoformat(),
                execution_time=0.0,
                metadata=health_status
            )
            
        except Exception as e:
            return HealthCheckResult(
                check_name=self.name,
                component=self.component,
                status=HealthStatus.CRITICAL,
                score=0.0,
                message=f"Log aggregator check failed: {str(e)}",
                timestamp=datetime.now().isoformat(),
                execution_time=0.0,
                error_details=str(e)
            )
    
    async def _check_metrics_collector(self) -> HealthCheckResult:
        """Check metrics collector health."""
        try:
            from .metrics_collector import metrics_collector
            
            if not metrics_collector.running:
                return HealthCheckResult(
                    check_name=self.name,
                    component=self.component,
                    status=HealthStatus.CRITICAL,
                    score=0.0,
                    message="Metrics collector is not running",
                    timestamp=datetime.now().isoformat(),
                    execution_time=0.0,
                    recommendations=["Start metrics collector", "Check metrics collector configuration"]
                )
            
            # Get metrics summary
            summary = metrics_collector.get_metrics_summary()
            
            score = 100.0
            issues = []
            
            # Check collection status
            if summary.get('collection_status') != 'running':
                score -= 40
                issues.append("Metrics collection not running")
            
            # Check buffer size
            buffer_size = summary.get('buffer_size', 0)
            if buffer_size > 8000:
                score -= 20
                issues.append(f"Large metrics buffer: {buffer_size}")
            elif buffer_size > 5000:
                score -= 10
                issues.append(f"Growing metrics buffer: {buffer_size}")
            
            # Check registered metrics
            registered_metrics = summary.get('registered_metrics', 0)
            if registered_metrics == 0:
                score -= 15
                issues.append("No registered metrics")
            
            # Determine status
            if score >= 80:
                status = HealthStatus.HEALTHY
            elif score >= 60:
                status = HealthStatus.WARNING
            else:
                status = HealthStatus.CRITICAL
            
            message = "Metrics collector healthy" if not issues else f"Issues: {', '.join(issues)}"
            
            return HealthCheckResult(
                check_name=self.name,
                component=self.component,
                status=status,
                score=score,
                message=message,
                timestamp=datetime.now().isoformat(),
                execution_time=0.0,
                metadata=summary
            )
            
        except Exception as e:
            return HealthCheckResult(
                check_name=self.name,
                component=self.component,
                status=HealthStatus.CRITICAL,
                score=0.0,
                message=f"Metrics collector check failed: {str(e)}",
                timestamp=datetime.now().isoformat(),
                execution_time=0.0,
                error_details=str(e)
            )
    
    async def _check_dashboard_backend(self) -> HealthCheckResult:
        """Check dashboard backend health."""
        try:
            # Test dashboard API endpoint
            dashboard_url = f"http://{monitoring_config.dashboard.host}:{monitoring_config.dashboard.port}/api/health"
            
            start_time = time.time()
            try:
                response = requests.get(dashboard_url, timeout=10)
                response_time = time.time() - start_time
                
                if response.status_code == 200:
                    score = 100.0
                    status = HealthStatus.HEALTHY
                    message = f"Dashboard API healthy (response time: {response_time:.2f}s)"
                    
                    # Check response time
                    if response_time > 5:
                        score -= 20
                        status = HealthStatus.WARNING
                        message = f"Dashboard API slow (response time: {response_time:.2f}s)"
                    elif response_time > 2:
                        score -= 10
                        
                else:
                    score = 30.0
                    status = HealthStatus.CRITICAL
                    message = f"Dashboard API error: HTTP {response.status_code}"
                    
            except requests.exceptions.ConnectionError:
                score = 0.0
                status = HealthStatus.CRITICAL
                message = "Dashboard API not accessible"
                response_time = time.time() - start_time
                
            except requests.exceptions.Timeout:
                score = 10.0
                status = HealthStatus.CRITICAL
                message = "Dashboard API timeout"
                response_time = time.time() - start_time
            
            return HealthCheckResult(
                check_name=self.name,
                component=self.component,
                status=status,
                score=score,
                message=message,
                timestamp=datetime.now().isoformat(),
                execution_time=response_time,
                metadata={
                    "dashboard_url": dashboard_url,
                    "response_time": response_time
                }
            )
            
        except Exception as e:
            return HealthCheckResult(
                check_name=self.name,
                component=self.component,
                status=HealthStatus.CRITICAL,
                score=0.0,
                message=f"Dashboard backend check failed: {str(e)}",
                timestamp=datetime.now().isoformat(),
                execution_time=0.0,
                error_details=str(e)
            )
    
    async def _check_notification_system(self) -> HealthCheckResult:
        """Check notification system health."""
        try:
            from .notification_system import notification_system
            
            if not notification_system.running:
                return HealthCheckResult(
                    check_name=self.name,
                    component=self.component,
                    status=HealthStatus.CRITICAL,
                    score=0.0,
                    message="Notification system is not running",
                    timestamp=datetime.now().isoformat(),
                    execution_time=0.0,
                    recommendations=["Start notification system", "Check notification system configuration"]
                )
            
            # Get health status
            health_status = notification_system.get_health_status()
            
            score = 100.0
            issues = []
            
            # Check delivery channels
            channels_status = health_status.get('channels_status', {})
            failed_channels = [name for name, status in channels_status.items() if not status.get('healthy', False)]
            if failed_channels:
                score -= 20
                issues.append(f"Failed channels: {', '.join(failed_channels)}")
            
            # Check queue size
            queue_size = health_status.get('queue_size', 0)
            if queue_size > 100:
                score -= 15
                issues.append(f"Large notification queue: {queue_size}")
            elif queue_size > 50:
                score -= 8
                issues.append(f"Growing notification queue: {queue_size}")
            
            # Check delivery rate
            delivery_rate = health_status.get('delivery_success_rate', 100)
            if delivery_rate < 80:
                score -= 25
                issues.append(f"Low delivery rate: {delivery_rate}%")
            elif delivery_rate < 95:
                score -= 10
                issues.append(f"Reduced delivery rate: {delivery_rate}%")
            
            # Determine status
            if score >= 80:
                status = HealthStatus.HEALTHY
            elif score >= 60:
                status = HealthStatus.WARNING
            else:
                status = HealthStatus.CRITICAL
            
            message = "Notification system healthy" if not issues else f"Issues: {', '.join(issues)}"
            
            return HealthCheckResult(
                check_name=self.name,
                component=self.component,
                status=status,
                score=score,
                message=message,
                timestamp=datetime.now().isoformat(),
                execution_time=0.0,
                metadata=health_status
            )
            
        except Exception as e:
            return HealthCheckResult(
                check_name=self.name,
                component=self.component,
                status=HealthStatus.CRITICAL,
                score=0.0,
                message=f"Notification system check failed: {str(e)}",
                timestamp=datetime.now().isoformat(),
                execution_time=0.0,
                error_details=str(e)
            )
    
    async def _check_generic_component(self) -> HealthCheckResult:
        """Generic component health check."""
        try:
            # Basic process check
            component_processes = []
            for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
                try:
                    if self.component.lower() in ' '.join(proc.info['cmdline']).lower():
                        component_processes.append(proc)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            if not component_processes:
                return HealthCheckResult(
                    check_name=self.name,
                    component=self.component,
                    status=HealthStatus.CRITICAL,
                    score=0.0,
                    message=f"No {self.component} processes found",
                    timestamp=datetime.now().isoformat(),
                    execution_time=0.0,
                    recommendations=[f"Start {self.component} service", f"Check {self.component} configuration"]
                )
            
            # Check process health
            score = 100.0
            issues = []
            
            for proc in component_processes:
                try:
                    cpu_percent = proc.cpu_percent()
                    memory_percent = proc.memory_percent()
                    
                    if cpu_percent > 80:
                        score -= 15
                        issues.append(f"High CPU usage: {cpu_percent}%")
                    
                    if memory_percent > 80:
                        score -= 15
                        issues.append(f"High memory usage: {memory_percent}%")
                        
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            
            # Determine status
            if score >= 80:
                status = HealthStatus.HEALTHY
            elif score >= 60:
                status = HealthStatus.WARNING
            else:
                status = HealthStatus.CRITICAL
            
            message = f"{self.component} healthy" if not issues else f"Issues: {', '.join(issues)}"
            
            return HealthCheckResult(
                check_name=self.name,
                component=self.component,
                status=status,
                score=score,
                message=message,
                timestamp=datetime.now().isoformat(),
                execution_time=0.0,
                metadata={
                    "process_count": len(component_processes),
                    "processes": [{"pid": p.pid, "name": p.name()} for p in component_processes]
                }
            )
            
        except Exception as e:
            return HealthCheckResult(
                check_name=self.name,
                component=self.component,
                status=HealthStatus.CRITICAL,
                score=0.0,
                message=f"Generic component check failed: {str(e)}",
                timestamp=datetime.now().isoformat(),
                execution_time=0.0,
                error_details=str(e)
            )

class HealthChecker:
    """Main health check orchestrator and framework coordinator."""
    
    def __init__(self):
        self.logger = get_logger(__name__)
        self.config = monitoring_config
        self.running = False
        self.check_thread: Optional[threading.Thread] = None
        
        # Health checks registry
        self.health_checks: Dict[str, BaseHealthCheck] = {}
        self.check_results: Dict[str, HealthCheckResult] = {}
        
        # Alert integration
        self.alert_callbacks: List[Callable] = []
        
        # Database setup
        self._initialize_database()
        self._register_default_checks()
    
    def _initialize_database(self):
        """Initialize health check database tables."""
        try:
            with db_manager.get_cursor() as cursor:
                # Health check results table
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS health_check_results (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        check_name TEXT NOT NULL,
                        component TEXT NOT NULL,
                        status TEXT NOT NULL,
                        score REAL NOT NULL,
                        message TEXT,
                        timestamp TIMESTAMP NOT NULL,
                        execution_time REAL,
                        metadata TEXT,
                        recommendations TEXT,
                        error_details TEXT
                    )
                """)
                
                # Create indexes
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_health_results_component ON health_check_results(component, timestamp)")
                
        except Exception as e:
            self.logger.error(f"Failed to initialize health check database: {e}")
            raise
    
    def _register_default_checks(self):
        """Register default health checks for all monitoring components."""
        try:
            # System monitoring components
            components = [
                "system_monitor", "ai_monitor", "alert_manager",
                "log_aggregator", "metrics_collector", "dashboard_backend",
                "notification_system"
            ]
            
            for component in components:
                check_config = {
                    "type": "service",
                    "interval": self.config.health_checks.check_interval,
                    "timeout": self.config.health_checks.timeout,
                    "enabled": self.config.health_checks.enabled
                }
                
                health_check = ComponentHealthCheck(
                    name=f"{component}_health",
                    component=component,
                    check_config=check_config
                )
                
                self.register_health_check(health_check)
            
            self.logger.info(f"Registered {len(self.health_checks)} default health checks")
            
        except Exception as e:
            self.logger.error(f"Failed to register default health checks: {e}")
    
    def register_health_check(self, health_check: BaseHealthCheck):
        """Register a health check."""
        self.health_checks[health_check.name] = health_check
        self.logger.debug(f"Registered health check: {health_check.name}")
    
    def start_health_checking(self):
        """Start the health checking system."""
        if not self.running:
            self.running = True
            self.check_thread = threading.Thread(target=self._health_check_loop, daemon=True)
            self.check_thread.start()
            self.logger.info("Health checking system started")
    
    def stop_health_checking(self):
        """Stop the health checking system."""
        self.running = False
        if self.check_thread:
            self.check_thread.join(timeout=5)
        self.logger.info("Health checking system stopped")
    
    def _health_check_loop(self):
        """Main health check processing loop."""
        while self.running:
            try:
                # Process health check results
                self._process_health_results()
                
                # Sleep for processing interval
                time.sleep(30)  # Process every 30 seconds
                
            except Exception as e:
                self.logger.error(f"Error in health check loop: {e}")
                time.sleep(5)
    
    def _process_health_results(self):
        """Process and store health check results."""
        try:
            for check_name, check in self.health_checks.items():
                if check.last_result:
                    result = check.last_result
                    
                    # Store result in database
                    self._store_health_result(result)
                    
                    # Update local cache
                    self.check_results[check_name] = result
                    
                    # Check for alerts
                    if result.status in [HealthStatus.CRITICAL, HealthStatus.WARNING]:
                        self._trigger_health_alert(result)
                    
                    # Clear processed result
                    check.last_result = None
                    
        except Exception as e:
            self.logger.error(f"Failed to process health results: {e}")
    
    def _store_health_result(self, result: HealthCheckResult):
        """Store health check result in database."""
        try:
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    INSERT INTO health_check_results (
                        check_name, component, status, score, message, timestamp,
                        execution_time, metadata, recommendations, error_details
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    result.check_name, result.component, result.status.value,
                    result.score, result.message, result.timestamp,
                    result.execution_time, json.dumps(result.metadata),
                    json.dumps(result.recommendations), result.error_details
                ))
        except Exception as e:
            self.logger.error(f"Failed to store health result: {e}")
    
    def _trigger_health_alert(self, result: HealthCheckResult):
        """Trigger alert for health check result."""
        try:
            from .alert_manager import alert_manager
            
            severity = AlertLevel.CRITICAL if result.status == HealthStatus.CRITICAL else AlertLevel.WARNING
            
            alert_manager.create_alert(
                alert_type="health_check",
                severity=severity,
                title=f"Health Check Alert: {result.component}",
                message=result.message,
                source="health_checker",
                metric_name="health_score",
                metric_value=result.score,
                metadata={
                    "component": result.component,
                    "check_name": result.check_name,
                    "recommendations": result.recommendations
                }
            )
            
        except Exception as e:
            self.logger.error(f"Failed to trigger health alert: {e}")
    
    async def run_health_check(self, check_name: str) -> Optional[HealthCheckResult]:
        """Run a specific health check manually."""
        try:
            check = self.health_checks.get(check_name)
            if not check:
                self.logger.warning(f"Health check not found: {check_name}")
                return None
            
            result = await check.execute_check()
            
            # Store result
            self._store_health_result(result)
            self.check_results[check_name] = result
            
            return result
            
        except Exception as e:
            self.logger.error(f"Failed to run health check {check_name}: {e}")
            return None
    
    def get_system_health_summary(self) -> Dict[str, Any]:
        """Get comprehensive system health summary."""
        try:
            # Get component scores
            component_scores = {}
            for check_name, result in self.check_results.items():
                component_scores[result.component] = result.score
            
            # Calculate system score
            if component_scores:
                system_score = sum(component_scores.values()) / len(component_scores)
            else:
                system_score = 0.0
            
            # Get active alerts count
            try:
                from .alert_manager import alert_manager
                active_alerts = alert_manager.get_active_alerts()
                critical_alerts = [a for a in active_alerts if a.severity == AlertLevel.CRITICAL]
            except:
                active_alerts = []
                critical_alerts = []
            
            # Determine overall status
            if system_score >= 90:
                overall_status = "excellent"
            elif system_score >= 80:
                overall_status = "good"
            elif system_score >= 70:
                overall_status = "fair"
            elif system_score >= 50:
                overall_status = "poor"
            else:
                overall_status = "critical"
            
            return {
                "timestamp": datetime.now().isoformat(),
                "overall_status": overall_status,
                "system_score": system_score,
                "component_scores": component_scores,
                "component_count": len(component_scores),
                "healthy_components": len([s for s in component_scores.values() if s >= 80]),
                "degraded_components": len([s for s in component_scores.values() if s < 80]),
                "active_alerts": len(active_alerts),
                "critical_alerts": len(critical_alerts),
                "last_check_time": max([r.timestamp for r in self.check_results.values()]) if self.check_results else None,
                "health_checks_registered": len(self.health_checks)
            }
            
        except Exception as e:
            self.logger.error(f"Failed to get system health summary: {e}")
            return {
                "timestamp": datetime.now().isoformat(),
                "overall_status": "error",
                "error": str(e)
            }
    
    def get_health_status(self) -> Dict[str, Any]:
        """Get health checker status."""
        return {
            "running": self.running,
            "registered_checks": len(self.health_checks),
            "last_results_count": len(self.check_results)
        }

# Global health checker instance
health_checker = HealthChecker()