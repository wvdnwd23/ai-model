"""
Unified Monitoring System for the AI Crypto Trading System.
Provides comprehensive monitoring integration with all components orchestrated through a single entry point.

This module integrates:
- System monitoring (hardware/resource monitoring)
- AI performance monitoring (trading and decision tracking)
- Alert management (multi-channel support)
- Log aggregation (centralized logging)
- Metrics collection (time-series data)
- Dashboard backend (Flask APIs and WebSocket)
- Notification system (Telegram/email delivery)
- Health checking (automated component monitoring)
- Performance profiling (code profiling and optimization)

Usage:
    from src.monitoring import monitoring_system
    
    # Start the entire monitoring system
    monitoring_system.start()
    
    # Get a specific component
    system_monitor = monitoring_system.get_component('system_monitor')
    
    # Check system health
    health = monitoring_system.get_system_health()
    
    # Graceful shutdown
    monitoring_system.stop()

Standalone Usage:
    # For monitoring-only mode without AI system dependencies
    from src.monitoring.standalone_monitor import main
    main()
"""

import os
import sys
import time
import threading
import logging
import traceback
import signal
import atexit
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List, Callable, Set, Union
from dataclasses import dataclass, asdict, field
from collections import defaultdict, deque
from enum import Enum
from pathlib import Path
import json
import concurrent.futures
from contextlib import contextmanager

# Import configuration first
from .config import MonitoringConfig, monitoring_config, AlertLevel

# Import dependency injection system
from .interfaces import ILogger, IDatabaseManager, IConfigManager
from .dependency_injection import get_container, initialize_monitoring_container

# Check if we're in monitoring-only mode
MONITORING_ONLY_MODE = os.getenv('MONITORING_ONLY_MODE', 'false').lower() == 'true'

# Initialize dependency container based on mode
if MONITORING_ONLY_MODE:
    # Use standalone implementations
    container = initialize_monitoring_container()
    logger = container.get_logger(__name__)
    db_manager = container.get_database_manager()
else:
    # Use full AI system implementations (lazy import to avoid coupling)
    container = None
    logger = None
    db_manager = None
    
    def _get_logger(name: str):
        """Lazy import of AI system logger."""
        global logger
        if logger is None:
            try:
                from ..utils.logging import get_logger
                logger = get_logger(name)
            except ImportError:
                # Fallback to basic logging if AI system not available
                logger = logging.getLogger(name)
        return logger
    
    def _get_db_manager():
        """Lazy import of AI system database manager."""
        global db_manager
        if db_manager is None:
            try:
                from ..utils.database import db_manager as ai_db_manager
                db_manager = ai_db_manager
            except ImportError:
                # Use standalone database manager if AI system not available
                if container is None:
                    container = initialize_monitoring_container()
                db_manager = container.get_database_manager()
        return db_manager

# Import monitoring components with conditional loading
if MONITORING_ONLY_MODE:
    # In monitoring-only mode, use simplified components
    system_monitor = None
    ai_monitor = None
    alert_manager = None
    log_aggregator = None
    metrics_collector = None
    dashboard_backend = None
    notification_system = None
    health_checker = None
    performance_profiler = None
else:
    # Import full components (with lazy loading to avoid import chain issues)
    system_monitor = None
    ai_monitor = None
    alert_manager = None
    log_aggregator = None
    metrics_collector = None
    dashboard_backend = None
    notification_system = None
    health_checker = None
    performance_profiler = None

def _lazy_import_components():
    """Lazy import of monitoring components to avoid import chain coupling."""
    global system_monitor, ai_monitor, alert_manager, log_aggregator
    global metrics_collector, dashboard_backend, notification_system
    global health_checker, performance_profiler
    
    if MONITORING_ONLY_MODE:
        # Use standalone monitoring system
        from .standalone_monitor import StandaloneSystemMonitor
        system_monitor = StandaloneSystemMonitor(container)
        
        # Use simple implementations from dependency injection
        metrics_collector = container.get_metrics_collector()
        alert_manager = container.get_alert_manager()
        
        # Other components are not needed in monitoring-only mode
        ai_monitor = None
        log_aggregator = None
        dashboard_backend = None
        notification_system = None
        health_checker = None
        performance_profiler = None
    else:
        # Import full AI system components
        try:
            from .system_monitor import SystemMonitor, system_monitor as sm
            from .ai_monitor import AIPerformanceMonitor, ai_monitor as am
            from .alert_manager import AlertManager, alert_manager as alm
            from .log_aggregator import LogAggregator, log_aggregator as la
            from .metrics_collector import MetricsCollector, metrics_collector as mc
            from .dashboard_backend import DashboardBackend, dashboard_backend as db
            from .notification_system import NotificationSystem, notification_system as ns
            from .health_checker import HealthChecker, health_checker as hc
            from .performance_profiler import PerformanceProfiler, performance_profiler as pp
            
            system_monitor = sm
            ai_monitor = am
            alert_manager = alm
            log_aggregator = la
            metrics_collector = mc
            dashboard_backend = db
            notification_system = ns
            health_checker = hc
            performance_profiler = pp
            
        except ImportError as e:
            # Fallback to monitoring-only mode if AI components not available
            logger = _get_logger(__name__)
            logger.warning(f"AI system components not available, falling back to monitoring-only mode: {e}")
            os.environ['MONITORING_ONLY_MODE'] = 'true'
            _lazy_import_components()  # Recursive call with monitoring-only mode

class ComponentStatus(Enum):
    """Status of monitoring components."""
    STOPPED = "stopped"
    STARTING = "starting"
    RUNNING = "running"
    STOPPING = "stopping"
    ERROR = "error"
    MAINTENANCE = "maintenance"

class SystemHealth(Enum):
    """Overall system health levels."""
    EXCELLENT = "excellent"
    GOOD = "good"
    FAIR = "fair"
    POOR = "poor"
    CRITICAL = "critical"
    UNKNOWN = "unknown"

@dataclass
class ComponentInfo:
    """Information about a monitoring component."""
    name: str
    instance: Any
    status: ComponentStatus
    dependencies: List[str]
    start_method: str
    stop_method: str
    health_method: Optional[str] = None
    restart_count: int = 0
    last_restart: Optional[str] = None
    last_error: Optional[str] = None
    startup_time: Optional[float] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class SystemStatus:
    """Overall system status information."""
    timestamp: str
    overall_health: SystemHealth
    health_score: float
    components_status: Dict[str, ComponentStatus]
    active_components: int
    failed_components: int
    total_components: int
    uptime_seconds: float
    last_restart: Optional[str]
    alerts_count: int
    critical_alerts_count: int
    performance_metrics: Dict[str, Any]
    resource_usage: Dict[str, Any]
    recommendations: List[str]

class DependencyResolver:
    """Handles component dependencies and initialization order."""
    
    def __init__(self):
        self.logger = _get_logger(f"{__name__}.DependencyResolver") if not MONITORING_ONLY_MODE else container.get_logger(f"{__name__}.DependencyResolver")
        self.dependency_graph: Dict[str, Set[str]] = {}
        self.resolved_order: List[str] = []
    
    def add_dependency(self, component: str, depends_on: List[str]):
        """Add component dependencies."""
        self.dependency_graph[component] = set(depends_on)
    
    def resolve_order(self) -> List[str]:
        """Resolve component initialization order based on dependencies."""
        try:
            visited = set()
            temp_visited = set()
            order = []
            
            def visit(component: str):
                if component in temp_visited:
                    raise ValueError(f"Circular dependency detected involving {component}")
                if component in visited:
                    return
                
                temp_visited.add(component)
                
                # Visit dependencies first
                for dependency in self.dependency_graph.get(component, set()):
                    visit(dependency)
                
                temp_visited.remove(component)
                visited.add(component)
                order.append(component)
            
            # Visit all components
            for component in self.dependency_graph.keys():
                if component not in visited:
                    visit(component)
            
            self.resolved_order = order
            self.logger.info(f"Resolved component initialization order: {order}")
            return order
            
        except Exception as e:
            self.logger.error(f"Failed to resolve dependency order: {e}")
            # Fallback to predefined order based on mode
            if MONITORING_ONLY_MODE:
                return ['metrics_collector', 'system_monitor', 'alert_manager']
            else:
                return [
                    'config', 'database', 'log_aggregator', 'metrics_collector',
                    'system_monitor', 'ai_monitor', 'alert_manager', 'notification_system',
                    'health_checker', 'performance_profiler', 'dashboard_backend'
                ]

class ComponentManager:
    """Manages individual component lifecycle."""
    
    def __init__(self, monitoring_system):
        self.monitoring_system = monitoring_system
        self.logger = _get_logger(f"{__name__}.ComponentManager") if not MONITORING_ONLY_MODE else container.get_logger(f"{__name__}.ComponentManager")
        self.components: Dict[str, ComponentInfo] = {}
        self.startup_timeout = 30  # seconds
        self.shutdown_timeout = 15  # seconds
    
    def register_component(self, name: str, instance: Any, dependencies: List[str] = None,
                          start_method: str = "start", stop_method: str = "stop",
                          health_method: str = None):
        """Register a monitoring component."""
        try:
            component_info = ComponentInfo(
                name=name,
                instance=instance,
                status=ComponentStatus.STOPPED,
                dependencies=dependencies or [],
                start_method=start_method,
                stop_method=stop_method,
                health_method=health_method
            )
            
            self.components[name] = component_info
            self.logger.debug(f"Registered component: {name}")
            
        except Exception as e:
            self.logger.error(f"Failed to register component {name}: {e}")
            raise
    
    def start_component(self, name: str, timeout: float = None) -> bool:
        """Start a specific component."""
        try:
            if name not in self.components:
                raise ValueError(f"Component not found: {name}")
            
            component = self.components[name]
            
            if component.status == ComponentStatus.RUNNING:
                self.logger.debug(f"Component {name} is already running")
                return True
            
            if timeout is None:
                timeout = self.startup_timeout
            
            self.logger.info(f"Starting component: {name}")
            component.status = ComponentStatus.STARTING
            
            start_time = time.time()
            
            # Get the start method
            start_method = getattr(component.instance, component.start_method, None)
            if not start_method:
                raise AttributeError(f"Component {name} has no method {component.start_method}")
            
            # Start the component with timeout
            with concurrent.futures.ThreadPoolExecutor() as executor:
                future = executor.submit(start_method)
                try:
                    future.result(timeout=timeout)
                except concurrent.futures.TimeoutError:
                    raise TimeoutError(f"Component {name} startup timed out after {timeout}s")
            
            component.startup_time = time.time() - start_time
            component.status = ComponentStatus.RUNNING
            component.last_error = None
            
            self.logger.info(f"Component {name} started successfully in {component.startup_time:.2f}s")
            return True
            
        except Exception as e:
            if name in self.components:
                self.components[name].status = ComponentStatus.ERROR
                self.components[name].last_error = str(e)
            
            self.logger.error(f"Failed to start component {name}: {e}")
            return False
    
    def stop_component(self, name: str, timeout: float = None) -> bool:
        """Stop a specific component."""
        try:
            if name not in self.components:
                self.logger.warning(f"Component not found: {name}")
                return True
            
            component = self.components[name]
            
            if component.status == ComponentStatus.STOPPED:
                self.logger.debug(f"Component {name} is already stopped")
                return True
            
            if timeout is None:
                timeout = self.shutdown_timeout
            
            self.logger.info(f"Stopping component: {name}")
            component.status = ComponentStatus.STOPPING
            
            # Get the stop method
            stop_method = getattr(component.instance, component.stop_method, None)
            if not stop_method:
                self.logger.warning(f"Component {name} has no method {component.stop_method}")
                component.status = ComponentStatus.STOPPED
                return True
            
            # Stop the component with timeout
            with concurrent.futures.ThreadPoolExecutor() as executor:
                future = executor.submit(stop_method)
                try:
                    future.result(timeout=timeout)
                except concurrent.futures.TimeoutError:
                    self.logger.warning(f"Component {name} shutdown timed out after {timeout}s")
            
            component.status = ComponentStatus.STOPPED
            component.last_error = None
            
            self.logger.info(f"Component {name} stopped successfully")
            return True
            
        except Exception as e:
            if name in self.components:
                self.components[name].status = ComponentStatus.ERROR
                self.components[name].last_error = str(e)
            
            self.logger.error(f"Failed to stop component {name}: {e}")
            return False
    
    def restart_component(self, name: str) -> bool:
        """Restart a specific component."""
        try:
            self.logger.info(f"Restarting component: {name}")
            
            # Stop the component
            if not self.stop_component(name):
                self.logger.error(f"Failed to stop component {name} for restart")
                return False
            
            # Wait a moment
            time.sleep(1)
            
            # Start the component
            if not self.start_component(name):
                self.logger.error(f"Failed to start component {name} after restart")
                return False
            
            # Update restart count
            if name in self.components:
                self.components[name].restart_count += 1
                self.components[name].last_restart = datetime.now().isoformat()
            
            self.logger.info(f"Component {name} restarted successfully")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to restart component {name}: {e}")
            return False
    
    def get_component_status(self, name: str) -> Optional[ComponentStatus]:
        """Get the status of a specific component."""
        if name in self.components:
            return self.components[name].status
        return None
    
    def get_component_health(self, name: str) -> Dict[str, Any]:
        """Get health information for a specific component."""
        try:
            if name not in self.components:
                return {'status': 'not_found', 'message': f'Component {name} not found'}
            
            component = self.components[name]
            
            health_info = {
                'name': name,
                'status': component.status.value,
                'restart_count': component.restart_count,
                'last_restart': component.last_restart,
                'last_error': component.last_error,
                'startup_time': component.startup_time
            }
            
            # Get component-specific health if available
            if component.health_method:
                health_method = getattr(component.instance, component.health_method, None)
                if health_method:
                    try:
                        component_health = health_method()
                        health_info['component_health'] = component_health
                    except Exception as e:
                        health_info['health_error'] = str(e)
            
            return health_info
            
        except Exception as e:
            self.logger.error(f"Failed to get component health for {name}: {e}")
            return {'status': 'error', 'message': str(e)}

class MonitoringSystem:
    """Main unified monitoring system orchestrator."""
    
    def __init__(self):
        self.logger = _get_logger(__name__) if not MONITORING_ONLY_MODE else container.get_logger(__name__)
        self.config = monitoring_config
        
        # Core managers
        self.dependency_resolver = DependencyResolver()
        self.component_manager = ComponentManager(self)
        
        # System state
        self.running = False
        self.start_time: Optional[datetime] = None
        self.last_restart: Optional[datetime] = None
        
        # Thread safety
        self._lock = threading.RLock()
        
        # Signal handling
        self._setup_signal_handlers()
        
        # Initialize the system
        self._initialize_system()
    
    def _setup_signal_handlers(self):
        """Setup signal handlers for graceful shutdown."""
        try:
            def signal_handler(signum, frame):
                self.logger.info(f"Received signal {signum}, initiating graceful shutdown")
                self.stop()
                sys.exit(0)
            
            signal.signal(signal.SIGINT, signal_handler)
            signal.signal(signal.SIGTERM, signal_handler)
            
            # Register cleanup on exit
            atexit.register(self.stop)
            
        except Exception as e:
            self.logger.warning(f"Failed to setup signal handlers: {e}")
    
    def _initialize_system(self):
        """Initialize the monitoring system."""
        try:
            self.logger.info(f"Initializing monitoring system (monitoring_only_mode={MONITORING_ONLY_MODE})")
            
            # Lazy import components
            _lazy_import_components()
            
            # Register all components with their dependencies
            self._register_components()
            
            # Setup component dependencies
            self._setup_dependencies()
            
            self.logger.info("Monitoring system initialized successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize monitoring system: {e}")
            raise
    
    def _register_components(self):
        """Register all monitoring components."""
        try:
            if MONITORING_ONLY_MODE:
                # Register only essential components for monitoring-only mode
                components_config = [
                    {
                        'name': 'metrics_collector',
                        'instance': metrics_collector,
                        'start_method': 'start_collection',
                        'stop_method': 'stop_collection',
                        'health_method': None,
                        'dependencies': []
                    },
                    {
                        'name': 'system_monitor',
                        'instance': system_monitor,
                        'start_method': 'start_monitoring',
                        'stop_method': 'stop_monitoring',
                        'health_method': 'get_system_health_score',
                        'dependencies': ['metrics_collector']
                    },
                    {
                        'name': 'alert_manager',
                        'instance': alert_manager,
                        'start_method': None,  # Simple alert manager doesn't need start/stop
                        'stop_method': None,
                        'health_method': None,
                        'dependencies': []
                    }
                ]
            else:
                # Register full components for AI system mode
                components_config = [
                    {
                        'name': 'log_aggregator',
                        'instance': log_aggregator,
                        'start_method': 'start',
                        'stop_method': 'stop',
                        'health_method': 'get_health_status',
                        'dependencies': []
                    },
                    {
                        'name': 'metrics_collector',
                        'instance': metrics_collector,
                        'start_method': 'start_collection',
                        'stop_method': 'stop_collection',
                        'health_method': 'get_metrics_summary',
                        'dependencies': []
                    },
                    {
                        'name': 'system_monitor',
                        'instance': system_monitor,
                        'start_method': 'start_monitoring',
                        'stop_method': 'stop_monitoring',
                        'health_method': 'get_system_health_score',
                        'dependencies': ['metrics_collector']
                    },
                    {
                        'name': 'ai_monitor',
                        'instance': ai_monitor,
                        'start_method': 'start_monitoring',
                        'stop_method': 'stop_monitoring',
                        'health_method': 'get_performance_summary',
                        'dependencies': ['metrics_collector']
                    },
                    {
                        'name': 'alert_manager',
                        'instance': alert_manager,
                        'start_method': 'start',
                        'stop_method': 'stop',
                        'health_method': 'get_health_status',
                        'dependencies': ['log_aggregator']
                    },
                    {
                        'name': 'notification_system',
                        'instance': notification_system,
                        'start_method': 'start',
                        'stop_method': 'stop',
                        'health_method': 'get_system_status',
                        'dependencies': ['alert_manager']
                    },
                    {
                        'name': 'health_checker',
                        'instance': health_checker,
                        'start_method': 'start_health_checking',
                        'stop_method': 'stop_health_checking',
                        'health_method': 'get_health_status',
                        'dependencies': ['system_monitor', 'ai_monitor']
                    },
                    {
                        'name': 'performance_profiler',
                        'instance': performance_profiler,
                        'start_method': None,  # No automatic start
                        'stop_method': None,   # No automatic stop
                        'health_method': 'get_health_status',
                        'dependencies': []
                    },
                    {
                        'name': 'dashboard_backend',
                        'instance': dashboard_backend,
                        'start_method': 'start_real_time_updates',
                        'stop_method': 'stop_real_time_updates',
                        'health_method': 'get_health_status',
                        'dependencies': ['system_monitor', 'ai_monitor', 'alert_manager', 'metrics_collector']
                    }
                ]
            
            # Filter out None instances
            valid_components = [c for c in components_config if c['instance'] is not None]
            
            for component_config in valid_components:
                self.component_manager.register_component(**component_config)
            
            self.logger.info(f"Registered {len(valid_components)} monitoring components")
            
        except Exception as e:
            self.logger.error(f"Failed to register components: {e}")
            raise
    
    def _setup_dependencies(self):
        """Setup component dependencies for proper initialization order."""
        try:
            # Add dependencies to resolver
            for name, component in self.component_manager.components.items():
                self.dependency_resolver.add_dependency(name, component.dependencies)
            
            # Resolve initialization order
            self.initialization_order = self.dependency_resolver.resolve_order()
            
        except Exception as e:
            self.logger.error(f"Failed to setup dependencies: {e}")
            raise
    
    def start(self, components: List[str] = None) -> bool:
        """Start the monitoring system or specific components."""
        try:
            with self._lock:
                if self.running:
                    self.logger.info("Monitoring system is already running")
                    return True
                
                self.logger.info(f"Starting monitoring system (monitoring_only_mode={MONITORING_ONLY_MODE})")
                self.start_time = datetime.now()
                
                # Determine which components to start
                if components is None:
                    components_to_start = self.initialization_order
                else:
                    # Validate requested components
                    invalid_components = [c for c in components if c not in self.component_manager.components]
                    if invalid_components:
                        raise ValueError(f"Invalid components: {invalid_components}")
                    components_to_start = components
                
                # Start components in dependency order
                started_components = []
                failed_components = []
                
                for component_name in components_to_start:
                    if component_name not in self.component_manager.components:
                        continue
                    
                    component = self.component_manager.components[component_name]
                    
                    # Skip components without start method
                    if not component.start_method:
                        self.logger.debug(f"Skipping component {component_name} (no start method)")
                        continue
                    
                    self.logger.info(f"Starting component: {component_name}")
                    
                    if self.component_manager.start_component(component_name):
                        started_components.append(component_name)
                        self.logger.info(f"✓ Component {component_name} started successfully")
                    else:
                        failed_components.append(component_name)
                        self.logger.error(f"✗ Component {component_name} failed to start")
                
                # Update system state
                if started_components:
                    self.running = True
                    self.logger.info(f"Monitoring system started with {len(started_components)} components")
                    
                    if failed_components:
                        self.logger.warning(f"Some components failed to start: {failed_components}")
                    
                    return True
                else:
                    self.logger.error("No components started successfully")
                    return False
                
        except Exception as e:
            self.logger.error(f"Failed to start monitoring system: {e}")
            return False
    
    def stop(self, components: List[str] = None) -> bool:
        """Stop the monitoring system or specific components."""
        try:
            with self._lock:
                if not self.running and components is None:
                    self.logger.info("Monitoring system is already stopped")
                    return True
                
                self.logger.info("Stopping monitoring system")
                
                # Determine which components to stop
                if components is None:
                    components_to_stop = list(reversed(self.initialization_order))
                else:
                    components_to_stop = components
                
                # Stop components in reverse dependency order
                stopped_components = []
                failed_components = []
                
                for component_name in components_to_stop:
                    if component_name not in self.component_manager.components:
                        continue
                    
                    component = self.component_manager.components[component_name]
                    
                    # Skip components without stop method
                    if not component.stop_method:
                        self.logger.debug(f"Skipping component {component_name} (no stop method)")
                        continue
                    
                    if component.status == ComponentStatus.RUNNING:
                        self.logger.info(f"Stopping component: {component_name}")
                        
                        if self.component_manager.stop_component(component_name):
                            stopped_components.append(component_name)
                            self.logger.info(f"✓ Component {component_name} stopped successfully")
                        else:
                            failed_components.append(component_name)
                            self.logger.error(f"✗ Component {component_name} failed to stop")
                
                # Update system state
                if components is None:
                    self.running = False
                    self.logger.info(f"Monitoring system stopped. {len(stopped_components)} components stopped")
                    
                    if failed_components:
                        self.logger.warning(f"Some components failed to stop: {failed_components}")
                
                return len(failed_components) == 0
                
        except Exception as e:
            self.logger.error(f"Failed to stop monitoring system: {e}")
            return False
    
    def restart(self, components: List[str] = None) -> bool:
        """Restart the monitoring system or specific components."""
        try:
            self.logger.info("Restarting monitoring system")
            self.last_restart = datetime.now()
            
            if components is None:
                # Full system restart
                if not self.stop():
                    self.logger.error("Failed to stop system for restart")
                    return False
                
                time.sleep(2)  # Brief pause
                
                if not self.start():
                    self.logger.error("Failed to start system after restart")
                    return False
            else:
                # Restart specific components
                for component_name in components:
                    if not self.component_manager.restart_component(component_name):
                        self.logger.error(f"Failed to restart component: {component_name}")
                        return False
            
            self.logger.info("Monitoring system restarted successfully")
            return True
            
        except Exception as e:
            self.logger.error(f"Failed to restart monitoring system: {e}")
            return False
    
    def get_component(self, name: str) -> Optional[Any]:
        """Get a specific monitoring component instance."""
        try:
            if name in self.component_manager.components:
                return self.component_manager.components[name].instance
            else:
                self.logger.warning(f"Component not found: {name}")
                return None
                
        except Exception as e:
            self.logger.error(f"Failed to get component {name}: {e}")
            return None
    
    def get_system_health(self) -> Dict[str, Any]:
        """Get comprehensive system health information."""
        try:
            timestamp = datetime.now().isoformat()
            
            # Get component statuses
            components_status = {}
            active_components = 0
            failed_components = 0
            
            for name, component in self.component_manager.components.items():
                components_status[name] = component.status.value
                if component.status == ComponentStatus.RUNNING:
                    active_components += 1
                elif component.status == ComponentStatus.ERROR:
                    failed_components += 1
            
            total_components = len(self.component_manager.components)
            
            # Calculate health score
            if total_components > 0:
                health_score = (active_components / total_components) * 100
            else:
                health_score = 0
            
            # Determine overall health
            if health_score >= 90:
                overall_health = "excellent"
            elif health_score >= 80:
                overall_health = "good"
            elif health_score >= 60:
                overall_health = "fair"
            elif health_score >= 40:
                overall_health = "poor"
            else:
                overall_health = "critical"
            
            # Calculate uptime
            uptime_seconds = 0
            if self.start_time:
                uptime_seconds = (datetime.now() - self.start_time).total_seconds()
            
            # Get alerts count
            alerts_count = 0
            critical_alerts_count = 0
            try:
                if alert_manager and hasattr(alert_manager, 'get_active_alerts'):
                    active_alerts = alert_manager.get_active_alerts()
                    alerts_count = len(active_alerts)
                    critical_alerts_count = len([a for a in active_alerts if hasattr(a, 'severity') and a.severity == AlertLevel.CRITICAL])
            except Exception:
                pass
            
            # Get performance metrics
            performance_metrics = {}
            try:
                if system_monitor and hasattr(system_monitor, 'get_current_metrics'):
                    current_metrics = system_monitor.get_current_metrics()
                    if current_metrics:
                        if isinstance(current_metrics, dict):
                            performance_metrics = {
                                'cpu_usage': current_metrics.get('cpu_usage', 0),
                                'memory_usage': current_metrics.get('memory_usage', 0),
                                'disk_usage': current_metrics.get('disk_usage', 0)
                            }
                        else:
                            performance_metrics = {
                                'cpu_usage': getattr(current_metrics, 'cpu_usage', 0),
                                'memory_usage': getattr(current_metrics, 'memory_usage', 0),
                                'disk_usage': getattr(current_metrics, 'disk_usage', 0)
                            }
            except Exception:
                pass
            
            # Generate recommendations
            recommendations = []
            if failed_components > 0:
                recommendations.append(f"Restart {failed_components} failed components")
            if health_score < 80:
                recommendations.append("Investigate component health issues")
            if critical_alerts_count > 0:
                recommendations.append(f"Address {critical_alerts_count} critical alerts")
            
            return {
                'timestamp': timestamp,
                'overall_health': overall_health,
                'health_score': health_score,
                'running': self.running,
                'monitoring_only_mode': MONITORING_ONLY_MODE,
                'components_status': components_status,
                'active_components': active_components,
                'failed_components': failed_components,
                'total_components': total_components,
                'uptime_seconds': uptime_seconds,
                'last_restart': self.last_restart.isoformat() if self.last_restart else None,
                'alerts_count': alerts_count,
                'critical_alerts_count': critical_alerts_count,
                'performance_metrics': performance_metrics,
                'recommendations': recommendations
            }
            
        except Exception as e:
            self.logger.error(f"Failed to get system health: {e}")
            return {
                'timestamp': datetime.now().isoformat(),
                'overall_health': 'error',
                'monitoring_only_mode': MONITORING_ONLY_MODE,
                'error': str(e)
            }
    
    def get_config(self) -> MonitoringConfig:
        """Get the monitoring configuration."""
        return self.config
    
    def get_status(self) -> Dict[str, Any]:
        """Get detailed system status."""
        try:
            return {
                'timestamp': datetime.now().isoformat(),
                'running': self.running,
                'monitoring_only_mode': MONITORING_ONLY_MODE,
                'start_time': self.start_time.isoformat() if self.start_time else None,
                'last_restart': self.last_restart.isoformat() if self.last_restart else None,
                'components': {
                    name: {
                        'status': component.status.value,
                        'restart_count': component.restart_count,
                        'last_restart': component.last_restart,
                        'last_error': component.last_error,
                        'startup_time': component.startup_time
                    }
                    for name, component in self.component_manager.components.items()
                },
                'initialization_order': getattr(self, 'initialization_order', []),
                'health': self.get_system_health()
            }
            
        except Exception as e:
            self.logger.error(f"Failed to get system status: {e}")
            return {
                'timestamp': datetime.now().isoformat(),
                'monitoring_only_mode': MONITORING_ONLY_MODE,
                'error': str(e)
            }

# Create global monitoring system instance
monitoring_system = MonitoringSystem()

# Export all components and the main system
__version__ = "1.0.0"
__all__ = [
    # Main system
    "monitoring_system",
    "MonitoringSystem",
    
    # Configuration
    "MonitoringConfig",
    "monitoring_config",
    
    # Individual components (conditionally available)
    "SystemMonitor",
    "system_monitor",
    "AIPerformanceMonitor", 
    "ai_monitor",
    "AlertManager",
    "alert_manager",
    "LogAggregator",
    "log_aggregator",
    "MetricsCollector",
    "metrics_collector",
    "DashboardBackend",
    "dashboard_backend",
    "NotificationSystem",
    "notification_system",
    "HealthChecker",
    "health_checker",
    "PerformanceProfiler",
    "performance_profiler",
    
    # Enums and data classes
    "ComponentStatus",
    "SystemHealth",
    "ComponentInfo",
    "SystemStatus",
    "AlertLevel",
    
    # Dependency injection
    "container",
    "MONITORING_ONLY_MODE"
]

# Auto-start monitoring system if configured
if monitoring_config.alerts.enabled and os.getenv('AUTO_START_MONITORING', 'false').lower() == 'true':
    try:
        monitoring_system.start()
    except Exception as e:
        logging.getLogger(__name__).error(f"Failed to auto-start monitoring system: {e}")