#!/usr/bin/env python3
"""
AI Crypto Trading System - Main Application Entry Point
Orchestrates all modules and provides the main application loop.
"""

import os
import sys
import signal
import asyncio
import threading
import time
from pathlib import Path
from typing import Dict, Any, Optional
import json

# Add src to Python path
sys.path.insert(0, str(Path(__file__).parent))

# Core imports
from utils.config import config_manager
from utils.database import db_manager
from utils.logging import get_logger, get_performance_logger
from utils.communication import CommunicationManager

# Module imports
from modules.ai_controller.controller import AIController
from modules.coin_scanner.scanner import CoinScanner
from modules.chart_checker.checker import ChartChecker
from modules.combiner.combiner import Combiner
from modules.verifier_executor.executor import VerifierExecutor

# Dashboard import
try:
    from dashboard.app import create_app
except ImportError:
    create_app = None

class AITradingSystem:
    """Main AI Trading System orchestrator."""
    
    def __init__(self):
        self.logger = get_logger("main")
        self.perf_logger = get_performance_logger("main")
        
        # System state
        self.running = False
        self.modules = {}
        self.communication_manager = None
        self.dashboard_app = None
        self.dashboard_thread = None
        
        # Performance tracking
        self.start_time = None
        self.stats = {
            'trades_executed': 0,
            'decisions_made': 0,
            'uptime_seconds': 0,
            'last_activity': None
        }
        
        # Signal handlers
        signal.signal(signal.SIGTERM, self._signal_handler)
        signal.signal(signal.SIGINT, self._signal_handler)
        
        self.logger.system("AI Trading System initialized")
    
    def _signal_handler(self, signum, frame):
        """Handle shutdown signals gracefully."""
        self.logger.system(f"Received signal {signum}, initiating shutdown...")
        self.shutdown()
    
    def initialize_modules(self):
        """Initialize all AI modules."""
        self.logger.system("Initializing AI modules...")
        
        try:
            # Initialize communication manager
            self.communication_manager = CommunicationManager()
            
            # Initialize modules in dependency order
            self.modules['ai_controller'] = AIController()
            self.modules['coin_scanner'] = CoinScanner()
            self.modules['chart_checker'] = ChartChecker()
            self.modules['combiner'] = Combiner()
            self.modules['verifier_executor'] = VerifierExecutor()
            
            # Set up inter-module communication
            for module_name, module in self.modules.items():
                self.communication_manager.register_module(module_name, module)
            
            self.logger.system("All modules initialized successfully")
            return True
            
        except Exception as e:
            self.logger.error("Failed to initialize modules", exception=e)
            return False
    
    def start_dashboard(self):
        """Start the Flask dashboard in a separate thread."""
        if create_app is None:
            self.logger.warn("Dashboard not available - Flask app not found")
            return
        
        try:
            self.dashboard_app = create_app()
            
            def run_dashboard():
                port = config_manager.get_all_config().get('system', {}).get('flask_port', 5050)
                self.dashboard_app.run(
                    host='0.0.0.0',
                    port=port,
                    debug=False,
                    use_reloader=False,
                    threaded=True
                )
            
            self.dashboard_thread = threading.Thread(target=run_dashboard, daemon=True)
            self.dashboard_thread.start()
            
            self.logger.system(f"Dashboard started on port {config_manager.get_all_config().get('system', {}).get('flask_port', 5050)}")
            
        except Exception as e:
            self.logger.error("Failed to start dashboard", exception=e)
    
    def health_check(self) -> Dict[str, Any]:
        """Perform system health check."""
        health_status = {
            'overall_status': 'healthy',
            'modules': {},
            'system': {
                'uptime': time.time() - self.start_time if self.start_time else 0,
                'running': self.running
            },
            'stats': self.stats.copy()
        }
        
        # Check module health
        for module_name, module in self.modules.items():
            try:
                if hasattr(module, 'health_check'):
                    module_health = module.health_check()
                    health_status['modules'][module_name] = module_health
                    
                    if module_health.get('status') != 'healthy':
                        health_status['overall_status'] = 'warning'
                else:
                    health_status['modules'][module_name] = {'status': 'unknown'}
                    
            except Exception as e:
                health_status['modules'][module_name] = {
                    'status': 'error',
                    'error': str(e)
                }
                health_status['overall_status'] = 'error'
        
        return health_status
    
    def update_stats(self):
        """Update system statistics."""
        if self.start_time:
            self.stats['uptime_seconds'] = int(time.time() - self.start_time)
        
        self.stats['last_activity'] = time.time()
        
        # Log stats to database
        try:
            db_manager.update_system_health({
                'module_name': 'main_system',
                'status': 'healthy' if self.running else 'stopped',
                'cpu_usage': 0,  # Would be populated by health check script
                'memory_usage': 0,  # Would be populated by health check script
                'response_time': 0,
                'error_count': 0,
                'last_activity': self.stats['last_activity']
            })
        except Exception as e:
            self.logger.error("Failed to update system stats", exception=e)
    
    async def trading_loop(self):
        """Main trading loop - orchestrates the AI modules."""
        self.logger.system("Starting main trading loop...")
        
        loop_count = 0
        
        while self.running:
            try:
                loop_start_time = time.time()
                loop_count += 1
                
                self.logger.system(f"Trading loop iteration {loop_count}")
                
                # Step 1: Scan for potential coins
                self.logger.system("Step 1: Scanning for potential coins...")
                scan_result = await self.modules['coin_scanner'].scan_markets()
                
                if scan_result and scan_result.get('coins'):
                    self.logger.system(f"Found {len(scan_result['coins'])} potential coins")
                    
                    # Step 2: Analyze each potential coin
                    for coin_data in scan_result['coins'][:5]:  # Limit to top 5
                        symbol = coin_data['symbol']
                        self.logger.system(f"Step 2: Analyzing {symbol}...")
                        
                        # Chart analysis
                        chart_result = await self.modules['chart_checker'].analyze_chart(symbol, coin_data)
                        
                        if chart_result and chart_result.get('overall_bias') == 'bullish':
                            self.logger.system(f"Step 3: Combining signals for {symbol}...")
                            
                            # Combine signals
                            combined_result = await self.modules['combiner'].combine_signals(
                                coin_data, chart_result
                            )
                            
                            if combined_result and combined_result.get('decision') == 'buy':
                                self.logger.system(f"Step 4: Verifying and executing {symbol}...")
                                
                                # Verify and execute
                                execution_result = await self.modules['verifier_executor'].verify_and_execute(
                                    combined_result
                                )
                                
                                if execution_result:
                                    self.stats['trades_executed'] += 1
                                    self.logger.trade(f"Trade executed for {symbol}", execution_result)
                
                self.stats['decisions_made'] += 1
                
                # Update statistics
                self.update_stats()
                
                # Calculate loop duration
                loop_duration = time.time() - loop_start_time
                self.logger.system(f"Trading loop {loop_count} completed in {loop_duration:.2f}s")
                
                # Wait before next iteration (configurable)
                await asyncio.sleep(60)  # 1 minute between loops
                
            except Exception as e:
                self.logger.error(f"Error in trading loop iteration {loop_count}", exception=e)
                await asyncio.sleep(30)  # Wait 30 seconds on error
    
    async def start(self):
        """Start the AI trading system."""
        self.logger.system("=== Starting AI Crypto Trading System ===")
        
        try:
            # Initialize modules
            if not self.initialize_modules():
                raise Exception("Module initialization failed")
            
            # Start dashboard
            self.start_dashboard()
            
            # Mark system as running
            self.running = True
            self.start_time = time.time()
            
            # Log startup
            self.logger.system("AI Trading System started successfully")
            self.logger.system(f"Dashboard available at: http://localhost:{config_manager.get_all_config().get('system', {}).get('flask_port', 5050)}")
            
            # Start main trading loop
            await self.trading_loop()
            
        except Exception as e:
            self.logger.error("Failed to start AI trading system", exception=e)
            self.shutdown()
            raise
    
    def shutdown(self):
        """Shutdown the AI trading system gracefully."""
        if not self.running:
            return
        
        self.logger.system("=== Shutting down AI Trading System ===")
        
        # Mark as not running
        self.running = False
        
        # Shutdown modules
        for module_name, module in self.modules.items():
            try:
                if hasattr(module, 'shutdown'):
                    module.shutdown()
                self.logger.system(f"Module {module_name} shutdown complete")
            except Exception as e:
                self.logger.error(f"Error shutting down module {module_name}", exception=e)
        
        # Shutdown communication manager
        if self.communication_manager:
            try:
                self.communication_manager.shutdown()
                self.logger.system("Communication manager shutdown complete")
            except Exception as e:
                self.logger.error("Error shutting down communication manager", exception=e)
        
        # Final stats update
        self.update_stats()
        
        # Log shutdown
        uptime = time.time() - self.start_time if self.start_time else 0
        self.logger.system(f"AI Trading System shutdown complete. Uptime: {uptime:.1f}s")
        self.logger.system(f"Final stats: {self.stats}")

def create_pid_file():
    """Create PID file for process management."""
    pid_file = Path("/opt/ai-crypto-trader/data/ai-trader.pid")
    pid_file.parent.mkdir(parents=True, exist_ok=True)
    
    with open(pid_file, 'w') as f:
        f.write(str(os.getpid()))

def remove_pid_file():
    """Remove PID file on shutdown."""
    pid_file = Path("/opt/ai-crypto-trader/data/ai-trader.pid")
    if pid_file.exists():
        pid_file.unlink()

async def main():
    """Main entry point."""
    try:
        # Create PID file
        create_pid_file()
        
        # Create and start the trading system
        trading_system = AITradingSystem()
        await trading_system.start()
        
    except KeyboardInterrupt:
        print("\nShutdown requested by user")
    except Exception as e:
        print(f"Fatal error: {e}")
        sys.exit(1)
    finally:
        # Clean up PID file
        remove_pid_file()

if __name__ == "__main__":
    # Set up event loop
    if sys.platform == 'win32':
        asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
    
    # Run the main application
    asyncio.run(main())