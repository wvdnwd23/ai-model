"""
AI Crypto Trading System - Self-learning cryptocurrency trading system.

This package contains all the core modules for the AI-powered crypto trading system:
- AI Controller: Central orchestrator using LLaMA Mini
- Coin Scanner: Sentiment analysis and volume anomaly detection
- Chart Checker: Multi-timeframe technical analysis
- Combiner: Decision fusion engine with adaptive learning
- Verifier Executor: Final validation and trade execution

The system uses local LLaMA Mini via Ollama for AI coordination,
browser automation with Playwright for data scraping and trade execution,
and SQLite database with JSON fields for AI learning and data storage.
"""

__version__ = "1.0.0"
__author__ = "AI Crypto Trading System"
__description__ = "Self-learning AI cryptocurrency trading system"

# Core modules
import os
from . import utils

# Only import modules if not in monitoring-only mode
MONITORING_ONLY_MODE = os.getenv('MONITORING_ONLY_MODE', 'false').lower() == 'true'

if not MONITORING_ONLY_MODE:
    from . import modules
    __all__ = [
        "utils",
        "modules",
        "__version__",
        "__author__",
        "__description__"
    ]
else:
    # In monitoring-only mode, don't import modules to avoid TA-Lib dependency
    __all__ = [
        "utils",
        "__version__",
        "__author__",
        "__description__"
    ]