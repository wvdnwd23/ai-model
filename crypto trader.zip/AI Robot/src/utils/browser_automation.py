"""
Browser automation utilities for the AI Crypto Trading System.
Handles Playwright-based web scraping and trade execution.
"""

import asyncio
import logging
from typing import Dict, List, Any, Optional, Callable
from datetime import datetime, timedelta
import json
import random
import time
from pathlib import Path

from playwright.async_api import async_playwright, Browser, BrowserContext, Page
from playwright.async_api import TimeoutError as PlaywrightTimeoutError
import requests
from bs4 import BeautifulSoup

class BrowserManager:
    """Manages browser instances and automation tasks."""
    
    def __init__(self, headless: bool = True, user_data_dir: Optional[str] = None):
        self.headless = headless
        self.user_data_dir = user_data_dir or "src/data/cache/session_data"
        self.browser: Optional[Browser] = None
        self.context: Optional[BrowserContext] = None
        self.pages: Dict[str, Page] = {}
        self.logger = logging.getLogger(__name__)
        
        # Browser configuration
        self.config = {
            "headless": headless,
            "viewport": {"width": 1920, "height": 1080},
            "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "timeout": 30000,
            "retry_attempts": 3,
            "session_persistence": True
        }
        
        # Rate limiting
        self.last_request_time = {}
        self.min_delay = 1.0  # Minimum delay between requests
        
    async def start(self):
        """Start browser instance."""
        try:
            self.playwright = await async_playwright().start()
            self.browser = await self.playwright.chromium.launch(
                headless=self.config["headless"],
                user_data_dir=self.user_data_dir,
                args=[
                    "--no-sandbox",
                    "--disable-blink-features=AutomationControlled",
                    "--disable-web-security",
                    "--disable-features=VizDisplayCompositor"
                ]
            )
            
            self.context = await self.browser.new_context(
                viewport=self.config["viewport"],
                user_agent=self.config["user_agent"]
            )
            
            # Add stealth scripts
            await self.context.add_init_script("""
                Object.defineProperty(navigator, 'webdriver', {
                    get: () => undefined,
                });
            """)
            
            self.logger.info("Browser started successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to start browser: {e}")
            raise
    
    async def stop(self):
        """Stop browser instance."""
        try:
            if self.context:
                await self.context.close()
            if self.browser:
                await self.browser.close()
            if hasattr(self, 'playwright'):
                await self.playwright.stop()
            self.logger.info("Browser stopped successfully")
        except Exception as e:
            self.logger.error(f"Error stopping browser: {e}")
    
    async def get_page(self, page_id: str, url: Optional[str] = None) -> Page:
        """Get or create a page with given ID."""
        if page_id not in self.pages:
            page = await self.context.new_page()
            self.pages[page_id] = page
            
            # Set up page event handlers
            page.on("console", lambda msg: self.logger.debug(f"Console [{page_id}]: {msg.text}"))
            page.on("pageerror", lambda error: self.logger.error(f"Page error [{page_id}]: {error}"))
            
        page = self.pages[page_id]
        
        if url:
            await self._navigate_with_retry(page, url)
        
        return page
    
    async def _navigate_with_retry(self, page: Page, url: str, max_retries: int = 3):
        """Navigate to URL with retry logic."""
        for attempt in range(max_retries):
            try:
                # Rate limiting
                await self._apply_rate_limit(url)
                
                await page.goto(url, wait_until="domcontentloaded", timeout=self.config["timeout"])
                await page.wait_for_load_state("networkidle", timeout=10000)
                return
                
            except PlaywrightTimeoutError:
                if attempt == max_retries - 1:
                    raise
                await asyncio.sleep(2 ** attempt)  # Exponential backoff
            except Exception as e:
                self.logger.error(f"Navigation error (attempt {attempt + 1}): {e}")
                if attempt == max_retries - 1:
                    raise
                await asyncio.sleep(2 ** attempt)
    
    async def _apply_rate_limit(self, url: str):
        """Apply rate limiting based on domain."""
        domain = url.split('/')[2] if '://' in url else url.split('/')[0]
        
        if domain in self.last_request_time:
            elapsed = time.time() - self.last_request_time[domain]
            if elapsed < self.min_delay:
                await asyncio.sleep(self.min_delay - elapsed)
        
        self.last_request_time[domain] = time.time()
    
    async def wait_for_element(self, page: Page, selector: str, timeout: int = 10000) -> bool:
        """Wait for element to appear."""
        try:
            await page.wait_for_selector(selector, timeout=timeout)
            return True
        except PlaywrightTimeoutError:
            return False
    
    async def safe_click(self, page: Page, selector: str, timeout: int = 10000) -> bool:
        """Safely click an element with error handling."""
        try:
            await page.wait_for_selector(selector, timeout=timeout)
            await page.click(selector)
            await asyncio.sleep(random.uniform(0.5, 1.5))  # Human-like delay
            return True
        except Exception as e:
            self.logger.error(f"Click failed for selector {selector}: {e}")
            return False
    
    async def safe_type(self, page: Page, selector: str, text: str, timeout: int = 10000) -> bool:
        """Safely type text into an element."""
        try:
            await page.wait_for_selector(selector, timeout=timeout)
            await page.fill(selector, text)
            await asyncio.sleep(random.uniform(0.3, 0.8))
            return True
        except Exception as e:
            self.logger.error(f"Type failed for selector {selector}: {e}")
            return False
    
    async def get_text(self, page: Page, selector: str, timeout: int = 10000) -> Optional[str]:
        """Get text content from an element."""
        try:
            await page.wait_for_selector(selector, timeout=timeout)
            return await page.text_content(selector)
        except Exception as e:
            self.logger.error(f"Get text failed for selector {selector}: {e}")
            return None
    
    async def get_attribute(self, page: Page, selector: str, attribute: str, timeout: int = 10000) -> Optional[str]:
        """Get attribute value from an element."""
        try:
            await page.wait_for_selector(selector, timeout=timeout)
            return await page.get_attribute(selector, attribute)
        except Exception as e:
            self.logger.error(f"Get attribute failed for selector {selector}: {e}")
            return None
    
    async def execute_script(self, page: Page, script: str) -> Any:
        """Execute JavaScript on the page."""
        try:
            return await page.evaluate(script)
        except Exception as e:
            self.logger.error(f"Script execution failed: {e}")
            return None
    
    async def take_screenshot(self, page: Page, path: Optional[str] = None) -> bytes:
        """Take a screenshot of the page."""
        try:
            if path:
                await page.screenshot(path=path, full_page=True)
            return await page.screenshot(full_page=True)
        except Exception as e:
            self.logger.error(f"Screenshot failed: {e}")
            return b""
    
    async def handle_captcha_detection(self, page: Page) -> bool:
        """Detect and handle captcha challenges."""
        captcha_selectors = [
            "iframe[src*='captcha']",
            ".captcha",
            "#captcha",
            "[data-captcha]",
            ".recaptcha",
            ".hcaptcha"
        ]
        
        for selector in captcha_selectors:
            if await page.query_selector(selector):
                self.logger.warning("Captcha detected - manual intervention required")
                # Take screenshot for manual review
                await self.take_screenshot(page, f"src/data/logs/captcha_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png")
                return True
        
        return False
    
    async def check_rate_limit(self, page: Page) -> bool:
        """Check if page shows rate limiting."""
        rate_limit_indicators = [
            "rate limit",
            "too many requests",
            "429",
            "please wait",
            "try again later"
        ]
        
        try:
            content = await page.content()
            content_lower = content.lower()
            
            for indicator in rate_limit_indicators:
                if indicator in content_lower:
                    self.logger.warning(f"Rate limit detected: {indicator}")
                    return True
        except Exception:
            pass
        
        return False
    
    async def wait_for_network_idle(self, page: Page, timeout: int = 30000):
        """Wait for network to be idle."""
        try:
            await page.wait_for_load_state("networkidle", timeout=timeout)
        except PlaywrightTimeoutError:
            self.logger.warning("Network idle timeout - continuing anyway")

class WebScraper:
    """Base class for web scraping operations."""
    
    def __init__(self, browser_manager: BrowserManager):
        self.browser_manager = browser_manager
        self.logger = logging.getLogger(__name__)
    
    async def scrape_with_fallback(self, url: str, selectors: List[str], 
                                 fallback_method: Optional[Callable] = None) -> Optional[str]:
        """Scrape content with multiple selector fallbacks."""
        page = await self.browser_manager.get_page("scraper", url)
        
        # Try each selector
        for selector in selectors:
            content = await self.browser_manager.get_text(page, selector, timeout=5000)
            if content:
                return content.strip()
        
        # Try fallback method if provided
        if fallback_method:
            try:
                return await fallback_method(page)
            except Exception as e:
                self.logger.error(f"Fallback method failed: {e}")
        
        return None
    
    async def scrape_table_data(self, page: Page, table_selector: str) -> List[Dict[str, str]]:
        """Scrape table data into list of dictionaries."""
        try:
            await page.wait_for_selector(table_selector)
            
            # Get headers
            headers = await page.evaluate(f"""
                () => {{
                    const table = document.querySelector('{table_selector}');
                    const headerRow = table.querySelector('thead tr, tr:first-child');
                    return Array.from(headerRow.cells).map(cell => cell.textContent.trim());
                }}
            """)
            
            # Get rows
            rows_data = await page.evaluate(f"""
                () => {{
                    const table = document.querySelector('{table_selector}');
                    const rows = table.querySelectorAll('tbody tr, tr:not(:first-child)');
                    return Array.from(rows).map(row => 
                        Array.from(row.cells).map(cell => cell.textContent.trim())
                    );
                }}
            """)
            
            # Combine headers with row data
            result = []
            for row_data in rows_data:
                if len(row_data) == len(headers):
                    result.append(dict(zip(headers, row_data)))
            
            return result
            
        except Exception as e:
            self.logger.error(f"Table scraping failed: {e}")
            return []
    
    async def extract_json_from_script(self, page: Page, script_selector: str) -> Optional[Dict]:
        """Extract JSON data from script tags."""
        try:
            script_content = await page.evaluate(f"""
                () => {{
                    const script = document.querySelector('{script_selector}');
                    return script ? script.textContent : null;
                }}
            """)
            
            if script_content:
                # Try to extract JSON from script content
                import re
                json_match = re.search(r'\{.*\}', script_content, re.DOTALL)
                if json_match:
                    return json.loads(json_match.group())
            
        except Exception as e:
            self.logger.error(f"JSON extraction failed: {e}")
        
        return None

# Session manager for persistent browser sessions
class SessionManager:
    """Manages persistent browser sessions for different exchanges."""
    
    def __init__(self):
        self.sessions: Dict[str, BrowserManager] = {}
        self.logger = logging.getLogger(__name__)
    
    async def get_session(self, exchange: str) -> BrowserManager:
        """Get or create browser session for exchange."""
        if exchange not in self.sessions:
            session_dir = f"src/data/cache/session_data/{exchange}"
            browser_manager = BrowserManager(user_data_dir=session_dir)
            await browser_manager.start()
            self.sessions[exchange] = browser_manager
        
        return self.sessions[exchange]
    
    async def close_all_sessions(self):
        """Close all browser sessions."""
        for exchange, session in self.sessions.items():
            try:
                await session.stop()
                self.logger.info(f"Closed session for {exchange}")
            except Exception as e:
                self.logger.error(f"Error closing session for {exchange}: {e}")
        
        self.sessions.clear()

# Global session manager instance
session_manager = SessionManager()