"""
Utilities package for the AI Crypto Trading System.

Contains core utility modules:
- database: SQLite database operations with JSON support
- browser_automation: Playwright-based web scraping and automation
- communication: JSON-based inter-module communication
- config: Configuration management and settings
- logging: Structured logging with multiple categories
"""

from .database import db_manager, DatabaseManager
from .browser_automation import BrowserManager, WebScraper, session_manager
from .communication import message_bus, ModuleCommunicator, Priority, MessageType
from .config import config_manager, ConfigManager
from .logging import get_logger, get_performance_logger, get_audit_logger, setup_logging

__all__ = [
    # Database
    "db_manager",
    "DatabaseManager",
    
    # Browser automation
    "BrowserManager",
    "WebScraper", 
    "session_manager",
    
    # Communication
    "message_bus",
    "ModuleCommunicator",
    "Priority",
    "MessageType",
    
    # Configuration
    "config_manager",
    "ConfigManager",
    
    # Logging
    "get_logger",
    "get_performance_logger",
    "get_audit_logger",
    "setup_logging"
]