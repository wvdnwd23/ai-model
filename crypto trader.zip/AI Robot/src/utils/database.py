"""
Database utilities for the AI Crypto Trading System.
Handles SQLite database operations with JSON field support.
"""

import sqlite3
import json
import logging
from datetime import datetime
from typing import Dict, List, Any, Optional
from pathlib import Path
import threading
from contextlib import contextmanager

class DatabaseManager:
    """Manages SQLite database operations with thread safety and JSON support."""
    
    def __init__(self, db_path: str = None):
        """Initialize database manager."""
        if db_path is None:
            # Use default path if no config available
            db_path = "src/data/database/trading_system.db"
            try:
                from .config import config_manager
                db_path = config_manager.database.path
            except ImportError:
                pass  # Use default path
        
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._local = threading.local()
        self.logger = logging.getLogger(__name__)
        self._initialize_database()
    
    def _get_connection(self) -> sqlite3.Connection:
        """Get thread-local database connection."""
        if not hasattr(self._local, 'connection'):
            self._local.connection = sqlite3.connect(
                self.db_path,
                check_same_thread=False,
                timeout=30.0
            )
            self._local.connection.row_factory = sqlite3.Row
            # Enable JSON support
            self._local.connection.execute("PRAGMA journal_mode=WAL")
            self._local.connection.execute("PRAGMA synchronous=NORMAL")
        return self._local.connection
    
    def get_connection(self):
        """Public method to get database connection."""
        return self._get_connection()
    
    def get_table_names(self) -> List[str]:
        """Get list of table names in the database."""
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
            return [row[0] for row in cursor.fetchall()]
        except Exception as e:
            self.logger.error(f"Error getting table names: {e}")
            return []
    
    @contextmanager
    def get_cursor(self):
        """Context manager for database operations."""
        conn = self._get_connection()
        cursor = conn.cursor()
        try:
            yield cursor
            conn.commit()
        except Exception as e:
            conn.rollback()
            self.logger.error(f"Database operation failed: {e}")
            raise
        finally:
            cursor.close()
    
    def _initialize_database(self):
        """Initialize database with required tables."""
        with self.get_cursor() as cursor:
            # Trades table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS trades (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    symbol TEXT NOT NULL,
                    exchange TEXT NOT NULL,
                    side TEXT NOT NULL,
                    entry_price REAL,
                    exit_price REAL,
                    quantity REAL,
                    leverage INTEGER,
                    pnl REAL,
                    status TEXT,
                    entry_time TIMESTAMP,
                    exit_time TIMESTAMP,
                    strategy_version TEXT,
                    metadata TEXT
                )
            """)
            
            # AI decisions table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS ai_decisions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    module_name TEXT NOT NULL,
                    input_data TEXT,
                    output_data TEXT,
                    confidence_score REAL,
                    execution_time REAL,
                    success BOOLEAN,
                    error_message TEXT
                )
            """)
            
            # Learning data table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS learning_data (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    trade_id INTEGER,
                    prediction TEXT,
                    actual_outcome TEXT,
                    accuracy_score REAL,
                    learning_notes TEXT,
                    strategy_adjustments TEXT,
                    FOREIGN KEY (trade_id) REFERENCES trades (id)
                )
            """)
            
            # System health table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS system_health (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    module_name TEXT,
                    status TEXT,
                    cpu_usage REAL,
                    memory_usage REAL,
                    response_time REAL,
                    error_count INTEGER,
                    last_activity TIMESTAMP
                )
            """)
            
            # Market data cache table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS market_data_cache (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    symbol TEXT NOT NULL,
                    timeframe TEXT NOT NULL,
                    data TEXT,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    expiry TIMESTAMP,
                    source TEXT
                )
            """)
            
            # Create indexes for better performance
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_trades_symbol ON trades(symbol)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_trades_timestamp ON trades(entry_time)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_ai_decisions_module ON ai_decisions(module_name)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_market_data_symbol ON market_data_cache(symbol, timeframe)")
    
    def insert_trade(self, trade_data: Dict[str, Any]) -> int:
        """Insert a new trade record."""
        with self.get_cursor() as cursor:
            cursor.execute("""
                INSERT INTO trades (
                    symbol, exchange, side, entry_price, exit_price, quantity,
                    leverage, pnl, status, entry_time, exit_time, strategy_version, metadata
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                trade_data.get('symbol'),
                trade_data.get('exchange'),
                trade_data.get('side'),
                trade_data.get('entry_price'),
                trade_data.get('exit_price'),
                trade_data.get('quantity'),
                trade_data.get('leverage'),
                trade_data.get('pnl'),
                trade_data.get('status'),
                trade_data.get('entry_time'),
                trade_data.get('exit_time'),
                trade_data.get('strategy_version'),
                json.dumps(trade_data.get('metadata', {}))
            ))
            return cursor.lastrowid
    
    def update_trade(self, trade_id: int, updates: Dict[str, Any]):
        """Update an existing trade record."""
        if 'metadata' in updates:
            updates['metadata'] = json.dumps(updates['metadata'])
        
        set_clause = ", ".join([f"{key} = ?" for key in updates.keys()])
        values = list(updates.values()) + [trade_id]
        
        with self.get_cursor() as cursor:
            cursor.execute(f"UPDATE trades SET {set_clause} WHERE id = ?", values)
    
    def get_trades(self, symbol: Optional[str] = None, status: Optional[str] = None, 
                   limit: int = 100) -> List[Dict[str, Any]]:
        """Get trade records with optional filtering."""
        query = "SELECT * FROM trades WHERE 1=1"
        params = []
        
        if symbol:
            query += " AND symbol = ?"
            params.append(symbol)
        
        if status:
            query += " AND status = ?"
            params.append(status)
        
        query += " ORDER BY entry_time DESC LIMIT ?"
        params.append(limit)
        
        with self.get_cursor() as cursor:
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            trades = []
            for row in rows:
                trade = dict(row)
                if trade['metadata']:
                    trade['metadata'] = json.loads(trade['metadata'])
                trades.append(trade)
            
            return trades
    
    def insert_ai_decision(self, decision_data: Dict[str, Any]) -> int:
        """Insert AI decision record."""
        with self.get_cursor() as cursor:
            cursor.execute("""
                INSERT INTO ai_decisions (
                    module_name, input_data, output_data, confidence_score,
                    execution_time, success, error_message
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                decision_data.get('module_name'),
                json.dumps(decision_data.get('input_data', {})),
                json.dumps(decision_data.get('output_data', {})),
                decision_data.get('confidence_score'),
                decision_data.get('execution_time'),
                decision_data.get('success'),
                decision_data.get('error_message')
            ))
            return cursor.lastrowid
    
    def get_recent_decisions(self, module_name: Optional[str] = None, 
                           limit: int = 50) -> List[Dict[str, Any]]:
        """Get recent AI decisions."""
        query = "SELECT * FROM ai_decisions WHERE 1=1"
        params = []
        
        if module_name:
            query += " AND module_name = ?"
            params.append(module_name)
        
        query += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)
        
        with self.get_cursor() as cursor:
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            decisions = []
            for row in rows:
                decision = dict(row)
                if decision['input_data']:
                    decision['input_data'] = json.loads(decision['input_data'])
                if decision['output_data']:
                    decision['output_data'] = json.loads(decision['output_data'])
                decisions.append(decision)
            
            return decisions
    
    def insert_learning_data(self, learning_data: Dict[str, Any]) -> int:
        """Insert learning data record."""
        with self.get_cursor() as cursor:
            cursor.execute("""
                INSERT INTO learning_data (
                    trade_id, prediction, actual_outcome, accuracy_score,
                    learning_notes, strategy_adjustments
                ) VALUES (?, ?, ?, ?, ?, ?)
            """, (
                learning_data.get('trade_id'),
                json.dumps(learning_data.get('prediction', {})),
                json.dumps(learning_data.get('actual_outcome', {})),
                learning_data.get('accuracy_score'),
                learning_data.get('learning_notes'),
                json.dumps(learning_data.get('strategy_adjustments', {}))
            ))
            return cursor.lastrowid
    
    def update_system_health(self, health_data: Dict[str, Any]):
        """Update system health metrics."""
        with self.get_cursor() as cursor:
            cursor.execute("""
                INSERT INTO system_health (
                    module_name, status, cpu_usage, memory_usage,
                    response_time, error_count, last_activity
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                health_data.get('module_name'),
                health_data.get('status'),
                health_data.get('cpu_usage'),
                health_data.get('memory_usage'),
                health_data.get('response_time'),
                health_data.get('error_count'),
                health_data.get('last_activity', datetime.now())
            ))
    
    def cache_market_data(self, symbol: str, timeframe: str, data: Dict[str, Any], 
                         expiry: datetime, source: str):
        """Cache market data with expiry."""
        with self.get_cursor() as cursor:
            cursor.execute("""
                INSERT OR REPLACE INTO market_data_cache (
                    symbol, timeframe, data, expiry, source
                ) VALUES (?, ?, ?, ?, ?)
            """, (symbol, timeframe, json.dumps(data), expiry, source))
    
    def get_cached_market_data(self, symbol: str, timeframe: str) -> Optional[Dict[str, Any]]:
        """Get cached market data if not expired."""
        with self.get_cursor() as cursor:
            cursor.execute("""
                SELECT data FROM market_data_cache 
                WHERE symbol = ? AND timeframe = ? AND expiry > CURRENT_TIMESTAMP
                ORDER BY timestamp DESC LIMIT 1
            """, (symbol, timeframe))
            
            row = cursor.fetchone()
            if row:
                return json.loads(row['data'])
            return None
    
    def get_performance_metrics(self, days: int = 30) -> Dict[str, Any]:
        """Get trading performance metrics."""
        with self.get_cursor() as cursor:
            # Total trades
            cursor.execute("""
                SELECT COUNT(*) as total_trades,
                       SUM(CASE WHEN pnl > 0 THEN 1 ELSE 0 END) as winning_trades,
                       SUM(pnl) as total_pnl,
                       AVG(pnl) as avg_pnl
                FROM trades 
                WHERE entry_time >= datetime('now', '-{} days')
                AND status = 'closed'
            """.format(days))
            
            metrics = dict(cursor.fetchone())
            
            # Win rate
            if metrics['total_trades'] > 0:
                metrics['win_rate'] = metrics['winning_trades'] / metrics['total_trades']
            else:
                metrics['win_rate'] = 0
            
            return metrics
    
    def cleanup_old_data(self, days: int = 90):
        """Clean up old data to maintain database performance."""
        with self.get_cursor() as cursor:
            # Clean old market data cache
            cursor.execute("""
                DELETE FROM market_data_cache 
                WHERE timestamp < datetime('now', '-{} days')
            """.format(days))
            
            # Clean old system health data
            cursor.execute("""
                DELETE FROM system_health 
                WHERE timestamp < datetime('now', '-{} days')
            """.format(days))
            
            # Vacuum database
            cursor.execute("VACUUM")

# Global database instance - initialized lazily
db_manager = None

def get_db_manager():
    """Get or create the global database manager instance."""
    global db_manager
    if db_manager is None:
        db_manager = DatabaseManager()
    return db_manager

# For backward compatibility, create instance immediately
db_manager = DatabaseManager()