"""
Communication utilities for the AI Crypto Trading System.
Handles JSON-based inter-module communication and message routing.
"""

import json
import uuid
import asyncio
import logging
from datetime import datetime
from typing import Dict, Any, Optional, Callable, List
from enum import Enum
from dataclasses import dataclass, asdict
import threading
from queue import Queue, Empty
import time

class MessageType(Enum):
    """Message types for inter-module communication."""
    REQUEST = "request"
    RESPONSE = "response"
    NOTIFICATION = "notification"
    ERROR = "error"

class Priority(Enum):
    """Message priority levels."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

@dataclass
class Message:
    """Standard message format for inter-module communication."""
    timestamp: str
    module_id: str
    message_id: str
    message_type: MessageType
    priority: Priority
    data: Dict[str, Any]
    metadata: Dict[str, Any]
    
    def __post_init__(self):
        """Ensure proper types after initialization."""
        if isinstance(self.message_type, str):
            self.message_type = MessageType(self.message_type)
        if isinstance(self.priority, str):
            self.priority = Priority(self.priority)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert message to dictionary."""
        result = asdict(self)
        result['message_type'] = self.message_type.value
        result['priority'] = self.priority.value
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Message':
        """Create message from dictionary."""
        return cls(
            timestamp=data['timestamp'],
            module_id=data['module_id'],
            message_id=data['message_id'],
            message_type=MessageType(data['message_type']),
            priority=Priority(data['priority']),
            data=data['data'],
            metadata=data['metadata']
        )
    
    def to_json(self) -> str:
        """Convert message to JSON string."""
        return json.dumps(self.to_dict(), indent=2)
    
    @classmethod
    def from_json(cls, json_str: str) -> 'Message':
        """Create message from JSON string."""
        return cls.from_dict(json.loads(json_str))

class MessageBus:
    """Central message bus for inter-module communication."""
    
    def __init__(self):
        self.subscribers: Dict[str, List[Callable]] = {}
        self.message_queue: Queue = Queue()
        self.response_handlers: Dict[str, Callable] = {}
        self.logger = logging.getLogger(__name__)
        self.running = False
        self.worker_thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()
    
    def start(self):
        """Start the message bus worker thread."""
        if not self.running:
            self.running = True
            self.worker_thread = threading.Thread(target=self._process_messages, daemon=True)
            self.worker_thread.start()
            self.logger.info("Message bus started")
    
    def stop(self):
        """Stop the message bus."""
        self.running = False
        if self.worker_thread:
            self.worker_thread.join(timeout=5)
        self.logger.info("Message bus stopped")
    
    def subscribe(self, topic: str, handler: Callable[[Message], None]):
        """Subscribe to messages for a specific topic."""
        with self._lock:
            if topic not in self.subscribers:
                self.subscribers[topic] = []
            self.subscribers[topic].append(handler)
            self.logger.debug(f"Subscribed to topic: {topic}")
    
    def unsubscribe(self, topic: str, handler: Callable[[Message], None]):
        """Unsubscribe from a topic."""
        with self._lock:
            if topic in self.subscribers and handler in self.subscribers[topic]:
                self.subscribers[topic].remove(handler)
                if not self.subscribers[topic]:
                    del self.subscribers[topic]
                self.logger.debug(f"Unsubscribed from topic: {topic}")
    
    def publish(self, message: Message):
        """Publish a message to the bus."""
        self.message_queue.put(message)
        self.logger.debug(f"Published message: {message.message_id}")
    
    def send_request(self, target_module: str, data: Dict[str, Any], 
                    priority: Priority = Priority.MEDIUM, 
                    timeout: float = 30.0) -> Optional[Message]:
        """Send a request and wait for response."""
        message_id = str(uuid.uuid4())
        correlation_id = str(uuid.uuid4())
        
        request = Message(
            timestamp=datetime.now().isoformat(),
            module_id="system",
            message_id=message_id,
            message_type=MessageType.REQUEST,
            priority=priority,
            data=data,
            metadata={
                "version": "1.0",
                "correlation_id": correlation_id,
                "retry_count": 0,
                "target_module": target_module,
                "timeout": timeout
            }
        )
        
        # Set up response handler
        response_event = threading.Event()
        response_data = {"message": None}
        
        def response_handler(response: Message):
            if response.metadata.get("correlation_id") == correlation_id:
                response_data["message"] = response
                response_event.set()
        
        self.response_handlers[correlation_id] = response_handler
        
        try:
            self.publish(request)
            
            # Wait for response
            if response_event.wait(timeout):
                return response_data["message"]
            else:
                self.logger.warning(f"Request timeout for message {message_id}")
                return None
        
        finally:
            # Clean up response handler
            self.response_handlers.pop(correlation_id, None)
    
    def send_response(self, original_request: Message, data: Dict[str, Any], 
                     success: bool = True):
        """Send a response to a request."""
        response = Message(
            timestamp=datetime.now().isoformat(),
            module_id="system",
            message_id=str(uuid.uuid4()),
            message_type=MessageType.RESPONSE,
            priority=original_request.priority,
            data=data,
            metadata={
                "version": "1.0",
                "correlation_id": original_request.metadata.get("correlation_id"),
                "retry_count": 0,
                "success": success,
                "original_message_id": original_request.message_id
            }
        )
        
        self.publish(response)
    
    def send_notification(self, module_id: str, data: Dict[str, Any], 
                         priority: Priority = Priority.LOW):
        """Send a notification message."""
        notification = Message(
            timestamp=datetime.now().isoformat(),
            module_id=module_id,
            message_id=str(uuid.uuid4()),
            message_type=MessageType.NOTIFICATION,
            priority=priority,
            data=data,
            metadata={
                "version": "1.0",
                "correlation_id": str(uuid.uuid4()),
                "retry_count": 0
            }
        )
        
        self.publish(notification)
    
    def _process_messages(self):
        """Process messages in the queue."""
        while self.running:
            try:
                message = self.message_queue.get(timeout=1.0)
                self._route_message(message)
                self.message_queue.task_done()
            except Empty:
                continue
            except Exception as e:
                self.logger.error(f"Error processing message: {e}")
    
    def _route_message(self, message: Message):
        """Route message to appropriate handlers."""
        try:
            # Handle responses
            if message.message_type == MessageType.RESPONSE:
                correlation_id = message.metadata.get("correlation_id")
                if correlation_id in self.response_handlers:
                    self.response_handlers[correlation_id](message)
                    return
            
            # Route to topic subscribers
            target_module = message.metadata.get("target_module", message.module_id)
            
            with self._lock:
                if target_module in self.subscribers:
                    for handler in self.subscribers[target_module]:
                        try:
                            handler(message)
                        except Exception as e:
                            self.logger.error(f"Handler error for {target_module}: {e}")
                
                # Also route to wildcard subscribers
                if "*" in self.subscribers:
                    for handler in self.subscribers["*"]:
                        try:
                            handler(message)
                        except Exception as e:
                            self.logger.error(f"Wildcard handler error: {e}")
        
        except Exception as e:
            self.logger.error(f"Message routing error: {e}")

class ModuleCommunicator:
    """Communication interface for individual modules."""
    
    def __init__(self, module_id: str, message_bus: MessageBus):
        self.module_id = module_id
        self.message_bus = message_bus
        self.logger = logging.getLogger(f"{__name__}.{module_id}")
        
        # Subscribe to messages for this module
        self.message_bus.subscribe(module_id, self._handle_message)
        self.request_handlers: Dict[str, Callable] = {}
    
    def register_request_handler(self, request_type: str, handler: Callable):
        """Register a handler for specific request types."""
        self.request_handlers[request_type] = handler
        self.logger.debug(f"Registered handler for {request_type}")
    
    def _handle_message(self, message: Message):
        """Handle incoming messages for this module."""
        try:
            if message.message_type == MessageType.REQUEST:
                request_type = message.data.get("type")
                if request_type in self.request_handlers:
                    # Process request in separate thread to avoid blocking
                    threading.Thread(
                        target=self._process_request,
                        args=(message, self.request_handlers[request_type]),
                        daemon=True
                    ).start()
                else:
                    self.logger.warning(f"No handler for request type: {request_type}")
            
            elif message.message_type == MessageType.NOTIFICATION:
                self._handle_notification(message)
        
        except Exception as e:
            self.logger.error(f"Message handling error: {e}")
    
    def _process_request(self, request: Message, handler: Callable):
        """Process a request and send response."""
        try:
            start_time = time.time()
            result = handler(request.data)
            execution_time = time.time() - start_time
            
            response_data = {
                "result": result,
                "execution_time": execution_time,
                "success": True
            }
            
            self.message_bus.send_response(request, response_data, success=True)
            
        except Exception as e:
            self.logger.error(f"Request processing error: {e}")
            
            error_data = {
                "error": str(e),
                "success": False
            }
            
            self.message_bus.send_response(request, error_data, success=False)
    
    def _handle_notification(self, message: Message):
        """Handle notification messages."""
        self.logger.info(f"Received notification: {message.data}")
    
    def send_request(self, target_module: str, request_type: str, data: Dict[str, Any], 
                    priority: Priority = Priority.MEDIUM, timeout: float = 30.0) -> Optional[Dict[str, Any]]:
        """Send a request to another module."""
        request_data = {
            "type": request_type,
            **data
        }
        
        response = self.message_bus.send_request(
            target_module, request_data, priority, timeout
        )
        
        if response and response.metadata.get("success"):
            return response.data.get("result")
        elif response:
            self.logger.error(f"Request failed: {response.data.get('error')}")
        
        return None
    
    def send_notification(self, data: Dict[str, Any], priority: Priority = Priority.LOW):
        """Send a notification from this module."""
        self.message_bus.send_notification(self.module_id, data, priority)
    
    def broadcast(self, data: Dict[str, Any], priority: Priority = Priority.LOW):
        """Broadcast a message to all modules."""
        notification = Message(
            timestamp=datetime.now().isoformat(),
            module_id=self.module_id,
            message_id=str(uuid.uuid4()),
            message_type=MessageType.NOTIFICATION,
            priority=priority,
            data=data,
            metadata={
                "version": "1.0",
                "correlation_id": str(uuid.uuid4()),
                "retry_count": 0,
                "broadcast": True
            }
        )
        
        self.message_bus.publish(notification)

class CommunicationProtocol:
    """Defines standard communication protocols for different operations."""
    
    @staticmethod
    def create_scan_request(symbols: List[str], timeframe: str = "1h") -> Dict[str, Any]:
        """Create a coin scan request."""
        return {
            "type": "scan_coins",
            "symbols": symbols,
            "timeframe": timeframe,
            "timestamp": datetime.now().isoformat()
        }
    
    @staticmethod
    def create_chart_analysis_request(symbol: str, timeframes: List[str]) -> Dict[str, Any]:
        """Create a chart analysis request."""
        return {
            "type": "analyze_chart",
            "symbol": symbol,
            "timeframes": timeframes,
            "timestamp": datetime.now().isoformat()
        }
    
    @staticmethod
    def create_trade_decision_request(scanner_output: Dict, chart_output: Dict) -> Dict[str, Any]:
        """Create a trade decision request."""
        return {
            "type": "make_decision",
            "scanner_data": scanner_output,
            "chart_data": chart_output,
            "timestamp": datetime.now().isoformat()
        }
    
    @staticmethod
    def create_trade_execution_request(decision: Dict[str, Any]) -> Dict[str, Any]:
        """Create a trade execution request."""
        return {
            "type": "execute_trade",
            "decision": decision,
            "timestamp": datetime.now().isoformat()
        }
    
    @staticmethod
    def create_health_check_request() -> Dict[str, Any]:
        """Create a health check request."""
        return {
            "type": "health_check",
            "timestamp": datetime.now().isoformat()
        }

# Global message bus instance
message_bus = MessageBus()

def get_communicator(module_id: str) -> ModuleCommunicator:
    """Get a communicator instance for a module."""
    return ModuleCommunicator(module_id, message_bus)