"""
Logging utilities for the AI Crypto Trading System.
Provides structured logging with different categories and levels.
"""

import logging
import logging.handlers
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional
from enum import Enum
import traceback

class LogCategory(Enum):
    """Log categories for different types of events."""
    TRADE = "TRADE"
    DECISION = "DECISION"
    ERROR = "ERROR"
    HEALTH = "HEALTH"
    LEARNING = "LEARNING"
    SECURITY = "SECURITY"
    SYSTEM = "SYSTEM"
    BROWSER = "BROWSER"
    API = "API"

class StructuredLogger:
    """Structured logger with JSON formatting and multiple handlers."""
    
    def __init__(self, name: str, log_dir: str = "src/data/logs"):
        self.name = name
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        
        # Create logger
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.DEBUG)
        
        # Prevent duplicate handlers
        if not self.logger.handlers:
            self._setup_handlers()
    
    def _setup_handlers(self):
        """Set up logging handlers for different categories."""
        
        # Console handler
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.INFO)
        console_formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        console_handler.setFormatter(console_formatter)
        self.logger.addHandler(console_handler)
        
        # Main log file handler
        main_log_path = self.log_dir / "system" / "main.log"
        main_log_path.parent.mkdir(parents=True, exist_ok=True)
        
        main_handler = logging.handlers.RotatingFileHandler(
            main_log_path,
            maxBytes=10*1024*1024,  # 10MB
            backupCount=5
        )
        main_handler.setLevel(logging.DEBUG)
        main_formatter = JsonFormatter()
        main_handler.setFormatter(main_formatter)
        self.logger.addHandler(main_handler)
        
        # Category-specific handlers
        self._setup_category_handlers()
    
    def _setup_category_handlers(self):
        """Set up handlers for specific log categories."""
        category_configs = {
            LogCategory.TRADE: {
                "path": "trades/trades.log",
                "level": logging.INFO
            },
            LogCategory.DECISION: {
                "path": "ai_learning/decisions.log",
                "level": logging.INFO
            },
            LogCategory.ERROR: {
                "path": "errors/errors.log",
                "level": logging.ERROR
            },
            LogCategory.HEALTH: {
                "path": "system/health.log",
                "level": logging.INFO
            },
            LogCategory.LEARNING: {
                "path": "ai_learning/learning.log",
                "level": logging.INFO
            },
            LogCategory.SECURITY: {
                "path": "system/security.log",
                "level": logging.WARNING
            }
        }
        
        for category, config in category_configs.items():
            log_path = self.log_dir / config["path"]
            log_path.parent.mkdir(parents=True, exist_ok=True)
            
            handler = logging.handlers.RotatingFileHandler(
                log_path,
                maxBytes=5*1024*1024,  # 5MB
                backupCount=3
            )
            handler.setLevel(config["level"])
            handler.setFormatter(JsonFormatter())
            
            # Add filter to only log specific category
            handler.addFilter(CategoryFilter(category))
            self.logger.addHandler(handler)
    
    def log_structured(self, level: int, category: LogCategory, message: str, 
                      data: Optional[Dict[str, Any]] = None, **kwargs):
        """Log a structured message with category and data."""
        extra = {
            'category': category.value,
            'structured_data': data or {},
            'timestamp_iso': datetime.now().isoformat(),
            **kwargs
        }
        
        self.logger.log(level, message, extra=extra)
    
    def trade(self, message: str, trade_data: Optional[Dict[str, Any]] = None, **kwargs):
        """Log trade-related events."""
        self.log_structured(logging.INFO, LogCategory.TRADE, message, trade_data, **kwargs)
    
    def decision(self, message: str, decision_data: Optional[Dict[str, Any]] = None, **kwargs):
        """Log AI decision events."""
        self.log_structured(logging.INFO, LogCategory.DECISION, message, decision_data, **kwargs)
    
    def error(self, message: str, error_data: Optional[Dict[str, Any]] = None, 
              exception: Optional[Exception] = None, **kwargs):
        """Log error events."""
        if exception:
            error_data = error_data or {}
            error_data.update({
                'exception_type': type(exception).__name__,
                'exception_message': str(exception),
                'traceback': traceback.format_exc()
            })
        
        self.log_structured(logging.ERROR, LogCategory.ERROR, message, error_data, **kwargs)
    
    def health(self, message: str, health_data: Optional[Dict[str, Any]] = None, **kwargs):
        """Log system health events."""
        self.log_structured(logging.INFO, LogCategory.HEALTH, message, health_data, **kwargs)
    
    def learning(self, message: str, learning_data: Optional[Dict[str, Any]] = None, **kwargs):
        """Log AI learning events."""
        self.log_structured(logging.INFO, LogCategory.LEARNING, message, learning_data, **kwargs)
    
    def security(self, message: str, security_data: Optional[Dict[str, Any]] = None, **kwargs):
        """Log security events."""
        self.log_structured(logging.WARNING, LogCategory.SECURITY, message, security_data, **kwargs)
    
    def system(self, message: str, system_data: Optional[Dict[str, Any]] = None, **kwargs):
        """Log general system events."""
        self.log_structured(logging.INFO, LogCategory.SYSTEM, message, system_data, **kwargs)
    
    def browser(self, message: str, browser_data: Optional[Dict[str, Any]] = None, **kwargs):
        """Log browser automation events."""
        self.log_structured(logging.DEBUG, LogCategory.BROWSER, message, browser_data, **kwargs)
    
    def api(self, message: str, api_data: Optional[Dict[str, Any]] = None, **kwargs):
        """Log API-related events."""
        self.log_structured(logging.DEBUG, LogCategory.API, message, api_data, **kwargs)
    
    def info(self, message: str, data: Optional[Dict[str, Any]] = None, **kwargs):
        """Log info level messages."""
        self.log_structured(logging.INFO, LogCategory.SYSTEM, message, data, **kwargs)
    
    def debug(self, message: str, data: Optional[Dict[str, Any]] = None, **kwargs):
        """Log debug level messages."""
        self.log_structured(logging.DEBUG, LogCategory.SYSTEM, message, data, **kwargs)
    
    def warning(self, message: str, data: Optional[Dict[str, Any]] = None, **kwargs):
        """Log warning level messages."""
        self.log_structured(logging.WARNING, LogCategory.SYSTEM, message, data, **kwargs)
    
    def critical(self, message: str, data: Optional[Dict[str, Any]] = None, **kwargs):
        """Log critical level messages."""
        self.log_structured(logging.CRITICAL, LogCategory.SYSTEM, message, data, **kwargs)

class JsonFormatter(logging.Formatter):
    """JSON formatter for structured logging."""
    
    def format(self, record):
        """Format log record as JSON."""
        log_entry = {
            'timestamp': datetime.fromtimestamp(record.created).isoformat(),
            'level': record.levelname,
            'logger': record.name,
            'message': record.getMessage(),
            'module': record.module,
            'function': record.funcName,
            'line': record.lineno
        }
        
        # Add structured data if available
        if hasattr(record, 'category'):
            log_entry['category'] = record.category
        
        if hasattr(record, 'structured_data'):
            log_entry['data'] = record.structured_data
        
        if hasattr(record, 'timestamp_iso'):
            log_entry['timestamp_iso'] = record.timestamp_iso
        
        # Add exception info if present
        if record.exc_info:
            log_entry['exception'] = self.formatException(record.exc_info)
        
        return json.dumps(log_entry, default=str)

class CategoryFilter(logging.Filter):
    """Filter to only allow specific log categories."""
    
    def __init__(self, category: LogCategory):
        super().__init__()
        self.category = category.value
    
    def filter(self, record):
        """Filter records by category."""
        return hasattr(record, 'category') and record.category == self.category

class PerformanceLogger:
    """Logger for performance metrics and timing."""
    
    def __init__(self, logger: StructuredLogger):
        self.logger = logger
        self.timers: Dict[str, float] = {}
    
    def start_timer(self, operation: str):
        """Start timing an operation."""
        import time
        self.timers[operation] = time.time()
    
    def end_timer(self, operation: str, additional_data: Optional[Dict[str, Any]] = None):
        """End timing and log the duration."""
        import time
        if operation in self.timers:
            duration = time.time() - self.timers[operation]
            
            perf_data = {
                'operation': operation,
                'duration_seconds': duration,
                'duration_ms': duration * 1000
            }
            
            if additional_data:
                perf_data.update(additional_data)
            
            self.logger.system(f"Performance: {operation} completed", perf_data)
            
            del self.timers[operation]
            return duration
        
        return None
    
    def log_memory_usage(self, operation: str):
        """Log current memory usage."""
        try:
            import psutil
            import os
            
            process = psutil.Process(os.getpid())
            memory_info = process.memory_info()
            
            memory_data = {
                'operation': operation,
                'rss_mb': memory_info.rss / 1024 / 1024,
                'vms_mb': memory_info.vms / 1024 / 1024,
                'percent': process.memory_percent()
            }
            
            self.logger.health(f"Memory usage for {operation}", memory_data)
            
        except ImportError:
            self.logger.system("psutil not available for memory monitoring")

class AuditLogger:
    """Audit logger for security and compliance events."""
    
    def __init__(self, logger: StructuredLogger):
        self.logger = logger
    
    def log_trade_execution(self, trade_data: Dict[str, Any]):
        """Log trade execution for audit purposes."""
        audit_data = {
            'event_type': 'trade_execution',
            'trade_id': trade_data.get('id'),
            'symbol': trade_data.get('symbol'),
            'side': trade_data.get('side'),
            'quantity': trade_data.get('quantity'),
            'price': trade_data.get('price'),
            'exchange': trade_data.get('exchange'),
            'timestamp': datetime.now().isoformat()
        }
        
        self.logger.security("Trade executed", audit_data)
    
    def log_api_access(self, exchange: str, endpoint: str, success: bool):
        """Log API access attempts."""
        audit_data = {
            'event_type': 'api_access',
            'exchange': exchange,
            'endpoint': endpoint,
            'success': success,
            'timestamp': datetime.now().isoformat()
        }
        
        self.logger.security("API access", audit_data)
    
    def log_configuration_change(self, section: str, changes: Dict[str, Any]):
        """Log configuration changes."""
        audit_data = {
            'event_type': 'config_change',
            'section': section,
            'changes': changes,
            'timestamp': datetime.now().isoformat()
        }
        
        self.logger.security("Configuration changed", audit_data)

def setup_logging(log_level: str = "INFO", log_dir: str = "src/data/logs"):
    """Set up global logging configuration."""
    
    # Create log directory
    Path(log_dir).mkdir(parents=True, exist_ok=True)
    
    # Set global log level
    numeric_level = getattr(logging, log_level.upper(), logging.INFO)
    logging.getLogger().setLevel(numeric_level)
    
    # Disable some noisy loggers
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("requests").setLevel(logging.WARNING)
    logging.getLogger("playwright").setLevel(logging.WARNING)

def get_logger(name: str) -> StructuredLogger:
    """Get a structured logger instance."""
    return StructuredLogger(name)

def get_performance_logger(name: str) -> PerformanceLogger:
    """Get a performance logger instance."""
    structured_logger = get_logger(name)
    return PerformanceLogger(structured_logger)

def get_audit_logger(name: str) -> AuditLogger:
    """Get an audit logger instance."""
    structured_logger = get_logger(name)
    return AuditLogger(structured_logger)

# Context manager for performance timing
class TimedOperation:
    """Context manager for timing operations."""
    
    def __init__(self, logger: PerformanceLogger, operation: str, 
                 additional_data: Optional[Dict[str, Any]] = None):
        self.logger = logger
        self.operation = operation
        self.additional_data = additional_data
    
    def __enter__(self):
        self.logger.start_timer(self.operation)
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        duration = self.logger.end_timer(self.operation, self.additional_data)
        if exc_type:
            # Log error if operation failed
            error_data = {
                'operation': self.operation,
                'duration_seconds': duration,
                'error_type': exc_type.__name__,
                'error_message': str(exc_val)
            }
            self.logger.logger.error(f"Operation {self.operation} failed", error_data)

# Initialize logging on module import
setup_logging()