"""
OpenAI API Client - Comprehensive integration for AI Crypto Trading System.
Replaces OpenRouter with direct OpenAI API integration using gpt-4o-mini model.
Optimized for Raspberry Pi 5 ARM64 architecture with robust error handling.
"""

import asyncio
import json
import time
import hashlib
import psutil
import os
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Union, Callable
from dataclasses import dataclass, asdict
from enum import Enum
import statistics
import threading
from concurrent.futures import ThreadPoolExecutor
import gc

import aiohttp
import openai
from openai import OpenAI, AsyncOpenAI
from openai.types.chat import ChatCompletion
from openai._exceptions import (
    RateLimitError, 
    APIConnectionError, 
    AuthenticationError,
    APIError,
    APITimeoutError,
    BadRequestError
)

from src.utils.config import config_manager
from src.utils.logging import get_logger, get_performance_logger, TimedOperation

class TaskType(Enum):
    """Task types for AI operations."""
    MARKET_SCANNING = "market_scanning"
    TECHNICAL_ANALYSIS = "technical_analysis"
    DATA_SYNTHESIS = "data_synthesis"
    EXECUTION_VALIDATION = "execution_validation"
    GENERAL_COORDINATION = "general_coordination"
    SENTIMENT_ANALYSIS = "sentiment_analysis"
    RISK_ASSESSMENT = "risk_assessment"

class ErrorType(Enum):
    """Error types for categorization."""
    RATE_LIMIT = "rate_limit"
    NETWORK = "network"
    AUTHENTICATION = "authentication"
    TIMEOUT = "timeout"
    INVALID_REQUEST = "invalid_request"
    SERVER_ERROR = "server_error"
    UNKNOWN = "unknown"

@dataclass
class OpenAIConfig:
    """OpenAI API configuration."""
    api_key: str = "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"
    model: str = "gpt-4o-mini"
    base_url: str = "https://api.openai.com/v1"
    timeout: int = 30
    max_retries: int = 3
    rate_limit_rpm: int = 3500  # gpt-4o-mini limit
    rate_limit_tpm: int = 200000  # tokens per minute
    max_tokens_per_request: int = 16384
    temperature: float = 0.3
    enable_caching: bool = True
    cache_ttl_minutes: int = 5
    fallback_enabled: bool = True
    cost_tracking: bool = True
    daily_cost_limit: float = 10.0
    input_cost_per_1k_tokens: float = 0.000150  # gpt-4o-mini pricing
    output_cost_per_1k_tokens: float = 0.000600  # gpt-4o-mini pricing

@dataclass
class APIResponse:
    """Standardized API response format."""
    success: bool
    content: str
    model_used: str
    tokens_used: int
    input_tokens: int
    output_tokens: int
    response_time: float
    cost: float
    error_message: Optional[str] = None
    fallback_used: bool = False
    cached: bool = False
    retry_count: int = 0

@dataclass
class CacheEntry:
    """Cache entry for API responses."""
    response: APIResponse
    timestamp: datetime
    prompt_hash: str
    task_type: TaskType
    ttl_minutes: int

@dataclass
class RateLimitState:
    """Rate limiting state tracking."""
    requests_this_minute: List[datetime]
    tokens_this_minute: int
    last_reset: datetime
    backoff_until: Optional[datetime] = None

class SecurityValidator:
    """Input validation and sanitization for security."""
    
    @staticmethod
    def validate_prompt(prompt: str) -> bool:
        """Validate prompt for security issues."""
        if not prompt or not isinstance(prompt, str):
            return False
        
        # Check length
        if len(prompt) > 50000:  # Reasonable limit
            return False
        
        # Check for potential injection attempts
        dangerous_patterns = [
            "ignore previous instructions",
            "system:",
            "assistant:",
            "user:",
            "```python",
            "exec(",
            "eval(",
            "__import__",
            "subprocess",
            "os.system"
        ]
        
        prompt_lower = prompt.lower()
        for pattern in dangerous_patterns:
            if pattern in prompt_lower:
                return False
        
        return True
    
    @staticmethod
    def sanitize_prompt(prompt: str) -> str:
        """Sanitize prompt by removing potentially dangerous content."""
        if not prompt:
            return ""
        
        # Remove control characters
        sanitized = ''.join(char for char in prompt if ord(char) >= 32 or char in '\n\t')
        
        # Limit length
        if len(sanitized) > 10000:
            sanitized = sanitized[:10000] + "\n[Content truncated for safety]"
        
        return sanitized

class MemoryOptimizer:
    """Memory optimization for Raspberry Pi 5."""
    
    def __init__(self):
        self.max_concurrent_requests = 2  # Pi 5 limitation
        self.request_semaphore = asyncio.Semaphore(self.max_concurrent_requests)
        self.memory_threshold = 0.85  # 85% memory usage limit
        self.gc_threshold = 0.80  # Trigger GC at 80%
        
    def check_memory_usage(self) -> float:
        """Check current memory usage percentage."""
        try:
            memory = psutil.virtual_memory()
            return memory.percent / 100.0
        except Exception:
            return 0.5  # Conservative fallback
    
    def optimize_request_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Optimize request data for memory constraints."""
        optimized = data.copy()
        
        # Compress large messages
        if 'messages' in optimized:
            for message in optimized['messages']:
                if 'content' in message and len(message['content']) > 5000:
                    message['content'] = message['content'][:5000] + "\n[Truncated for memory optimization]"
        
        # Limit max_tokens based on available memory
        memory_usage = self.check_memory_usage()
        if memory_usage > self.memory_threshold:
            optimized['max_tokens'] = min(optimized.get('max_tokens', 1000), 500)
        
        return optimized
    
    async def manage_memory(self):
        """Manage memory usage proactively."""
        memory_usage = self.check_memory_usage()
        
        if memory_usage > self.gc_threshold:
            gc.collect()
            
        if memory_usage > self.memory_threshold:
            # Force more aggressive cleanup
            gc.collect()
            await asyncio.sleep(0.1)  # Brief pause to allow cleanup

class CostTracker:
    """Track API costs and enforce limits."""
    
    def __init__(self, daily_limit: float = 10.0):
        self.daily_limit = daily_limit
        self.daily_costs: Dict[str, float] = {}  # date -> cost
        self.total_cost = 0.0
        self.request_count = 0
        
    def calculate_cost(self, input_tokens: int, output_tokens: int, 
                      input_rate: float, output_rate: float) -> float:
        """Calculate cost for token usage."""
        input_cost = (input_tokens / 1000) * input_rate
        output_cost = (output_tokens / 1000) * output_rate
        return input_cost + output_cost
    
    def add_cost(self, cost: float):
        """Add cost to tracking."""
        today = datetime.now().strftime("%Y-%m-%d")
        
        if today not in self.daily_costs:
            self.daily_costs[today] = 0.0
        
        self.daily_costs[today] += cost
        self.total_cost += cost
        self.request_count += 1
    
    def get_daily_cost(self, date: Optional[str] = None) -> float:
        """Get cost for specific date or today."""
        if date is None:
            date = datetime.now().strftime("%Y-%m-%d")
        return self.daily_costs.get(date, 0.0)
    
    def is_within_limit(self, additional_cost: float = 0.0) -> bool:
        """Check if adding cost would exceed daily limit."""
        today_cost = self.get_daily_cost()
        return (today_cost + additional_cost) <= self.daily_limit
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cost tracking statistics."""
        today_cost = self.get_daily_cost()
        return {
            "total_cost": self.total_cost,
            "daily_cost": today_cost,
            "daily_limit": self.daily_limit,
            "remaining_budget": max(0, self.daily_limit - today_cost),
            "request_count": self.request_count,
            "average_cost_per_request": self.total_cost / max(1, self.request_count)
        }

class IntelligentCache:
    """Intelligent caching system for API responses."""
    
    def __init__(self, max_size: int = 1000):
        self.cache: Dict[str, CacheEntry] = {}
        self.max_size = max_size
        self.hit_count = 0
        self.miss_count = 0
        
    def _generate_cache_key(self, prompt: str, task_type: TaskType, 
                          context: Optional[Dict[str, Any]] = None) -> str:
        """Generate cache key for prompt."""
        cache_data = {
            "prompt": prompt,
            "task_type": task_type.value,
            "context": context or {}
        }
        
        cache_string = json.dumps(cache_data, sort_keys=True)
        return hashlib.sha256(cache_string.encode()).hexdigest()
    
    def get(self, prompt: str, task_type: TaskType, 
            context: Optional[Dict[str, Any]] = None) -> Optional[APIResponse]:
        """Get cached response if valid."""
        cache_key = self._generate_cache_key(prompt, task_type, context)
        
        if cache_key not in self.cache:
            self.miss_count += 1
            return None
        
        entry = self.cache[cache_key]
        
        # Check if cache is still valid
        age_minutes = (datetime.now() - entry.timestamp).total_seconds() / 60
        if age_minutes > entry.ttl_minutes:
            del self.cache[cache_key]
            self.miss_count += 1
            return None
        
        self.hit_count += 1
        response = entry.response
        response.cached = True
        return response
    
    def set(self, prompt: str, task_type: TaskType, response: APIResponse,
            context: Optional[Dict[str, Any]] = None, ttl_minutes: int = 5):
        """Cache successful response."""
        cache_key = self._generate_cache_key(prompt, task_type, context)
        
        entry = CacheEntry(
            response=response,
            timestamp=datetime.now(),
            prompt_hash=cache_key,
            task_type=task_type,
            ttl_minutes=ttl_minutes
        )
        
        self.cache[cache_key] = entry
        
        # Limit cache size
        if len(self.cache) > self.max_size:
            self._cleanup_cache()
    
    def _cleanup_cache(self):
        """Remove oldest cache entries."""
        # Remove expired entries first
        now = datetime.now()
        expired_keys = []
        
        for key, entry in self.cache.items():
            age_minutes = (now - entry.timestamp).total_seconds() / 60
            if age_minutes > entry.ttl_minutes:
                expired_keys.append(key)
        
        for key in expired_keys:
            del self.cache[key]
        
        # If still too large, remove oldest entries
        if len(self.cache) > self.max_size:
            sorted_entries = sorted(
                self.cache.items(),
                key=lambda x: x[1].timestamp
            )
            
            entries_to_remove = len(self.cache) - int(self.max_size * 0.8)
            for i in range(entries_to_remove):
                key = sorted_entries[i][0]
                del self.cache[key]
    
    def clear(self):
        """Clear all cache entries."""
        self.cache.clear()
        self.hit_count = 0
        self.miss_count = 0
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        total_requests = self.hit_count + self.miss_count
        hit_rate = self.hit_count / max(1, total_requests)
        
        return {
            "cache_size": len(self.cache),
            "max_size": self.max_size,
            "hit_count": self.hit_count,
            "miss_count": self.miss_count,
            "hit_rate": hit_rate,
            "total_requests": total_requests
        }

class RateLimiter:
    """Rate limiting for OpenAI API."""
    
    def __init__(self, rpm_limit: int = 3500, tpm_limit: int = 200000):
        self.rpm_limit = rpm_limit
        self.tpm_limit = tpm_limit
        self.state = RateLimitState(
            requests_this_minute=[],
            tokens_this_minute=0,
            last_reset=datetime.now()
        )
        self._lock = threading.Lock()
    
    def _reset_if_needed(self):
        """Reset counters if minute has passed."""
        now = datetime.now()
        if (now - self.state.last_reset).total_seconds() >= 60:
            self.state.requests_this_minute.clear()
            self.state.tokens_this_minute = 0
            self.state.last_reset = now
    
    def _clean_old_requests(self):
        """Remove requests older than 1 minute."""
        cutoff = datetime.now() - timedelta(minutes=1)
        self.state.requests_this_minute = [
            req_time for req_time in self.state.requests_this_minute
            if req_time > cutoff
        ]
    
    async def acquire(self, estimated_tokens: int = 1000) -> bool:
        """Acquire rate limit permission."""
        with self._lock:
            self._reset_if_needed()
            self._clean_old_requests()
            
            # Check if in backoff period
            if self.state.backoff_until and datetime.now() < self.state.backoff_until:
                return False
            
            # Check rate limits
            if len(self.state.requests_this_minute) >= self.rpm_limit:
                return False
            
            if self.state.tokens_this_minute + estimated_tokens > self.tpm_limit:
                return False
            
            # Acquire permission
            self.state.requests_this_minute.append(datetime.now())
            self.state.tokens_this_minute += estimated_tokens
            
            return True
    
    def set_backoff(self, seconds: int):
        """Set backoff period after rate limit error."""
        self.state.backoff_until = datetime.now() + timedelta(seconds=seconds)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get rate limiting statistics."""
        with self._lock:
            self._clean_old_requests()
            
            return {
                "requests_this_minute": len(self.state.requests_this_minute),
                "rpm_limit": self.rpm_limit,
                "tokens_this_minute": self.state.tokens_this_minute,
                "tpm_limit": self.tpm_limit,
                "backoff_until": self.state.backoff_until.isoformat() if self.state.backoff_until else None
            }

class ErrorHandler:
    """Comprehensive error handling for OpenAI API."""
    
    def __init__(self, logger):
        self.logger = logger
        self.error_counts: Dict[ErrorType, int] = {error_type: 0 for error_type in ErrorType}
        
    def classify_error(self, error: Exception) -> ErrorType:
        """Classify error type."""
        if isinstance(error, RateLimitError):
            return ErrorType.RATE_LIMIT
        elif isinstance(error, APIConnectionError):
            return ErrorType.NETWORK
        elif isinstance(error, AuthenticationError):
            return ErrorType.AUTHENTICATION
        elif isinstance(error, APITimeoutError):
            return ErrorType.TIMEOUT
        elif isinstance(error, BadRequestError):
            return ErrorType.INVALID_REQUEST
        elif isinstance(error, APIError):
            return ErrorType.SERVER_ERROR
        else:
            return ErrorType.UNKNOWN
    
    async def handle_error(self, error: Exception, context: Dict[str, Any]) -> Dict[str, Any]:
        """Handle API error with appropriate response."""
        error_type = self.classify_error(error)
        self.error_counts[error_type] += 1
        
        error_info = {
            "error_type": error_type.value,
            "error_message": str(error),
            "context": context,
            "timestamp": datetime.now().isoformat()
        }
        
        if error_type == ErrorType.RATE_LIMIT:
            return await self._handle_rate_limit_error(error, error_info)
        elif error_type == ErrorType.NETWORK:
            return await self._handle_network_error(error, error_info)
        elif error_type == ErrorType.AUTHENTICATION:
            return await self._handle_auth_error(error, error_info)
        elif error_type == ErrorType.TIMEOUT:
            return await self._handle_timeout_error(error, error_info)
        else:
            return await self._handle_generic_error(error, error_info)
    
    async def _handle_rate_limit_error(self, error: Exception, error_info: Dict) -> Dict[str, Any]:
        """Handle rate limit errors."""
        self.logger.warning("Rate limit exceeded", error_info)
        
        # Extract retry-after if available
        retry_after = 60  # Default backoff
        if hasattr(error, 'response') and error.response:
            retry_after = int(error.response.headers.get('retry-after', 60))
        
        return {
            "should_retry": True,
            "retry_after": retry_after,
            "use_fallback": False,
            "error_info": error_info
        }
    
    async def _handle_network_error(self, error: Exception, error_info: Dict) -> Dict[str, Any]:
        """Handle network errors."""
        self.logger.error("Network error occurred", error_info)
        
        return {
            "should_retry": True,
            "retry_after": 5,  # Short retry for network issues
            "use_fallback": True,
            "error_info": error_info
        }
    
    async def _handle_auth_error(self, error: Exception, error_info: Dict) -> Dict[str, Any]:
        """Handle authentication errors."""
        self.logger.critical("Authentication error - check API key", error_info)
        
        return {
            "should_retry": False,
            "retry_after": 0,
            "use_fallback": True,
            "error_info": error_info
        }
    
    async def _handle_timeout_error(self, error: Exception, error_info: Dict) -> Dict[str, Any]:
        """Handle timeout errors."""
        self.logger.warning("Request timeout", error_info)
        
        return {
            "should_retry": True,
            "retry_after": 2,
            "use_fallback": True,
            "error_info": error_info
        }
    
    async def _handle_generic_error(self, error: Exception, error_info: Dict) -> Dict[str, Any]:
        """Handle generic errors."""
        self.logger.error("Generic API error", error_info)
        
        return {
            "should_retry": True,
            "retry_after": 10,
            "use_fallback": True,
            "error_info": error_info
        }
    
    def get_error_stats(self) -> Dict[str, Any]:
        """Get error statistics."""
        total_errors = sum(self.error_counts.values())
        
        return {
            "total_errors": total_errors,
            "error_breakdown": {error_type.value: count for error_type, count in self.error_counts.items()},
            "error_rate_by_type": {
                error_type.value: count / max(1, total_errors) 
                for error_type, count in self.error_counts.items()
            }
        }

class OpenAIClient:
    """Comprehensive OpenAI API client for AI Crypto Trading System."""
    
    def __init__(self, config: Optional[OpenAIConfig] = None):
        self.config = config or OpenAIConfig()
        self.logger = get_logger("openai_client")
        self.perf_logger = get_performance_logger("openai_client")
        
        # Initialize OpenAI clients
        self.sync_client = OpenAI(api_key=self.config.api_key)
        self.async_client = AsyncOpenAI(api_key=self.config.api_key)
        
        # Initialize components
        self.rate_limiter = RateLimiter(self.config.rate_limit_rpm, self.config.rate_limit_tpm)
        self.cost_tracker = CostTracker(self.config.daily_cost_limit)
        self.cache = IntelligentCache() if self.config.enable_caching else None
        self.memory_optimizer = MemoryOptimizer()
        self.error_handler = ErrorHandler(self.logger)
        self.security_validator = SecurityValidator()
        
        # Performance tracking
        self.performance_stats = {
            "total_requests": 0,
            "successful_requests": 0,
            "failed_requests": 0,
            "cached_responses": 0,
            "fallback_responses": 0,
            "average_response_time": 0.0,
            "total_tokens_used": 0,
            "total_cost": 0.0
        }
        
        # Thread pool for CPU-intensive tasks
        self.thread_pool = ThreadPoolExecutor(max_workers=2)
        
        self.logger.system("OpenAI client initialized", {
            "model": self.config.model,
            "rate_limits": f"{self.config.rate_limit_rpm} RPM, {self.config.rate_limit_tpm} TPM",
            "caching_enabled": self.config.enable_caching,
            "daily_cost_limit": self.config.daily_cost_limit
        })
    
    async def generate_response(self, prompt: str, task_type: TaskType,
                              context: Optional[Dict[str, Any]] = None,
                              max_tokens: Optional[int] = None,
                              temperature: Optional[float] = None) -> APIResponse:
        """Generate AI response with comprehensive error handling and optimization."""
        
        start_time = time.time()
        
        try:
            # Input validation and sanitization
            if not self.security_validator.validate_prompt(prompt):
                return self._create_error_response("Invalid or potentially unsafe prompt", start_time)
            
            sanitized_prompt = self.security_validator.sanitize_prompt(prompt)
            
            # Check cache first
            if self.cache:
                cached_response = self.cache.get(sanitized_prompt, task_type, context)
                if cached_response:
                    self.performance_stats["cached_responses"] += 1
                    self.logger.debug("Using cached response", {"task_type": task_type.value})
                    return cached_response
            
            # Memory management
            await self.memory_optimizer.manage_memory()
            
            # Estimate tokens for rate limiting
            estimated_tokens = len(sanitized_prompt.split()) * 1.3  # Rough estimation
            
            # Check rate limits
            if not await self.rate_limiter.acquire(int(estimated_tokens)):
                self.logger.warning("Rate limit exceeded, using fallback")
                return await self._fallback_response(sanitized_prompt, task_type, start_time)
            
            # Check cost limits
            estimated_cost = self.cost_tracker.calculate_cost(
                int(estimated_tokens), int(estimated_tokens * 0.3),
                self.config.input_cost_per_1k_tokens, self.config.output_cost_per_1k_tokens
            )
            
            if not self.cost_tracker.is_within_limit(estimated_cost):
                self.logger.warning("Daily cost limit would be exceeded")
                return await self._fallback_response(sanitized_prompt, task_type, start_time)
            
            # Prepare request
            messages = self._build_messages(sanitized_prompt, task_type, context)
            request_params = self._build_request_params(messages, max_tokens, temperature)
            
            # Optimize for memory constraints
            request_params = self.memory_optimizer.optimize_request_data(request_params)
            
            # Make API call with retries
            response = await self._make_api_call_with_retries(request_params, task_type, start_time)
            
            # Cache successful response
            if response.success and self.cache:
                self.cache.set(sanitized_prompt, task_type, response, context, self.config.cache_ttl_minutes)
            
            # Update performance stats
            self._update_performance_stats(response)
            
            return response
            
        except Exception as e:
            self.logger.error("Unexpected error in generate_response", {"error": str(e)}, exception=e)
            return self._create_error_response(f"Unexpected error: {str(e)}", start_time)
    
    async def _make_api_call_with_retries(self, request_params: Dict[str, Any], 
                                        task_type: TaskType, start_time: float) -> APIResponse:
        """Make API call with exponential backoff retries."""
        
        last_error = None
        
        for attempt in range(self.config.max_retries + 1):
            try:
                async with self.memory_optimizer.request_semaphore:
                    with TimedOperation(self.perf_logger, "openai_api_call", {"attempt": attempt + 1}):
                        
                        # Make the API call
                        completion = await self.async_client.chat.completions.create(**request_params)
                        
                        # Process successful response
                        return self._process_successful_response(completion, start_time, attempt)
                        
            except Exception as e:
                last_error = e
                
                # Handle the error
                error_response = await self.error_handler.handle_error(e, {
                    "attempt": attempt + 1,
                    "task_type": task_type.value,
                    "request_params": {k: v for k, v in request_params.items() if k != 'messages'}
                })
                
                # Check if we should retry
                if not error_response["should_retry"] or attempt >= self.config.max_retries:
                    if error_response["use_fallback"]:
                        return await self._fallback_response(
                            request_params["messages"][-1]["content"], 
                            task_type, 
                            start_time
                        )
                    else:
                        return self._create_error_response(
                            error_response["error_info"]["error_message"], 
                            start_time, 
                            attempt
                        )
                
                # Wait before retry with exponential backoff
                retry_delay = min(error_response["retry_after"] * (2 ** attempt), 60)
                await asyncio.sleep(retry_delay)
                
                # Set rate limiter backoff if needed
                if error_response["error_info"]["error_type"] == "rate_limit":
                    self.rate_limiter.set_backoff(retry_delay)
        
        # All retries failed
        return self._create_error_response(
            f"All retries failed. Last error: {str(last_error)}", 
            start_time, 
            self.config.max_retries
        )
    
    def _process_successful_response(self, completion: ChatCompletion, 
                                   start_time: float, retry_count: int) -> APIResponse:
        """Process successful API response."""
        
        content = completion.choices[0].message.content or ""
        usage = completion.usage
        
        input_tokens = usage.prompt_tokens if usage else 0
        output_tokens = usage.completion_tokens if usage else 0
        total_tokens = usage.total_tokens if usage else input_tokens + output_tokens
        
        # Calculate cost
        cost = self.cost_tracker.calculate_cost(
            input_tokens, output_tokens,
            self.config.input_cost_per_1k_tokens, self.config.output_cost_per_1k_tokens
        )
        
        # Track cost
        self.cost_tracker.add_cost(cost)
        
        response = APIResponse(
            success=True,
            content=content,
            model_used=self.config.model,
            tokens_used=total_tokens,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            response_time=time.time() - start_time,
            cost=cost,
            retry_count=retry_count
        )
        
        self.logger.decision("OpenAI response generated successfully", {
            "model": self.config.model,
            "tokens_used": total_tokens,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "cost": cost,
            "response_time": response.response_time,
            "retry_count": retry_count
        })
        
        return response
    
    def _build_messages(self, prompt: str, task_type: TaskType, 
                       context: Optional[Dict[str, Any]] = None) -> List[Dict[str, str]]:
        """Build messages for API request."""
        
        messages = []
        
        # Add system message based on task type
        system_message = self._get_system_message(task_type, context)
        if system_message:
            messages.append({"role": "system", "content": system_message})
        
        # Add user prompt
        messages.append({"role": "user", "content": prompt})
        
        return messages
    
    def _get_system_message(self, task_type: TaskType, 
                           context: Optional[Dict[str, Any]] = None) -> str:
        """Get system message based on task type."""
        
        base_instructions = {
            TaskType.MARKET_SCANNING: "You are an AI assistant specialized in cryptocurrency market scanning and analysis. Provide concise, actionable insights focusing on market trends, volume analysis, and potential opportunities.",
            TaskType.TECHNICAL_ANALYSIS: "You are an AI assistant specialized in technical analysis of cryptocurrency markets. Analyze charts, indicators, and patterns to provide detailed technical insights and trading signals.",
            TaskType.DATA_SYNTHESIS: "You are an AI assistant specialized in synthesizing complex market data. Combine multiple data sources to provide comprehensive analysis and identify key insights for trading decisions.",
            TaskType.EXECUTION_VALIDATION: "You are an AI assistant specialized in trade execution validation and risk assessment. Be conservative and thorough in your analysis, focusing on risk management and execution safety."

            
            
            
        }
        
        instruction = base_instructions.get(task_type, "You are an AI assistant for cryptocurrency trading analysis.")
        
        # Add context-specific information
        if context:
            context_parts = []
            
            if context.get("market_data"):
                context_parts.append("Current market data is provided in the user message.")
            
            if context.get("constraints"):
                context_parts.append(f"Constraints: {context['constraints']}")
            
            if context.get("output_format"):
                context_parts.append(f"Required output format: {context['output_format']}")
            
            if context.get("risk_level"):
                context_parts.append(f"Risk tolerance: {context['risk_level']}")
            
            if context_parts:
                instruction += " " + " ".join(context_parts)
        
        return instruction
    
    def _build_request_params(self, messages: List[Dict[str, str]], 
                             max_tokens: Optional[int] = None,
                             temperature: Optional[float] = None) -> Dict[str, Any]:
        """Build request parameters for API call."""
        
        params = {
            "model": self.config.model,
            "messages": messages,
            "max_tokens": max_tokens or min(self.config.max_tokens_per_request, 4000),
            "temperature": temperature if temperature is not None else self.config.temperature,
            "timeout": self.config.timeout
        }
        
        return params
    
    async def _fallback_response(self, prompt: str, task_type: TaskType, start_time: float) -> APIResponse:
        """Generate fallback response using traditional algorithms."""
        
        if not self.config.fallback_enabled:
            return self._create_error_response("Fallback disabled", start_time)
        
        try:
            # Simple rule-based responses for different task types
            fallback_content = await self._generate_traditional_response(prompt, task_type)
            
            response = APIResponse(
                success=True,
                content=fallback_content,
                model_used="traditional_fallback",
                tokens_used=0,
                input_tokens=0,
                output_tokens=0,
                response_time=time.time() - start_time,
                cost=0.0,
                fallback_used=True
            )
            
            self.performance_stats["fallback_responses"] += 1
            
            self.logger.warning("Using fallback response", {
                "task_type": task_type.value,
                "prompt_length": len(prompt)
            })
            
            return response
            
        except Exception as e:
            self.logger.error("Fallback response failed", {"error": str(e)}, exception=e)
            return self._create_error_response(f"Fallback failed: {str(e)}", start_time)
    
    async def _generate_traditional_response(self, prompt: str, task_type: TaskType) -> str:
        """Generate response using traditional algorithms."""
        
        # Simple keyword-based responses
        prompt_lower = prompt.lower()
        
        if task_type == TaskType.MARKET_SCANNING:
            if any(word in prompt_lower for word in ["price", "trend", "market"]):
                return "Market analysis unavailable. Please check current market conditions manually and consider multiple data sources before making trading decisions."
        
        elif task_type == TaskType.TECHNICAL_ANALYSIS:
            if any(word in prompt_lower for word in ["chart", "indicator", "pattern"]):
                return "Technical analysis unavailable. Please use manual chart analysis and consider multiple timeframes and indicators before making trading decisions."
        
        elif task_type == TaskType.RISK_ASSESSMENT:
            return "Risk assessment unavailable. Please implement conservative risk management: use stop losses, limit position sizes, and avoid high-leverage trades."
        
        elif task_type == TaskType.EXECUTION_VALIDATION:
            return "Execution validation unavailable. Please manually verify all trade parameters, check market conditions, and ensure proper risk management before executing trades."
        
        return "AI analysis temporarily unavailable. Please use manual analysis and exercise caution in trading decisions."
    
    def _create_error_response(self, error_message: str, start_time: float, retry_count: int = 0) -> APIResponse:
        """Create error response."""
        
        response = APIResponse(
            success=False,
            content="",
            model_used=self.config.model,
            tokens_used=0,
            input_tokens=0,
            output_tokens=0,
            response_time=time.time() - start_time,
            cost=0.0,
            error_message=error_message,
            retry_count=retry_count
        )
        
        self.performance_stats["failed_requests"] += 1
        
        return response
    
    def _update_performance_stats(self, response: APIResponse):
        """Update performance statistics."""
        
        self.performance_stats["total_requests"] += 1
        
        if response.success:
            self.performance_stats["successful_requests"] += 1
        else:
            self.performance_stats["failed_requests"] += 1
        
        if response.cached:
            self.performance_stats["cached_responses"] += 1
        
        if response.fallback_used:
            self.performance_stats["fallback_responses"] += 1
        
        self.performance_stats["total_tokens_used"] += response.tokens_used
        self.performance_stats["total_cost"] += response.cost
        
        # Update average response time
        current_avg = self.performance_stats["average_response_time"]
        total_requests = self.performance_stats["total_requests"]
        
        self.performance_stats["average_response_time"] = (
            (current_avg * (total_requests - 1) + response.response_time) / total_requests
        )
    
    # Public API methods
    
    async def chat_completion(self, messages: List[Dict[str, str]], **kwargs) -> APIResponse:
        """Direct chat completion method for compatibility."""
        
        if not messages:
            return self._create_error_response("No messages provided", time.time())
        
        # Extract prompt from last user message
        user_messages = [msg for msg in messages if msg.get("role") == "user"]
        if not user_messages:
            return self._create_error_response("No user message found", time.time())
        
        prompt = user_messages[-1].get("content", "")
        
        # Determine task type from context or default
        task_type = kwargs.get("task_type", TaskType.GENERAL_COORDINATION)
        
        return await self.generate_response(prompt, task_type, kwargs)
    
    async def analyze_market_data(self, market_data: str, context: Optional[Dict[str, Any]] = None) -> APIResponse:
        """Analyze market data for trading insights."""
        
        prompt = f"Analyze the following market data and provide trading insights:\n\n{market_data}"
        
        analysis_context = context or {}
        analysis_context.update({
            "market_data": True,
            "output_format": "structured analysis with key insights and recommendations"
        })
        
        return await self.generate_response(prompt, TaskType.MARKET_SCANNING, analysis_context)
    
    async def perform_technical_analysis(self, chart_data: str, indicators: List[str] = None,
                                       context: Optional[Dict[str, Any]] = None) -> APIResponse:
        """Perform technical analysis on chart data."""
        
        indicators_text = f" Focus on these indicators: {', '.join(indicators)}" if indicators else ""
        prompt = f"Perform technical analysis on the following chart data:{indicators_text}\n\n{chart_data}"
        
        analysis_context = context or {}
        analysis_context.update({
            "output_format": "technical analysis with signals and confidence levels",
            "indicators": indicators
        })
        
        return await self.generate_response(prompt, TaskType.TECHNICAL_ANALYSIS, analysis_context)
    
    async def validate_trade_execution(self, trade_data: Dict[str, Any],
                                     context: Optional[Dict[str, Any]] = None) -> APIResponse:
        """Validate trade execution parameters."""
        
        trade_summary = json.dumps(trade_data, indent=2)
        prompt = f"Validate the following trade execution parameters for safety and correctness:\n\n{trade_summary}"
        
        validation_context = context or {}
        validation_context.update({
            "output_format": "validation result with risk assessment and recommendations",
            "risk_level": "conservative"
        })
        
        return await self.generate_response(prompt, TaskType.EXECUTION_VALIDATION, validation_context)
    
    async def assess_risk(self, position_data: Dict[str, Any],
                         market_conditions: str = "",
                         context: Optional[Dict[str, Any]] = None) -> APIResponse:
        """Assess risk for trading positions."""
        
        position_summary = json.dumps(position_data, indent=2)
        prompt = f"Assess the risk for the following trading position:\n\nPosition: {position_summary}\n\nMarket Conditions: {market_conditions}"
        
        risk_context = context or {}
        risk_context.update({
            "output_format": "risk assessment with quantified risk levels and mitigation strategies"
        })
        
        return await self.generate_response(prompt, TaskType.RISK_ASSESSMENT, risk_context)
    
    async def synthesize_data(self, data_sources: List[str],
                            context: Optional[Dict[str, Any]] = None) -> APIResponse:
        """Synthesize multiple data sources for comprehensive analysis."""
        
        combined_data = "\n\n".join([f"Source {i+1}:\n{data}" for i, data in enumerate(data_sources)])
        prompt = f"Synthesize the following data sources to provide comprehensive trading insights:\n\n{combined_data}"
        
        synthesis_context = context or {}
        synthesis_context.update({
            "output_format": "synthesized analysis with key insights and actionable recommendations"
        })
        
        return await self.generate_response(prompt, TaskType.DATA_SYNTHESIS, synthesis_context)
    
    # Utility and monitoring methods
    
    async def health_check(self) -> Dict[str, Any]:
        """Perform comprehensive health check."""
        
        health_status = {
            "timestamp": datetime.now().isoformat(),
            "api_connectivity": False,
            "rate_limiter": self.rate_limiter.get_stats(),
            "cost_tracker": self.cost_tracker.get_stats(),
            "error_stats": self.error_handler.get_error_stats(),
            "performance_stats": self.get_performance_stats(),
            "memory_usage": self.memory_optimizer.check_memory_usage(),
            "cache_stats": self.cache.get_stats() if self.cache else None
        }
        
        try:
            # Test API connectivity with minimal request
            test_response = await self.generate_response(
                "Test connectivity", 
                TaskType.GENERAL_COORDINATION,
                {"output_format": "single word response"}
            )
            
            health_status["api_connectivity"] = test_response.success
            health_status["last_test_response_time"] = test_response.response_time
            
        except Exception as e:
            health_status["api_connectivity"] = False
            health_status["connectivity_error"] = str(e)
        
        return health_status
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """Get comprehensive performance statistics."""
        
        stats = self.performance_stats.copy()
        
        # Calculate derived metrics
        total_requests = stats["total_requests"]
        if total_requests > 0:
            stats["success_rate"] = stats["successful_requests"] / total_requests
            stats["failure_rate"] = stats["failed_requests"] / total_requests
            stats["cache_hit_rate"] = stats["cached_responses"] / total_requests
            stats["fallback_rate"] = stats["fallback_responses"] / total_requests
            stats["average_cost_per_request"] = stats["total_cost"] / total_requests
        else:
            stats.update({
                "success_rate": 0.0,
                "failure_rate": 0.0,
                "cache_hit_rate": 0.0,
                "fallback_rate": 0.0,
                "average_cost_per_request": 0.0
            })
        
        return stats
    
    def clear_cache(self):
        """Clear response cache."""
        if self.cache:
            self.cache.clear()
            self.logger.system("Response cache cleared")
    
    def reset_stats(self):
        """Reset performance statistics."""
        self.performance_stats = {
            "total_requests": 0,
            "successful_requests": 0,
            "failed_requests": 0,
            "cached_responses": 0,
            "fallback_responses": 0,
            "average_response_time": 0.0,
            "total_tokens_used": 0,
            "total_cost": 0.0
        }
        self.logger.system("Performance statistics reset")
    
    def update_config(self, new_config: Dict[str, Any]):
        """Update configuration dynamically."""
        for key, value in new_config.items():
            if hasattr(self.config, key):
                setattr(self.config, key, value)
                self.logger.system(f"Configuration updated: {key} = {value}")
    
    def is_available(self) -> bool:
        """Check if OpenAI client is available and configured."""
        try:
            return bool(self.config.api_key) and len(self.config.api_key) > 20
        except Exception:
            return False
    
    async def estimate_cost(self, prompt: str, max_tokens: int = 1000) -> float:
        """Estimate cost for a request without making it."""
        
        # Rough token estimation
        input_tokens = len(prompt.split()) * 1.3
        estimated_output_tokens = min(max_tokens, 500)  # Conservative estimate
        
        return self.cost_tracker.calculate_cost(
            int(input_tokens), 
            estimated_output_tokens,
            self.config.input_cost_per_1k_tokens,
            self.config.output_cost_per_1k_tokens
        )
    
    def __del__(self):
        """Cleanup resources."""
        try:
            if hasattr(self, 'thread_pool'):
                self.thread_pool.shutdown(wait=False)
        except Exception:
            pass

# Global OpenAI client instance
openai_client = OpenAIClient()