"""
Gemma Client - Comprehensive local Ollama integration for crypto trading operations.
Optimized for Raspberry Pi 5 with high-performance, low-latency access to Gemma models.

This client provides:
- Direct Ollama API integration for Gemma models (gemma2:2b and gemma2:9b-instruct-q4_0)
- Intelligent model selection based on task complexity and system load
- Performance optimizations for Raspberry Pi 5 ARM64 architecture
- Crypto trading specific features and prompt templates
- Comprehensive error handling and resilience
- Resource management and monitoring
"""

import asyncio
import json
import time
import hashlib
import psutil
import os
import gc
import threading
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Union, Callable, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
from collections import deque, defaultdict
import statistics
from concurrent.futures import ThreadPoolExecutor
import aiohttp
import requests

try:
    import ollama
    OLLAMA_AVAILABLE = True
except ImportError:
    OLLAMA_AVAILABLE = False
    print("Warning: ollama package not available. Install with: pip install ollama")

from src.utils.config import get_config_manager
from src.utils.logging import get_logger, get_performance_logger, TimedOperation

class GemmaModel(Enum):
    """Available Gemma models for different use cases."""
    GEMMA2_2B = "gemma2:2b"                    # Fast trading analysis
    GEMMA2_9B_INSTRUCT = "gemma2:9b-instruct-q4_0"  # Complex analysis
    
class TaskComplexity(Enum):
    """Task complexity levels for model selection."""
    SIMPLE = "simple"        # Quick market scans, basic analysis
    MODERATE = "moderate"    # Technical analysis, pattern recognition
    COMPLEX = "complex"      # Deep analysis, multi-factor decisions
    CRITICAL = "critical"    # Risk assessment, execution validation

class TradingTaskType(Enum):
    """Crypto trading specific task types."""
    MARKET_SCAN = "market_scan"
    PRICE_ANALYSIS = "price_analysis"
    TECHNICAL_ANALYSIS = "technical_analysis"
    SENTIMENT_ANALYSIS = "sentiment_analysis"
    RISK_ASSESSMENT = "risk_assessment"
    TRADE_VALIDATION = "trade_validation"
    PORTFOLIO_ANALYSIS = "portfolio_analysis"
    NEWS_ANALYSIS = "news_analysis"
    PATTERN_RECOGNITION = "pattern_recognition"
    SIGNAL_GENERATION = "signal_generation"

@dataclass
class GemmaConfig:
    """Configuration for Gemma client."""
    ollama_host: str = "http://localhost:11434"
    primary_model: str = "gemma2:2b"
    secondary_model: str = "gemma2:9b-instruct-q4_0"
    max_concurrent_requests: int = 2
    request_timeout: int = 60
    max_retries: int = 3
    cache_enabled: bool = True
    cache_ttl_seconds: int = 300
    memory_limit_mb: int = 1536  # 1.5GB for Pi 5
    cpu_threshold: float = 0.8   # 80% CPU threshold
    temperature_threshold: float = 70.0  # CPU temperature threshold
    enable_preloading: bool = True
    health_check_interval: int = 30
    performance_monitoring: bool = True
    auto_model_switching: bool = True
    fallback_enabled: bool = True

@dataclass
class GemmaResponse:
    """Standardized response from Gemma models."""
    success: bool
    content: str
    model_used: str
    tokens_used: int
    response_time: float
    confidence: float
    task_type: TradingTaskType
    complexity: TaskComplexity
    cached: bool = False
    fallback_used: bool = False
    error_message: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

@dataclass
class ModelPerformance:
    """Performance metrics for a specific model."""
    model_name: str
    total_requests: int = 0
    successful_requests: int = 0
    average_response_time: float = 0.0
    average_tokens_per_second: float = 0.0
    memory_usage_mb: float = 0.0
    last_used: Optional[datetime] = None
    error_count: int = 0
    availability_score: float = 1.0

@dataclass
class SystemMetrics:
    """System performance metrics for Pi 5."""
    cpu_percent: float
    memory_percent: float
    memory_available_mb: float
    cpu_temperature: float
    disk_usage_percent: float
    load_average: Tuple[float, float, float]
    timestamp: datetime

class PromptTemplates:
    """Crypto trading specific prompt templates."""
    
    MARKET_SCAN = """
    Analyze the following market data for crypto trading opportunities:
    
    {market_data}
    
    Provide a concise analysis focusing on:
    1. Key price movements and trends
    2. Volume analysis
    3. Potential trading opportunities
    4. Risk factors
    5. Confidence level (0-1)
    
    Respond in JSON format with structured analysis.
    """
    
    TECHNICAL_ANALYSIS = """
    Perform technical analysis on the following crypto data:
    
    {chart_data}
    
    Analyze:
    1. Support and resistance levels
    2. Technical indicators (RSI, MACD, Moving Averages)
    3. Chart patterns
    4. Entry/exit points
    5. Risk/reward ratio
    6. Confidence level (0-1)
    
    Provide detailed technical insights in JSON format.
    """
    
    RISK_ASSESSMENT = """
    Assess the risk for the following crypto trading position:
    
    Position: {position_data}
    Market Conditions: {market_conditions}
    
    Evaluate:
    1. Position size risk
    2. Market volatility impact
    3. Correlation risks
    4. Liquidity concerns
    5. Stop-loss recommendations
    6. Overall risk score (0-1)
    
    Provide comprehensive risk analysis in JSON format.
    """
    
    TRADE_VALIDATION = """
    Validate the following crypto trade before execution:
    
    Trade Details: {trade_data}
    Market Context: {market_context}
    
    Validate:
    1. Trade parameters accuracy
    2. Market timing
    3. Risk management setup
    4. Execution feasibility
    5. Potential issues
    6. Recommendation (execute/modify/cancel)
    
    Provide validation result in JSON format.
    """
    
    SIGNAL_GENERATION = """
    Generate trading signals based on the following crypto market analysis:
    
    {analysis_data}
    
    Generate:
    1. Buy/Sell/Hold signals
    2. Signal strength (0-1)
    3. Timeframe recommendations
    4. Position sizing suggestions
    5. Stop-loss levels
    6. Take-profit targets
    
    Provide signals in structured JSON format.
    """

class ResourceMonitor:
    """Monitor system resources for Raspberry Pi 5 optimization."""
    
    def __init__(self, config: GemmaConfig):
        self.config = config
        self.logger = get_logger("gemma_resource_monitor")
        self.metrics_history = deque(maxlen=100)
        self._lock = threading.Lock()
        
    def get_system_metrics(self) -> SystemMetrics:
        """Get current system metrics."""
        try:
            # CPU metrics
            cpu_percent = psutil.cpu_percent(interval=0.1)
            load_avg = os.getloadavg() if hasattr(os, 'getloadavg') else (0.0, 0.0, 0.0)
            
            # Memory metrics
            memory = psutil.virtual_memory()
            memory_percent = memory.percent
            memory_available_mb = memory.available / (1024 * 1024)
            
            # Disk metrics
            disk = psutil.disk_usage('/')
            disk_usage_percent = disk.percent
            
            # Temperature (Pi 5 specific)
            cpu_temp = self._get_cpu_temperature()
            
            metrics = SystemMetrics(
                cpu_percent=cpu_percent,
                memory_percent=memory_percent,
                memory_available_mb=memory_available_mb,
                cpu_temperature=cpu_temp,
                disk_usage_percent=disk_usage_percent,
                load_average=load_avg,
                timestamp=datetime.now()
            )
            
            with self._lock:
                self.metrics_history.append(metrics)
            
            return metrics
            
        except Exception as e:
            self.logger.error("Error getting system metrics", {"error": str(e)})
            return SystemMetrics(0.0, 0.0, 0.0, 0.0, 0.0, (0.0, 0.0, 0.0), datetime.now())
    
    def _get_cpu_temperature(self) -> float:
        """Get CPU temperature for Raspberry Pi 5."""
        try:
            # Try Pi 5 thermal zone
            with open('/sys/class/thermal/thermal_zone0/temp', 'r') as f:
                temp = float(f.read().strip()) / 1000.0
                return temp
        except:
            try:
                # Fallback to vcgencmd
                import subprocess
                result = subprocess.run(['vcgencmd', 'measure_temp'], 
                                      capture_output=True, text=True, timeout=5)
                if result.returncode == 0:
                    temp_str = result.stdout.strip()
                    temp = float(temp_str.replace('temp=', '').replace("'C", ''))
                    return temp
            except:
                pass
        return 0.0
    
    def should_throttle(self) -> bool:
        """Check if system should throttle due to resource constraints."""
        metrics = self.get_system_metrics()
        
        return (
            metrics.cpu_percent > self.config.cpu_threshold * 100 or
            metrics.memory_percent > 90.0 or
            metrics.cpu_temperature > self.config.temperature_threshold or
            metrics.memory_available_mb < 200
        )
    
    def get_optimal_model(self, task_complexity: TaskComplexity) -> GemmaModel:
        """Get optimal model based on system resources and task complexity."""
        metrics = self.get_system_metrics()
        
        # If system is under stress, use lighter model
        if self.should_throttle():
            return GemmaModel.GEMMA2_2B
        
        # For complex tasks with good resources, use larger model
        if task_complexity in [TaskComplexity.COMPLEX, TaskComplexity.CRITICAL]:
            if metrics.memory_available_mb > 800 and metrics.cpu_percent < 60:
                return GemmaModel.GEMMA2_9B_INSTRUCT
        
        # Default to fast model
        return GemmaModel.GEMMA2_2B

class ResponseCache:
    """Intelligent caching system for Gemma responses."""
    
    def __init__(self, config: GemmaConfig):
        self.config = config
        self.cache: Dict[str, Dict[str, Any]] = {}
        self.access_times: Dict[str, datetime] = {}
        self.hit_count = 0
        self.miss_count = 0
        self._lock = threading.Lock()
        
    def _generate_cache_key(self, prompt: str, model: GemmaModel, 
                           task_type: TradingTaskType, context: Dict[str, Any]) -> str:
        """Generate cache key for prompt and context."""
        cache_data = {
            "prompt": prompt[:500],  # Limit prompt length for key
            "model": model.value,
            "task_type": task_type.value,
            "context_hash": hashlib.md5(json.dumps(context, sort_keys=True).encode()).hexdigest()
        }
        
        cache_string = json.dumps(cache_data, sort_keys=True)
        return hashlib.sha256(cache_string.encode()).hexdigest()
    
    def get(self, prompt: str, model: GemmaModel, task_type: TradingTaskType, 
            context: Dict[str, Any]) -> Optional[GemmaResponse]:
        """Get cached response if available and valid."""
        if not self.config.cache_enabled:
            return None
            
        cache_key = self._generate_cache_key(prompt, model, task_type, context)
        
        with self._lock:
            if cache_key not in self.cache:
                self.miss_count += 1
                return None
            
            cached_data = self.cache[cache_key]
            cache_time = self.access_times[cache_key]
            
            # Check if cache is still valid
            if (datetime.now() - cache_time).total_seconds() > self.config.cache_ttl_seconds:
                del self.cache[cache_key]
                del self.access_times[cache_key]
                self.miss_count += 1
                return None
            
            # Update access time
            self.access_times[cache_key] = datetime.now()
            self.hit_count += 1
            
            # Recreate response object
            response = GemmaResponse(**cached_data)
            response.cached = True
            
            return response
    
    def set(self, prompt: str, model: GemmaModel, task_type: TradingTaskType,
            context: Dict[str, Any], response: GemmaResponse):
        """Cache successful response."""
        if not self.config.cache_enabled or not response.success:
            return
            
        cache_key = self._generate_cache_key(prompt, model, task_type, context)
        
        with self._lock:
            self.cache[cache_key] = asdict(response)
            self.access_times[cache_key] = datetime.now()
            
            # Cleanup old entries if cache is too large
            if len(self.cache) > 1000:
                self._cleanup_cache()
    
    def _cleanup_cache(self):
        """Remove old cache entries."""
        # Remove expired entries
        now = datetime.now()
        expired_keys = [
            key for key, access_time in self.access_times.items()
            if (now - access_time).total_seconds() > self.config.cache_ttl_seconds
        ]
        
        for key in expired_keys:
            self.cache.pop(key, None)
            self.access_times.pop(key, None)
        
        # If still too large, remove oldest entries
        if len(self.cache) > 800:
            sorted_keys = sorted(self.access_times.items(), key=lambda x: x[1])
            keys_to_remove = [key for key, _ in sorted_keys[:200]]
            
            for key in keys_to_remove:
                self.cache.pop(key, None)
                self.access_times.pop(key, None)
    
    def clear(self):
        """Clear all cache entries."""
        with self._lock:
            self.cache.clear()
            self.access_times.clear()
            self.hit_count = 0
            self.miss_count = 0
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        with self._lock:
            total_requests = self.hit_count + self.miss_count
            hit_rate = self.hit_count / max(1, total_requests)
            
            return {
                "cache_size": len(self.cache),
                "hit_count": self.hit_count,
                "miss_count": self.miss_count,
                "hit_rate": hit_rate,
                "total_requests": total_requests
            }

class ModelManager:
    """Manage Gemma models and their performance."""
    
    def __init__(self, config: GemmaConfig):
        self.config = config
        self.logger = get_logger("gemma_model_manager")
        self.performance: Dict[str, ModelPerformance] = {}
        self.loaded_models: set = set()
        self._lock = threading.Lock()
        
        # Initialize performance tracking
        for model in GemmaModel:
            self.performance[model.value] = ModelPerformance(model_name=model.value)
    
    async def ensure_model_loaded(self, model: GemmaModel) -> bool:
        """Ensure model is loaded and ready."""
        try:
            if not OLLAMA_AVAILABLE:
                self.logger.error("Ollama not available")
                return False
            
            # Check if model is already loaded
            if model.value in self.loaded_models:
                return True
            
            # Try to load/pull model
            client = ollama.Client(host=self.config.ollama_host)
            
            try:
                # Test if model is available
                response = client.generate(
                    model=model.value,
                    prompt="Test",
                    options={"num_predict": 1}
                )
                
                with self._lock:
                    self.loaded_models.add(model.value)
                
                self.logger.system(f"Model {model.value} loaded successfully")
                return True
                
            except Exception as e:
                if "not found" in str(e).lower():
                    self.logger.warning(f"Model {model.value} not found, attempting to pull...")
                    
                    # Try to pull the model
                    try:
                        client.pull(model.value)
                        with self._lock:
                            self.loaded_models.add(model.value)
                        self.logger.system(f"Model {model.value} pulled and loaded")
                        return True
                    except Exception as pull_error:
                        self.logger.error(f"Failed to pull model {model.value}", {"error": str(pull_error)})
                        return False
                else:
                    self.logger.error(f"Error loading model {model.value}", {"error": str(e)})
                    return False
                    
        except Exception as e:
            self.logger.error(f"Error ensuring model {model.value} is loaded", {"error": str(e)})
            return False
    
    def update_performance(self, model: GemmaModel, response_time: float, 
                          tokens_used: int, success: bool):
        """Update performance metrics for a model."""
        with self._lock:
            perf = self.performance[model.value]
            perf.total_requests += 1
            perf.last_used = datetime.now()
            
            if success:
                perf.successful_requests += 1
                
                # Update average response time
                if perf.average_response_time == 0:
                    perf.average_response_time = response_time
                else:
                    perf.average_response_time = (
                        (perf.average_response_time * (perf.successful_requests - 1) + response_time) /
                        perf.successful_requests
                    )
                
                # Update tokens per second
                if response_time > 0:
                    tokens_per_second = tokens_used / response_time
                    if perf.average_tokens_per_second == 0:
                        perf.average_tokens_per_second = tokens_per_second
                    else:
                        perf.average_tokens_per_second = (
                            (perf.average_tokens_per_second * (perf.successful_requests - 1) + tokens_per_second) /
                            perf.successful_requests
                        )
            else:
                perf.error_count += 1
            
            # Update availability score
            perf.availability_score = perf.successful_requests / max(1, perf.total_requests)
    
    def get_best_model(self, task_complexity: TaskComplexity, 
                      resource_monitor: ResourceMonitor) -> GemmaModel:
        """Get the best model based on performance and resources."""
        
        # Get resource-based recommendation
        optimal_model = resource_monitor.get_optimal_model(task_complexity)
        
        # Check if the optimal model is available and performing well
        with self._lock:
            optimal_perf = self.performance[optimal_model.value]
            
            # If optimal model has good availability, use it
            if optimal_perf.availability_score > 0.8:
                return optimal_model
            
            # Otherwise, find the best available model
            available_models = [
                (model, perf) for model, perf in self.performance.items()
                if perf.availability_score > 0.5
            ]
            
            if not available_models:
                return GemmaModel.GEMMA2_2B  # Fallback to primary model
            
            # Sort by performance score (availability * speed)
            available_models.sort(
                key=lambda x: x[1].availability_score * (1.0 / max(0.1, x[1].average_response_time)),
                reverse=True
            )
            
            best_model_name = available_models[0][0]
            return GemmaModel(best_model_name)
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """Get performance statistics for all models."""
        with self._lock:
            return {
                model_name: asdict(perf) 
                for model_name, perf in self.performance.items()
            }

class GemmaClient:
    """Comprehensive local Gemma client for crypto trading operations."""
    
    def __init__(self, config: Optional[GemmaConfig] = None):
        self.config = config or GemmaConfig()
        self.logger = get_logger("gemma_client")
        self.perf_logger = get_performance_logger("gemma_client")
        
        # Initialize components
        self.resource_monitor = ResourceMonitor(self.config)
        self.cache = ResponseCache(self.config)
        self.model_manager = ModelManager(self.config)
        self.prompt_templates = PromptTemplates()
        
        # Connection management
        self.ollama_client = None
        self.session_pool = None
        self.request_semaphore = asyncio.Semaphore(self.config.max_concurrent_requests)
        
        # Performance tracking
        self.stats = {
            "total_requests": 0,
            "successful_requests": 0,
            "cached_responses": 0,
            "fallback_responses": 0,
            "average_response_time": 0.0,
            "total_tokens_processed": 0,
            "models_used": defaultdict(int),
            "task_types_processed": defaultdict(int)
        }
        
        # Background tasks
        self.background_tasks = []
        self.running = False
        
        self.logger.system("Gemma client initialized", {
            "ollama_host": self.config.ollama_host,
            "primary_model": self.config.primary_model,
            "secondary_model": self.config.secondary_model,
            "cache_enabled": self.config.cache_enabled,
            "max_concurrent_requests": self.config.max_concurrent_requests
        })
    
    async def start(self):
        """Start the Gemma client and initialize connections."""
        try:
            self.running = True
            
            # Initialize Ollama client
            if OLLAMA_AVAILABLE:
                self.ollama_client = ollama.AsyncClient(host=self.config.ollama_host)
                
                # Test connection
                await self._test_connection()
                
                # Preload models if enabled
                if self.config.enable_preloading:
                    await self._preload_models()
            else:
                self.logger.error("Ollama not available - client will use fallback mode")
            
            # Start background tasks
            if self.config.performance_monitoring:
                self.background_tasks.append(
                    asyncio.create_task(self._performance_monitoring_loop())
                )
            
            self.background_tasks.append(
                asyncio.create_task(self._health_monitoring_loop())
            )
            
            self.logger.system("Gemma client started successfully")
            
        except Exception as e:
            self.logger.error("Failed to start Gemma client", exception=e)
            raise
    
    async def stop(self):
        """Stop the Gemma client and cleanup resources."""
        self.running = False
        
        # Cancel background tasks
        for task in self.background_tasks:
            task.cancel()
        
        if self.background_tasks:
            await asyncio.gather(*self.background_tasks, return_exceptions=True)
        
        # Cleanup session pool
        if self.session_pool:
            await self.session_pool.close()
        
        self.logger.system("Gemma client stopped", {
            "total_requests": self.stats["total_requests"],
            "successful_requests": self.stats["successful_requests"],
            "cache_stats": self.cache.get_stats()
        })
    
    async def generate_response(self, prompt: str, task_type: TradingTaskType,
                              complexity: TaskComplexity = TaskComplexity.MODERATE,
                              context: Optional[Dict[str, Any]] = None,
                              force_model: Optional[GemmaModel] = None) -> GemmaResponse:
        """Generate AI response optimized for crypto trading tasks."""
        
        start_time = time.time()
        context = context or {}
        
        try:
            # Update stats
            self.stats["total_requests"] += 1
            self.stats["task_types_processed"][task_type.value] += 1
            
            # Check cache first
            selected_model = force_model or self.model_manager.get_best_model(complexity, self.resource_monitor)
            cached_response = self.cache.get(prompt, selected_model, task_type, context)
            
            if cached_response:
                self.stats["cached_responses"] += 1
                self.logger.debug("Using cached response", {
                    "task_type": task_type.value,
                    "model": selected_model.value
                })
                return cached_response
            
            # Optimize prompt for trading task
            optimized_prompt = self._optimize_prompt(prompt, task_type, context)
            
            # Generate response with retries
            response = await self._generate_with_retries(
                optimized_prompt, selected_model, task_type, complexity, context, start_time
            )
            
            # Cache successful response
            if response.success:
                self.cache.set(prompt, selected_model, task_type, context, response)
            
            # Update performance stats
            self._update_stats(response, selected_model)
            
            return response
            
        except Exception as e:
            self.logger.error("Error in generate_response", exception=e)
            return self._create_error_response(str(e), start_time, task_type, complexity)
    
    async def _generate_with_retries(self, prompt: str, model: GemmaModel,
                                   task_type: TradingTaskType, complexity: TaskComplexity,
                                   context: Dict[str, Any], start_time: float) -> GemmaResponse:
        """Generate response with retry logic and fallback."""
        
        last_error = None
        
        for attempt in range(self.config.max_retries + 1):
            try:
                # Ensure model is loaded
                if not await self.model_manager.ensure_model_loaded(model):
                    if attempt == 0 and model != GemmaModel.GEMMA2_2B:
                        # Fallback to primary model
                        model = GemmaModel.GEMMA2_2B
                        continue
                    else:
                        raise Exception(f"Model {model.value} not available")
                
                # Check system resources
                if self.resource_monitor.should_throttle():
                    if model == GemmaModel.GEMMA2_9B_INSTRUCT:
                        model = GemmaModel.GEMMA2_2B
                        self.logger.warning("Switching to lighter model due to resource constraints")
                
                # Make the API call
                response = await self._call_ollama(prompt, model, task_type, complexity, context, start_time)
                
                if response.success:
                    self.model_manager.update_performance(
                        model, response.response_time, response.tokens_used, True
                    )
                    return response
                else:
                    last_error = Exception(response.error_message)
                    
            except Exception as e:
                last_error = e
                self.model_manager.update_performance(model, 0, 0, False)
                
                self.logger.warning(f"Attempt {attempt + 1} failed for model {model.value}", {
                    "error": str(e),
                    "task_type": task_type.value
                })
                
                # Try fallback model on first failure
                if attempt == 0 and model == GemmaModel.GEMMA2_9B_INSTRUCT:
                    model = GemmaModel.GEMMA2_2B
                    continue
                
                # Wait before retry
                if attempt < self.config.max_retries:
                    await asyncio.sleep(min(2 ** attempt, 10))
        
        # All retries failed - try fallback
        if self.config.fallback_enabled:
            return await self._fallback_response(prompt, task_type, complexity, start_time)
        
        return self._create_error_response(
            f"All retries failed. Last error: {str(last_error)}", 
            start_time, task_type, complexity
        )
    
    async def _call_ollama(self, prompt: str, model: GemmaModel, task_type: TradingTaskType,
                          complexity: TaskComplexity, context: Dict[str, Any], 
                          start_time: float) -> GemmaResponse:
        """Make API call to Ollama."""
        
        if not OLLAMA_AVAILABLE or not self.ollama_client:
            raise Exception("Ollama client not available")
        
        async with self.request_semaphore:
            try:
                # Prepare options based on task complexity
                options = self._get_model_options(complexity)
                
                # Make the API call
                with TimedOperation(self.perf_logger, f"ollama_call_{model.value}"):
                    response = await self.ollama_client.generate(
                        model=model.value,
                        prompt=prompt,
                        options=options
                    )
                
                # Extract response data
                content = response.get('response', '')
                tokens_used = self._estimate_tokens(prompt + content)
                response_time = time.time() - start_time
                
                # Parse confidence from response if available
                confidence = self._extract_confidence(content)
                
                return GemmaResponse(
                    success=True,
                    content=content,
                    model_used=model.value,
                    tokens_used=tokens_used,
                    response_time=response_time,
                    confidence=confidence,
                    task_type=task_type,
                    complexity=complexity,
                    metadata={
                        "options": options,
                        "context": context
                    }
                )
                
            except Exception as e:
                return GemmaResponse(
                    success=False,
                    content="",
                    model_used=model.value,
                    tokens_used=0,
                    response_time=time.time() - start_time,
                    confidence=0.0,
                    task_type=task_type,
                    complexity=complexity,
                    error_message=str(e)
                )
    
    def _get_model_options(self, complexity: TaskComplexity) -> Dict[str, Any]:
        """Get model options base
d on task complexity."""
        base_options = {
            "temperature": 0.3,
            "top_p": 0.9,
            "top_k": 40,
        }
        
        if complexity == TaskComplexity.SIMPLE:
            base_options.update({
                "num_predict": 512,
                "temperature": 0.2,
            })
        elif complexity == TaskComplexity.MODERATE:
            base_options.update({
                "num_predict": 1024,
                "temperature": 0.3,
            })
        elif complexity == TaskComplexity.COMPLEX:
            base_options.update({
                "num_predict": 2048,
                "temperature": 0.4,
            })
        elif complexity == TaskComplexity.CRITICAL:
            base_options.update({
                "num_predict": 1024,
                "temperature": 0.1,  # Lower temperature for critical tasks
            })
        
        return base_options
    
    def _estimate_tokens(self, text: str) -> int:
        """Estimate token count for text."""
        # Rough estimation: ~1.3 tokens per word
        return int(len(text.split()) * 1.3)
    
    def _extract_confidence(self, content: str) -> float:
        """Extract confidence score from response content."""
        try:
            # Try to parse JSON response
            if content.strip().startswith('{'):
                data = json.loads(content)
                if 'confidence' in data:
                    return float(data['confidence'])
            
            # Look for confidence patterns in text
            import re
            confidence_patterns = [
                r'confidence[:\s]*([0-9.]+)',
                r'confidence level[:\s]*([0-9.]+)',
                r'score[:\s]*([0-9.]+)'
            ]
            
            for pattern in confidence_patterns:
                match = re.search(pattern, content.lower())
                if match:
                    return min(1.0, float(match.group(1)))
            
            return 0.7  # Default confidence
            
        except Exception:
            return 0.5  # Fallback confidence
    
    def _optimize_prompt(self, prompt: str, task_type: TradingTaskType, 
                        context: Dict[str, Any]) -> str:
        """Optimize prompt for specific trading task."""
        
        # Get task-specific template
        template = self._get_task_template(task_type)
        
        if template:
            # Format template with context data
            try:
                formatted_prompt = template.format(**context, original_prompt=prompt)
                return formatted_prompt
            except KeyError:
                # If template formatting fails, use original prompt with task prefix
                pass
        
        # Add task-specific prefix
        task_prefixes = {
            TradingTaskType.MARKET_SCAN: "Perform a crypto market scan analysis:",
            TradingTaskType.PRICE_ANALYSIS: "Analyze crypto price movements:",
            TradingTaskType.TECHNICAL_ANALYSIS: "Conduct technical analysis:",
            TradingTaskType.SENTIMENT_ANALYSIS: "Analyze market sentiment:",
            TradingTaskType.RISK_ASSESSMENT: "Assess trading risk:",
            TradingTaskType.TRADE_VALIDATION: "Validate trade parameters:",
            TradingTaskType.PORTFOLIO_ANALYSIS: "Analyze portfolio performance:",
            TradingTaskType.NEWS_ANALYSIS: "Analyze crypto news impact:",
            TradingTaskType.PATTERN_RECOGNITION: "Identify chart patterns:",
            TradingTaskType.SIGNAL_GENERATION: "Generate trading signals:"
        }
        
        prefix = task_prefixes.get(task_type, "Analyze the following crypto trading data:")
        
        # Add context information
        context_info = ""
        if context:
            if context.get("timeframe"):
                context_info += f"\nTimeframe: {context['timeframe']}"
            if context.get("symbol"):
                context_info += f"\nSymbol: {context['symbol']}"
            if context.get("risk_level"):
                context_info += f"\nRisk Level: {context['risk_level']}"
        
        optimized_prompt = f"{prefix}{context_info}\n\n{prompt}\n\nProvide analysis in structured format with confidence level."
        
        return optimized_prompt
    
    def _get_task_template(self, task_type: TradingTaskType) -> Optional[str]:
        """Get template for specific task type."""
        templates = {
            TradingTaskType.MARKET_SCAN: self.prompt_templates.MARKET_SCAN,
            TradingTaskType.TECHNICAL_ANALYSIS: self.prompt_templates.TECHNICAL_ANALYSIS,
            TradingTaskType.RISK_ASSESSMENT: self.prompt_templates.RISK_ASSESSMENT,
            TradingTaskType.TRADE_VALIDATION: self.prompt_templates.TRADE_VALIDATION,
            TradingTaskType.SIGNAL_GENERATION: self.prompt_templates.SIGNAL_GENERATION,
        }
        
        return templates.get(task_type)
    
    async def _fallback_response(self, prompt: str, task_type: TradingTaskType,
                                complexity: TaskComplexity, start_time: float) -> GemmaResponse:
        """Generate fallback response using traditional algorithms."""
        
        try:
            # Simple rule-based responses for different task types
            fallback_content = self._generate_traditional_response(prompt, task_type)
            
            response = GemmaResponse(
                success=True,
                content=fallback_content,
                model_used="traditional_fallback",
                tokens_used=0,
                response_time=time.time() - start_time,
                confidence=0.3,  # Lower confidence for fallback
                task_type=task_type,
                complexity=complexity,
                fallback_used=True
            )
            
            self.stats["fallback_responses"] += 1
            
            self.logger.warning("Using fallback response", {
                "task_type": task_type.value,
                "complexity": complexity.value
            })
            
            return response
            
        except Exception as e:
            self.logger.error("Fallback response failed", exception=e)
            return self._create_error_response(f"Fallback failed: {str(e)}", start_time, task_type, complexity)
    
    def _generate_traditional_response(self, prompt: str, task_type: TradingTaskType) -> str:
        """Generate response using traditional algorithms."""
        
        prompt_lower = prompt.lower()
        
        if task_type == TradingTaskType.MARKET_SCAN:
            return json.dumps({
                "analysis": "Market scan unavailable. Please check current market conditions manually.",
                "recommendation": "Use multiple data sources and exercise caution.",
                "confidence": 0.3,
                "risk_level": "high"
            })
        
        elif task_type == TradingTaskType.RISK_ASSESSMENT:
            return json.dumps({
                "risk_score": 0.7,
                "recommendation": "Implement conservative risk management: use stop losses, limit position sizes.",
                "confidence": 0.3,
                "factors": ["AI analysis unavailable", "Manual verification required"]
            })
        
        elif task_type == TradingTaskType.TRADE_VALIDATION:
            return json.dumps({
                "validation_result": "manual_review_required",
                "recommendation": "Please manually verify all trade parameters before execution.",
                "confidence": 0.2,
                "checks_passed": 0,
                "checks_total": 5
            })
        
        return json.dumps({
            "message": "AI analysis temporarily unavailable. Please use manual analysis and exercise caution.",
            "confidence": 0.2,
            "recommendation": "Seek alternative analysis methods"
        })
    
    def _create_error_response(self, error_message: str, start_time: float,
                              task_type: TradingTaskType, complexity: TaskComplexity) -> GemmaResponse:
        """Create error response."""
        
        return GemmaResponse(
            success=False,
            content="",
            model_used="error",
            tokens_used=0,
            response_time=time.time() - start_time,
            confidence=0.0,
            task_type=task_type,
            complexity=complexity,
            error_message=error_message
        )
    
    def _update_stats(self, response: GemmaResponse, model: GemmaModel):
        """Update performance statistics."""
        
        if response.success:
            self.stats["successful_requests"] += 1
        
        if response.cached:
            self.stats["cached_responses"] += 1
        
        if response.fallback_used:
            self.stats["fallback_responses"] += 1
        
        self.stats["total_tokens_processed"] += response.tokens_used
        self.stats["models_used"][model.value] += 1
        
        # Update average response time
        current_avg = self.stats["average_response_time"]
        total_requests = self.stats["total_requests"]
        
        self.stats["average_response_time"] = (
            (current_avg * (total_requests - 1) + response.response_time) / total_requests
        )
    
    async def _test_connection(self):
        """Test connection to Ollama server."""
        try:
            if not self.ollama_client:
                raise Exception("Ollama client not initialized")
            
            # Simple test call
            response = await self.ollama_client.generate(
                model=self.config.primary_model,
                prompt="Test",
                options={"num_predict": 1}
            )
            
            self.logger.system("Ollama connection test successful")
            
        except Exception as e:
            self.logger.error("Ollama connection test failed", exception=e)
            raise
    
    async def _preload_models(self):
        """Preload models for faster response times."""
        try:
            models_to_load = [GemmaModel.GEMMA2_2B, GemmaModel.GEMMA2_9B_INSTRUCT]
            
            for model in models_to_load:
                success = await self.model_manager.ensure_model_loaded(model)
                if success:
                    self.logger.system(f"Preloaded model {model.value}")
                else:
                    self.logger.warning(f"Failed to preload model {model.value}")
            
        except Exception as e:
            self.logger.error("Error preloading models", exception=e)
    
    async def _performance_monitoring_loop(self):
        """Background loop for performance monitoring."""
        while self.running:
            try:
                # Log performance metrics
                metrics = self.resource_monitor.get_system_metrics()
                model_stats = self.model_manager.get_performance_stats()
                cache_stats = self.cache.get_stats()
                
                self.logger.health("Performance metrics", {
                    "system_metrics": asdict(metrics),
                    "model_performance": model_stats,
                    "cache_stats": cache_stats,
                    "client_stats": self.stats
                })
                
                # Trigger garbage collection if memory usage is high
                if metrics.memory_percent > 85:
                    gc.collect()
                    self.logger.system("Triggered garbage collection due to high memory usage")
                
                await asyncio.sleep(60)  # Monitor every minute
                
            except Exception as e:
                self.logger.error("Error in performance monitoring loop", exception=e)
                await asyncio.sleep(60)
    
    async def _health_monitoring_loop(self):
        """Background loop for health monitoring."""
        while self.running:
            try:
                # Check Ollama health
                if OLLAMA_AVAILABLE and self.ollama_client:
                    try:
                        await self._test_connection()
                        health_status = "healthy"
                    except Exception:
                        health_status = "unhealthy"
                else:
                    health_status = "unavailable"
                
                self.logger.health("Gemma client health check", {
                    "status": health_status,
                    "models_loaded": list(self.model_manager.loaded_models),
                    "cache_size": len(self.cache.cache),
                    "total_requests": self.stats["total_requests"],
                    "success_rate": self.stats["successful_requests"] / max(1, self.stats["total_requests"])
                })
                
                await asyncio.sleep(self.config.health_check_interval)
                
            except Exception as e:
                self.logger.error("Error in health monitoring loop", exception=e)
                await asyncio.sleep(self.config.health_check_interval)
    
    # Public API methods for crypto trading
    
    async def analyze_market_data(self, market_data: str, symbols: List[str] = None,
                                 timeframe: str = "1h") -> GemmaResponse:
        """Analyze market data for trading opportunities."""
        
        context = {
            "market_data": market_data,
            "symbols": symbols or [],
            "timeframe": timeframe
        }
        
        prompt = f"Analyze the following crypto market data for trading opportunities:\n\n{market_data}"
        
        return await self.generate_response(
            prompt, 
            TradingTaskType.MARKET_SCAN,
            TaskComplexity.MODERATE,
            context
        )
    
    async def perform_technical_analysis(self, chart_data: str, symbol: str,
                                       indicators: List[str] = None) -> GemmaResponse:
        """Perform technical analysis on chart data."""
        
        context = {
            "chart_data": chart_data,
            "symbol": symbol,
            "indicators": indicators or []
        }
        
        prompt = f"Perform technical analysis on {symbol} chart data:\n\n{chart_data}"
        
        return await self.generate_response(
            prompt,
            TradingTaskType.TECHNICAL_ANALYSIS,
            TaskComplexity.COMPLEX,
            context
        )
    
    async def assess_trading_risk(self, position_data: Dict[str, Any],
                                 market_conditions: str = "") -> GemmaResponse:
        """Assess risk for trading position."""
        
        context = {
            "position_data": position_data,
            "market_conditions": market_conditions
        }
        
        prompt = f"Assess trading risk for position: {json.dumps(position_data, indent=2)}"
        
        return await self.generate_response(
            prompt,
            TradingTaskType.RISK_ASSESSMENT,
            TaskComplexity.CRITICAL,
            context
        )
    
    async def validate_trade(self, trade_data: Dict[str, Any],
                           market_context: Dict[str, Any] = None) -> GemmaResponse:
        """Validate trade parameters before execution."""
        
        context = {
            "trade_data": trade_data,
            "market_context": market_context or {}
        }
        
        prompt = f"Validate trade parameters: {json.dumps(trade_data, indent=2)}"
        
        return await self.generate_response(
            prompt,
            TradingTaskType.TRADE_VALIDATION,
            TaskComplexity.CRITICAL,
            context
        )
    
    async def generate_trading_signals(self, analysis_data: Dict[str, Any],
                                     signal_type: str = "all") -> GemmaResponse:
        """Generate trading signals based on analysis."""
        
        context = {
            "analysis_data": analysis_data,
            "signal_type": signal_type
        }
        
        prompt = f"Generate trading signals based on analysis: {json.dumps(analysis_data, indent=2)}"
        
        return await self.generate_response(
            prompt,
            TradingTaskType.SIGNAL_GENERATION,
            TaskComplexity.COMPLEX,
            context
        )
    
    async def analyze_portfolio(self, portfolio_data: Dict[str, Any]) -> GemmaResponse:
        """Analyze portfolio performance and recommendations."""
        
        context = {"portfolio_data": portfolio_data}
        
        prompt = f"Analyze portfolio performance: {json.dumps(portfolio_data, indent=2)}"
        
        return await self.generate_response(
            prompt,
            TradingTaskType.PORTFOLIO_ANALYSIS,
            TaskComplexity.MODERATE,
            context
        )
    
    # Utility and monitoring methods
    
    async def health_check(self) -> Dict[str, Any]:
        """Perform comprehensive health check."""
        
        system_metrics = self.resource_monitor.get_system_metrics()
        model_performance = self.model_manager.get_performance_stats()
        cache_stats = self.cache.get_stats()
        
        # Test model availability
        model_health = {}
        for model in GemmaModel:
            try:
                available = await self.model_manager.ensure_model_loaded(model)
                model_health[model.value] = "available" if available else "unavailable"
            except Exception as e:
                model_health[model.value] = f"error: {str(e)}"
        
        return {
            "timestamp": datetime.now().isoformat(),
            "system_metrics": asdict(system_metrics),
            "model_health": model_health,
            "model_performance": model_performance,
            "cache_stats": cache_stats,
            "client_stats": self.stats,
            "ollama_available": OLLAMA_AVAILABLE,
            "running": self.running
        }
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """Get comprehensive performance statistics."""
        
        stats = self.stats.copy()
        
        # Calculate derived metrics
        total_requests = stats["total_requests"]
        if total_requests > 0:
            stats["success_rate"] = stats["successful_requests"] / total_requests
            stats["cache_hit_rate"] = stats["cached_responses"] / total_requests
            stats["fallback_rate"] = stats["fallback_responses"] / total_requests
            stats["average_tokens_per_request"] = stats["total_tokens_processed"] / total_requests
        else:
            stats.update({
                "success_rate": 0.0,
                "cache_hit_rate": 0.0,
                "fallback_rate": 0.0,
                "average_tokens_per_request": 0.0
            })
        
        # Add system metrics
        stats["system_metrics"] = asdict(self.resource_monitor.get_system_metrics())
        stats["model_performance"] = self.model_manager.get_performance_stats()
        stats["cache_stats"] = self.cache.get_stats()
        
        return stats
    
    def clear_cache(self):
        """Clear response cache."""
        self.cache.clear()
        self.logger.system("Gemma client cache cleared")
    
    def reset_stats(self):
        """Reset performance statistics."""
        self.stats = {
            "total_requests": 0,
            "successful_requests": 0,
            "cached_responses": 0,
            "fallback_responses": 0,
            "average_response_time": 0.0,
            "total_tokens_processed": 0,
            "models_used": defaultdict(int),
            "task_types_processed": defaultdict(int)
        }
        self.logger.system("Gemma client statistics reset")
    
    def update_config(self, new_config: Dict[str, Any]):
        """Update configuration dynamically."""
        for key, value in new_config.items():
            if hasattr(self.config, key):
                setattr(self.config, key, value)
                self.logger.system(f"Gemma client configuration updated: {key} = {value}")
    
    def is_available(self) -> bool:
        """Check if Gemma client is available and ready."""
        return (
            OLLAMA_AVAILABLE and 
            self.ollama_client is not None and 
            self.running and
            len(self.model_manager.loaded_models) > 0
        )
    
    async def estimate_response_time(self, prompt: str, task_type: TradingTaskType,
                                   complexity: TaskComplexity) -> float:
        """Estimate response time for a request without making it."""
        
        # Get model that would be used
        model = self.model_manager.get_best_model(complexity, self.resource_monitor)
        
        # Get historical performance
        with self.model_manager._lock:
            perf = self.model_manager.performance[model.value]
            if perf.average_response_time > 0:
                base_time = perf.average_response_time
            else:
                # Estimate based on model and complexity
                base_time = 2.0 if model == GemmaModel.GEMMA2_2B else 5.0
        
        # Adjust for current system load
        metrics = self.resource_monitor.get_system_metrics()
        load_factor = 1.0 + (metrics.cpu_percent / 100.0)
        
        # Adjust for prompt length
        token_count = self._estimate_tokens(prompt)
        length_factor = 1.0 + (token_count / 1000.0)
        
        estimated_time = base_time * load_factor * length_factor
        
        return min(estimated_time, 60.0)  # Cap at 60 seconds
    
    def __del__(self):
        """Cleanup resources."""
        try:
            if hasattr(self, 'running'):
                self.running = False
        except Exception:
            pass


# Global Gemma client instance
gemma_client = None

def get_gemma_client(config: Optional[GemmaConfig] = None) -> GemmaClient:
    """Get the global Gemma client instance (lazy initialization)."""
    global gemma_client
    if gemma_client is None:
        gemma_client = GemmaClient(config)
    return gemma_client

def reset_gemma_client():
    """Reset the global Gemma client instance (for testing)."""
    global gemma_client
    if gemma_client and gemma_client.running:
        asyncio.create_task(gemma_client.stop())
    gemma_client = None