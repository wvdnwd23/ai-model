"""
AI Prompt Templates - Optimized prompts for each trading module.
Provides specialized prompts for different AI models and tasks.
Keeps prompts under 300 tokens where possible for cost optimization.
"""

from typing import Dict, Any, List, Optional
from enum import Enum
import json

class PromptType(Enum):
    """Types of prompts for different modules."""
    COIN_SCANNER_SENTIMENT = "coin_scanner_sentiment"
    COIN_SCANNER_ANALYSIS = "coin_scanner_analysis"
    CHART_CHECKER_TECHNICAL = "chart_checker_technical"
    CHART_CHECKER_PATTERN = "chart_checker_pattern"
    COMBINER_DECISION = "combiner_decision"
    COMBINER_SYNTHESIS = "combiner_synthesis"
    VERIFIER_VALIDATION = "verifier_validation"
    VERIFIER_RISK_ASSESSMENT = "verifier_risk_assessment"
    CONTROLLER_COORDINATION = "controller_coordination"

class PromptTemplates:
    """Collection of optimized prompt templates for AI trading modules."""
    
    def __init__(self):
        self.templates = {
            # Coin Scanner Templates (Gemma optimized)
            PromptType.COIN_SCANNER_SENTIMENT: {
                "system": "You are a crypto sentiment analyzer. Analyze social media and news quickly.",
                "template": """Analyze sentiment for {symbol}:

Social Data:
{social_data}

Market Data:
- Price: ${price}
- Volume: {volume}
- 24h Change: {price_change_24h}%

Provide JSON response:
{{
  "sentiment_score": float (-1 to 1),
  "confidence": float (0 to 1),
  "key_factors": [list of 2-3 main factors],
  "recommendation": "bullish/bearish/neutral"
}}

Be concise and focus on actionable insights.""",
                "max_tokens": 200
            },
            
            PromptType.COIN_SCANNER_ANALYSIS: {
                "system": "You are a fast market scanner. Identify breakout opportunities quickly.",
                "template": """Scan {symbol} for trading signals:

Market Metrics:
- Volume Anomaly: {volume_anomaly}x normal
- Sentiment: {sentiment_score}
- Social Mentions: {social_mentions}
- Price Change: {price_change_24h}%

Technical Indicators:
{technical_data}

JSON response:
{{
  "breakout_probability": float (0 to 1),
  "signal_strength": float (0 to 1),
  "timeframe": "short/medium/long",
  "key_signals": [list of 2-3 signals],
  "confidence": float (0 to 1)
}}

Focus on speed and accuracy.""",
                "max_tokens": 250
            },
            
            # Chart Checker Templates (Gemma optimized)
            PromptType.CHART_CHECKER_TECHNICAL: {
                "system": "You are an expert technical analyst. Provide detailed multi-timeframe analysis.",
                "template": """Analyze {symbol} technical indicators across timeframes:

Timeframe Data:
{timeframe_data}

Current Indicators:
- RSI: {rsi}
- MACD: {macd_signal}
- Bollinger Bands: {bb_position}
- Support: ${support}
- Resistance: ${resistance}

Provide comprehensive JSON analysis:
{{
  "overall_trend": "bullish/bearish/neutral",
  "trend_strength": float (0 to 1),
  "key_levels": {{
    "support": [list of support levels],
    "resistance": [list of resistance levels]
  }},
  "signals": {{
    "rsi_signal": "overbought/oversold/neutral",
    "macd_signal": "bullish/bearish/neutral",
    "bb_signal": "squeeze/expansion/normal"
  }},
  "timeframe_alignment": float (0 to 1),
  "confidence": float (0 to 1),
  "reasoning": "detailed explanation"
}}

Focus on pattern recognition and signal confluence.""",
                "max_tokens": 400
            },
            
            PromptType.CHART_CHECKER_PATTERN: {
                "system": "You are a pattern recognition expert. Identify advanced chart patterns.",
                "template": """Identify patterns in {symbol} chart data:

Price Action:
{price_data}

Volume Profile:
{volume_data}

Pattern Analysis Required:
- Wyckoff phases
- Fair Value Gaps (FVG)
- Inverse Fair Value Gaps (IFVG)
- Classic patterns (triangles, flags, etc.)

JSON response:
{{
  "wyckoff_phase": "accumulation/markup/distribution/markdown",
  "fvg_gaps": [{{
    "price_level": float,
    "strength": float (0 to 1),
    "direction": "bullish/bearish"
  }}],
  "classic_patterns": [{{
    "pattern": "pattern name",
    "completion": float (0 to 1),
    "target": float
  }}],
  "pattern_confluence": float (0 to 1),
  "breakout_probability": float (0 to 1)
}}

Prioritize high-probability setups.""",
                "max_tokens": 350
            },
            
            # Combiner Templates (Gemma optimized)
            PromptType.COMBINER_DECISION: {
                "system": "You are a trading decision engine. Synthesize multiple data sources for optimal decisions.",
                "template": """Make trading decision for {symbol}:

Scanner Analysis:
{scanner_data}

Chart Analysis:
{chart_data}

Market Context:
- Current Price: ${current_price}
- Market Hours: {market_hours}
- Volatility: {volatility}

Risk Parameters:
- Max Position Size: {max_position_size}
- Risk/Reward Min: {min_risk_reward}

Provide comprehensive decision:
{{
  "decision": "buy/sell/hold",
  "confidence": float (0 to 1),
  "position_size": float (0 to 1),
  "entry_strategy": {{
    "price": float,
    "stop_loss": float,
    "take_profit": [list of levels]
  }},
  "risk_assessment": {{
    "risk_score": float (0 to 1),
    "max_drawdown": float,
    "probability_success": float (0 to 1)
  }},
  "reasoning": "detailed multi-factor analysis",
  "timeframe": "expected holding period"
}}

Prioritize risk management and signal confluence.""",
                "max_tokens": 450
            },
            
            PromptType.COMBINER_SYNTHESIS: {
                "system": "You are a data synthesis expert. Combine multiple analysis sources intelligently.",
                "template": """Synthesize analysis for {symbol}:

Data Sources:
1. Scanner: {scanner_summary}
2. Technical: {technical_summary}
3. Sentiment: {sentiment_summary}

Correlation Analysis:
{correlation_data}

Synthesis Requirements:
- Weight each source by reliability
- Identify conflicting signals
- Calculate combined confidence
- Assess overall opportunity

JSON response:
{{
  "synthesis_score": float (0 to 1),
  "source_weights": {{
    "scanner": float (0 to 1),
    "technical": float (0 to 1),
    "sentiment": float (0 to 1)
  }},
  "signal_conflicts": [list of conflicts],
  "combined_confidence": float (0 to 1),
  "opportunity_rank": "high/medium/low",
  "key_insights": [list of 3-5 insights]
}}

Focus on data quality and signal reliability.""",
                "max_tokens": 300
            },
            
            # Verifier & Executor Templates (Gemma optimized)
            PromptType.VERIFIER_VALIDATION: {
                "system": "You are a conservative trade validator. Ensure all conditions are met before execution.",
                "template": """Validate trade execution for {symbol}:

Proposed Trade:
{trade_decision}

Market Conditions:
- Liquidity Score: {liquidity_score}
- Spread: {spread_percentage}%
- Market Hours: {market_hours}
- Volatility: {volatility_index}

Risk Factors:
{risk_factors}

Validation Checklist:
{{
  "liquidity_adequate": boolean,
  "spread_acceptable": boolean,
  "market_conditions_favorable": boolean,
  "risk_within_limits": boolean,
  "position_size_appropriate": boolean,
  "stop_loss_valid": boolean,
  "overall_approval": boolean,
  "risk_adjustments": [list of adjustments],
  "execution_recommendation": "proceed/modify/reject",
  "reasoning": "conservative risk assessment"
}}

Be extremely cautious and conservative. Reject if any doubt exists.""",
                "max_tokens": 350
            },
            
            PromptType.VERIFIER_RISK_ASSESSMENT: {
                "system": "You are a risk management specialist. Assess and mitigate all trading risks.",
                "template": """Assess risks for {symbol} trade:

Trade Parameters:
- Size: {position_size}
- Leverage: {leverage}x
- Entry: ${entry_price}
- Stop Loss: ${stop_loss}
- Take Profit: {take_profit}

Market Environment:
{macro_environment}

Portfolio Context:
- Current Exposure: {current_exposure}
- Daily P&L: {daily_pnl}
- Open Positions: {open_positions}

Risk Assessment:
{{
  "market_risk": float (0 to 1),
  "liquidity_risk": float (0 to 1),
  "concentration_risk": float (0 to 1),
  "leverage_risk": float (0 to 1),
  "overall_risk_score": float (0 to 1),
  "risk_mitigations": [list of actions],
  "position_adjustments": {{
    "recommended_size": float,
    "recommended_leverage": int,
    "adjusted_stops": float
  }},
  "approval_status": "approved/conditional/rejected"
}}

Prioritize capital preservation above all else.""",
                "max_tokens": 400
            },
            
            # Controller Templates (Gemma optimized)
            PromptType.CONTROLLER_COORDINATION: {
                "system": "You are the central AI coordinator. Make high-level trading decisions.",
                "template": """Coordinate trading decision for current market cycle:

System Status:
{system_status}

Module Outputs:
- Scanner: {scanner_result}
- Chart: {chart_result}
- Combiner: {combiner_result}
- Verifier: {verifier_result}

Market Context:
- Active Trades: {active_trades}
- Daily Limit: {daily_trade_limit}
- Portfolio Status: {portfolio_status}

Coordination Decision:
{{
  "proceed_with_trade": boolean,
  "priority_level": "high/medium/low",
  "resource_allocation": {{
    "scanner_focus": [list of symbols],
    "analysis_depth": "deep/standard/quick"
  }},
  "risk_override": boolean,
  "reasoning": "coordination logic",
  "next_actions": [list of actions]
}}

Balance opportunity with system capacity.""",
                "max_tokens": 250
            }
        }
    
    def get_prompt(self, prompt_type: PromptType, **kwargs) -> Dict[str, str]:
        """Get formatted prompt for a specific type."""
        if prompt_type not in self.templates:
            raise ValueError(f"Unknown prompt type: {prompt_type}")
        
        template_data = self.templates[prompt_type]
        
        try:
            formatted_prompt = template_data["template"].format(**kwargs)
            
            return {
                "system": template_data["system"],
                "prompt": formatted_prompt,
                "max_tokens": template_data.get("max_tokens", 300)
            }
        except KeyError as e:
            raise ValueError(f"Missing required parameter for {prompt_type}: {e}")
    
    def get_coin_scanner_sentiment_prompt(self, symbol: str, social_data: List[str], 
                                        price: float, volume: float, price_change_24h: float) -> Dict[str, str]:
        """Get optimized sentiment analysis prompt for coin scanner."""
        # Limit social data to prevent token overflow
        limited_social_data = social_data[:10] if social_data else ["No social data available"]
        social_text = "\n".join([f"- {text[:100]}..." if len(text) > 100 else f"- {text}" 
                                for text in limited_social_data])
        
        return self.get_prompt(
            PromptType.COIN_SCANNER_SENTIMENT,
            symbol=symbol,
            social_data=social_text,
            price=price,
            volume=volume,
            price_change_24h=price_change_24h
        )
    
    def get_chart_checker_technical_prompt(self, symbol: str, timeframe_data: Dict[str, Any],
                                         rsi: float, macd_signal: str, bb_position: str,
                                         support: float, resistance: float) -> Dict[str, str]:
        """Get technical analysis prompt for chart checker."""
        # Summarize timeframe data to prevent token overflow
        tf_summary = {}
        for tf, data in timeframe_data.items():
            tf_summary[tf] = {
                "trend": data.get("trend", "neutral"),
                "confidence": data.get("confidence", 0.5)
            }
        
        return self.get_prompt(
            PromptType.CHART_CHECKER_TECHNICAL,
            symbol=symbol,
            timeframe_data=json.dumps(tf_summary, indent=2),
            rsi=rsi,
            macd_signal=macd_signal,
            bb_position=bb_position,
            support=support,
            resistance=resistance
        )
    
    def get_combiner_decision_prompt(self, symbol: str, scanner_data: Dict[str, Any],
                                   chart_data: Dict[str, Any], current_price: float,
                                   market_hours: bool, volatility: float,
                                   max_position_size: float, min_risk_reward: float) -> Dict[str, str]:
        """Get trading decision prompt for combiner."""
        # Summarize data to prevent token overflow
        scanner_summary = {
            "confidence": scanner_data.get("confidence", 0),
            "sentiment": scanner_data.get("sentiment_score", 0),
            "volume_anomaly": scanner_data.get("volume_anomaly", 1)
        }
        
        chart_summary = {
            "overall_bias": chart_data.get("overall_bias", "neutral"),
            "confidence": chart_data.get("overall_confidence", 0)
        }
        
        return self.get_prompt(
            PromptType.COMBINER_DECISION,
            symbol=symbol,
            scanner_data=json.dumps(scanner_summary, indent=2),
            chart_data=json.dumps(chart_summary, indent=2),
            current_price=current_price,
            market_hours=market_hours,
            volatility=volatility,
            max_position_size=max_position_size,
            min_risk_reward=min_risk_reward
        )
    
    def get_verifier_validation_prompt(self, symbol: str, trade_decision: Dict[str, Any],
                                     liquidity_score: float, spread_percentage: float,
                                     market_hours: bool, volatility_index: float,
                                     risk_factors: List[str]) -> Dict[str, str]:
        """Get trade validation prompt for verifier."""
        # Summarize trade decision
        trade_summary = {
            "decision": trade_decision.get("decision", "hold"),
            "position_size": trade_decision.get("position_size", 0),
            "confidence": trade_decision.get("confidence", 0),
            "risk_reward_ratio": trade_decision.get("risk_reward_ratio", 0)
        }
        
        risk_text = "\n".join([f"- {risk}" for risk in risk_factors[:5]])  # Limit to 5 risks
        
        return self.get_prompt(
            PromptType.VERIFIER_VALIDATION,
            symbol=symbol,
            trade_decision=json.dumps(trade_summary, indent=2),
            liquidity_score=liquidity_score,
            spread_percentage=spread_percentage,
            market_hours=market_hours,
            volatility_index=volatility_index,
            risk_factors=risk_text
        )
    
    def get_controller_coordination_prompt(self, system_status: Dict[str, Any],
                                         scanner_result: Optional[Dict[str, Any]],
                                         chart_result: Optional[Dict[str, Any]],
                                         combiner_result: Optional[Dict[str, Any]],
                                         verifier_result: Optional[Dict[str, Any]],
                                         active_trades: int, daily_trade_limit: int,
                                         portfolio_status: Dict[str, Any]) -> Dict[str, str]:
        """Get coordination prompt for AI controller."""
        # Summarize all results
        results_summary = {
            "scanner": "completed" if scanner_result else "pending",
            "chart": "completed" if chart_result else "pending",
            "combiner": "completed" if combiner_result else "pending",
            "verifier": "completed" if verifier_result else "pending"
        }
        
        return self.get_prompt(
            PromptType.CONTROLLER_COORDINATION,
            system_status=json.dumps(system_status, indent=2),
            scanner_result=json.dumps(results_summary),
            chart_result=json.dumps(results_summary),
            combiner_result=json.dumps(results_summary),
            verifier_result=json.dumps(results_summary),
            active_trades=active_trades,
            daily_trade_limit=daily_trade_limit,
            portfolio_status=json.dumps(portfolio_status, indent=2)
        )
    
    def estimate_tokens(self, prompt_text: str) -> int:
        """Estimate token count for a prompt (rough approximation)."""
        # Rough estimation: 1 token ≈ 0.75 words
        word_count = len(prompt_text.split())
        return int(word_count * 1.33)
    
    def optimize_prompt_length(self, prompt_text: str, max_tokens: int = 300) -> str:
        """Optimize prompt length to stay under token limit."""
        estimated_tokens = self.estimate_tokens(prompt_text)
        
        if estimated_tokens <= max_tokens:
            return prompt_text
        
        # Calculate reduction ratio
        reduction_ratio = max_tokens / estimated_tokens
        
        # Split into lines and reduce content
        lines = prompt_text.split('\n')
        optimized_lines = []
        
        for line in lines:
            if line.strip():
                # Keep important structural lines
                if any(keyword in line.lower() for keyword in ['json', 'response:', 'analysis:', 'provide']):
                    optimized_lines.append(line)
                else:
                    # Reduce content of other lines
                    words = line.split()
                    target_words = int(len(words) * reduction_ratio)
                    if target_words > 0:
                        optimized_lines.append(' '.join(words[:target_words]))
            else:
                optimized_lines.append(line)
        
        optimized_prompt = '\n'.join(optimized_lines)
        
        # Add truncation notice if significantly reduced
        if len(optimized_prompt) < len(prompt_text) * 0.8:
            optimized_prompt += "\n\n[Prompt optimized for length - focus on key requirements]"
        
        return optimized_prompt

# Global prompt templates instance
prompt_templates = PromptTemplates()

# Alias for backward compatibility
AIPromptTemplates = PromptTemplates