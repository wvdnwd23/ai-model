"""
OpenRouter API Client - Unified interface for accessing multiple AI models.
Provides model-specific routing, prompt optimization, and comprehensive error handling.
Implements three-tier fallback: OpenRouter → Gemma Local → Traditional algorithms.
"""

import asyncio
import json
import time
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Union, Callable
from dataclasses import dataclass, asdict
from enum import Enum
import statistics

import requests
import aiohttp
from ollama import Client

from src.utils.config import config_manager
from src.utils.logging import get_logger, get_performance_logger, TimedOperation

class ModelType(Enum):
    """Available OpenRouter model types."""
    GEMMA_2_2B_IT = "google/gemma-2-2b-it"
    GPT_4O = "openai/gpt-4o"
    CLAUDE_3_5_SONNET = "anthropic/claude-3.5-sonnet"
    GEMMA_LOCAL = "gemma2:2b"  # Local Gemma fallback

class TaskType(Enum):
    """Task types for model selection."""
    MARKET_SCANNING = "market_scanning"
    TECHNICAL_ANALYSIS = "technical_analysis"
    DATA_SYNTHESIS = "data_synthesis"
    EXECUTION_VALIDATION = "execution_validation"
    GENERAL_COORDINATION = "general_coordination"

@dataclass
class ModelConfig:
    """Configuration for a specific model."""
    model_id: str
    max_tokens: int
    temperature: float
    timeout: int
    cost_per_1k_tokens: float
    rate_limit_rpm: int
    specialization: str

@dataclass
class APIResponse:
    """Standardized API response format."""
    success: bool
    content: str
    model_used: str
    tokens_used: int
    response_time: float
    cost: float
    error_message: Optional[str] = None
    fallback_used: bool = False

@dataclass
class CacheEntry:
    """Cache entry for API responses."""
    response: APIResponse
    timestamp: datetime
    prompt_hash: str

class OpenRouterClient:
    """Main OpenRouter API client with intelligent model routing and fallback."""
    
    def __init__(self):
        self.logger = get_logger("openrouter_client")
        self.perf_logger = get_performance_logger("openrouter_client")
        
        # Model configurations
        self.model_configs = {
            ModelType.GEMMA_2_2B_IT: ModelConfig(
                model_id="google/gemma-2-2b-it",
                max_tokens=2048,
                temperature=0.3,
                timeout=30,
                cost_per_1k_tokens=0.0001,
                rate_limit_rpm=60,
                specialization="Fast market scanning and sentiment analysis"
            ),
            ModelType.GPT_4O: ModelConfig(
                model_id="openai/gpt-4o",
                max_tokens=2048,
                temperature=0.2,
                timeout=45,
                cost_per_1k_tokens=0.005,
                rate_limit_rpm=30,
                specialization="Advanced technical analysis and pattern recognition"
            ),
            ModelType.CLAUDE_3_5_SONNET: ModelConfig(
                model_id="anthropic/claude-3.5-sonnet",
                max_tokens=2048,
                temperature=0.1,
                timeout=30,
                cost_per_1k_tokens=0.003,
                rate_limit_rpm=20,
                specialization="High-reliability execution decisions and risk assessment"
            ),
            ModelType.GEMMA_LOCAL: ModelConfig(
                model_id="gemma2:2b",
                max_tokens=2048,
                temperature=0.3,
                timeout=30,
                cost_per_1k_tokens=0.0,
                rate_limit_rpm=150,
                specialization="Fast local Gemma model for all tasks"
            )
        }
        
        # Task to model mapping
        self.task_model_mapping = {
            TaskType.MARKET_SCANNING: [ModelType.GEMMA_2_2B_IT, ModelType.GEMMA_LOCAL],
            TaskType.TECHNICAL_ANALYSIS: [ModelType.GPT_4O, ModelType.GEMMA_LOCAL],
            TaskType.DATA_SYNTHESIS: [ModelType.GPT_4O, ModelType.GEMMA_LOCAL],
            TaskType.EXECUTION_VALIDATION: [ModelType.CLAUDE_3_5_SONNET, ModelType.GEMMA_LOCAL],
            TaskType.GENERAL_COORDINATION: [ModelType.GEMMA_LOCAL]
        }
        
        # API configuration
        self.openrouter_api_key = config_manager.get_openrouter_api_key()
        self.openrouter_base_url = "https://openrouter.ai/api/v1"
        
        # Local Ollama client for fallback
        self.ollama_client = Client(host=config_manager.get_ollama_url())
        
        # Response cache
        self.response_cache: Dict[str, CacheEntry] = {}
        self.cache_ttl = timedelta(minutes=5)
        
        # Rate limiting
        self.rate_limits: Dict[ModelType, List[datetime]] = {
            model: [] for model in ModelType
        }
        
        # Performance tracking
        self.performance_stats = {
            "total_requests": 0,
            "successful_requests": 0,
            "fallback_requests": 0,
            "total_cost": 0.0,
            "average_response_time": 0.0,
            "model_usage": {model.value: 0 for model in ModelType}
        }
        
        self.logger.system("OpenRouter client initialized", {
            "models_configured": len(self.model_configs),
            "api_key_configured": bool(self.openrouter_api_key)
        })
    
    async def generate_response(self, prompt: str, task_type: TaskType, 
                              context: Optional[Dict[str, Any]] = None,
                              force_model: Optional[ModelType] = None) -> APIResponse:
        """Generate AI response with intelligent model selection and fallback."""
        try:
            with TimedOperation(self.perf_logger, "ai_generation", {"task_type": task_type.value}):
                # Check cache first
                cache_key = self._generate_cache_key(prompt, task_type, context)
                cached_response = self._get_cached_response(cache_key)
                if cached_response:
                    self.logger.debug("Using cached response", {"cache_key": cache_key[:16]})
                    return cached_response
                
                # Select model
                selected_models = self._select_models(task_type, force_model)
                
                # Optimize prompt for the task
                optimized_prompt = self._optimize_prompt(prompt, task_type, context)
                
                # Try models in order with fallback
                for i, model_type in enumerate(selected_models):
                    try:
                        # Check rate limits
                        if not self._check_rate_limit(model_type):
                            self.logger.warning(f"Rate limit exceeded for {model_type.value}")
                            continue
                        
                        # Generate response
                        response = await self._call_model(model_type, optimized_prompt, context)
                        
                        if response.success:
                            # Cache successful response
                            self._cache_response(cache_key, response)
                            
                            # Update performance stats
                            self._update_performance_stats(response, model_type, fallback_used=(i > 0))
                            
                            self.logger.decision("AI response generated", {
                                "model": model_type.value,
                                "task_type": task_type.value,
                                "tokens": response.tokens_used,
                                "cost": response.cost,
                                "fallback_used": i > 0
                            })
                            
                            return response
                        
                    except Exception as e:
                        self.logger.error(f"Error with model {model_type.value}: {e}")
                        continue
                
                # All models failed
                return APIResponse(
                    success=False,
                    content="",
                    model_used="none",
                    tokens_used=0,
                    response_time=0.0,
                    cost=0.0,
                    error_message="All models failed to respond",
                    fallback_used=True
                )
                
        except Exception as e:
            self.logger.error(f"Error in generate_response: {e}")
            return APIResponse(
                success=False,
                content="",
                model_used="error",
                tokens_used=0,
                response_time=0.0,
                cost=0.0,
                error_message=str(e),
                fallback_used=False
            )
    
    async def _call_model(self, model_type: ModelType, prompt: str, 
                         context: Optional[Dict[str, Any]] = None) -> APIResponse:
        """Call a specific model."""
        start_time = time.time()
        
        try:
            if model_type == ModelType.GEMMA_LOCAL:
                # Use local Ollama
                response = await self._call_ollama(prompt, context)
            else:
                # Use OpenRouter API
                response = await self._call_openrouter(model_type, prompt, context)
            
            response.response_time = time.time() - start_time
            return response
            
        except Exception as e:
            return APIResponse(
                success=False,
                content="",
                model_used=model_type.value,
                tokens_used=0,
                response_time=time.time() - start_time,
                cost=0.0,
                error_message=str(e),
                fallback_used=False
            )
    
    async def _call_openrouter(self, model_type: ModelType, prompt: str,
                              context: Optional[Dict[str, Any]] = None) -> APIResponse:
        """Call OpenRouter API."""
        if not self.openrouter_api_key:
            raise ValueError("OpenRouter API key not configured")
        
        config = self.model_configs[model_type]
        
        headers = {
            "Authorization": f"Bearer {self.openrouter_api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://ai-crypto-trader.local",
            "X-Title": "AI Crypto Trader"
        }
        
        # Prepare messages
        messages = [{"role": "user", "content": prompt}]
        
        # Add context if provided
        if context:
            system_message = self._build_system_message(context)
            messages.insert(0, {"role": "system", "content": system_message})
        
        payload = {
            "model": config.model_id,
            "messages": messages,
            "max_tokens": config.max_tokens,
            "temperature": config.temperature,
            "stream": False
        }
        
        async with aiohttp.ClientSession() as session:
            async with session.post(
                f"{self.openrouter_base_url}/chat/completions",
                headers=headers,
                json=payload,
                timeout=aiohttp.ClientTimeout(total=config.timeout)
            ) as response:
                
                if response.status != 200:
                    error_text = await response.text()
                    raise Exception(f"OpenRouter API error {response.status}: {error_text}")
                
                data = await response.json()
                
                # Extract response content
                content = data["choices"][0]["message"]["content"]
                tokens_used = data.get("usage", {}).get("total_tokens", 0)
                cost = tokens_used * config.cost_per_1k_tokens / 1000
                
                return APIResponse(
                    success=True,
                    content=content,
                    model_used=model_type.value,
                    tokens_used=tokens_used,
                    response_time=0.0,  # Will be set by caller
                    cost=cost,
                    fallback_used=False
                )
    
    async def _call_ollama(self, prompt: str, context: Optional[Dict[str, Any]] = None) -> APIResponse:
        """Call local Ollama instance."""
        try:
            config = self.model_configs[ModelType.GEMMA_LOCAL]
            
            # Prepare messages
            messages = [{"role": "user", "content": prompt}]
            
            if context:
                system_message = self._build_system_message(context)
                messages.insert(0, {"role": "system", "content": system_message})
            
            # Call Ollama
            response = self.ollama_client.chat(
                model=config.model_id,
                messages=messages,
                options={
                    "temperature": config.temperature,
                    "num_predict": config.max_tokens
                }
            )
            
            content = response["message"]["content"]
            
            # Estimate tokens (rough approximation)
            tokens_used = len(content.split()) * 1.3  # Approximate token count
            
            return APIResponse(
                success=True,
                content=content,
                model_used=ModelType.GEMMA_LOCAL.value,
                tokens_used=int(tokens_used),
                response_time=0.0,  # Will be set by caller
                cost=0.0,  # Local model is free
                fallback_used=False
            )
            
        except Exception as e:
            raise Exception(f"Ollama error: {str(e)}")
    
    def _select_models(self, task_type: TaskType, force_model: Optional[ModelType] = None) -> List[ModelType]:
        """Select models for a task with fallback order."""
        if force_model:
            return [force_model, ModelType.GEMMA_LOCAL]
        
        return self.task_model_mapping.get(task_type, [ModelType.GEMMA_LOCAL])
    
    def _optimize_prompt(self, prompt: str, task_type: TaskType, 
                        context: Optional[Dict[str, Any]] = None) -> str:
        """Optimize prompt for specific task type and model."""
        # Add task-specific instructions
        task_instructions = {
            TaskType.MARKET_SCANNING: "Focus on speed and efficiency. Provide concise analysis.",
            TaskType.TECHNICAL_ANALYSIS: "Provide detailed technical analysis with specific indicators.",
            TaskType.DATA_SYNTHESIS: "Synthesize information comprehensively and identify key insights.",
            TaskType.EXECUTION_VALIDATION: "Be conservative and thorough. Focus on risk assessment.",
            TaskType.GENERAL_COORDINATION: "Provide balanced coordination and decision-making."
        }
        
        instruction = task_instructions.get(task_type, "")
        
        if instruction:
            optimized_prompt = f"{instruction}\n\n{prompt}"
        else:
            optimized_prompt = prompt
        
        # Ensure prompt is under token limit (rough estimation)
        max_prompt_tokens = 2000  # Conservative limit
        words = optimized_prompt.split()
        if len(words) > max_prompt_tokens * 0.75:  # Rough word-to-token ratio
            # Truncate prompt
            truncated_words = words[:int(max_prompt_tokens * 0.75)]
            optimized_prompt = " ".join(truncated_words) + "\n\n[Prompt truncated for length]"
            self.logger.warning("Prompt truncated due to length", {"original_words": len(words)})
        
        return optimized_prompt
    
    def _build_system_message(self, context: Dict[str, Any]) -> str:
        """Build system message from context."""
        system_parts = []
        
        if context.get("role"):
            system_parts.append(f"You are {context['role']}.")
        
        if context.get("constraints"):
            system_parts.append(f"Constraints: {context['constraints']}")
        
        if context.get("output_format"):
            system_parts.append(f"Output format: {context['output_format']}")
        
        if context.get("market_data"):
            system_parts.append("Current market context provided in user message.")
        
        return " ".join(system_parts) if system_parts else "You are an AI assistant for cryptocurrency trading analysis."
    
    def _check_rate_limit(self, model_type: ModelType) -> bool:
        """Check if model is within rate limits."""
        now = datetime.now()
        config = self.model_configs[model_type]
        
        # Clean old requests
        cutoff = now - timedelta(minutes=1)
        self.rate_limits[model_type] = [
            req_time for req_time in self.rate_limits[model_type] 
            if req_time > cutoff
        ]
        
        # Check current rate
        if len(self.rate_limits[model_type]) >= config.rate_limit_rpm:
            return False
        
        # Add current request
        self.rate_limits[model_type].append(now)
        return True
    
    def _generate_cache_key(self, prompt: str, task_type: TaskType, 
                           context: Optional[Dict[str, Any]] = None) -> str:
        """Generate cache key for prompt."""
        import hashlib
        
        cache_data = {
            "prompt": prompt,
            "task_type": task_type.value,
            "context": context or {}
        }
        
        cache_string = json.dumps(cache_data, sort_keys=True)
        return hashlib.md5(cache_string.encode()).hexdigest()
    
    def _get_cached_response(self, cache_key: str) -> Optional[APIResponse]:
        """Get cached response if valid."""
        if cache_key not in self.response_cache:
            return None
        
        entry = self.response_cache[cache_key]
        
        # Check if cache is still valid
        if datetime.now() - entry.timestamp > self.cache_ttl:
            del self.response_cache[cache_key]
            return None
        
        return entry.response
    
    def _cache_response(self, cache_key: str, response: APIResponse):
        """Cache successful response."""
        self.response_cache[cache_key] = CacheEntry(
            response=response,
            timestamp=datetime.now(),
            prompt_hash=cache_key
        )
        
        # Limit cache size
        if len(self.response_cache) > 100:
            # Remove oldest entries
            oldest_keys = sorted(
                self.response_cache.keys(),
                key=lambda k: self.response_cache[k].timestamp
            )[:20]
            
            for key in oldest_keys:
                del self.response_cache[key]
    
    def _update_performance_stats(self, response: APIResponse, model_type: ModelType, fallback_used: bool):
        """Update performance statistics."""
        self.performance_stats["total_requests"] += 1
        
        if response.success:
            self.performance_stats["successful_requests"] += 1
        
        if fallback_used:
            self.performance_stats["fallback_requests"] += 1
        
        self.performance_stats["total_cost"] += response.cost
        self.performance_stats["model_usage"][model_type.value] += 1
        
        # Update average response time
        current_avg = self.performance_stats["average_response_time"]
        total_requests = self.performance_stats["total_requests"]
        
        self.performance_stats["average_response_time"] = (
            (current_avg * (total_requests - 1) + response.response_time) / total_requests
        )
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """Get current performance statistics."""
        stats = self.performance_stats.copy()
        
        # Calculate success rate
        if stats["total_requests"] > 0:
            stats["success_rate"] = stats["successful_requests"] / stats["total_requests"]
            stats["fallback_rate"] = stats["fallback_requests"] / stats["total_requests"]
        else:
            stats["success_rate"] = 0.0
            stats["fallback_rate"] = 0.0
        
        # Add cache stats
        stats["cache_size"] = len(self.response_cache)
        
        return stats
    
    def clear_cache(self):
        """Clear response cache."""
        self.response_cache.clear()
        self.logger.system("Response cache cleared")
    
    def get_model_info(self, model_type: ModelType) -> Dict[str, Any]:
        """Get information about a specific model."""
        if model_type not in self.model_configs:
            return {}
        
        config = self.model_configs[model_type]
        return {
            "model_id": config.model_id,
            "specialization": config.specialization,
            "max_tokens": config.max_tokens,
            "cost_per_1k_tokens": config.cost_per_1k_tokens,
            "rate_limit_rpm": config.rate_limit_rpm,
            "usage_count": self.performance_stats["model_usage"].get(model_type.value, 0)
        }
    
    async def health_check(self) -> Dict[str, Any]:
        """Perform health check on all models."""
        health_status = {}
        
        for model_type in ModelType:
            try:
                if model_type == ModelType.GEMMA_LOCAL:
                    # Test Ollama
                    response = await self._call_ollama("Test prompt", None)
                    health_status[model_type.value] = {
                        "status": "healthy" if response.success else "unhealthy",
                        "response_time": response.response_time,
                        "error": response.error_message
                    }
                else:
                    # Test OpenRouter models with a simple prompt
                    if self.openrouter_api_key:
                        response = await self._call_openrouter(model_type, "Hello", None)
                        health_status[model_type.value] = {
                            "status": "healthy" if response.success else "unhealthy",
                            "response_time": response.response_time,
                            "error": response.error_message
                        }
                    else:
                        health_status[model_type.value] = {
                            "status": "unavailable",
                            "error": "API key not configured"
                        }
                        
            except Exception as e:
                health_status[model_type.value] = {
                    "status": "error",
                    "error": str(e)
                }
        
        return health_status
    
    def get_model_for_task(self, task_type: TaskType) -> ModelType:
        """Get the preferred model for a specific task type."""
        model_mapping = {
            TaskType.MARKET_SCANNING: ModelType.GEMMA_2_2B_IT,
            TaskType.TECHNICAL_ANALYSIS: ModelType.GPT_4O,
            TaskType.DATA_SYNTHESIS: ModelType.GPT_4O,
            TaskType.EXECUTION_VALIDATION: ModelType.CLAUDE_3_5_SONNET,
            TaskType.GENERAL_COORDINATION: ModelType.GEMMA_LOCAL
        }
        return model_mapping.get(task_type, ModelType.GEMMA_LOCAL)
    
    def is_available(self) -> bool:
        """Check if OpenRouter service is available."""
        try:
            return bool(self.openrouter_api_key) and config_manager.openrouter.enabled
        except Exception:
            return False

# Global OpenRouter client instance
openrouter_client = OpenRouterClient()