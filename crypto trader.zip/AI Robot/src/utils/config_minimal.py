"""
Minimal configuration module for emergency deployment.
Bypasses all hanging operations to restore system functionality.
"""

import os

class MinimalConfig:
    """Minimal configuration manager that avoids hanging operations."""
    
    def __init__(self):
        # Set basic defaults without any I/O operations
        self.is_development_mode = True
        self.openai_api_key = os.environ.get("OPENAI_API_KEY", "sk-development-placeholder")
        self.database_path = "src/data/database/trading_system.db"
        self.monitoring_enabled = True
        self.monitoring_port = 8080
        
    def is_openai_configured(self):
        """Check if OpenAI is configured."""
        return self.openai_api_key.startswith("sk-") and self.openai_api_key != "sk-development-placeholder"
    
    def get_openai_api_key(self):
        """Get OpenAI API key."""
        return self.openai_api_key
    
    def get_database_path(self):
        """Get database path."""
        return self.database_path

# Create minimal config instance
config_manager = MinimalConfig()

# Backward compatibility
ConfigManager = MinimalConfig
get_config_manager = lambda: config_manager
reset_config_manager = lambda: None