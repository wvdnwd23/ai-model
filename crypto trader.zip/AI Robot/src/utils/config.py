"""
Configuration management utilities for the AI Crypto Trading System.
Handles settings, API keys, and environment configuration.
"""

import os
import json
import logging
from typing import Dict, Any, Optional, Union
from pathlib import Path
from dataclasses import dataclass, asdict
from dotenv import load_dotenv
import yaml

@dataclass
class OpenAIConfig:
    """OpenAI API configuration."""
    api_key: str = ""
    base_url: str = "https://api.openai.com/v1"
    model: str = "gpt-4o-mini"
    temperature: float = 0.3
    max_tokens: int = 4096
    timeout: int = 60
    max_retries: int = 3
    cost_limit_daily: float = 10.0
    cost_limit_monthly: float = 100.0
    rate_limit_requests_per_minute: int = 500
    rate_limit_tokens_per_minute: int = 200000

@dataclass
class DatabaseConfig:
    """Database configuration."""
    path: str = "src/data/database/trading_system.db"
    backup_interval: int = 3600  # seconds
    cleanup_days: int = 90
    connection_timeout: int = 30

@dataclass
class BrowserConfig:
    """Browser automation configuration."""
    headless: bool = True
    timeout: int = 30000
    retry_attempts: int = 3
    user_agent: str = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    viewport_width: int = 1920
    viewport_height: int = 1080
    session_persistence: bool = True

@dataclass
class TradingConfig:
    """Trading configuration."""
    max_position_size: float = 0.1  # 10% of portfolio
    max_leverage: int = 50
    min_risk_reward_ratio: float = 1.3
    stop_loss_percentage: float = 2.0
    take_profit_levels: int = 3
    max_daily_trades: int = 10
    emergency_stop_loss: float = 5.0  # 5% portfolio loss

@dataclass
class ExchangeConfig:
    """Exchange configuration."""
    name: str
    api_key: str = ""
    api_secret: str = ""
    testnet: bool = True
    base_url: str = ""
    rate_limit: int = 10  # requests per second

@dataclass
class TelegramConfig:
    """Telegram bot configuration."""
    bot_token: str = ""
    chat_id: str = ""
    enabled: bool = False
    notification_level: str = "high"  # low, medium, high, critical

@dataclass
class LoggingConfig:
    """Logging configuration."""
    level: str = "INFO"
    format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    file_path: str = "src/data/logs/system/app.log"
    max_file_size: int = 10485760  # 10MB
    backup_count: int = 5
    console_output: bool = True

@dataclass
class MonitoringConfig:
    """Monitoring configuration."""
    enabled: bool = True
    port: int = 8080
    host: str = "localhost"
    update_interval: int = 30
    alert_threshold_cpu: float = 80.0
    alert_threshold_memory: float = 85.0
    alert_threshold_disk: float = 90.0
    log_retention_days: int = 30
    metrics_retention_days: int = 7

class ConfigManager:
    """Manages application configuration from multiple sources."""
    
    def __init__(self, config_dir: str = "src/config"):
        self.config_dir = Path(config_dir)
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.logger = logging.getLogger(__name__)
        
        # Load environment variables
        load_dotenv()
        
        # Configuration instances
        self.openai = OpenAIConfig()
        self.database = DatabaseConfig()
        self.browser = BrowserConfig()
        self.trading = TradingConfig()
        self.telegram = TelegramConfig()
        self.logging_config = LoggingConfig()
        self.monitoring = MonitoringConfig()
        self.exchanges: Dict[str, ExchangeConfig] = {}
        
        # Development mode flag
        self.is_development_mode = False
        
        # Load configurations
        self._load_configurations()
    
    def _load_configurations(self):
        """Load configurations from files and environment variables."""
        try:
            # Load from config files
            self._load_from_files()
            
            # Override with environment variables
            self._load_from_environment()
            
            # Validate configurations
            self._validate_configurations()
            
            self.logger.info("Configuration loaded successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to load configuration: {e}")
            raise
    
    def _load_from_files(self):
        """Load configuration from JSON/YAML files."""
        config_files = {
            "openai.json": self._load_openai_config,
            "database.json": self._load_database_config,
            "browser.json": self._load_browser_config,
            "trading.json": self._load_trading_config,
            "telegram.json": self._load_telegram_config,
            "logging.json": self._load_logging_config,
            "monitoring.json": self._load_monitoring_config,
            "exchanges.json": self._load_exchanges_config
        }
        
        for filename, loader in config_files.items():
            file_path = self.config_dir / filename
            if file_path.exists():
                try:
                    with open(file_path, 'r') as f:
                        data = json.load(f)
                    loader(data)
                    self.logger.debug(f"Loaded config from {filename}")
                except Exception as e:
                    self.logger.warning(f"Failed to load {filename}: {e}")
    
    def _load_openai_config(self, data: Dict[str, Any]):
        """Load OpenAI configuration."""
        for key, value in data.items():
            if hasattr(self.openai, key):
                setattr(self.openai, key, value)
    
    def _load_database_config(self, data: Dict[str, Any]):
        """Load database configuration."""
        for key, value in data.items():
            if hasattr(self.database, key):
                setattr(self.database, key, value)
    
    def _load_browser_config(self, data: Dict[str, Any]):
        """Load browser configuration."""
        for key, value in data.items():
            if hasattr(self.browser, key):
                setattr(self.browser, key, value)
    
    def _load_trading_config(self, data: Dict[str, Any]):
        """Load trading configuration."""
        for key, value in data.items():
            if hasattr(self.trading, key):
                setattr(self.trading, key, value)
    
    def _load_telegram_config(self, data: Dict[str, Any]):
        """Load Telegram configuration."""
        for key, value in data.items():
            if hasattr(self.telegram, key):
                setattr(self.telegram, key, value)
    
    def _load_logging_config(self, data: Dict[str, Any]):
        """Load logging configuration."""
        for key, value in data.items():
            if hasattr(self.logging_config, key):
                setattr(self.logging_config, key, value)
    
    def _load_monitoring_config(self, data: Dict[str, Any]):
        """Load monitoring configuration."""
        for key, value in data.items():
            if hasattr(self.monitoring, key):
                setattr(self.monitoring, key, value)
    
    def _load_exchanges_config(self, data: Dict[str, Any]):
        """Load exchanges configuration."""
        for exchange_name, exchange_data in data.items():
            self.exchanges[exchange_name] = ExchangeConfig(
                name=exchange_name,
                **exchange_data
            )
    
    def _load_from_environment(self):
        """Load configuration from environment variables."""
        # OpenAI configuration
        self.openai.api_key = os.getenv("OPENAI_API_KEY", self.openai.api_key)
        self.openai.model = os.getenv("OPENAI_MODEL", self.openai.model)
        self.openai.temperature = float(os.getenv("OPENAI_TEMPERATURE", self.openai.temperature))
        self.openai.max_tokens = int(os.getenv("OPENAI_MAX_TOKENS", self.openai.max_tokens))
        self.openai.cost_limit_daily = float(os.getenv("OPENAI_DAILY_LIMIT", self.openai.cost_limit_daily))
        self.openai.cost_limit_monthly = float(os.getenv("OPENAI_MONTHLY_LIMIT", self.openai.cost_limit_monthly))
        
        # Database configuration
        self.database.path = os.getenv("DATABASE_PATH", self.database.path)
        
        # Trading configuration
        self.trading.max_position_size = float(os.getenv("MAX_POSITION_SIZE", self.trading.max_position_size))
        self.trading.max_leverage = int(os.getenv("MAX_LEVERAGE", self.trading.max_leverage))
        
        # Telegram configuration
        self.telegram.bot_token = os.getenv("TELEGRAM_BOT_TOKEN", self.telegram.bot_token)
        self.telegram.chat_id = os.getenv("TELEGRAM_CHAT_ID", self.telegram.chat_id)
        self.telegram.enabled = os.getenv("TELEGRAM_ENABLED", "false").lower() == "true"
        
        # Monitoring configuration
        self.monitoring.enabled = os.getenv("MONITORING_ENABLED", "true").lower() == "true"
        self.monitoring.port = int(os.getenv("MONITORING_PORT", self.monitoring.port))
        self.monitoring.host = os.getenv("MONITORING_HOST", self.monitoring.host)
        self.monitoring.update_interval = int(os.getenv("MONITORING_UPDATE_INTERVAL", self.monitoring.update_interval))
        self.monitoring.alert_threshold_cpu = float(os.getenv("MONITORING_CPU_THRESHOLD", self.monitoring.alert_threshold_cpu))
        self.monitoring.alert_threshold_memory = float(os.getenv("MONITORING_MEMORY_THRESHOLD", self.monitoring.alert_threshold_memory))
        self.monitoring.alert_threshold_disk = float(os.getenv("MONITORING_DISK_THRESHOLD", self.monitoring.alert_threshold_disk))
        self.monitoring.log_retention_days = int(os.getenv("MONITORING_LOG_RETENTION", self.monitoring.log_retention_days))
        self.monitoring.metrics_retention_days = int(os.getenv("MONITORING_METRICS_RETENTION", self.monitoring.metrics_retention_days))
        
        # Exchange API keys
        for exchange_name in ["mexc", "xt"]:
            api_key = os.getenv(f"{exchange_name.upper()}_API_KEY")
            api_secret = os.getenv(f"{exchange_name.upper()}_API_SECRET")
            testnet = os.getenv(f"{exchange_name.upper()}_TESTNET", "true").lower() == "true"
            
            if api_key and api_secret:
                if exchange_name not in self.exchanges:
                    self.exchanges[exchange_name] = ExchangeConfig(name=exchange_name)
                
                self.exchanges[exchange_name].api_key = api_key
                self.exchanges[exchange_name].api_secret = api_secret
                self.exchanges[exchange_name].testnet = testnet
    
    def _validate_configurations(self):
        """Validate configuration values with graceful degradation for development."""
        # Check if we're in development mode (invalid or placeholder API key)
        self.is_development_mode = (
            not self.openai.api_key or 
            self.openai.api_key in ["", "your_openai_api_key_here", "sk-placeholder"] or
            not self.openai.api_key.startswith("sk-")
        )
        
        # Validate OpenAI configuration with graceful degradation
        if self.is_development_mode:
            self.logger.warning("Running in development mode - OpenAI functionality will be limited")
            # Set a placeholder key that won't cause import failures
            if not self.openai.api_key or self.openai.api_key == "your_openai_api_key_here":
                self.openai.api_key = "sk-development-placeholder"
        else:
            # Only validate API key format in production mode
            if not self.openai.api_key.startswith("sk-"):
                raise ValueError("Invalid OpenAI API key format")
        
        # Validate other OpenAI parameters (always validate these)
        if not (0.0 <= self.openai.temperature <= 2.0):
            self.logger.warning(f"Invalid OpenAI temperature: {self.openai.temperature}, using default 0.3")
            self.openai.temperature = 0.3
        
        if not (0.0 <= self.openai.cost_limit_daily <= 1000.0):
            self.logger.warning(f"Invalid OpenAI daily cost limit: {self.openai.cost_limit_daily}, using default 10.0")
            self.openai.cost_limit_daily = 10.0
        
        if not (100 <= self.openai.max_tokens <= 128000):
            self.logger.warning(f"Invalid OpenAI max tokens: {self.openai.max_tokens}, using default 4096")
            self.openai.max_tokens = 4096
        
        # Validate trading configuration with graceful degradation
        if not (0.01 <= self.trading.max_position_size <= 1.0):
            self.logger.warning(f"Invalid max position size: {self.trading.max_position_size}, using default 0.05")
            self.trading.max_position_size = 0.05
        
        if not (1 <= self.trading.max_leverage <= 100):
            self.logger.warning(f"Invalid max leverage: {self.trading.max_leverage}, using default 10")
            self.trading.max_leverage = 10
        
        if self.trading.min_risk_reward_ratio < 1.0:
            self.logger.warning(f"Risk/reward ratio must be >= 1.0: {self.trading.min_risk_reward_ratio}, using default 1.3")
            self.trading.min_risk_reward_ratio = 1.3
        
        # Validate monitoring configuration
        if not (1024 <= self.monitoring.port <= 65535):
            self.logger.warning(f"Invalid monitoring port: {self.monitoring.port}, using default 8080")
            self.monitoring.port = 8080
        
        if not (10 <= self.monitoring.update_interval <= 300):
            self.logger.warning(f"Invalid monitoring update interval: {self.monitoring.update_interval}, using default 30")
            self.monitoring.update_interval = 30
    
    def save_configuration(self, config_name: str):
        """Save current configuration to file."""
        config_data = {}
        
        if config_name == "openai":
            config_data = asdict(self.openai)
        elif config_name == "database":
            config_data = asdict(self.database)
        elif config_name == "browser":
            config_data = asdict(self.browser)
        elif config_name == "trading":
            config_data = asdict(self.trading)
        elif config_name == "telegram":
            config_data = asdict(self.telegram)
        elif config_name == "logging":
            config_data = asdict(self.logging_config)
        elif config_name == "monitoring":
            config_data = asdict(self.monitoring)
        elif config_name == "exchanges":
            config_data = {name: asdict(config) for name, config in self.exchanges.items()}
        else:
            raise ValueError(f"Unknown configuration: {config_name}")
        
        file_path = self.config_dir / f"{config_name}.json"
        with open(file_path, 'w') as f:
            json.dump(config_data, f, indent=2)
        
        self.logger.info(f"Saved {config_name} configuration to {file_path}")
    
    def get_exchange_config(self, exchange_name: str) -> Optional[ExchangeConfig]:
        """Get configuration for a specific exchange."""
        return self.exchanges.get(exchange_name.lower())
    
    def add_exchange_config(self, exchange_config: ExchangeConfig):
        """Add or update exchange configuration."""
        self.exchanges[exchange_config.name.lower()] = exchange_config
    
    def get_openai_api_key(self) -> str:
        """Get OpenAI API key."""
        return self.openai.api_key
    
    def is_openai_configured(self) -> bool:
        """Check if OpenAI is properly configured."""
        return bool(self.openai.api_key and self.openai.api_key.startswith("sk-") and not self.is_development_mode)
    
    def get_database_path(self) -> Path:
        """Get database file path."""
        path = Path(self.database.path)
        path.parent.mkdir(parents=True, exist_ok=True)
        return path
    
    def get_log_path(self) -> Path:
        """Get log file path."""
        path = Path(self.logging_config.file_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        return path
    
    def is_testnet_enabled(self, exchange: str) -> bool:
        """Check if testnet is enabled for an exchange."""
        exchange_config = self.get_exchange_config(exchange)
        return exchange_config.testnet if exchange_config else True
    
    def get_all_config(self) -> Dict[str, Any]:
        """Get all configuration as dictionary."""
        return {
            "openai": asdict(self.openai),
            "database": asdict(self.database),
            "browser": asdict(self.browser),
            "trading": asdict(self.trading),
            "telegram": asdict(self.telegram),
            "logging": asdict(self.logging_config),
            "monitoring": asdict(self.monitoring),
            "exchanges": {name: asdict(config) for name, config in self.exchanges.items()}
        }
    
    def update_config(self, section: str, updates: Dict[str, Any]):
        """Update configuration section with new values."""
        if section == "openai":
            for key, value in updates.items():
                if hasattr(self.openai, key):
                    setattr(self.openai, key, value)
        elif section == "trading":
            for key, value in updates.items():
                if hasattr(self.trading, key):
                    setattr(self.trading, key, value)
        elif section == "telegram":
            for key, value in updates.items():
                if hasattr(self.telegram, key):
                    setattr(self.telegram, key, value)
        elif section == "monitoring":
            for key, value in updates.items():
                if hasattr(self.monitoring, key):
                    setattr(self.monitoring, key, value)
        else:
            raise ValueError(f"Unknown configuration section: {section}")
        
        # Validate after update
        self._validate_configurations()
        
        # Save updated configuration
        self.save_configuration(section)

def create_default_configs():
    """Create default configuration files."""
    config_dir = Path("src/config")
    config_dir.mkdir(parents=True, exist_ok=True)
    
    # Default configurations
    default_configs = {
        "openai.json": {
            "api_key": "",
            "base_url": "https://api.openai.com/v1",
            "model": "gpt-4o-mini",
            "temperature": 0.3,
            "max_tokens": 4096,
            "timeout": 60,
            "max_retries": 3,
            "cost_limit_daily": 10.0,
            "cost_limit_monthly": 100.0,
            "rate_limit_requests_per_minute": 500,
            "rate_limit_tokens_per_minute": 200000
        },
        "trading.json": {
            "max_position_size": 0.05,
            "max_leverage": 10,
            "min_risk_reward_ratio": 1.5,
            "stop_loss_percentage": 2.0,
            "take_profit_levels": 3,
            "max_daily_trades": 5,
            "emergency_stop_loss": 5.0
        },
        "browser.json": {
            "headless": True,
            "timeout": 30000,
            "retry_attempts": 3,
            "session_persistence": True
        },
        "monitoring.json": {
            "enabled": True,
            "port": 8080,
            "host": "localhost",
            "update_interval": 30,
            "alert_threshold_cpu": 80.0,
            "alert_threshold_memory": 85.0,
            "alert_threshold_disk": 90.0,
            "log_retention_days": 30,
            "metrics_retention_days": 7
        },
        "exchanges.json": {
            "mexc": {
                "name": "mexc",
                "testnet": True,
                "base_url": "https://api.mexc.com",
                "rate_limit": 10
            },
            "xt": {
                "name": "xt",
                "testnet": True,
                "base_url": "https://sapi.xt.com",
                "rate_limit": 10
            }
        }
    }
    
    for filename, config_data in default_configs.items():
        file_path = config_dir / filename
        if not file_path.exists():
            with open(file_path, 'w') as f:
                json.dump(config_data, f, indent=2)

# Global configuration manager instance
_config_manager_instance = None

def get_config_manager() -> ConfigManager:
    """Get the global configuration manager instance (lazy initialization)."""
    global _config_manager_instance
    if _config_manager_instance is None:
        _config_manager_instance = ConfigManager()
    return _config_manager_instance

def reset_config_manager():
    """Reset the global configuration manager instance (for testing)."""
    global _config_manager_instance
    _config_manager_instance = None

# Backward compatibility - create a lazy-loading proxy object
class ConfigManagerProxy:
    """Proxy object that provides backward compatibility for config_manager imports."""
    
    def __getattr__(self, name):
        return getattr(get_config_manager(), name)
    
    def __setattr__(self, name, value):
        return setattr(get_config_manager(), name, value)

# Create the backward-compatible config_manager object
config_manager = ConfigManagerProxy()