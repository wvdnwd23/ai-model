# AI Crypto Trading System - OpenRouter to OpenAI API Migration Architecture

**Version:** 1.0  
**Date:** 2025-01-29  
**Status:** ARCHITECTURAL DESIGN PHASE

---

## Executive Summary

This document outlines the comprehensive architecture for migrating the AI Crypto Trading System from OpenRouter API to direct OpenAI API integration using the `gpt-4o-mini` model. The migration eliminates all LLaMA Mini dependencies while maintaining system reliability, optimizing for Raspberry Pi 5 ARM64 architecture, and implementing robust error handling and monitoring.

## Current System Analysis

### **Existing Architecture Overview**
- **Central Coordinator**: LLaMA Mini via Ollama (AI Controller)
- **Module AI Enhancement**: OpenRouter API with multiple models:
  - Coin Scanner: `google/gemma-2-2b-it`
  - Chart Checker: `openai/gpt-4o`
  - Combiner: `openai/gpt-4o`
  - Verifier: `anthropic/claude-3.5-sonnet`
- **Fallback System**: Three-tier (OpenRouter → LLaMA Mini → Traditional algorithms)
- **API Key**: `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`

### **Components to be Replaced**
1. **OpenRouter Client** (`src/utils/openrouter_client.py`)
2. **LLaMA Mini Integration** (Ollama client references)
3. **Multi-model routing logic**
4. **OpenRouter-specific error handling**
5. **Model-specific prompt templates**

---

## New System Architecture

### **1. Unified OpenAI API Client**

```python
# New: src/utils/openai_client.py
class OpenAIClient:
    """Unified OpenAI API client for all AI operations."""
    
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.model = "gpt-4o-mini"
        self.base_url = "https://api.openai.com/v1"
        self.timeout = 30
        self.max_retries = 3
        self.rate_limiter = RateLimiter()
        
    async def chat_completion(self, messages: List[Dict], **kwargs):
        """Unified chat completion for all modules."""
        pass
```

### **2. New System Architecture Diagram**

```mermaid
graph TB
    subgraph "AI Layer - OpenAI Integration"
        OAI[OpenAI API Client]
        GPT[gpt-4o-mini Model]
        RL[Rate Limiter]
        EH[Error Handler]
        CH[Cache Handler]
    end
    
    subgraph "Trading Modules"
        AC[AI Controller]
        CS[Coin Scanner]
        CC[Chart Checker]
        CB[Combiner]
        VE[Verifier Executor]
    end
    
    subgraph "Infrastructure"
        CFG[Config Manager]
        LOG[Logging System]
        DB[Database]
        MON[Monitoring]
    end
    
    subgraph "Raspberry Pi 5 Optimizations"
        ARM[ARM64 Optimizations]
        GPIO[GPIO Integration]
        MEM[Memory Management]
        CPU[CPU Optimization]
    end
    
    AC --> OAI
    CS --> OAI
    CC --> OAI
    CB --> OAI
    VE --> OAI
    
    OAI --> GPT
    OAI --> RL
    OAI --> EH
    OAI --> CH
    
    OAI -.-> CFG
    OAI -.-> LOG
    OAI -.-> DB
    OAI -.-> MON
    
    ARM --> OAI
    GPIO --> AC
    MEM --> OAI
    CPU --> OAI
```

### **3. Configuration Architecture**

```python
@dataclass
class OpenAIConfig:
    """OpenAI API configuration."""
    api_key: str = "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"
    model: str = "gpt-4o-mini"
    base_url: str = "https://api.openai.com/v1"
    timeout: int = 30
    max_retries: int = 3
    rate_limit_rpm: int = 3500  # gpt-4o-mini limit
    rate_limit_tpm: int = 200000  # tokens per minute
    max_tokens_per_request: int = 16384
    temperature: float = 0.3
    enable_caching: bool = True
    cache_ttl_minutes: int = 5
    fallback_enabled: bool = True
    cost_tracking: bool = True
    daily_cost_limit: float = 10.0
```

---

## Error Handling & Fallback Strategy

### **1. Three-Tier Fallback System**

```mermaid
graph LR
    REQ[Request] --> OAI[OpenAI API]
    OAI -->|Success| RESP[Response]
    OAI -->|Failure| TRAD[Traditional Algorithms]
    TRAD -->|Success| RESP
    TRAD -->|Failure| ERR[Error Response]
    
    OAI -.->|Rate Limit| WAIT[Wait & Retry]
    OAI -.->|Network Error| RETRY[Exponential Backoff]
    OAI -.->|API Error| LOG[Log & Fallback]
```

### **2. Error Handling Patterns**

```python
class ErrorHandler:
    """Comprehensive error handling for OpenAI API."""
    
    async def handle_api_error(self, error: Exception, context: Dict):
        """Handle different types of API errors."""
        if isinstance(error, RateLimitError):
            return await self._handle_rate_limit(error, context)
        elif isinstance(error, APIConnectionError):
            return await self._handle_connection_error(error, context)
        elif isinstance(error, AuthenticationError):
            return await self._handle_auth_error(error, context)
        else:
            return await self._handle_generic_error(error, context)
```

### **3. Fallback Mechanisms**

| Error Type | Primary Response | Fallback Action | Recovery Strategy |
|------------|------------------|-----------------|-------------------|
| Rate Limit | Wait with exponential backoff | Use cached response | Implement request queuing |
| Network Error | Retry with backoff | Traditional algorithms | Health check & reconnect |
| Authentication | Log security alert | Disable AI features | Manual intervention required |
| Model Error | Retry with different params | Simplified processing | Gradual feature restoration |
| Timeout | Increase timeout & retry | Fast traditional method | Optimize request size |

---

## Raspberry Pi 5 ARM64 Optimizations

### **1. Memory Management**

```python
class MemoryOptimizer:
    """Memory optimization for Raspberry Pi 5."""
    
    def __init__(self):
        self.max_concurrent_requests = 2  # Pi 5 limitation
        self.request_queue = asyncio.Queue(maxsize=10)
        self.memory_threshold = 0.85  # 85% memory usage limit
        
    async def optimize_request(self, request_data: Dict) -> Dict:
        """Optimize request for Pi 5 memory constraints."""
        # Compress large data
        # Limit context window
        # Batch small requests
        pass
```

### **2. CPU Optimization**

```python
class CPUOptimizer:
    """CPU optimization strategies for ARM64."""
    
    def __init__(self):
        self.cpu_cores = 4  # Pi 5 has 4 cores
        self.thread_pool = ThreadPoolExecutor(max_workers=2)
        
    async def optimize_processing(self, task: Callable) -> Any:
        """Optimize CPU-intensive tasks."""
        # Use async/await for I/O
        # Offload CPU tasks to thread pool
        # Implement task prioritization
        pass
```

### **3. GPIO Integration Architecture**

```python
class GPIOIntegration:
    """GPIO integration for hardware monitoring."""
    
    def __init__(self):
        self.status_led = LED(18)  # System status LED
        self.error_led = LED(19)   # Error indicator LED
        self.button = Button(21)   # Emergency stop button
        
    def setup_hardware_monitoring(self):
        """Setup hardware status indicators."""
        self.button.when_pressed = self.emergency_stop
        self.status_led.blink(on_time=1, off_time=1)  # Heartbeat
```

---

## Logging and Monitoring Framework

### **1. Comprehensive Logging Strategy**

```python
class AITradingLogger:
    """Enhanced logging for OpenAI integration."""
    
    def __init__(self):
        self.loggers = {
            'api': self._setup_api_logger(),
            'performance': self._setup_performance_logger(),
            'cost': self._setup_cost_logger(),
            'security': self._setup_security_logger(),
            'system': self._setup_system_logger()
        }
        
    def log_api_request(self, request_data: Dict, response_data: Dict):
        """Log API requests with cost tracking."""
        pass
```

### **2. Rotating Log Configuration**

```python
LOG_CONFIG = {
    'api_requests': {
        'file': 'data/logs/api/openai_requests.log',
        'max_size': '50MB',
        'backup_count': 10,
        'rotation': 'daily'
    },
    'performance': {
        'file': 'data/logs/performance/system_performance.log',
        'max_size': '25MB',
        'backup_count': 7,
        'rotation': 'daily'
    },
    'cost_tracking': {
        'file': 'data/logs/cost/api_costs.log',
        'max_size': '10MB',
        'backup_count': 30,
        'rotation': 'daily'
    }
}
```

### **3. Real-time Monitoring Metrics**

| Metric Category | Specific Metrics | Alert Thresholds |
|-----------------|------------------|------------------|
| **API Performance** | Response time, success rate, error rate | >5s response, <95% success |
| **Cost Tracking** | Daily spend, token usage, request count | >$8/day, >150k tokens/hour |
| **System Health** | CPU usage, memory usage, disk space | >80% CPU, >90% memory |
| **Trading Performance** | Decision accuracy, trade success rate | <70% accuracy, <60% success |

---

## Security Framework

### **1. API Key Management**

```python
class SecureKeyManager:
    """Secure API key management."""
    
    def __init__(self):
        self.key_rotation_interval = timedelta(days=30)
        self.key_validation_interval = timedelta(hours=1)
        
    def validate_api_key(self) -> bool:
        """Validate API key is still active."""
        pass
        
    def rotate_api_key(self) -> str:
        """Rotate API key if needed."""
        pass
```

### **2. Security Monitoring**

```python
class SecurityMonitor:
    """Monitor for security threats."""
    
    def monitor_api_usage(self):
        """Monitor for unusual API usage patterns."""
        # Detect unusual request patterns
        # Monitor for potential key compromise
        # Alert on suspicious activity
        pass
```

---

## Performance Optimization Strategies

### **1. Request Optimization**

```python
class RequestOptimizer:
    """Optimize API requests for performance."""
    
    def __init__(self):
        self.token_estimator = TokenEstimator()
        self.prompt_compressor = PromptCompressor()
        
    def optimize_prompt(self, prompt: str, max_tokens: int = 1000) -> str:
        """Optimize prompt length and structure."""
        # Compress verbose prompts
        # Remove redundant information
        # Prioritize essential context
        pass
```

### **2. Caching Strategy**

```python
class IntelligentCache:
    """Intelligent caching for API responses."""
    
    def __init__(self):
        self.cache_ttl = {
            'market_analysis': 300,    # 5 minutes
            'technical_analysis': 600, # 10 minutes
            'sentiment_analysis': 180  # 3 minutes
        }
        
    async def get_cached_response(self, cache_key: str) -> Optional[Dict]:
        """Get cached response if valid."""
        pass
```

### **3. Batch Processing**

```python
class BatchProcessor:
    """Batch multiple requests for efficiency."""
    
    def __init__(self):
        self.batch_size = 5
        self.batch_timeout = 2.0  # seconds
        
    async def process_batch(self, requests: List[Dict]) -> List[Dict]:
        """Process multiple requests in batch."""
        pass
```

---

## Installation and Deployment Strategy

### **1. Automated Migration Script**

```bash
#!/bin/bash
# migrate_to_openai.sh - Automated migration script

# Backup current system
./scripts/backup_system.sh

# Install OpenAI dependencies
pip install openai==1.12.0 tiktoken==0.5.2

# Update configuration
python scripts/migrate_config.py

# Replace OpenRouter client
mv src/utils/openrouter_client.py src/utils/openrouter_client.py.backup
cp src/utils/openai_client.py src/utils/openai_client.py

# Update all module imports
python scripts/update_imports.py

# Run migration tests
python scripts/test_migration.py

# Deploy new system
systemctl restart ai-crypto-trader
```

### **2. Systemd Service Configuration**

```ini
[Unit]
Description=AI Crypto Trading System with OpenAI Integration
After=network.target
Requires=network.target

[Service]
Type=simple
User=ai-trader
Group=ai-trader
WorkingDirectory=/opt/ai-crypto-trader
Environment=OPENAI_API_KEY=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
Environment=OPENAI_MODEL=gpt-4o-mini
ExecStart=/opt/ai-crypto-trader/venv/bin/python src/main.py
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

# Security settings
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/opt/ai-crypto-trader/data

[Install]
WantedBy=multi-user.target
```

### **3. Health Check Script**

```bash
#!/bin/bash
# health_check_openai.sh - Comprehensive health check

# Check OpenAI API connectivity
curl -H "Authorization: Bearer $OPENAI_API_KEY" \
     -H "Content-Type: application/json" \
     -d '{"model":"gpt-4o-mini","messages":[{"role":"user","content":"test"}],"max_tokens":5}' \
     https://api.openai.com/v1/chat/completions

# Check system resources
python scripts/check_system_health.py

# Check trading system status
systemctl status ai-crypto-trader

# Check log files for errors
tail -n 100 /opt/ai-crypto-trader/data/logs/system/main.log | grep ERROR
```

---

## Migration Timeline and Risk Assessment

### **Migration Phases**

| Phase | Duration | Tasks | Risk Level |
|-------|----------|-------|------------|
| **Phase 1** | 2 days | Backup system, install dependencies | Low |
| **Phase 2** | 3 days | Implement OpenAI client, update configs | Medium |
| **Phase 3** | 2 days | Update all modules, remove LLaMA references | High |
| **Phase 4** | 1 day | Testing, validation, deployment | Medium |
| **Phase 5** | 1 day | Monitoring, optimization, documentation | Low |

### **Risk Mitigation Strategies**

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| API rate limiting | High | Medium | Implement intelligent rate limiting |
| Cost overrun | Medium | High | Daily cost monitoring and alerts |
| Performance degradation | Medium | Medium | Comprehensive performance testing |
| System downtime | Low | High | Blue-green deployment strategy |

---

## Cost Analysis and Optimization

### **OpenAI API Pricing (gpt-4o-mini)**
- **Input tokens**: $0.000150 per 1K tokens
- **Output tokens**: $0.000600 per 1K tokens
- **Rate limits**: 3,500 RPM, 200,000 TPM

### **Estimated Daily Costs**
- **Trading decisions**: ~50 requests/day × 2K tokens = $0.15/day
- **Market analysis**: ~200 requests/day × 1K tokens = $0.18/day
- **Technical analysis**: ~100 requests/day × 1.5K tokens = $0.14/day
- **Total estimated**: ~$0.50/day (well under $10 limit)

### **Cost Optimization Strategies**
1. **Prompt optimization**: Reduce token usage by 30%
2. **Intelligent caching**: Reduce API calls by 40%
3. **Batch processing**: Improve efficiency by 25%
4. **Context compression**: Reduce input tokens by 20%

---

## Testing and Validation Strategy

### **1. Unit Testing**

```python
class TestOpenAIClient:
    """Comprehensive unit tests for OpenAI client."""
    
    def test_api_connection(self):
        """Test basic API connectivity."""
        pass
        
    def test_error_handling(self):
        """Test error handling scenarios."""
        pass
        
    def test_rate_limiting(self):
        """Test rate limiting functionality."""
        pass
```

### **2. Integration Testing**

```python
class TestSystemIntegration:
    """Integration tests for complete system."""
    
    def test_trading_workflow(self):
        """Test complete trading workflow."""
        pass
        
    def test_fallback_mechanisms(self):
        """Test fallback to traditional algorithms."""
        pass
```

### **3. Performance Testing**

```python
class TestPerformance:
    """Performance tests for Raspberry Pi 5."""
    
    def test_concurrent_requests(self):
        """Test concurrent API requests."""
        pass
        
    def test_memory_usage(self):
        """Test memory usage under load."""
        pass
```

---

## Monitoring and Alerting

### **1. Real-time Dashboards**

```python
class OpenAIDashboard:
    """Real-time monitoring dashboard."""
    
    def __init__(self):
        self.metrics = {
            'api_requests_per_minute': 0,
            'average_response_time': 0,
            'error_rate': 0,
            'daily_cost': 0,
            'token_usage': 0
        }
```

### **2. Alert Configuration**

```yaml
alerts:
  api_errors:
    threshold: 5
    window: 5m
    action: email_admin
    
  high_costs:
    threshold: 8.0
    window: 1d
    action: disable_trading
    
  performance_degradation:
    threshold: 10s
    window: 1m
    action: restart_service
```

---

## Conclusion

This comprehensive architecture provides a robust foundation for migrating from OpenRouter to OpenAI API integration. The design prioritizes:

1. **Reliability**: Comprehensive error handling and fallback mechanisms
2. **Performance**: Optimized for Raspberry Pi 5 ARM64 architecture
3. **Cost Efficiency**: Intelligent caching and request optimization
4. **Security**: Secure API key management and monitoring
5. **Maintainability**: Clean architecture and comprehensive logging

The migration maintains all existing functionality while simplifying the AI integration layer and reducing operational complexity.

**Next Steps**: Review this architecture, approve the design, and proceed with implementation using the detailed todo list provided.