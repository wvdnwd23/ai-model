#!/usr/bin/env python3
"""
Comprehensive Raspberry Pi Deployment Verification Script
AI Crypto Trading System - End-to-End Testing and Issue Detection

This script performs complete verification of the deployed system on Raspberry Pi.
"""

import asyncio
import sys
import os
import json
import time
import subprocess
import sqlite3
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Optional
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('pi_verification.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class PiDeploymentVerifier:
    """Comprehensive Raspberry Pi deployment verification system."""
    
    def __init__(self, install_dir: str = "/opt/ai-crypto-trader"):
        self.install_dir = Path(install_dir)
        self.results = []
        self.start_time = datetime.now()
        self.critical_issues = []
        self.warnings = []
        self.performance_metrics = {}
        
    def log_result(self, test_name: str, status: str, details: str = "", duration: float = 0.0):
        """Log a verification test result."""
        result = {
            "test_name": test_name,
            "status": status,
            "details": details,
            "duration": duration,
            "timestamp": datetime.now().isoformat()
        }
        self.results.append(result)
        
        if status == "FAIL":
            self.critical_issues.append(test_name)
        elif status == "WARN":
            self.warnings.append(test_name)
        
        status_icon = {"PASS": "✅", "FAIL": "❌", "WARN": "⚠️", "SKIP": "⏭️"}.get(status, "❓")
        logger.info(f"{status_icon} {test_name}: {status}")
        if details:
            logger.info(f"   Details: {details}")
        if duration > 0:
            logger.info(f"   Duration: {duration:.2f}s")

    async def verify_system_resources(self) -> bool:
        """Verify system resources and performance."""
        logger.info("\n🔧 Verifying System Resources...")
        
        try:
            start_time = time.time()
            
            # Import psutil here to avoid dependency issues
            try:
                import psutil
            except ImportError:
                self.log_result("System Resources", "SKIP", "psutil not available")
                return True
            
            # CPU Information
            cpu_count = psutil.cpu_count()
            cpu_percent = psutil.cpu_percent(interval=1)
            
            self.performance_metrics['cpu'] = {
                'count': cpu_count,
                'usage_percent': cpu_percent
            }
            
            if cpu_percent > 80:
                self.log_result("CPU Usage", "WARN", f"High CPU usage: {cpu_percent}%")
            else:
                self.log_result("CPU Usage", "PASS", f"CPU usage normal: {cpu_percent}%")
            
            # Memory Information
            memory = psutil.virtual_memory()
            self.performance_metrics['memory'] = {
                'total_gb': memory.total / (1024**3),
                'usage_percent': memory.percent
            }
            
            if memory.percent > 85:
                self.log_result("Memory Usage", "WARN", f"High memory usage: {memory.percent}%")
            else:
                self.log_result("Memory Usage", "PASS", f"Memory usage: {memory.percent}%")
            
            # Disk Information
            disk = psutil.disk_usage('/')
            disk_percent = (disk.used / disk.total) * 100
            
            if disk_percent > 90:
                self.log_result("Disk Usage", "WARN", f"High disk usage: {disk_percent:.1f}%")
            else:
                self.log_result("Disk Usage", "PASS", f"Disk usage: {disk_percent:.1f}%")
            
            # Temperature (Raspberry Pi specific)
            try:
                with open('/sys/class/thermal/thermal_zone0/temp', 'r') as f:
                    temp_raw = int(f.read().strip())
                    temp_celsius = temp_raw / 1000
                    
                    if temp_celsius > 75:
                        self.log_result("CPU Temperature", "WARN", f"High temperature: {temp_celsius}°C")
                    else:
                        self.log_result("CPU Temperature", "PASS", f"Temperature: {temp_celsius}°C")
            except Exception:
                self.log_result("CPU Temperature", "SKIP", "Temperature monitoring not available")
            
            duration = time.time() - start_time
            self.log_result("System Resources Check", "PASS", "All system resources verified", duration)
            return True
            
        except Exception as e:
            self.log_result("System Resources Check", "FAIL", f"Error: {e}")
            return False

    async def verify_file_structure(self) -> bool:
        """Verify complete file structure and permissions."""
        logger.info("\n📁 Verifying File Structure...")
        
        try:
            start_time = time.time()
            
            # Required directories
            required_dirs = [
                "src", "src/utils", "src/modules", "src/monitoring",
                "src/data", "src/data/logs", "src/data/database", "venv"
            ]
            
            missing_dirs = []
            for dir_path in required_dirs:
                full_path = self.install_dir / dir_path
                if not full_path.exists():
                    missing_dirs.append(dir_path)
            
            if missing_dirs:
                self.log_result("Directory Structure", "FAIL", f"Missing directories: {missing_dirs}")
                return False
            else:
                self.log_result("Directory Structure", "PASS", f"All {len(required_dirs)} directories present")
            
            # Required files
            required_files = [
                "src/main.py", "src/__init__.py", "src/utils/config.py",
                "src/utils/database.py", "requirements.txt", ".env"
            ]
            
            missing_files = []
            for file_path in required_files:
                full_path = self.install_dir / file_path
                if not full_path.exists():
                    missing_files.append(file_path)
            
            if missing_files:
                self.log_result("File Structure", "FAIL", f"Missing files: {missing_files}")
                return False
            else:
                self.log_result("File Structure", "PASS", f"All {len(required_files)} files present")
            
            duration = time.time() - start_time
            self.log_result("File Structure Verification", "PASS", "File structure verified", duration)
            return True
            
        except Exception as e:
            self.log_result("File Structure Verification", "FAIL", f"Error: {e}")
            return False

    async def verify_virtual_environment(self) -> bool:
        """Verify virtual environment integrity and dependencies."""
        logger.info("\n🐍 Verifying Virtual Environment...")
        
        try:
            start_time = time.time()
            
            venv_path = self.install_dir / "venv"
            if not venv_path.exists():
                self.log_result("Virtual Environment", "FAIL", "Virtual environment directory not found")
                return False
            
            # Check Python executable
            python_exe = venv_path / "bin" / "python3"
            if not python_exe.exists():
                self.log_result("Python Executable", "FAIL", "Python executable not found in venv")
                return False
            
            self.log_result("Python Executable", "PASS", "Python executable found")
            
            # Test Python version
            try:
                result = subprocess.run([str(python_exe), "--version"], 
                                      capture_output=True, text=True, timeout=10)
                if result.returncode == 0:
                    python_version = result.stdout.strip()
                    self.log_result("Python Version", "PASS", python_version)
                else:
                    self.log_result("Python Version", "FAIL", "Could not get Python version")
                    return False
            except subprocess.TimeoutExpired:
                self.log_result("Python Version", "FAIL", "Python version check timed out")
                return False
            
            # Test critical package imports
            critical_packages = ["openai", "numpy", "pandas", "requests", "flask"]
            
            missing_packages = []
            for package in critical_packages:
                try:
                    result = subprocess.run([str(python_exe), "-c", f"import {package}"], 
                                          capture_output=True, text=True, timeout=10)
                    if result.returncode != 0:
                        missing_packages.append(package)
                except subprocess.TimeoutExpired:
                    missing_packages.append(f"{package} (timeout)")
            
            if missing_packages:
                self.log_result("Package Dependencies", "FAIL", f"Missing packages: {missing_packages}")
                return False
            else:
                self.log_result("Package Dependencies", "PASS", f"All {len(critical_packages)} critical packages available")
            
            duration = time.time() - start_time
            self.log_result("Virtual Environment Verification", "PASS", "Virtual environment verified", duration)
            return True
            
        except Exception as e:
            self.log_result("Virtual Environment Verification", "FAIL", f"Error: {e}")
            return False

    async def verify_configuration_system(self) -> bool:
        """Verify configuration system."""
        logger.info("\n⚙️ Verifying Configuration System...")
        
        try:
            start_time = time.time()
            
            # Test environment file
            env_file = self.install_dir / ".env"
            if not env_file.exists():
                self.log_result("Environment File", "FAIL", ".env file not found")
                return False
            
            # Check for required environment variables
            required_env_vars = ["OPENAI_API_KEY", "DATABASE_PATH"]
            
            missing_vars = []
            with open(env_file, 'r') as f:
                env_content = f.read()
                for var in required_env_vars:
                    if f"{var}=" not in env_content:
                        missing_vars.append(var)
            
            if missing_vars:
                self.log_result("Environment Variables", "WARN", f"Missing variables: {missing_vars}")
            else:
                self.log_result("Environment Variables", "PASS", "All required variables present")
            
            # Test configuration module import
            try:
                sys.path.insert(0, str(self.install_dir / "src"))
                from utils.config import config_manager
                self.log_result("Config Module Import", "PASS", "Configuration module imported successfully")
            except ImportError as e:
                self.log_result("Config Module Import", "FAIL", f"Import error: {e}")
                return False
            
            duration = time.time() - start_time
            self.log_result("Configuration System Verification", "PASS", "Configuration system verified", duration)
            return True
            
        except Exception as e:
            self.log_result("Configuration System Verification", "FAIL", f"Error: {e}")
            return False

    async def verify_database_connectivity(self) -> bool:
        """Verify database connectivity and initialization."""
        logger.info("\n🗄️ Verifying Database Connectivity...")
        
        try:
            start_time = time.time()
            
            # Check database file
            db_path = self.install_dir / "src" / "data" / "database" / "trading_system.db"
            if not db_path.exists():
                self.log_result("Database File", "WARN", "Database file not found - will be created on first run")
            else:
                self.log_result("Database File", "PASS", "Database file exists")
                
                # Test database connection
                try:
                    conn = sqlite3.connect(str(db_path), timeout=5)
                    cursor = conn.cursor()
                    
                    # Test basic query
                    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
                    tables = cursor.fetchall()
                    
                    if len(tables) >= 3:
                        self.log_result("Database Tables", "PASS", f"Found {len(tables)} tables")
                    else:
                        self.log_result("Database Tables", "WARN", f"Only {len(tables)} tables found")
                    
                    conn.close()
                    
                except sqlite3.Error as e:
                    self.log_result("Database Connection", "FAIL", f"SQLite error: {e}")
                    return False
            
            # Test database module
            try:
                sys.path.insert(0, str(self.install_dir / "src"))
                from utils.database import db_manager
                
                # Test connection through database manager
                connection = db_manager.get_connection()
                if connection:
                    self.log_result("Database Manager", "PASS", "Database manager connection successful")
                    connection.close()
                else:
                    self.log_result("Database Manager", "FAIL", "Database manager connection failed")
                    return False
                    
            except ImportError as e:
                self.log_result("Database Module", "FAIL", f"Import error: {e}")
                return False
            
            duration = time.time() - start_time
            self.log_result("Database Connectivity Verification", "PASS", "Database connectivity verified", duration)
            return True
            
        except Exception as e:
            self.log_result("Database Connectivity Verification", "FAIL", f"Error: {e}")
            return False

    async def verify_ai_client_connections(self) -> bool:
        """Verify AI client connections."""
        logger.info("\n🤖 Verifying AI Client Connections...")
        
        try:
            start_time = time.time()
            
            sys.path.insert(0, str(self.install_dir / "src"))
            
            # Test OpenAI client
            try:
                from utils.openai_client import OpenAIClient
                
                # Check if API key is configured
                env_file = self.install_dir / ".env"
                with open(env_file, 'r') as f:
                    env_content = f.read()
                    if "OPENAI_API_KEY=" in env_content and "your_openai_api_key_here" not in env_content:
                        self.log_result("OpenAI API Key", "PASS", "API key configured")
                        
                        # Test client instantiation
                        client = OpenAIClient()
                        self.log_result("OpenAI Client", "PASS", "Client instantiated successfully")
                        
                    else:
                        self.log_result("OpenAI API Key", "WARN", "API key not configured or using placeholder")
                        
            except ImportError as e:
                self.log_result("OpenAI Client", "FAIL", f"Import error: {e}")
            
            duration = time.time() - start_time
            self.log_result("AI Client Connections Verification", "PASS", "AI client connections verified", duration)
            return True
            
        except Exception as e:
            self.log_result("AI Client Connections Verification", "FAIL", f"Error: {e}")
            return False

    async def verify_module_imports(self) -> bool:
        """Test all module imports systematically."""
        logger.info("\n📦 Verifying Module Imports...")
        
        try:
            start_time = time.time()
            
            sys.path.insert(0, str(self.install_dir / "src"))
            
            # Core modules
            core_modules = ["utils", "utils.config", "utils.database", "utils.logging"]
            
            # AI modules
            ai_modules = ["modules.ai_controller.controller", "modules.coin_scanner.scanner"]
            
            # Monitoring modules
            monitoring_modules = ["monitoring.system_monitor", "monitoring.health_checker"]
            
            all_modules = core_modules + ai_modules + monitoring_modules
            failed_imports = []
            successful_imports = []
            
            for module in all_modules:
                try:
                    __import__(module)
                    successful_imports.append(module)
                    self.log_result(f"Import: {module}", "PASS", "Module imported successfully")
                except ImportError as e:
                    failed_imports.append(f"{module}: {e}")
                    self.log_result(f"Import: {module}", "FAIL", f"Import error: {e}")
                except Exception as e:
                    failed_imports.append(f"{module}: {e}")
                    self.log_result(f"Import: {module}", "FAIL", f"Error: {e}")
            
            success_rate = len(successful_imports) / len(all_modules) * 100
            
            if len(failed_imports) == 0:
                self.log_result("Module Imports", "PASS", f"All {len(all_modules)} modules imported successfully")
            elif success_rate >= 80:
                self.log_result("Module Imports", "WARN", f"{success_rate:.1f}% success rate, {len(failed_imports)} failures")
            else:
                self.log_result("Module Imports", "FAIL", f"Only {success_rate:.1f}% success rate")
                return False
            
            duration = time.time() - start_time
            self.log_result("Module Import Verification", "PASS", "Module imports verified", duration)
            return True
            
        except Exception as e:
            self.log_result("Module Import Verification", "FAIL", f"Error: {e}")
            return False

    def generate_diagnostic_report(self) -> Dict[str, Any]:
        """Generate comprehensive diagnostic report."""
        logger.info("\n📋 Generating Diagnostic Report...")
        
        total_tests = len(self.results)
        passed_tests = len([r for r in self.results if r["status"] == "PASS"])
        failed_tests = len([r for r in self.results if r["status"] == "FAIL"])
        warning_tests = len([r for r in self.results if r["status"] == "WARN"])
        skipped_tests = len([r for r in self.results if r["status"] == "SKIP"])
        
        total_duration = (datetime.now() - self.start_time).total_seconds()
        success_rate = (passed_tests / total_tests * 100) if total_tests > 0 else 0
        
        # Determine overall status
        if failed_tests == 0 and len(self.critical_issues) == 0:
            overall_status = "HEALTHY"
        elif failed_tests <= 2 and len(self.critical_issues) == 0:
            overall_status = "WARNING"
        else:
            overall_status = "CRITICAL"
        
        # Generate recommendations
        recommendations = []
        
        if len(self.critical_issues) > 0:
            recommendations.append(f"Address {len(self.critical_issues)} critical issues before deployment")
        
        if warning_tests > 0:
            recommendations.append(f"Review {warning_tests} warning conditions")
        
        if success_rate < 90:
            recommendations.append("System requires attention before production deployment")
        elif success_rate >= 95:
            recommendations.append("System is ready for production deployment")
        else:
            recommendations.append("System is mostly ready but monitor closely")
        
        # Create comprehensive report
        report = {
            "verification_report": {
                "timestamp": datetime.now().isoformat(),
                "system_info": {
                    "hostname": os.uname().nodename,
                    "platform": os.uname().system,
                    "architecture": os.uname().machine,
                    "install_directory": str(self.install_dir)
                },
                "summary": {
                    "overall_status": overall_status,
                    "total_tests": total_tests,
                    "passed_tests": passed_tests,
                    "failed_tests": failed_tests,
                    "warning_tests": warning_tests,
                    "skipped_tests": skipped_tests,
                    "success_rate": round(success_rate, 2),
                    "total_duration": round(total_duration, 2),
                    "critical_issues_count": len(self.critical_issues),
                    "warnings_count": len(self.warnings)
                },
                "performance_metrics": self.performance_metrics,
                "test_results": self.results,
                "critical_issues": self.critical_issues,
                "warnings": self.warnings,
                "recommendations": recommendations
            }
        }
        
        return report

    async def run_comprehensive_verification(self) -> Dict[str, Any]:
        """Run complete comprehensive verification suite."""
        logger.info("🚀 Starting Comprehensive Raspberry Pi Deployment Verification")
        logger.info("=" * 80)
        
        # List of verification functions to run
        verification_functions = [
            ("System Resources", self.verify_system_resources),
            ("File Structure", self.verify_file_structure),
            ("Virtual Environment", self.verify_virtual_environment),
            ("Configuration System", self.verify_configuration_system),
            ("Database Connectivity", self.verify_database_connectivity),
            ("AI Client Connections", self.verify_ai_client_connections),
            ("Module Imports", self.verify_module_imports)
        ]
        
        # Run all verification functions
        for test_name, test_func in verification_functions:
            try:
                logger.info(f"\n🔍 Running {test_name} verification...")
                await test_func()
            except Exception as e:
                self.log_result(f"{test_name} Verification", "FAIL", f"Test function crashed: {e}")
        
        # Generate final report
        report = self.generate_diagnostic_report()
        
        # Save report to file
        report_file = Path("pi_verification_report.json")
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2)
        
        logger.info(f"\n📄 Comprehensive report saved to: {report_file}")
        
        return report

def print_final_summary(report: Dict[str, Any]):
    """Print final verification summary."""
    print("\n" + "=" * 80)
    print("🎯 RASPBERRY PI DEPLOYMENT VERIFICATION SUMMARY")
    print("=" * 80)
    
    summary = report["verification_report"]["summary"]
    
    print(f"Overall Status: {summary['overall_status']}")
    print(f"Total Tests: {summary['total_tests']}")
    print(f"✅ Passed: {summary['passed_tests']}")
    print(f"❌ Failed: {summary['failed_tests']}")
    print(f"⚠️ Warnings: {summary['warning_tests']}")
    print(f"⏭️ Skipped: {summary['skipped_tests']}")
    print(f"Success Rate: {summary['success_rate']}%")
    print(f"Duration: {summary['total_duration']}s")
    
    if summary['overall_status'] == "HEALTHY":
        print("\n🎉 DEPLOYMENT VERIFICATION PASSED!")
        print("✅ System is ready for production deployment")
    elif summary['overall_status'] == "WARNING":
        print("\n⚠️ DEPLOYMENT VERIFICATION COMPLETED WITH WARNINGS")
        print("🔍 System is mostly functional but requires attention")
    else:
        print("\n❌ DEPLOYMENT VERIFICATION FAILED")
        print("🚨 Critical issues detected - deployment not recommended")
    
    if summary['critical_issues_count'] > 0:
        print(f"\n🚨 Critical Issues ({summary['critical_issues_count']}):")
        for issue in report["verification_report"]["critical_issues"]:
            print(f"  - {issue}")
    
    if summary['warnings_count'] > 0:
        print(f"\n⚠️ Warnings ({summary['warnings_count']}):")
        for warning in report["verification_report"]["warnings"]:
            print(f"  - {warning}")
    
    print(f"\n📋 Recommendations:")
    for rec in report["verification_report"]["recommendations"]:
        print(f"  • {rec}")
    
    print(f"\nDetailed report: pi_verification_report.json")
    print("=" * 80)

async def main():
    """Main verification execution."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Comprehensive Raspberry Pi Deployment Verification")
    parser.add_argument("--install-dir", default="/opt/ai-crypto-trader", 
                       help="Installation directory (default: /opt/ai-crypto-trader)")
    parser.add_argument("--verbose", action="store_true", 
                       help="Enable verbose output")
    
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Initialize verifier
    verifier = PiDeploymentVerifier(install_dir=args.install_dir)
    
    try:
        # Run comprehensive verification
        report = await verifier.run_comprehensive_verification()
        
        # Print summary
        print_final_summary(report)
        
        # Exit with appropriate code
        summary = report["verification_report"]["summary"]
        if summary["overall_status"] == "HEALTHY":
            return 0
        elif summary["overall_status"] == "WARNING":
            return 1
        else:
            return 2
            
    except KeyboardInterrupt:
        logger.info("\n⏹️ Verification interrupted by user")
        return 130
    except Exception as e:
        logger.error(f"\n💥 CRITICAL ERROR: {e}")
        return 3

if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)