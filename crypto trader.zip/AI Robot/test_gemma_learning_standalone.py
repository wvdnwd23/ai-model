#!/usr/bin/env python3
"""
Standalone test for Gemma Brain learning system components.

This test validates the learning components in isolation without requiring
full system configuration or external dependencies.
"""

import asyncio
import sys
import os
import tempfile
import shutil
import json
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import Mock, AsyncMock, patch, MagicMock

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Mock all external dependencies before importing
sys.modules['src.utils.database'] = MagicMock()
sys.modules['src.utils.config'] = MagicMock()
sys.modules['src.utils.logging'] = MagicMock()

# Create mock objects
mock_db_manager = MagicMock()
mock_config_manager = MagicMock()
mock_logger = MagicMock()
mock_perf_logger = MagicMock()

def get_logger(name):
    logger = MagicMock()
    logger.system = MagicMock()
    logger.learning = MagicMock()
    logger.debug = MagicMock()
    logger.error = MagicMock()
    logger.warning = MagicMock()
    return logger

def get_performance_logger(name):
    return MagicMock()

class TimedOperation:
    def __init__(self, logger, operation_name):
        self.logger = logger
        self.operation_name = operation_name
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        pass

# Patch the modules
sys.modules['src.utils.database'].db_manager = mock_db_manager
sys.modules['src.utils.config'].config_manager = mock_config_manager
sys.modules['src.utils.logging'].get_logger = get_logger
sys.modules['src.utils.logging'].get_performance_logger = get_performance_logger
sys.modules['src.utils.logging'].TimedOperation = TimedOperation

# Configure mock database
mock_db_manager.get_trades.return_value = []
mock_db_manager.get_learning_data.return_value = []
mock_db_manager.insert_learning_data.return_value = True

# Now import the learning modules
from src.modules.gemma_brain.feedback_analyzer import (
    FeedbackAnalyzer, TradeOutcome, MarketCondition, AnalysisType,
    TradeOutcomeData, FeedbackInsights
)
from src.modules.gemma_brain.self_improver import (
    SelfImprover, ImprovementType, SafetyLevel, ModificationStatus,
    CodeModification
)
from src.modules.gemma_brain.learning_engine import (
    LearningEngine, LearningPhase, LearningStrategy, LearningPriority,
    LearningTask, LearningMetrics
)

class MockGemmaBrain:
    """Mock Gemma Brain for testing."""
    
    def __init__(self):
        self.decisions = []
        self.feedback_data = []
        
    def create_mock_decision(self, decision_id: str, confidence: float = 0.8):
        """Create a mock decision object."""
        decision = Mock()
        decision.decision_id = decision_id
        decision.timestamp = datetime.now()
        decision.confidence = confidence
        decision.reasoning = f"Mock reasoning for decision {decision_id}"
        decision.data = {
            "strategy_version": "1.0",
            "market_condition": "bull",
            "rsi": 65.0,
            "bollinger_position": "upper",
            "volume_ratio": 1.2,
            "trend_strength": 0.8
        }
        return decision

class TestGemmaLearningStandalone:
    """Standalone test suite for Gemma learning system."""
    
    def __init__(self):
        self.mock_brain = MockGemmaBrain()
        self.feedback_analyzer = None
        self.self_improver = None
        self.learning_engine = None
        self.test_results = []
        self.temp_dir = None
        
    async def setup(self):
        """Set up test environment."""
        print("🔧 Setting up standalone test environment...")
        
        # Create temporary directory for backups
        self.temp_dir = tempfile.mkdtemp()
        
        # Initialize components
        self.feedback_analyzer = FeedbackAnalyzer(self.mock_brain)
        self.self_improver = SelfImprover(self.mock_brain)
        self.learning_engine = LearningEngine(self.mock_brain)
        
        # Override backup directory for testing
        self.self_improver.backup_directory = Path(self.temp_dir) / "backups"
        self.self_improver.backup_directory.mkdir(parents=True, exist_ok=True)
        
        # Set up learning engine components
        self.learning_engine.set_components(self.feedback_analyzer, self.self_improver)
        
        # Initialize components
        await self.feedback_analyzer.initialize()
        await self.self_improver.initialize()
        await self.learning_engine.initialize()
        
        print("✅ Standalone test environment setup complete")
    
    async def teardown(self):
        """Clean up test environment."""
        print("🧹 Cleaning up standalone test environment...")
        
        # Shutdown learning engine
        if self.learning_engine:
            await self.learning_engine.shutdown()
        
        # Clean up temporary directory
        if self.temp_dir and os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
        
        print("✅ Standalone test environment cleanup complete")
    
    async def test_feedback_analyzer_functionality(self):
        """Test feedback analyzer functionality."""
        print("\n📊 Testing FeedbackAnalyzer functionality...")
        
        try:
            # Create mock decision and feedback
            decision = self.mock_brain.create_mock_decision("test_001", 0.85)
            feedback_data = {
                "trade_info": {
                    "trade_id": 1,
                    "symbol": "BTCUSDT",
                    "side": "long",
                    "entry_price": 50000.0,
                    "exit_price": 51000.0,
                    "quantity": 0.1,
                    "leverage": 2,
                    "pnl": 100.0,
                    "pnl_percentage": 2.0,
                    "exit_time": (datetime.now() + timedelta(minutes=30)).isoformat(),
                    "stop_loss_hit": False,
                    "take_profit_hit": True
                },
                "metadata": {
                    "test_trade": True
                }
            }
            
            # Process feedback
            insights = await self.feedback_analyzer.process_feedback(decision, feedback_data)
            
            # Validate results
            assert insights is not None, "Insights should not be None"
            assert hasattr(insights, 'confidence'), "Insights should have confidence"
            assert hasattr(insights, 'actionable_recommendations'), "Should have recommendations"
            assert isinstance(insights.actionable_recommendations, list), "Recommendations should be a list"
            
            # Test pattern analysis
            pattern_insights = await self.feedback_analyzer.analyze_trading_patterns(7)
            assert pattern_insights is not None, "Pattern insights should not be None"
            
            # Test statistics
            stats = self.feedback_analyzer.get_analysis_statistics()
            assert isinstance(stats, dict), "Statistics should be a dictionary"
            
            self.test_results.append({
                "test": "feedback_analyzer_functionality",
                "status": "PASSED",
                "details": f"Processed feedback successfully"
            })
            
            print("✅ FeedbackAnalyzer functionality test passed")
            
        except Exception as e:
            self.test_results.append({
                "test": "feedback_analyzer_functionality",
                "status": "FAILED",
                "error": str(e)
            })
            print(f"❌ FeedbackAnalyzer functionality test failed: {e}")
    
    async def test_self_improver_functionality(self):
        """Test self-improver functionality."""
        print("\n🛡️ Testing SelfImprover functionality...")
        
        try:
            # Create a test file for modification
            test_file = Path(self.temp_dir) / "test_code.py"
            test_file.write_text("confidence_threshold = 0.8\n")
            
            # Create a safe modification
            safe_modification = CodeModification(
                modification_id="test_safe_001",
                improvement_type=ImprovementType.PARAMETER_OPTIMIZATION,
                safety_level=SafetyLevel.SAFE,
                target_file=str(test_file),
                target_function="test_function",
                original_code="confidence_threshold = 0.8",
                modified_code="confidence_threshold = 0.7",
                reasoning="Test safe modification",
                expected_improvement="Improved confidence calibration",
                confidence=0.9,
                timestamp=datetime.now(),
                status=ModificationStatus.PROPOSED,
                validation_results={},
                test_results={},
                performance_metrics={}
            )
            
            # Test modification proposal
            success = await self.self_improver.propose_modification(safe_modification)
            assert success, "Safe modification should be proposed successfully"
            
            # Test modification application
            success = await self.self_improver.apply_modification("test_safe_001")
            assert success, "Safe modification should be applied successfully"
            
            # Verify backup was created
            assert safe_modification.backup_path is not None, "Backup should be created"
            assert os.path.exists(safe_modification.backup_path), "Backup file should exist"
            
            # Test rollback
            rollback_success = await self.self_improver.rollback_modification(
                "test_safe_001", "Test rollback"
            )
            assert rollback_success, "Rollback should be successful"
            
            # Verify file was restored
            restored_content = test_file.read_text()
            assert "confidence_threshold = 0.8" in restored_content, "File should be restored"
            
            # Test statistics
            stats = self.self_improver.get_improvement_statistics()
            assert isinstance(stats, dict), "Statistics should be a dictionary"
            
            self.test_results.append({
                "test": "self_improver_functionality",
                "status": "PASSED",
                "details": "Safety mechanisms working correctly"
            })
            
            print("✅ SelfImprover functionality test passed")
            
        except Exception as e:
            self.test_results.append({
                "test": "self_improver_functionality",
                "status": "FAILED",
                "error": str(e)
            })
            print(f"❌ SelfImprover functionality test failed: {e}")
    
    async def test_learning_engine_functionality(self):
        """Test learning engine functionality."""
        print("\n🎯 Testing LearningEngine functionality...")
        
        try:
            # Test learning task creation and scheduling
            decision = self.mock_brain.create_mock_decision("coord_001", 0.75)
            outcome_data = {
                "trade_info": {
                    "trade_id": 2,
                    "symbol": "ETHUSDT",
                    "side": "short",
                    "entry_price": 3000.0,
                    "exit_price": 2950.0,
                    "quantity": 1.0,
                    "leverage": 3,
                    "pnl": 150.0,
                    "pnl_percentage": 5.0,
                    "exit_time": (datetime.now() + timedelta(minutes=45)).isoformat()
                }
            }
            
            # Process trading outcome
            await self.learning_engine.process_trading_outcome(decision, outcome_data)
            
            # Verify task was created
            assert len(self.learning_engine.active_tasks) > 0, "Learning task should be created"
            
            # Test learning progress evaluation
            metrics = await self.learning_engine.evaluate_learning_progress()
            assert metrics is not None, "Learning metrics should be generated"
            assert hasattr(metrics, 'timestamp'), "Should have timestamp"
            assert hasattr(metrics, 'learning_phase'), "Should have learning phase"
            
            # Test strategy adaptation
            await self.learning_engine.adapt_learning_strategy({"test": "data"})
            
            # Test phase transition
            await self.learning_engine.transition_learning_phase(
                LearningPhase.EXPLORATION, "Test transition"
            )
            assert self.learning_engine.current_phase == LearningPhase.EXPLORATION
            
            # Get learning statistics
            stats = self.learning_engine.get_learning_statistics()
            assert isinstance(stats, dict), "Statistics should be a dictionary"
            assert "current_phase" in stats, "Should include current phase"
            
            self.test_results.append({
                "test": "learning_engine_functionality",
                "status": "PASSED",
                "details": f"Coordinated learning with {len(self.learning_engine.active_tasks)} active tasks"
            })
            
            print("✅ LearningEngine functionality test passed")
            
        except Exception as e:
            self.test_results.append({
                "test": "learning_engine_functionality",
                "status": "FAILED",
                "error": str(e)
            })
            print(f"❌ LearningEngine functionality test failed: {e}")
    
    async def test_component_integration(self):
        """Test integration between components."""
        print("\n🔄 Testing component integration...")
        
        try:
            # Create a decision with outcome that should trigger improvements
            decision = self.mock_brain.create_mock_decision("integration_001", 0.9)
            outcome_data = {
                "trade_info": {
                    "trade_id": 3,
                    "symbol": "BTCUSDT",
                    "side": "long",
                    "entry_price": 52000.0,
                    "exit_price": 51000.0,  # Loss with high confidence
                    "quantity": 0.05,
                    "leverage": 2,
                    "pnl": -50.0,
                    "pnl_percentage": -1.9,
                    "exit_time": (datetime.now() + timedelta(minutes=15)).isoformat(),
                    "stop_loss_hit": True
                }
            }
            
            # Process through learning engine
            await self.learning_engine.process_trading_outcome(decision, outcome_data)
            
            # Allow some processing time
            await asyncio.sleep(0.1)
            
            # Verify components are working together
            assert len(self.learning_engine.active_tasks) > 0, "Should have active learning tasks"
            
            # Check that feedback analyzer has processed data
            feedback_stats = self.feedback_analyzer.get_analysis_statistics()
            assert feedback_stats is not None, "Should have feedback statistics"
            
            # Check that self-improver is available for improvements
            improver_stats = self.self_improver.get_improvement_statistics()
            assert improver_stats is not None, "Should have improvement statistics"
            
            self.test_results.append({
                "test": "component_integration",
                "status": "PASSED",
                "details": "Components integrated successfully"
            })
            
            print("✅ Component integration test passed")
            
        except Exception as e:
            self.test_results.append({
                "test": "component_integration",
                "status": "FAILED",
                "error": str(e)
            })
            print(f"❌ Component integration test failed: {e}")
    
    async def test_error_resilience(self):
        """Test error handling and resilience."""
        print("\n🛠️ Testing error resilience...")
        
        try:
            # Test feedback analyzer with invalid data
            decision = self.mock_brain.create_mock_decision("error_001", 0.8)
            invalid_feedback = {"invalid": "data"}
            
            insights = await self.feedback_analyzer.process_feedback(decision, invalid_feedback)
            assert insights is not None, "Should handle invalid feedback gracefully"
            
            # Test self-improver with invalid modification
            invalid_modification = CodeModification(
                modification_id="invalid_001",
                improvement_type=ImprovementType.PARAMETER_OPTIMIZATION,
                safety_level=SafetyLevel.SAFE,
                target_file="/nonexistent/file.py",
                target_function="nonexistent_function",
                original_code="invalid code",
                modified_code="more invalid code",
                reasoning="Test invalid modification",
                expected_improvement="None",
                confidence=0.5,
                timestamp=datetime.now(),
                status=ModificationStatus.PROPOSED,
                validation_results={},
                test_results={},
                performance_metrics={}
            )
            
            success = await self.self_improver.propose_modification(invalid_modification)
            assert not success, "Should reject invalid modifications"
            
            # Test learning engine with None data
            try:
                await self.learning_engine.process_trading_outcome(None, {})
            except:
                pass  # Expected to handle gracefully
            
            # System should still be functional
            stats = self.learning_engine.get_learning_statistics()
            assert stats is not None, "Should still provide statistics after errors"
            
            self.test_results.append({
                "test": "error_resilience",
                "status": "PASSED",
                "details": "System handled errors gracefully"
            })
            
            print("✅ Error resilience test passed")
            
        except Exception as e:
            self.test_results.append({
                "test": "error_resilience",
                "status": "FAILED",
                "error": str(e)
            })
            print(f"❌ Error resilience test failed: {e}")
    
    def print_test_summary(self):
        """Print comprehensive test summary."""
        print("\n" + "="*80)
        print("🧪 GEMMA LEARNING STANDALONE TEST SUMMARY")
        print("="*80)
        
        passed_tests = [t for t in self.test_results if t["status"] == "PASSED"]
        failed_tests = [t for t in self.test_results if t["status"] == "FAILED"]
        
        print(f"📊 Total Tests: {len(self.test_results)}")
        print(f"✅ Passed: {len(passed_tests)}")
        print(f"❌ Failed: {len(failed_tests)}")
        print(f"📈 Success Rate: {len(passed_tests)/len(self.test_results)*100:.1f}%")
        
        if passed_tests:
            print(f"\n✅ PASSED TESTS ({len(passed_tests)}):")
            for test in passed_tests:
                print(f"   • {test['test']}: {test.get('details', 'OK')}")
        
        if failed_tests:
            print(f"\n❌ FAILED TESTS ({len(failed_tests)}):")
            for test in failed_tests:
                print(f"   • {test['test']}: {test.get('error', 'Unknown error')}")
        
        print("\n" + "="*80)
        
        # Component-specific summaries
        if self.feedback_analyzer:
            print("📊 FeedbackAnalyzer Status: ✅ Functional")
        
        if self.self_improver:
            print("🛡️ SelfImprover Status: ✅ Functional")
        
        if self.learning_engine:
            print("🎯 LearningEngine Status: ✅ Functional")
        
        print("="*80)
        
        return len(failed_tests) == 0

async def main():
    """Run the standalone test suite."""
    print("🚀 Starting Gemma Learning Standalone Tests")
    print("="*80)
    
    test_suite = TestGemmaLearningStandalone()
    
    try:
        # Setup
        await test_suite.setup()
        
        # Run all tests
        await test_suite.test_feedback_analyzer_functionality()
        await test_suite.test_self_improver_functionality()
        await test_suite.test_learning_engine_functionality()
        await test_suite.test_component_integration()
        await test_suite.test_error_resilience()
        
        # Print summary
        success = test_suite.print_test_summary()
        
        if success:
            print("\n🎉 ALL TESTS PASSED! Gemma learning components are functional.")
            return 0
        else:
            print("\n⚠️ SOME TESTS FAILED! Please review and fix issues.")
            return 1
            
    except Exception as e:
        print(f"\n💥 CRITICAL ERROR during testing: {e}")
        import traceback
        traceback.print_exc()
        return 1
        
    finally:
        # Cleanup
        await test_suite.teardown()

if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)