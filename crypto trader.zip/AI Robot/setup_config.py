#!/usr/bin/env python3
"""
AI Crypto Trading System - Interactive Configuration Setup
Guides users through setting up API keys, trading parameters, and system configuration.
"""

import os
import sys
import json
import getpass
import re
from pathlib import Path
from typing import Dict, Any, Optional
import requests

# Add src to path for imports
sys.path.append('/opt/ai-crypto-trader/src')

try:
    from utils.config import ConfigManager, create_default_configs
    from utils.database import DatabaseManager
except ImportError:
    print("Error: Could not import required modules. Make sure the system is properly installed.")
    sys.exit(1)

class Colors:
    """ANSI color codes for terminal output."""
    RED = '\033[0;31m'
    GREEN = '\033[0;32m'
    YELLOW = '\033[1;33m'
    BLUE = '\033[0;34m'
    PURPLE = '\033[0;35m'
    CYAN = '\033[0;36m'
    WHITE = '\033[1;37m'
    NC = '\033[0m'  # No Color

class ConfigurationWizard:
    """Interactive configuration wizard for the AI trading system."""
    
    def __init__(self):
        self.install_dir = Path("/opt/ai-crypto-trader")
        self.config_dir = self.install_dir / "config"
        self.env_file = self.install_dir / ".env"
        self.config_manager = None
        
        # Ensure directories exist
        self.config_dir.mkdir(parents=True, exist_ok=True)
        
        # Configuration data
        self.config_data = {}
        
    def print_header(self, title: str):
        """Print a formatted header."""
        print(f"\n{Colors.CYAN}{'='*60}{Colors.NC}")
        print(f"{Colors.WHITE}{title.center(60)}{Colors.NC}")
        print(f"{Colors.CYAN}{'='*60}{Colors.NC}\n")
    
    def print_info(self, message: str):
        """Print an info message."""
        print(f"{Colors.BLUE}ℹ {message}{Colors.NC}")
    
    def print_success(self, message: str):
        """Print a success message."""
        print(f"{Colors.GREEN}✓ {message}{Colors.NC}")
    
    def print_warning(self, message: str):
        """Print a warning message."""
        print(f"{Colors.YELLOW}⚠ {message}{Colors.NC}")
    
    def print_error(self, message: str):
        """Print an error message."""
        print(f"{Colors.RED}✗ {message}{Colors.NC}")
    
    def get_input(self, prompt: str, default: str = "", password: bool = False) -> str:
        """Get user input with optional default value."""
        if default:
            display_prompt = f"{prompt} [{default}]: "
        else:
            display_prompt = f"{prompt}: "
        
        if password:
            value = getpass.getpass(display_prompt)
        else:
            value = input(display_prompt).strip()
        
        return value if value else default
    
    def get_yes_no(self, prompt: str, default: bool = False) -> bool:
        """Get yes/no input from user."""
        default_str = "Y/n" if default else "y/N"
        response = input(f"{prompt} [{default_str}]: ").strip().lower()
        
        if not response:
            return default
        
        return response in ['y', 'yes', 'true', '1']
    
    def validate_api_key(self, api_key: str) -> bool:
        """Validate API key format."""
        if not api_key:
            return False
        
        # Basic validation - should be alphanumeric and reasonable length
        if len(api_key) < 16 or len(api_key) > 128:
            return False
        
        if not re.match(r'^[a-zA-Z0-9_-]+$', api_key):
            return False
        
        return True
    
    def validate_telegram_token(self, token: str) -> bool:
        """Validate Telegram bot token format."""
        if not token:
            return False
        
        # Telegram bot token format: 123456789:ABCdefGHIjklMNOpqrsTUVwxyz
        pattern = r'^\d{8,10}:[a-zA-Z0-9_-]{35}$'
        return bool(re.match(pattern, token))
    
    def test_telegram_bot(self, token: str) -> bool:
        """Test Telegram bot token."""
        try:
            response = requests.get(
                f"https://api.telegram.org/bot{token}/getMe",
                timeout=10
            )
            return response.status_code == 200
        except Exception:
            return False
    
    def welcome_screen(self):
        """Display welcome screen."""
        self.print_header("AI Crypto Trading System Configuration")
        
        print(f"{Colors.WHITE}Welcome to the AI Crypto Trading System setup wizard!{Colors.NC}")
        print()
        print("This wizard will guide you through configuring:")
        print("• Exchange API credentials")
        print("• Trading parameters and risk management")
        print("• Telegram bot notifications")
        print("• System optimization settings")
        print()
        self.print_warning("Make sure you have your API keys ready before proceeding.")
        print()
        
        if not self.get_yes_no("Do you want to continue with the setup?", True):
            print("Setup cancelled.")
            sys.exit(0)
    
    def configure_exchanges(self):
        """Configure exchange API credentials."""
        self.print_header("Exchange Configuration")
        
        exchanges = {
            'mexc': {
                'name': 'MEXC',
                'testnet_url': 'https://api.mexc.com',
                'mainnet_url': 'https://api.mexc.com'
            },
            'xt': {
                'name': 'XT.com',
                'testnet_url': 'https://sapi.xt.com',
                'mainnet_url': 'https://sapi.xt.com'
            }
        }
        
        self.config_data['exchanges'] = {}
        
        for exchange_id, exchange_info in exchanges.items():
            print(f"\n{Colors.PURPLE}Configuring {exchange_info['name']}:{Colors.NC}")
            
            if self.get_yes_no(f"Do you want to configure {exchange_info['name']}?", True):
                
                # API Key
                while True:
                    api_key = self.get_input(f"{exchange_info['name']} API Key", password=True)
                    if self.validate_api_key(api_key):
                        break
                    self.print_error("Invalid API key format. Please try again.")
                
                # API Secret
                while True:
                    api_secret = self.get_input(f"{exchange_info['name']} API Secret", password=True)
                    if self.validate_api_key(api_secret):
                        break
                    self.print_error("Invalid API secret format. Please try again.")
                
                # Testnet option
                use_testnet = self.get_yes_no(f"Use {exchange_info['name']} testnet (recommended for testing)?", True)
                
                self.config_data['exchanges'][exchange_id] = {
                    'api_key': api_key,
                    'api_secret': api_secret,
                    'testnet': use_testnet,
                    'name': exchange_id,
                    'base_url': exchange_info['testnet_url'] if use_testnet else exchange_info['mainnet_url'],
                    'rate_limit': 10
                }
                
                self.print_success(f"{exchange_info['name']} configured successfully!")
            else:
                self.print_info(f"Skipping {exchange_info['name']} configuration.")
    
    def configure_trading_parameters(self):
        """Configure trading parameters and risk management."""
        self.print_header("Trading Parameters Configuration")
        
        print("Configure your trading parameters and risk management settings:")
        print()
        
        # Position size
        while True:
            try:
                max_position = float(self.get_input(
                    "Maximum position size (as decimal, e.g., 0.05 for 5%)", "0.05"
                ))
                if 0.01 <= max_position <= 0.5:
                    break
                self.print_error("Position size must be between 0.01 (1%) and 0.5 (50%)")
            except ValueError:
                self.print_error("Please enter a valid decimal number")
        
        # Leverage
        while True:
            try:
                max_leverage = int(self.get_input("Maximum leverage", "10"))
                if 1 <= max_leverage <= 100:
                    break
                self.print_error("Leverage must be between 1 and 100")
            except ValueError:
                self.print_error("Please enter a valid integer")
        
        # Risk/Reward ratio
        while True:
            try:
                min_rr = float(self.get_input("Minimum risk/reward ratio", "1.5"))
                if min_rr >= 1.0:
                    break
                self.print_error("Risk/reward ratio must be at least 1.0")
            except ValueError:
                self.print_error("Please enter a valid decimal number")
        
        # Stop loss percentage
        while True:
            try:
                stop_loss = float(self.get_input("Stop loss percentage", "2.0"))
                if 0.5 <= stop_loss <= 10.0:
                    break
                self.print_error("Stop loss must be between 0.5% and 10%")
            except ValueError:
                self.print_error("Please enter a valid decimal number")
        
        # Emergency stop loss
        while True:
            try:
                emergency_stop = float(self.get_input("Emergency stop loss (portfolio %)", "5.0"))
                if 1.0 <= emergency_stop <= 20.0:
                    break
                self.print_error("Emergency stop loss must be between 1% and 20%")
            except ValueError:
                self.print_error("Please enter a valid decimal number")
        
        # Daily trade limit
        while True:
            try:
                daily_trades = int(self.get_input("Maximum daily trades", "5"))
                if 1 <= daily_trades <= 50:
                    break
                self.print_error("Daily trades must be between 1 and 50")
            except ValueError:
                self.print_error("Please enter a valid integer")
        
        self.config_data['trading'] = {
            'max_position_size': max_position,
            'max_leverage': max_leverage,
            'min_risk_reward_ratio': min_rr,
            'stop_loss_percentage': stop_loss,
            'emergency_stop_loss': emergency_stop,
            'max_daily_trades': daily_trades,
            'take_profit_levels': 3
        }
        
        self.print_success("Trading parameters configured successfully!")
    
    def configure_telegram(self):
        """Configure Telegram bot notifications."""
        self.print_header("Telegram Bot Configuration")
        
        print("Configure Telegram notifications for trade alerts and system status:")
        print()
        print("To set up Telegram notifications:")
        print("1. Create a bot by messaging @BotFather on Telegram")
        print("2. Get your bot token from @BotFather")
        print("3. Get your chat ID by messaging @userinfobot")
        print()
        
        if self.get_yes_no("Do you want to configure Telegram notifications?", True):
            
            # Bot token
            while True:
                bot_token = self.get_input("Telegram Bot Token", password=True)
                if not bot_token:
                    if self.get_yes_no("Skip Telegram configuration?", False):
                        self.config_data['telegram'] = {'enabled': False}
                        return
                    continue
                
                if self.validate_telegram_token(bot_token):
                    # Test the token
                    self.print_info("Testing Telegram bot token...")
                    if self.test_telegram_bot(bot_token):
                        self.print_success("Bot token is valid!")
                        break
                    else:
                        self.print_error("Bot token test failed. Please check your token.")
                else:
                    self.print_error("Invalid bot token format.")
            
            # Chat ID
            chat_id = self.get_input("Telegram Chat ID")
            
            # Notification level
            print("\nNotification levels:")
            print("1. Critical - Only critical errors and important trades")
            print("2. High - Important events and trade results")
            print("3. Medium - Regular updates and system status")
            print("4. Low - All events including debug information")
            
            while True:
                level_choice = self.get_input("Choose notification level (1-4)", "2")
                if level_choice in ['1', '2', '3', '4']:
                    levels = {'1': 'critical', '2': 'high', '3': 'medium', '4': 'low'}
                    notification_level = levels[level_choice]
                    break
                self.print_error("Please choose a valid option (1-4)")
            
            self.config_data['telegram'] = {
                'bot_token': bot_token,
                'chat_id': chat_id,
                'enabled': True,
                'notification_level': notification_level
            }
            
            self.print_success("Telegram configuration completed!")
        else:
            self.config_data['telegram'] = {'enabled': False}
            self.print_info("Telegram notifications disabled.")
    
    def configure_system_settings(self):
        """Configure system optimization settings."""
        self.print_header("System Settings Configuration")
        
        print("Configure system optimization settings:")
        print()
        
        # Log level
        print("Log levels:")
        print("1. DEBUG - Detailed debugging information")
        print("2. INFO - General information (recommended)")
        print("3. WARNING - Only warnings and errors")
        print("4. ERROR - Only errors")
        
        while True:
            log_choice = self.get_input("Choose log level (1-4)", "2")
            if log_choice in ['1', '2', '3', '4']:
                levels = {'1': 'DEBUG', '2': 'INFO', '3': 'WARNING', '4': 'ERROR'}
                log_level = levels[log_choice]
                break
            self.print_error("Please choose a valid option (1-4)")
        
        # Debug mode
        debug_mode = self.get_yes_no("Enable debug mode (more verbose logging)?", False)
        
        # Flask port
        while True:
            try:
                flask_port = int(self.get_input("Flask dashboard port", "5050"))
                if 1024 <= flask_port <= 65535:
                    break
                self.print_error("Port must be between 1024 and 65535")
            except ValueError:
                self.print_error("Please enter a valid port number")
        
        self.config_data['system'] = {
            'log_level': log_level,
            'debug_mode': debug_mode,
            'flask_port': flask_port
        }
        
        self.print_success("System settings configured!")
    
    def save_configuration(self):
        """Save configuration to files."""
        self.print_header("Saving Configuration")
        
        try:
            # Create default configs first
            create_default_configs()
            
            # Initialize config manager
            self.config_manager = ConfigManager(str(self.config_dir))
            
            # Update configurations
            if 'trading' in self.config_data:
                self.config_manager.update_config('trading', self.config_data['trading'])
            
            if 'telegram' in self.config_data:
                self.config_manager.update_config('telegram', self.config_data['telegram'])
            
            # Save exchange configurations
            if 'exchanges' in self.config_data:
                exchanges_file = self.config_dir / "exchanges.json"
                with open(exchanges_file, 'w') as f:
                    json.dump(self.config_data['exchanges'], f, indent=2)
            
            # Create/update .env file
            self.create_env_file()
            
            self.print_success("Configuration saved successfully!")
            
        except Exception as e:
            self.print_error(f"Failed to save configuration: {e}")
            return False
        
        return True
    
    def create_env_file(self):
        """Create or update the .env file."""
        env_content = []
        
        # Header
        env_content.append("# AI Crypto Trading System Environment Configuration")
        env_content.append("# Generated by setup wizard")
        env_content.append("")
        
        # Ollama configuration
        env_content.append("# Ollama Configuration")
        env_content.append("OLLAMA_HOST=localhost")
        env_content.append("OLLAMA_PORT=11434")
        env_content.append("OLLAMA_MODEL=llama3.1:8b-instruct-q4_0")
        env_content.append("")
        
        # Database configuration
        env_content.append("# Database Configuration")
        env_content.append("DATABASE_PATH=/opt/ai-crypto-trader/data/database/trading_system.db")
        env_content.append("")
        
        # Trading configuration
        if 'trading' in self.config_data:
            trading = self.config_data['trading']
            env_content.append("# Trading Configuration")
            env_content.append(f"MAX_POSITION_SIZE={trading['max_position_size']}")
            env_content.append(f"MAX_LEVERAGE={trading['max_leverage']}")
            env_content.append(f"EMERGENCY_STOP_LOSS={trading['emergency_stop_loss']}")
            env_content.append("")
        
        # Telegram configuration
        if 'telegram' in self.config_data:
            telegram = self.config_data['telegram']
            env_content.append("# Telegram Configuration")
            if telegram.get('enabled', False):
                env_content.append(f"TELEGRAM_BOT_TOKEN={telegram['bot_token']}")
                env_content.append(f"TELEGRAM_CHAT_ID={telegram['chat_id']}")
                env_content.append("TELEGRAM_ENABLED=true")
            else:
                env_content.append("TELEGRAM_BOT_TOKEN=")
                env_content.append("TELEGRAM_CHAT_ID=")
                env_content.append("TELEGRAM_ENABLED=false")
            env_content.append("")
        
        # Exchange API keys
        if 'exchanges' in self.config_data:
            env_content.append("# Exchange API Keys")
            for exchange_id, exchange_config in self.config_data['exchanges'].items():
                env_content.append(f"{exchange_id.upper()}_API_KEY={exchange_config['api_key']}")
                env_content.append(f"{exchange_id.upper()}_API_SECRET={exchange_config['api_secret']}")
                env_content.append(f"{exchange_id.upper()}_TESTNET={'true' if exchange_config['testnet'] else 'false'}")
            env_content.append("")
        
        # System configuration
        if 'system' in self.config_data:
            system = self.config_data['system']
            env_content.append("# System Configuration")
            env_content.append(f"LOG_LEVEL={system['log_level']}")
            env_content.append(f"DEBUG_MODE={'true' if system['debug_mode'] else 'false'}")
            env_content.append(f"FLASK_PORT={system['flask_port']}")
        
        # Write to file
        with open(self.env_file, 'w') as f:
            f.write('\n'.join(env_content))
        
        # Set secure permissions
        os.chmod(self.env_file, 0o600)
    
    def test_configuration(self):
        """Test the configuration."""
        self.print_header("Testing Configuration")
        
        try:
            # Test database connection
            self.print_info("Testing database connection...")
            db = DatabaseManager(str(self.install_dir / "data/database/trading_system.db"))
            self.print_success("Database connection successful!")
            
            # Test Ollama connection
            self.print_info("Testing Ollama connection...")
            response = requests.get("http://localhost:11434/api/tags", timeout=10)
            if response.status_code == 200:
                self.print_success("Ollama connection successful!")
            else:
                self.print_warning("Ollama connection failed - make sure Ollama is running")
            
            # Test Telegram if configured
            if self.config_data.get('telegram', {}).get('enabled', False):
                self.print_info("Testing Telegram bot...")
                token = self.config_data['telegram']['bot_token']
                if self.test_telegram_bot(token):
                    self.print_success("Telegram bot test successful!")
                else:
                    self.print_warning("Telegram bot test failed")
            
            return True
            
        except Exception as e:
            self.print_error(f"Configuration test failed: {e}")
            return False
    
    def completion_summary(self):
        """Display completion summary."""
        self.print_header("Configuration Complete!")
        
        print(f"{Colors.GREEN}✓ Configuration wizard completed successfully!{Colors.NC}")
        print()
        print("Configuration summary:")
        
        # Exchanges
        if 'exchanges' in self.config_data:
            print(f"• Exchanges configured: {len(self.config_data['exchanges'])}")
            for exchange_id in self.config_data['exchanges']:
                testnet = self.config_data['exchanges'][exchange_id]['testnet']
                mode = "testnet" if testnet else "mainnet"
                print(f"  - {exchange_id.upper()} ({mode})")
        
        # Trading
        if 'trading' in self.config_data:
            trading = self.config_data['trading']
            print(f"• Max position size: {trading['max_position_size']*100:.1f}%")
            print(f"• Max leverage: {trading['max_leverage']}x")
            print(f"• Emergency stop loss: {trading['emergency_stop_loss']}%")
        
        # Telegram
        if 'telegram' in self.config_data:
            if self.config_data['telegram'].get('enabled', False):
                print("• Telegram notifications: Enabled")
            else:
                print("• Telegram notifications: Disabled")
        
        print()
        print("Next steps:")
        print("1. Start the service: sudo systemctl start ai-crypto-trader")
        print("2. Check status: sudo systemctl status ai-crypto-trader")
        print("3. View logs: sudo journalctl -u ai-crypto-trader -f")
        print("4. Access dashboard: http://localhost:5050")
        print()
        print(f"Configuration files saved to: {self.config_dir}")
        print(f"Environment file: {self.env_file}")
    
    def run(self):
        """Run the configuration wizard."""
        try:
            self.welcome_screen()
            self.configure_exchanges()
            self.configure_trading_parameters()
            self.configure_telegram()
            self.configure_system_settings()
            
            if self.save_configuration():
                self.test_configuration()
                self.completion_summary()
            else:
                self.print_error("Configuration failed. Please check the errors above.")
                sys.exit(1)
                
        except KeyboardInterrupt:
            print(f"\n{Colors.YELLOW}Configuration cancelled by user.{Colors.NC}")
            sys.exit(1)
        except Exception as e:
            self.print_error(f"Unexpected error: {e}")
            sys.exit(1)

def main():
    """Main entry point."""
    if os.geteuid() == 0:
        print("Error: Do not run this script as root. Use: sudo -u ai-trader python3 setup_config.py")
        sys.exit(1)
    
    wizard = ConfigurationWizard()
    wizard.run()

if __name__ == "__main__":
    main()