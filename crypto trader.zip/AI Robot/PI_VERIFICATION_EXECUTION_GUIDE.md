# Raspberry Pi Deployment Verification - Execution Guide

## Overview

This guide provides comprehensive instructions for executing end-to-end verification of the AI Crypto Trading System deployment on Raspberry Pi (192.168.1.91).

## Created Verification Scripts

### 1. Core Verification Scripts

#### `pi_deployment_verifier.py`
- **Purpose**: Local verification script that runs comprehensive tests on the Pi
- **Features**:
  - System resource monitoring (CPU, memory, disk, temperature)
  - File structure and permissions verification
  - Virtual environment integrity testing
  - Configuration system validation
  - Database connectivity testing
  - AI client connection verification
  - Module import testing
  - Performance validation

#### `remote_pi_verification.py`
- **Purpose**: Remote execution script that connects to Pi via SSH
- **Features**:
  - SSH connectivity testing
  - System information gathering
  - Script upload and execution
  - Remote verification orchestration
  - Report retrieval and analysis

#### `execute_pi_verification.py`
- **Purpose**: Master coordinator for complete verification process
- **Features**:
  - Multi-phase verification execution
  - Detailed issue diagnosis
  - Deployment readiness assessment
  - Comprehensive reporting
  - Executive summary generation

## Execution Instructions

### Prerequisites

1. **SSH Access**: Ensure passwordless SSH access to the Pi
   ```bash
   ssh-copy-id pi@192.168.1.91
   ```

2. **Python Dependencies**: Install required packages locally
   ```bash
   pip install asyncio subprocess pathlib
   ```

3. **Network Connectivity**: Verify Pi is accessible
   ```bash
   ping 192.168.1.91
   ```

### Quick Execution

For immediate comprehensive verification:

```bash
python3 execute_pi_verification.py --host 192.168.1.91 --user pi --install-dir /opt/ai-crypto-trader
```

### Detailed Execution Options

#### 1. Basic Remote Verification
```bash
python3 remote_pi_verification.py --host 192.168.1.91 --user pi
```

#### 2. Local Pi Verification (run on Pi directly)
```bash
python3 pi_deployment_verifier.py --install-dir /opt/ai-crypto-trader --verbose
```

#### 3. Comprehensive Master Verification
```bash
python3 execute_pi_verification.py --verbose
```

### Command Line Options

| Option | Description | Default |
|--------|-------------|---------|
| `--host` | Pi hostname or IP address | 192.168.1.91 |
| `--user` | SSH username | pi |
| `--install-dir` | Installation directory on Pi | /opt/ai-crypto-trader |
| `--verbose` | Enable detailed logging | False |

## Verification Process

### Phase 1: Remote Connectivity
- ✅ SSH connection testing
- ✅ System information gathering
- ✅ Installation directory verification
- ✅ Script upload and execution

### Phase 2: System Verification
- ✅ File structure and permissions
- ✅ Virtual environment integrity
- ✅ Python dependencies validation
- ✅ Configuration system testing

### Phase 3: Application Testing
- ✅ Database connectivity
- ✅ AI client connections (OpenAI/OpenRouter)
- ✅ Module import verification
- ✅ Monitoring system testing

### Phase 4: Performance & Integration
- ✅ System resource monitoring
- ✅ Performance benchmarking
- ✅ End-to-end integration testing
- ✅ Logging system validation

## Expected Output

### Success Indicators
- **Overall Status**: HEALTHY
- **Deployment Readiness**: READY
- **System Health Score**: >90%
- **Success Rate**: >95%

### Warning Indicators
- **Overall Status**: WARNING
- **Deployment Readiness**: READY_WITH_MONITORING
- **System Health Score**: 70-90%
- **Success Rate**: 80-95%

### Failure Indicators
- **Overall Status**: CRITICAL
- **Deployment Readiness**: NOT_READY
- **System Health Score**: <70%
- **Success Rate**: <80%

## Generated Reports

### 1. Verification Logs
- `pi_verification_master_YYYYMMDD_HHMMSS.log`
- `remote_verification.log`
- `pi_verification.log`

### 2. JSON Reports
- `comprehensive_pi_verification_YYYYMMDD_HHMMSS.json`
- `remote_pi_verification_report_YYYYMMDD_HHMMSS.json`
- `pi_verification_report.json`

### 3. Report Structure
```json
{
  "comprehensive_verification_report": {
    "metadata": {
      "timestamp": "ISO-8601",
      "pi_host": "192.168.1.91",
      "total_duration": "seconds"
    },
    "executive_summary": {
      "overall_status": "HEALTHY|WARNING|CRITICAL",
      "deployment_recommendation": "READY|READY_WITH_MONITORING|NOT_READY",
      "system_health_score": "0-100",
      "confidence_level": "HIGH|MEDIUM|LOW"
    },
    "detailed_results": {
      "remote_verification": {...},
      "pi_analysis": {...},
      "diagnosis": {...}
    }
  }
}
```

## Troubleshooting

### Common Issues

#### SSH Connection Failures
```bash
# Test SSH connectivity
ssh -v pi@192.168.1.91

# Check SSH key authentication
ssh-add -l
```

#### Permission Errors
```bash
# Fix script permissions
chmod +x *.py

# Fix Pi directory permissions
ssh pi@192.168.1.91 "sudo chown -R pi:pi /opt/ai-crypto-trader"
```

#### Python Import Errors
```bash
# Verify Python path on Pi
ssh pi@192.168.1.91 "cd /opt/ai-crypto-trader && source venv/bin/activate && python3 -c 'import sys; print(sys.path)'"
```

### Diagnostic Commands

#### System Status Check
```bash
ssh pi@192.168.1.91 "uptime && free -h && df -h && cat /sys/class/thermal/thermal_zone0/temp"
```

#### Service Status Check
```bash
ssh pi@192.168.1.91 "systemctl status ai-crypto-trader"
```

#### Log Analysis
```bash
ssh pi@192.168.1.91 "tail -50 /opt/ai-crypto-trader/src/data/logs/system/main.log"
```

## Issue Resolution

### Critical Issues (Deployment Blocking)
1. **Virtual Environment Corruption**
   - Recreate venv: `python3 -m venv venv`
   - Reinstall dependencies: `pip install -r requirements.txt`

2. **Database Connection Failures**
   - Check file permissions: `chmod 644 *.db`
   - Verify database integrity: `sqlite3 database.db "PRAGMA integrity_check;"`

3. **API Configuration Errors**
   - Verify .env file: `cat .env | grep API_KEY`
   - Test API connectivity: `curl -H "Authorization: Bearer $API_KEY" https://api.openai.com/v1/models`

### Warning Issues (Monitor Closely)
1. **High Resource Usage**
   - Monitor with: `htop`, `iotop`, `nethogs`
   - Optimize configuration settings

2. **Permission Warnings**
   - Review and fix: `find /opt/ai-crypto-trader -type f -perm /o+w`

3. **Import Warnings**
   - Check optional dependencies
   - Verify fallback mechanisms

## Performance Benchmarks

### Raspberry Pi 5 Expected Performance
- **CPU Usage**: <20% idle, <60% under load
- **Memory Usage**: <50% of available RAM
- **Disk Usage**: <80% of available space
- **Temperature**: <65°C under normal load
- **Import Time**: <5 seconds for critical modules
- **Database Response**: <100ms for basic queries

## Security Considerations

### Verification Checks
- ✅ File permissions (600 for .env, 755 for scripts)
- ✅ No hardcoded secrets in code
- ✅ Secure SSH configuration
- ✅ Firewall status verification
- ✅ Service user isolation

### Recommendations
- Enable automatic security updates
- Configure log rotation
- Set up intrusion detection
- Regular backup verification
- Monitor for unusual network activity

## Next Steps After Verification

### If Status = READY
1. Deploy to production
2. Enable monitoring alerts
3. Schedule regular health checks
4. Document operational procedures

### If Status = READY_WITH_MONITORING
1. Address warning conditions
2. Implement enhanced monitoring
3. Create incident response plan
4. Schedule frequent health checks

### If Status = NOT_READY
1. Address all critical issues
2. Re-run verification
3. Consider infrastructure upgrades
4. Review deployment strategy

## Support and Maintenance

### Regular Verification Schedule
- **Daily**: Quick health checks
- **Weekly**: Performance monitoring
- **Monthly**: Comprehensive verification
- **Quarterly**: Security audit

### Monitoring Integration
- Set up automated alerts for critical metrics
- Configure log aggregation
- Implement performance dashboards
- Create backup and recovery procedures

---

## Execution Summary

The comprehensive verification system provides:

1. **Systematic Testing**: 13 verification categories covering all system aspects
2. **Remote Execution**: SSH-based testing without manual Pi access
3. **Detailed Diagnostics**: Component-level health analysis
4. **Deployment Readiness**: Clear go/no-go recommendations
5. **Performance Validation**: Resource usage and optimization insights
6. **Security Assessment**: Permission and configuration verification
7. **Comprehensive Reporting**: JSON and log-based documentation

Execute the verification with confidence knowing that all critical system components, dependencies, configurations, and integrations will be thoroughly tested and validated.