#!/usr/bin/env python3
"""
Monitoring System Component Instantiation Test
Tests actual component creation and basic functionality
"""

import sys
import os
import tempfile
import sqlite3
from datetime import datetime
import importlib.util

def log_test(message, status="INFO"):
    """Simple logging for test output"""
    timestamp = datetime.now().strftime("%H:%M:%S")
    status_symbol = "✓" if status == "PASS" else "✗" if status == "FAIL" else "ℹ"
    print(f"[{timestamp}] {status_symbol} {message}")

def load_module_from_file(module_name, file_path):
    """Load a Python module from file path"""
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def test_monitoring_config_instantiation():
    """Test monitoring configuration instantiation"""
    log_test("Testing monitoring configuration instantiation...")
    
    try:
        config_module = load_module_from_file("monitoring_config", "src/monitoring/config.py")
        config = config_module.monitoring_config
        
        # Test config sections
        expected_sections = [
            'system_monitor', 'ai_monitor', 'alert_manager', 
            'notification_system', 'dashboard', 'health_checker',
            'performance_profiler', 'log_aggregator', 'metrics_collector'
        ]
        
        found_sections = []
        for section in expected_sections:
            if hasattr(config, section):
                found_sections.append(section)
                log_test(f"Config section '{section}' available", "PASS")
            else:
                log_test(f"Config section '{section}' missing", "FAIL")
        
        return len(found_sections) == len(expected_sections), config
        
    except Exception as e:
        log_test(f"Config instantiation failed: {str(e)}", "FAIL")
        return False, None

def test_database_schema_creation():
    """Test monitoring database schema creation"""
    log_test("Testing database schema creation...")
    
    try:
        # Create temporary database
        with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp_db:
            db_path = tmp_db.name
        
        # Load database utilities
        db_module = load_module_from_file("database", "src/utils/database.py")
        
        # Test database connection
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Test basic table creation
        test_tables = [
            ("system_metrics", "CREATE TABLE system_metrics (id INTEGER PRIMARY KEY, timestamp TEXT, cpu_percent REAL, memory_percent REAL)"),
            ("ai_metrics", "CREATE TABLE ai_metrics (id INTEGER PRIMARY KEY, timestamp TEXT, model_name TEXT, performance_score REAL)"),
            ("alerts", "CREATE TABLE alerts (id INTEGER PRIMARY KEY, timestamp TEXT, level TEXT, message TEXT, resolved INTEGER)")
        ]
        
        for table_name, create_sql in test_tables:
            try:
                cursor.execute(create_sql)
                log_test(f"Table '{table_name}' created successfully", "PASS")
            except Exception as e:
                log_test(f"Table '{table_name}' creation failed: {str(e)}", "FAIL")
        
        conn.commit()
        conn.close()
        
        # Cleanup
        os.unlink(db_path)
        
        log_test("Database schema test completed", "PASS")
        return True
        
    except Exception as e:
        log_test(f"Database schema test failed: {str(e)}", "FAIL")
        return False

def test_component_basic_instantiation():
    """Test basic instantiation of monitoring components"""
    log_test("Testing component basic instantiation...")
    
    # Mock configuration for testing
    class MockConfig:
        def __init__(self):
            self.system_monitor = type('obj', (object,), {
                'enabled': True,
                'interval': 60,
                'cpu_threshold': 80,
                'memory_threshold': 80,
                'disk_threshold': 90
            })()
            
            self.ai_monitor = type('obj', (object,), {
                'enabled': True,
                'interval': 30,
                'performance_threshold': 0.8
            })()
            
            self.alert_manager = type('obj', (object,), {
                'enabled': True,
                'rate_limit_window': 300,
                'max_alerts_per_window': 10
            })()
            
            self.notification_system = type('obj', (object,), {
                'enabled': True,
                'channels': ['console'],
                'templates_dir': 'templates'
            })()
            
            self.dashboard = type('obj', (object,), {
                'enabled': True,
                'host': '127.0.0.1',
                'port': 5000,
                'debug': False
            })()
            
            self.health_checker = type('obj', (object,), {
                'enabled': True,
                'interval': 60,
                'timeout': 30
            })()
            
            self.performance_profiler = type('obj', (object,), {
                'enabled': True,
                'profile_interval': 300
            })()
            
            self.log_aggregator = type('obj', (object,), {
                'enabled': True,
                'log_level': 'INFO',
                'max_file_size': 10485760
            })()
            
            self.metrics_collector = type('obj', (object,), {
                'enabled': True,
                'collection_interval': 60,
                'retention_days': 30
            })()
    
    mock_config = MockConfig()
    results = {}
    
    # Test components that can be instantiated without heavy dependencies
    test_components = [
        ("MetricsCollector", "src/monitoring/metrics_collector.py"),
        ("LogAggregator", "src/monitoring/log_aggregator.py"),
        ("PerformanceProfiler", "src/monitoring/performance_profiler.py")
    ]
    
    for component_name, file_path in test_components:
        try:
            log_test(f"Testing {component_name} instantiation...")
            
            # Load the module
            module = load_module_from_file(component_name.lower(), file_path)
            
            # Get the class
            component_class = getattr(module, component_name)
            
            # Try to instantiate with mock config
            config_attr = getattr(mock_config, component_name.lower().replace('collector', '_collector').replace('aggregator', '_aggregator').replace('profiler', '_profiler'))
            
            # Basic instantiation test (may fail due to dependencies, but we test the class structure)
            try:
                instance = component_class(config_attr)
                log_test(f"{component_name} instantiated successfully", "PASS")
                results[component_name] = True
            except Exception as e:
                # Check if it's a dependency issue vs structural issue
                if "No module named" in str(e) or "import" in str(e).lower():
                    log_test(f"{component_name} has dependency issues (expected): {str(e)[:50]}...", "INFO")
                    results[component_name] = "dependency_issue"
                else:
                    log_test(f"{component_name} instantiation failed: {str(e)}", "FAIL")
                    results[component_name] = False
                    
        except Exception as e:
            log_test(f"{component_name} test failed: {str(e)}", "FAIL")
            results[component_name] = False
    
    return results

def test_monitoring_system_main():
    """Test the main MonitoringSystem class structure"""
    log_test("Testing MonitoringSystem main class...")
    
    try:
        # Load the main monitoring module
        main_module = load_module_from_file("monitoring_main", "src/monitoring/__init__.py")
        
        # Check for key classes
        key_classes = ["MonitoringSystem", "ComponentManager", "DependencyResolver"]
        found_classes = []
        
        for class_name in key_classes:
            if hasattr(main_module, class_name):
                found_classes.append(class_name)
                log_test(f"Found {class_name} class", "PASS")
                
                # Test class structure
                cls = getattr(main_module, class_name)
                if hasattr(cls, '__init__'):
                    log_test(f"{class_name} has __init__ method", "PASS")
                else:
                    log_test(f"{class_name} missing __init__ method", "FAIL")
            else:
                log_test(f"Missing {class_name} class", "FAIL")
        
        return len(found_classes) == len(key_classes)
        
    except Exception as e:
        log_test(f"MonitoringSystem main test failed: {str(e)}", "FAIL")
        return False

def main():
    """Run monitoring system instantiation tests"""
    print("=" * 70)
    print("AI Crypto Trading System - Monitoring Instantiation Test")
    print("=" * 70)
    
    # Test 1: Configuration instantiation
    config_ok, config = test_monitoring_config_instantiation()
    
    # Test 2: Database schema
    db_ok = test_database_schema_creation()
    
    # Test 3: Component instantiation
    component_results = test_component_basic_instantiation()
    
    # Test 4: Main system class
    main_system_ok = test_monitoring_system_main()
    
    # Summary
    print("\n" + "=" * 70)
    print("INSTANTIATION TEST SUMMARY")
    print("=" * 70)
    
    if config_ok:
        print("✅ Monitoring configuration instantiates successfully")
    else:
        print("❌ Monitoring configuration has instantiation issues")
    
    if db_ok:
        print("✅ Database schema creation works")
    else:
        print("❌ Database schema creation has issues")
    
    # Component results
    passed = sum(1 for result in component_results.values() if result is True)
    dependency_issues = sum(1 for result in component_results.values() if result == "dependency_issue")
    failed = sum(1 for result in component_results.values() if result is False)
    total = len(component_results)
    
    print(f"📊 Component instantiation: {passed} passed, {dependency_issues} dependency issues, {failed} failed (total: {total})")
    
    if main_system_ok:
        print("✅ Main MonitoringSystem class structure is valid")
    else:
        print("❌ Main MonitoringSystem class has issues")
    
    # Overall assessment
    critical_ok = config_ok and db_ok and main_system_ok
    
    if critical_ok:
        print("\n🎉 Monitoring system core functionality is ready!")
        if dependency_issues > 0:
            print("⚠️  Some components have dependency issues (expected for isolated testing)")
        print("Next steps: Test full system integration with AI trading modules")
    else:
        print("\n⚠️  Monitoring system has critical issues that need resolution")

if __name__ == "__main__":
    main()