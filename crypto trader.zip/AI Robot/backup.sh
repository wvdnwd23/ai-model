#!/bin/bash

# AI Crypto Trading System - Backup Script
# Automated backup of database, configuration, logs, and trading history

set -e

# Configuration
INSTALL_DIR="/opt/ai-crypto-trader"
SERVICE_USER="ai-trader"
BACKUP_BASE_DIR="$INSTALL_DIR/data/backups"
LOG_FILE="$INSTALL_DIR/data/logs/system/backup.log"
REMOTE_BACKUP_DIR=""  # Set this for remote backups
RETENTION_DAYS=30
COMPRESSION_LEVEL=6

# Backup directories
DB_BACKUP_DIR="$BACKUP_BASE_DIR/database"
CONFIG_BACKUP_DIR="$BACKUP_BASE_DIR/configs"
LOG_BACKUP_DIR="$BACKUP_BASE_DIR/logs"
FULL_BACKUP_DIR="$BACKUP_BASE_DIR/full"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m'

# Backup metadata
BACKUP_ID=$(date +%Y%m%d_%H%M%S)
BACKUP_DATE=$(date -Iseconds)

# Ensure directories exist
mkdir -p "$DB_BACKUP_DIR" "$CONFIG_BACKUP_DIR" "$LOG_BACKUP_DIR" "$FULL_BACKUP_DIR"
mkdir -p "$(dirname "$LOG_FILE")"

# Logging functions
log() {
    echo -e "${GREEN}[$(date '+%Y-%m-%d %H:%M:%S')] $1${NC}" | tee -a "$LOG_FILE"
}

warn() {
    echo -e "${YELLOW}[$(date '+%Y-%m-%d %H:%M:%S')] WARNING: $1${NC}" | tee -a "$LOG_FILE"
}

error() {
    echo -e "${RED}[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: $1${NC}" | tee -a "$LOG_FILE"
}

info() {
    echo -e "${BLUE}[$(date '+%Y-%m-%d %H:%M:%S')] $1${NC}" | tee -a "$LOG_FILE"
}

# Check if running as correct user
check_user() {
    if [[ "$USER" != "$SERVICE_USER" && "$USER" != "root" ]]; then
        error "This script must be run as '$SERVICE_USER' or 'root'"
        exit 1
    fi
}

# Get database size
get_database_size() {
    local db_path="$INSTALL_DIR/data/database/trading_system.db"
    if [[ -f "$db_path" ]]; then
        stat -c%s "$db_path" 2>/dev/null || echo "0"
    else
        echo "0"
    fi
}

# Backup database
backup_database() {
    log "Starting database backup..."
    
    local db_path="$INSTALL_DIR/data/database/trading_system.db"
    local backup_file="$DB_BACKUP_DIR/trading_system_$BACKUP_ID.db"
    local compressed_file="$backup_file.gz"
    
    if [[ ! -f "$db_path" ]]; then
        warn "Database file not found: $db_path"
        return 1
    fi
    
    # Check database integrity before backup
    if ! sqlite3 "$db_path" "PRAGMA integrity_check;" | grep -q "ok"; then
        error "Database integrity check failed - backup aborted"
        return 1
    fi
    
    # Create database backup using SQLite backup API
    if sqlite3 "$db_path" ".backup $backup_file"; then
        log "Database backed up to: $backup_file"
        
        # Compress the backup
        if gzip -$COMPRESSION_LEVEL "$backup_file"; then
            log "Database backup compressed: $compressed_file"
            
            # Verify compressed backup
            if gunzip -t "$compressed_file" 2>/dev/null; then
                log "Compressed backup verified"
            else
                error "Compressed backup verification failed"
                return 1
            fi
        else
            error "Failed to compress database backup"
            return 1
        fi
        
        # Create backup metadata
        local metadata_file="$DB_BACKUP_DIR/trading_system_$BACKUP_ID.meta"
        cat > "$metadata_file" << EOF
{
    "backup_id": "$BACKUP_ID",
    "timestamp": "$BACKUP_DATE",
    "original_size": $(get_database_size),
    "compressed_size": $(stat -c%s "$compressed_file" 2>/dev/null || echo "0"),
    "integrity_check": "passed",
    "backup_type": "database"
}
EOF
        
        log "Database backup completed successfully"
        return 0
    else
        error "Database backup failed"
        return 1
    fi
}

# Backup configuration files
backup_configuration() {
    log "Starting configuration backup..."
    
    local config_backup_file="$CONFIG_BACKUP_DIR/config_$BACKUP_ID.tar.gz"
    local temp_dir="/tmp/ai-trader-config-$BACKUP_ID"
    
    mkdir -p "$temp_dir"
    
    # Copy configuration files
    if [[ -d "$INSTALL_DIR/config" ]]; then
        cp -r "$INSTALL_DIR/config" "$temp_dir/"
        log "Configuration directory backed up"
    fi
    
    # Copy environment file (with sensitive data)
    if [[ -f "$INSTALL_DIR/.env" ]]; then
        cp "$INSTALL_DIR/.env" "$temp_dir/"
        log "Environment file backed up"
    fi
    
    # Copy requirements.txt
    if [[ -f "$INSTALL_DIR/requirements.txt" ]]; then
        cp "$INSTALL_DIR/requirements.txt" "$temp_dir/"
        log "Requirements file backed up"
    fi
    
    # Copy systemd service files
    if [[ -f "/etc/systemd/system/ai-crypto-trader.service" ]]; then
        mkdir -p "$temp_dir/systemd"
        cp "/etc/systemd/system/ai-crypto-trader.service" "$temp_dir/systemd/"
        log "Systemd service file backed up"
    fi
    
    # Create archive
    if tar -czf "$config_backup_file" -C "$temp_dir" .; then
        log "Configuration backup created: $config_backup_file"
        
        # Create metadata
        local metadata_file="$CONFIG_BACKUP_DIR/config_$BACKUP_ID.meta"
        cat > "$metadata_file" << EOF
{
    "backup_id": "$BACKUP_ID",
    "timestamp": "$BACKUP_DATE",
    "archive_size": $(stat -c%s "$config_backup_file" 2>/dev/null || echo "0"),
    "files_included": [
        "config/",
        ".env",
        "requirements.txt",
        "systemd/ai-crypto-trader.service"
    ],
    "backup_type": "configuration"
}
EOF
        
        # Cleanup temp directory
        rm -rf "$temp_dir"
        
        log "Configuration backup completed successfully"
        return 0
    else
        error "Configuration backup failed"
        rm -rf "$temp_dir"
        return 1
    fi
}

# Backup and archive logs
backup_logs() {
    log "Starting log backup and archiving..."
    
    local log_backup_file="$LOG_BACKUP_DIR/logs_$BACKUP_ID.tar.gz"
    local source_log_dir="$INSTALL_DIR/data/logs"
    
    if [[ ! -d "$source_log_dir" ]]; then
        warn "Log directory not found: $source_log_dir"
        return 1
    fi
    
    # Create log archive (excluding current day's logs)
    local yesterday=$(date -d "yesterday" +%Y-%m-%d)
    
    if find "$source_log_dir" -name "*.log" -not -newermt "$yesterday" | tar -czf "$log_backup_file" -T - 2>/dev/null; then
        log "Log backup created: $log_backup_file"
        
        # Count archived files
        local file_count=$(tar -tzf "$log_backup_file" | wc -l)
        
        # Create metadata
        local metadata_file="$LOG_BACKUP_DIR/logs_$BACKUP_ID.meta"
        cat > "$metadata_file" << EOF
{
    "backup_id": "$BACKUP_ID",
    "timestamp": "$BACKUP_DATE",
    "archive_size": $(stat -c%s "$log_backup_file" 2>/dev/null || echo "0"),
    "files_archived": $file_count,
    "cutoff_date": "$yesterday",
    "backup_type": "logs"
}
EOF
        
        # Remove archived log files to save space (optional)
        if [[ "${1:-}" == "--cleanup-logs" ]]; then
            find "$source_log_dir" -name "*.log" -not -newermt "$yesterday" -delete
            log "Archived log files removed from source"
        fi
        
        log "Log backup completed successfully"
        return 0
    else
        warn "No old log files found to archive"
        return 0
    fi
}

# Create full system backup
backup_full_system() {
    log "Starting full system backup..."
    
    local full_backup_file="$FULL_BACKUP_DIR/full_backup_$BACKUP_ID.tar.gz"
    local temp_dir="/tmp/ai-trader-full-$BACKUP_ID"
    
    mkdir -p "$temp_dir"
    
    # Copy source code
    if [[ -d "$INSTALL_DIR/src" ]]; then
        cp -r "$INSTALL_DIR/src" "$temp_dir/"
        log "Source code included in full backup"
    fi
    
    # Copy scripts
    if [[ -d "$INSTALL_DIR/scripts" ]]; then
        cp -r "$INSTALL_DIR/scripts" "$temp_dir/"
        log "Scripts included in full backup"
    fi
    
    # Include database backup
    local latest_db_backup=$(ls -1t "$DB_BACKUP_DIR"/trading_system_*.db.gz 2>/dev/null | head -1)
    if [[ -n "$latest_db_backup" ]]; then
        mkdir -p "$temp_dir/database"
        cp "$latest_db_backup" "$temp_dir/database/"
        log "Latest database backup included"
    fi
    
    # Include configuration backup
    local latest_config_backup=$(ls -1t "$CONFIG_BACKUP_DIR"/config_*.tar.gz 2>/dev/null | head -1)
    if [[ -n "$latest_config_backup" ]]; then
        mkdir -p "$temp_dir/config"
        cp "$latest_config_backup" "$temp_dir/config/"
        log "Latest configuration backup included"
    fi
    
    # Create full backup archive
    if tar -czf "$full_backup_file" -C "$temp_dir" .; then
        log "Full system backup created: $full_backup_file"
        
        # Create metadata
        local metadata_file="$FULL_BACKUP_DIR/full_backup_$BACKUP_ID.meta"
        cat > "$metadata_file" << EOF
{
    "backup_id": "$BACKUP_ID",
    "timestamp": "$BACKUP_DATE",
    "archive_size": $(stat -c%s "$full_backup_file" 2>/dev/null || echo "0"),
    "components": [
        "source_code",
        "scripts",
        "database_backup",
        "configuration_backup"
    ],
    "backup_type": "full_system"
}
EOF
        
        # Cleanup temp directory
        rm -rf "$temp_dir"
        
        log "Full system backup completed successfully"
        return 0
    else
        error "Full system backup failed"
        rm -rf "$temp_dir"
        return 1
    fi
}

# Export trading history
export_trading_history() {
    log "Exporting trading history..."
    
    local db_path="$INSTALL_DIR/data/database/trading_system.db"
    local export_file="$BACKUP_BASE_DIR/trading_history_$BACKUP_ID.csv"
    
    if [[ ! -f "$db_path" ]]; then
        warn "Database not found for trading history export"
        return 1
    fi
    
    # Export trades to CSV
    sqlite3 "$db_path" << EOF > "$export_file"
.headers on
.mode csv
SELECT 
    id,
    symbol,
    exchange,
    side,
    entry_price,
    exit_price,
    quantity,
    leverage,
    pnl,
    status,
    entry_time,
    exit_time,
    strategy_version
FROM trades 
ORDER BY entry_time DESC;
EOF
    
    if [[ -f "$export_file" && -s "$export_file" ]]; then
        log "Trading history exported: $export_file"
        
        # Compress the export
        if gzip "$export_file"; then
            log "Trading history export compressed"
        fi
        
        return 0
    else
        warn "No trading history to export"
        return 1
    fi
}

# Verify backup integrity
verify_backups() {
    log "Verifying backup integrity..."
    
    local verification_failed=false
    
    # Verify database backup
    local latest_db_backup=$(ls -1t "$DB_BACKUP_DIR"/trading_system_*.db.gz 2>/dev/null | head -1)
    if [[ -n "$latest_db_backup" ]]; then
        if gunzip -t "$latest_db_backup" 2>/dev/null; then
            log "Database backup verification: PASSED"
        else
            error "Database backup verification: FAILED"
            verification_failed=true
        fi
    fi
    
    # Verify configuration backup
    local latest_config_backup=$(ls -1t "$CONFIG_BACKUP_DIR"/config_*.tar.gz 2>/dev/null | head -1)
    if [[ -n "$latest_config_backup" ]]; then
        if tar -tzf "$latest_config_backup" >/dev/null 2>&1; then
            log "Configuration backup verification: PASSED"
        else
            error "Configuration backup verification: FAILED"
            verification_failed=true
        fi
    fi
    
    # Verify log backup
    local latest_log_backup=$(ls -1t "$LOG_BACKUP_DIR"/logs_*.tar.gz 2>/dev/null | head -1)
    if [[ -n "$latest_log_backup" ]]; then
        if tar -tzf "$latest_log_backup" >/dev/null 2>&1; then
            log "Log backup verification: PASSED"
        else
            error "Log backup verification: FAILED"
            verification_failed=true
        fi
    fi
    
    if [[ "$verification_failed" == "true" ]]; then
        error "Backup verification failed"
        return 1
    else
        log "All backup verifications passed"
        return 0
    fi
}

# Cleanup old backups
cleanup_old_backups() {
    log "Cleaning up old backups (older than $RETENTION_DAYS days)..."
    
    local cleanup_count=0
    
    # Cleanup database backups
    while IFS= read -r -d '' file; do
        rm -f "$file"
        ((cleanup_count++))
    done < <(find "$DB_BACKUP_DIR" -name "*.db.gz" -mtime +$RETENTION_DAYS -print0 2>/dev/null)
    
    # Cleanup configuration backups
    while IFS= read -r -d '' file; do
        rm -f "$file"
        ((cleanup_count++))
    done < <(find "$CONFIG_BACKUP_DIR" -name "*.tar.gz" -mtime +$RETENTION_DAYS -print0 2>/dev/null)
    
    # Cleanup log backups
    while IFS= read -r -d '' file; do
        rm -f "$file"
        ((cleanup_count++))
    done < <(find "$LOG_BACKUP_DIR" -name "*.tar.gz" -mtime +$RETENTION_DAYS -print0 2>/dev/null)
    
    # Cleanup full backups (keep fewer of these)
    while IFS= read -r -d '' file; do
        rm -f "$file"
        ((cleanup_count++))
    done < <(find "$FULL_BACKUP_DIR" -name "*.tar.gz" -mtime +7 -print0 2>/dev/null)
    
    # Cleanup metadata files
    while IFS= read -r -d '' file; do
        rm -f "$file"
        ((cleanup_count++))
    done < <(find "$BACKUP_BASE_DIR" -name "*.meta" -mtime +$RETENTION_DAYS -print0 2>/dev/null)
    
    if [[ $cleanup_count -gt 0 ]]; then
        log "Cleaned up $cleanup_count old backup files"
    else
        log "No old backup files to clean up"
    fi
}

# Upload to remote storage (if configured)
upload_to_remote() {
    if [[ -z "$REMOTE_BACKUP_DIR" ]]; then
        log "Remote backup not configured, skipping upload"
        return 0
    fi
    
    log "Uploading backups to remote storage..."
    
    # This is a placeholder for remote backup functionality
    # You would implement this based on your remote storage solution
    # Examples: rsync to remote server, AWS S3, Google Cloud Storage, etc.
    
    warn "Remote backup upload not implemented - configure based on your storage solution"
    return 0
}

# Generate backup report
generate_backup_report() {
    log "Generating backup report..."
    
    local report_file="$BACKUP_BASE_DIR/backup_report_$BACKUP_ID.json"
    
    # Calculate backup sizes
    local db_size=$(find "$DB_BACKUP_DIR" -name "*$BACKUP_ID*" -exec stat -c%s {} \; 2>/dev/null | awk '{sum+=$1} END {print sum+0}')
    local config_size=$(find "$CONFIG_BACKUP_DIR" -name "*$BACKUP_ID*" -exec stat -c%s {} \; 2>/dev/null | awk '{sum+=$1} END {print sum+0}')
    local log_size=$(find "$LOG_BACKUP_DIR" -name "*$BACKUP_ID*" -exec stat -c%s {} \; 2>/dev/null | awk '{sum+=$1} END {print sum+0}')
    local full_size=$(find "$FULL_BACKUP_DIR" -name "*$BACKUP_ID*" -exec stat -c%s {} \; 2>/dev/null | awk '{sum+=$1} END {print sum+0}')
    
    cat > "$report_file" << EOF
{
    "backup_id": "$BACKUP_ID",
    "timestamp": "$BACKUP_DATE",
    "backup_sizes": {
        "database": $db_size,
        "configuration": $config_size,
        "logs": $log_size,
        "full_system": $full_size,
        "total": $((db_size + config_size + log_size + full_size))
    },
    "backup_locations": {
        "database": "$DB_BACKUP_DIR",
        "configuration": "$CONFIG_BACKUP_DIR",
        "logs": "$LOG_BACKUP_DIR",
        "full_system": "$FULL_BACKUP_DIR"
    },
    "retention_days": $RETENTION_DAYS,
    "verification_status": "passed"
}
EOF
    
    log "Backup report generated: $report_file"
}

# List available backups
list_backups() {
    echo "Available Backups"
    echo "================="
    echo ""
    
    echo "Database Backups:"
    ls -lh "$DB_BACKUP_DIR"/*.db.gz 2>/dev/null | awk '{print "  " $9 " (" $5 ", " $6 " " $7 ")"}' || echo "  No database backups found"
    echo ""
    
    echo "Configuration Backups:"
    ls -lh "$CONFIG_BACKUP_DIR"/*.tar.gz 2>/dev/null | awk '{print "  " $9 " (" $5 ", " $6 " " $7 ")"}' || echo "  No configuration backups found"
    echo ""
    
    echo "Log Backups:"
    ls -lh "$LOG_BACKUP_DIR"/*.tar.gz 2>/dev/null | awk '{print "  " $9 " (" $5 ", " $6 " " $7 ")"}' || echo "  No log backups found"
    echo ""
    
    echo "Full System Backups:"
    ls -lh "$FULL_BACKUP_DIR"/*.tar.gz 2>/dev/null | awk '{print "  " $9 " (" $5 ", " $6 " " $7 ")"}' || echo "  No full system backups found"
    echo ""
    
    # Show disk usage
    echo "Backup Directory Usage:"
    du -sh "$BACKUP_BASE_DIR"/* 2>/dev/null | sed 's/^/  /' || echo "  No backup directories found"
}

# Restore from backup
restore_backup() {
    local backup_type="$1"
    local backup_file="$2"
    
    if [[ -z "$backup_type" || -z "$backup_file" ]]; then
        error "Usage: restore <type> <backup_file>"
        error "Types: database, config, full"
        return 1
    fi
    
    case "$backup_type" in
        database)
            log "Restoring database from: $backup_file"
            if [[ -f "$backup_file" ]]; then
                # Stop service first
                systemctl stop ai-crypto-trader 2>/dev/null || true
                
                # Restore database
                gunzip -c "$backup_file" > "$INSTALL_DIR/data/database/trading_system.db"
                chown "$SERVICE_USER:$SERVICE_USER" "$INSTALL_DIR/data/database/trading_system.db"
                
                log "Database restored successfully"
            else
                error "Backup file not found: $backup_file"
                return 1
            fi
            ;;
        config)
            log "Restoring configuration from: $backup_file"
            if [[ -f "$backup_file" ]]; then
                # Extract to temporary directory first
                local temp_dir="/tmp/restore-config-$$"
                mkdir -p "$temp_dir"
                
                tar -xzf "$backup_file" -C "$temp_dir"
                
                # Restore files
                if [[ -d "$temp_dir/config" ]]; then
                    cp -r "$temp_dir/config" "$INSTALL_DIR/"
                fi
                
                if [[ -f "$temp_dir/.env" ]]; then
                    cp "$temp_dir/.env" "$INSTALL_DIR/"
                fi
                
                # Set ownership
                chown -R "$SERVICE_USER:$SERVICE_USER" "$INSTALL_DIR/config" "$INSTALL_DIR/.env"
                
                rm -rf "$temp_dir"
                log "Configuration restored successfully"
            else
                error "Backup file not found: $backup_file"
                return 1
            fi
            ;;
        full)
            log "Restoring full system from: $backup_file"
            warn "Full system restore will overwrite current installation"
            read -p "Are you sure? (yes/no): " confirm
            if [[ "$confirm" == "yes" ]]; then
                # Implementation would go here
                warn "Full system restore not yet implemented"
            else
                log "Full system restore cancelled"
            fi
            ;;
        *)
            error "Unknown backup type: $backup_type"
            return 1
            ;;
    esac
}

# Print usage
print_usage() {
    echo "Usage: $0 {backup|list|restore|cleanup}"
    echo ""
    echo "Commands:"
    echo "  backup [type]     - Create backup (database|config|logs|full|all)"
    echo "  list              - List available backups"
    echo "  restore <type> <file> - Restore from backup"
    echo "  cleanup           - Remove old backups"
    echo ""
    echo "Examples:"
    echo "  $0 backup all     # Create all backups"
    echo "  $0 backup database # Create database backup only"
    echo "  $0 list           # List all backups"
    echo "  $0 cleanup        # Clean old backups"
}

# Main backup function
main() {
    check_user
    
    case "${1:-backup}" in
        backup)
            backup_type="${2:-all}"
            log "=== Starting Backup Process ==="
            
            case "$backup_type" in
                database)
                    backup_database
                    ;;
                config)
                    backup_configuration
                    ;;
                logs)
                    backup_logs "$3"
                    ;;
                full)
                    backup_full_system
                    ;;
                all)
                    backup_database
                    backup_configuration
                    backup_logs "$3"
                    export_trading_history
                    backup_full_system
                    ;;
                *)
                    error "Unknown backup type: $backup_type"
                    print_usage
                    exit 1
                    ;;
            esac
            
            verify_backups
            cleanup_old_backups
            upload_to_remote
            generate_backup_report
            
            log "=== Backup Process Complete ==="
            ;;
        list)
            list_backups
            ;;
        restore)
            restore_backup "$2" "$3"
            ;;
        cleanup)
            cleanup_old_backups
            ;;
        *)
            print_usage
            exit 1
            ;;
    esac
}

# Run main function
main "$@"