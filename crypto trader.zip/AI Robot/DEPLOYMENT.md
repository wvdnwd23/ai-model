# AI Crypto Trading System - Deployment Guide

## Overview

This guide provides comprehensive instructions for deploying the AI Crypto Trading System on Raspberry Pi 5. The system includes automated installation, configuration, monitoring, and maintenance scripts.

## System Requirements

### Hardware Requirements
- **Raspberry Pi 5** (4GB RAM minimum, 8GB recommended)
- **MicroSD Card**: 32GB minimum (Class 10 or better)
- **Power Supply**: Official Raspberry Pi 5 power adapter
- **Network**: Ethernet or Wi-Fi connection
- **Storage**: Additional USB storage recommended for backups

### Software Requirements
- **Raspberry Pi OS**: 64-bit (Bookworm or later)
- **Python**: 3.11+ (installed automatically)
- **Internet Connection**: Required for installation and operation

## Quick Start Installation

### 1. Prepare Raspberry Pi

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install git
sudo apt install git -y

# Clone repository
git clone https://github.com/your-repo/ai-crypto-trader.git
cd ai-crypto-trader
```

### 2. Run Auto-Installer

```bash
# Make installer executable
chmod +x install.sh

# Run installation (requires sudo)
sudo ./install.sh
```

The installer will:
- ✅ Optimize Raspberry Pi 5 settings
- ✅ Install Python 3.11+ and dependencies
- ✅ Install and configure Ollama with LLaMA model
- ✅ Set up Playwright browsers
- ✅ Initialize SQLite database
- ✅ Create system user and directories
- ✅ Configure systemd services
- ✅ Set up firewall and security

### 3. Configure System

```bash
# Run configuration wizard
sudo -u ai-trader python3 setup_config.py
```

Configure:
- Exchange API keys (MEXC, XT.com)
- Trading parameters and risk management
- Telegram bot notifications
- System settings

### 4. Start Services

```bash
# Start the AI trading system
sudo systemctl start ai-crypto-trader

# Enable auto-start on boot
sudo systemctl enable ai-crypto-trader

# Check status
sudo systemctl status ai-crypto-trader
```

## Detailed Installation Steps

### Pre-Installation Checklist

- [ ] Raspberry Pi 5 with fresh OS installation
- [ ] Internet connection configured
- [ ] SSH access enabled (if installing remotely)
- [ ] Exchange API keys ready
- [ ] Telegram bot token (optional)

### Installation Process

#### Step 1: System Preparation

The installer automatically:

1. **Hardware Optimization**
   - Sets GPU memory split to 128MB
   - Enables hardware acceleration
   - Increases swap to 2GB
   - Sets CPU governor to performance

2. **System Updates**
   - Updates all packages
   - Installs build tools and dependencies
   - Configures package repositories

#### Step 2: Core Dependencies

1. **Python Environment**
   ```bash
   # Python 3.11+ with virtual environment
   # All required packages from requirements.txt
   # TA-Lib compiled from source
   ```

2. **Ollama AI Platform**
   ```bash
   # Ollama service installation
   # LLaMA 3.1 8B model download
   # Service configuration and optimization
   ```

3. **Browser Automation**
   ```bash
   # Playwright with Chromium
   # Browser dependencies
   # Headless configuration
   ```

#### Step 3: Application Setup

1. **Directory Structure**
   ```
   /opt/ai-crypto-trader/
   ├── src/                 # Application source code
   ├── config/              # Configuration files
   ├── data/                # Data storage
   │   ├── database/        # SQLite database
   │   ├── logs/           # System logs
   │   ├── cache/          # Temporary data
   │   └── backups/        # Backup storage
   ├── venv/               # Python virtual environment
   └── scripts/            # Utility scripts
   ```

2. **Database Initialization**
   - Creates SQLite database with required tables
   - Sets up indexes for performance
   - Initializes configuration tables

3. **Service Configuration**
   - Creates systemd service files
   - Sets up log rotation
   - Configures auto-restart policies

## Configuration

### Environment Variables

The system uses a `.env` file for configuration:

```bash
# Ollama Configuration
OLLAMA_HOST=localhost
OLLAMA_PORT=11434
OLLAMA_MODEL=llama3.1:8b-instruct-q4_0

# Database
DATABASE_PATH=/opt/ai-crypto-trader/data/database/trading_system.db

# Trading Parameters
MAX_POSITION_SIZE=0.05
MAX_LEVERAGE=10
EMERGENCY_STOP_LOSS=5.0

# Exchange API Keys
MEXC_API_KEY=your_mexc_api_key
MEXC_API_SECRET=your_mexc_secret
MEXC_TESTNET=true

XT_API_KEY=your_xt_api_key
XT_API_SECRET=your_xt_secret
XT_TESTNET=true

# Telegram Notifications
TELEGRAM_BOT_TOKEN=your_bot_token
TELEGRAM_CHAT_ID=your_chat_id
TELEGRAM_ENABLED=true

# System Settings
LOG_LEVEL=INFO
DEBUG_MODE=false
FLASK_PORT=5050
```

### Trading Configuration

Key trading parameters in `config/trading.json`:

```json
{
  "max_position_size": 0.05,
  "max_leverage": 10,
  "min_risk_reward_ratio": 1.5,
  "stop_loss_percentage": 2.0,
  "take_profit_levels": 3,
  "max_daily_trades": 5,
  "emergency_stop_loss": 5.0
}
```

## Service Management

### Basic Commands

```bash
# Start service
sudo systemctl start ai-crypto-trader

# Stop service
sudo systemctl stop ai-crypto-trader

# Restart service
sudo systemctl restart ai-crypto-trader

# Check status
sudo systemctl status ai-crypto-trader

# View logs
sudo journalctl -u ai-crypto-trader -f

# Enable auto-start
sudo systemctl enable ai-crypto-trader
```

### Health Monitoring

```bash
# Run health check
sudo -u ai-trader ./health_check.sh

# View health status
sudo -u ai-trader ./health_check.sh status

# Brief summary
sudo -u ai-trader ./health_check.sh summary
```

### Backup Management

```bash
# Create full backup
sudo -u ai-trader ./backup.sh backup all

# Create database backup only
sudo -u ai-trader ./backup.sh backup database

# List available backups
sudo -u ai-trader ./backup.sh list

# Restore from backup
sudo ./backup.sh restore database /path/to/backup.db.gz
```

### System Updates

```bash
# Check for updates
sudo ./update.sh status

# Apply updates
sudo ./update.sh update

# Force update
sudo ./update.sh force

# Rollback to previous version
sudo ./update.sh rollback
```

## Monitoring and Maintenance

### Dashboard Access

The web dashboard is available at:
- **URL**: `http://your-pi-ip:5050`
- **Features**: 
  - Real-time trading status
  - Performance metrics
  - System health monitoring
  - Trade history
  - Configuration management

### Log Files

Important log locations:

```bash
# Main application logs
/opt/ai-crypto-trader/data/logs/system/main.log

# Trading activity
/opt/ai-crypto-trader/data/logs/trades/trades.log

# AI decisions
/opt/ai-crypto-trader/data/logs/ai_learning/decisions.log

# System errors
/opt/ai-crypto-trader/data/logs/errors/errors.log

# Health checks
/opt/ai-crypto-trader/data/logs/system/health_check.log
```

### Performance Monitoring

```bash
# System resources
htop

# Service status
systemctl status ai-crypto-trader ollama

# Database size
du -sh /opt/ai-crypto-trader/data/database/

# Log sizes
du -sh /opt/ai-crypto-trader/data/logs/

# Network connectivity
ping -c 4 8.8.8.8
```

## Troubleshooting

### Common Issues

#### 1. Service Won't Start

```bash
# Check service status
sudo systemctl status ai-crypto-trader

# Check logs
sudo journalctl -u ai-crypto-trader -n 50

# Verify dependencies
sudo systemctl status ollama
curl http://localhost:11434/api/tags
```

#### 2. High Memory Usage

```bash
# Check memory usage
free -h

# Check process memory
ps aux --sort=-%mem | head -10

# Restart services
sudo systemctl restart ai-crypto-trader
```

#### 3. Database Issues

```bash
# Check database integrity
sqlite3 /opt/ai-crypto-trader/data/database/trading_system.db "PRAGMA integrity_check;"

# Backup and restore
sudo -u ai-trader ./backup.sh backup database
sudo ./backup.sh restore database /path/to/backup.db.gz
```

#### 4. Network Connectivity

```bash
# Test internet connection
ping -c 4 8.8.8.8

# Test DNS resolution
nslookup google.com

# Check firewall
sudo ufw status
```

### Recovery Procedures

#### Complete System Recovery

1. **Stop all services**
   ```bash
   sudo systemctl stop ai-crypto-trader
   sudo systemctl stop ollama
   ```

2. **Restore from backup**
   ```bash
   sudo ./backup.sh restore full /path/to/full_backup.tar.gz
   ```

3. **Restart services**
   ```bash
   sudo systemctl start ollama
   sudo systemctl start ai-crypto-trader
   ```

#### Database Recovery

1. **Stop trading service**
   ```bash
   sudo systemctl stop ai-crypto-trader
   ```

2. **Restore database**
   ```bash
   sudo ./backup.sh restore database /path/to/backup.db.gz
   ```

3. **Restart service**
   ```bash
   sudo systemctl start ai-crypto-trader
   ```

## Security Considerations

### File Permissions

- Configuration files: `600` (owner read/write only)
- Database files: `644` (owner read/write, group read)
- Log files: `644` (owner read/write, group read)
- Scripts: `755` (executable)

### Network Security

- Firewall configured to allow only necessary ports
- Dashboard accessible only on local network
- API keys stored securely in environment files

### Access Control

- Dedicated system user (`ai-trader`)
- No root privileges for application
- Secure service configuration

## Performance Optimization

### Raspberry Pi 5 Specific

- GPU memory optimized for headless operation
- CPU governor set to performance mode
- Swap configured for AI workloads
- Hardware acceleration enabled

### Application Tuning

- Database WAL mode for better performance
- Connection pooling for external APIs
- Efficient caching strategies
- Optimized logging levels

## Maintenance Schedule

### Daily
- [ ] Check system health
- [ ] Review trading performance
- [ ] Monitor resource usage

### Weekly
- [ ] Review logs for errors
- [ ] Check backup integrity
- [ ] Update system packages

### Monthly
- [ ] Full system backup
- [ ] Performance analysis
- [ ] Security audit
- [ ] Clean old logs and backups

## Support and Updates

### Getting Help

1. Check logs for error messages
2. Run health check script
3. Review this documentation
4. Check GitHub issues

### Updating the System

The system includes automatic update capabilities:

```bash
# Check for updates
sudo ./update.sh status

# Apply updates with backup
sudo ./update.sh update

# Rollback if needed
sudo ./update.sh rollback
```

### Version Information

Check current version:
```bash
cd /opt/ai-crypto-trader
git log --oneline -1
```

## Advanced Configuration

### Custom Ollama Models

To use different AI models:

1. **Download model**
   ```bash
   sudo -u ollama ollama pull model-name
   ```

2. **Update configuration**
   ```bash
   # Edit .env file
   OLLAMA_MODEL=model-name
   ```

3. **Restart service**
   ```bash
   sudo systemctl restart ai-crypto-trader
   ```

### Remote Monitoring

Set up remote access:

1. **Configure SSH**
   ```bash
   sudo systemctl enable ssh
   ```

2. **Set up VPN** (recommended)
   ```bash
   # Install and configure WireGuard or OpenVPN
   ```

3. **Dashboard Access**
   ```bash
   # Access via VPN: http://pi-ip:5050
   ```

### High Availability Setup

For production deployment:

1. **Multiple Pi Setup**
   - Primary and backup systems
   - Shared database storage
   - Load balancing

2. **External Database**
   - PostgreSQL or MySQL
   - Backup and replication
   - Connection pooling

3. **Monitoring Integration**
   - Prometheus metrics
   - Grafana dashboards
   - Alert management

---

## Conclusion

This deployment guide provides everything needed to successfully deploy and maintain the AI Crypto Trading System on Raspberry Pi 5. The automated installation and management scripts ensure reliable operation with minimal manual intervention.

For additional support or questions, please refer to the project documentation or create an issue in the GitHub repository.