# Comprehensive SSH Passwordless Authentication Setup Guide

## Overview
This guide establishes secure, automated SSH connections to Raspberry Pi using key-based authentication, eliminating password prompts and enabling seamless deployment workflows.

## Prerequisites
- Windows 10/11 with OpenSSH client
- Raspberry Pi with SSH enabled
- Network connectivity between client and Pi

## Step 1: Generate SSH Key Pair

### Option A: Ed25519 Keys (Recommended - Modern & Secure)
```bash
# Generate Ed25519 key pair
ssh-keygen -t ed25519 -C "your-email@example.com" -f ~/.ssh/id_ed25519_pi

# When prompted:
# - Enter file location: ~/.ssh/id_ed25519_pi
# - Passphrase: (optional but recommended)
```

### Option B: RSA Keys (Legacy Compatibility)
```bash
# Generate 4096-bit RSA key pair
ssh-keygen -t rsa -b 4096 -C "your-email@example.com" -f ~/.ssh/id_rsa_pi
```

## Step 2: Copy Public Key to Raspberry Pi

### Method A: Using ssh-copy-id (Linux/WSL)
```bash
ssh-copy-id -i ~/.ssh/id_ed25519_pi.pub pi@192.168.1.91
```

### Method B: Manual Copy (Windows)
```bash
# Display public key
type %USERPROFILE%\.ssh\id_ed25519_pi.pub

# Copy output, then SSH to Pi and append to authorized_keys
ssh pi@192.168.1.91
mkdir -p ~/.ssh
echo "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5... your-email@example.com" >> ~/.ssh/authorized_keys
chmod 700 ~/.ssh
chmod 600 ~/.ssh/authorized_keys
exit
```

### Method C: SCP Transfer
```bash
# Copy public key to Pi
scp %USERPROFILE%\.ssh\id_ed25519_pi.pub pi@192.168.1.91:~/

# SSH to Pi and configure
ssh pi@192.168.1.91
mkdir -p ~/.ssh
cat ~/id_ed25519_pi.pub >> ~/.ssh/authorized_keys
chmod 700 ~/.ssh
chmod 600 ~/.ssh/authorized_keys
rm ~/id_ed25519_pi.pub
exit
```

## Step 3: Configure SSH Client Settings

### Create SSH Config File
```bash
# Windows path: %USERPROFILE%\.ssh\config
# Create/edit config file:
```

```
# Raspberry Pi Configuration
Host pi
    HostName 192.168.1.91
    User pi
    IdentityFile ~/.ssh/id_ed25519_pi
    IdentitiesOnly yes
    ServerAliveInterval 60
    ServerAliveCountMax 3
    ConnectTimeout 10

# Alternative alias for crypto trading deployment
Host crypto-pi
    HostName 192.168.1.91
    User pi
    IdentityFile ~/.ssh/id_ed25519_pi
    IdentitiesOnly yes
    Port 22
    ForwardAgent yes
    Compression yes

# Production deployment alias
Host ai-trader
    HostName 192.168.1.91
    User pi
    IdentityFile ~/.ssh/id_ed25519_pi
    IdentitiesOnly yes
    LocalForward 8080 localhost:8080
    LocalForward 5000 localhost:5000
```

## Step 4: SSH Agent Configuration

### Windows SSH Agent Setup
```bash
# Start SSH Agent service
Get-Service ssh-agent | Set-Service -StartupType Automatic
Start-Service ssh-agent

# Add private key to agent
ssh-add %USERPROFILE%\.ssh\id_ed25519_pi
```

### Verify Agent Status
```bash
# List loaded keys
ssh-add -l

# Test connection
ssh -T pi@192.168.1.91
```

## Step 5: Test Passwordless Connection

### Basic Connection Test
```bash
# Using hostname
ssh pi@192.168.1.91

# Using config alias
ssh pi
ssh crypto-pi
ssh ai-trader
```

### Advanced Connection Tests
```bash
# Test with verbose output
ssh -v pi

# Test specific key
ssh -i ~/.ssh/id_ed25519_pi pi@192.168.1.91

# Test with command execution
ssh pi "echo 'Passwordless SSH working!'"
```

## Step 6: Troubleshooting Common Issues

### Permission Problems
```bash
# Fix client-side permissions (Windows)
icacls %USERPROFILE%\.ssh\id_ed25519_pi /inheritance:r
icacls %USERPROFILE%\.ssh\id_ed25519_pi /grant:r %USERNAME%:F

# Fix server-side permissions (on Pi)
ssh pi@192.168.1.91
chmod 700 ~/.ssh
chmod 600 ~/.ssh/authorized_keys
sudo chown -R pi:pi ~/.ssh
```

### SSH Service Configuration (on Pi)
```bash
# Edit SSH daemon config
sudo nano /etc/ssh/sshd_config

# Ensure these settings:
PubkeyAuthentication yes
AuthorizedKeysFile .ssh/authorized_keys
PasswordAuthentication yes  # Keep enabled initially
PermitRootLogin no

# Restart SSH service
sudo systemctl restart ssh
```

### Debug Connection Issues
```bash
# Client-side debugging
ssh -vvv pi@192.168.1.91

# Server-side logs (on Pi)
sudo tail -f /var/log/auth.log

# Test key format
ssh-keygen -l -f ~/.ssh/id_ed25519_pi.pub
```

## Step 7: Security Hardening

### Disable Password Authentication (Optional)
```bash
# On Pi, edit SSH config
sudo nano /etc/ssh/sshd_config

# Change to:
PasswordAuthentication no
ChallengeResponseAuthentication no
UsePAM no

# Restart SSH
sudo systemctl restart ssh
```

### Firewall Configuration
```bash
# On Pi, configure UFW
sudo ufw allow ssh
sudo ufw enable
```

## Step 8: Automated Deployment Integration

### PowerShell Deployment Script
```powershell
# deploy_to_pi.ps1
$PI_HOST = "pi"
$PROJECT_PATH = "/opt/ai-crypto-trader"

# Test connection
ssh $PI_HOST "echo 'Connection successful'"

# Deploy files
scp -r ./src/* ${PI_HOST}:${PROJECT_PATH}/src/
scp requirements.txt ${PI_HOST}:${PROJECT_PATH}/

# Execute remote commands
ssh $PI_HOST "cd $PROJECT_PATH && source venv/bin/activate && pip install -r requirements.txt"
```

### Batch Deployment Commands
```bash
# Single command deployment
ssh pi "cd /opt/ai-crypto-trader && git pull && source venv/bin/activate && pip install -r requirements.txt && python test_imports.py"

# File synchronization
rsync -avz --progress ./src/ pi:/opt/ai-crypto-trader/src/

# Remote script execution
ssh pi "bash -s" < ./deploy_script.sh
```

## Step 9: Advanced SSH Features

### Port Forwarding for Development
```bash
# Forward Pi web services to local machine
ssh -L 8080:localhost:8080 -L 5000:localhost:5000 pi

# Background forwarding
ssh -f -N -L 8080:localhost:8080 pi
```

### SSH Tunneling
```bash
# Create secure tunnel
ssh -D 1080 pi

# SOCKS proxy configuration
# Configure applications to use localhost:1080
```

### File System Mounting (SSHFS)
```bash
# Install SSHFS (if available)
# Mount Pi filesystem locally
sshfs pi:/opt/ai-crypto-trader ./pi_mount
```

## Step 10: Maintenance and Monitoring

### Key Rotation Schedule
```bash
# Generate new keys annually
ssh-keygen -t ed25519 -C "renewal-$(date +%Y)" -f ~/.ssh/id_ed25519_pi_new

# Update authorized_keys on Pi
# Remove old keys after verification
```

### Connection Monitoring
```bash
# Monitor active SSH sessions (on Pi)
who
w
last

# Check SSH logs
sudo journalctl -u ssh -f
```

### Backup SSH Configuration
```bash
# Backup SSH directory
tar -czf ssh_backup_$(date +%Y%m%d).tar.gz ~/.ssh/

# Store securely and separately from system
```

## Integration with AI Crypto Trader Deployment

### Seamless Workflow Commands
```bash
# Complete deployment pipeline
ssh pi "cd /opt/ai-crypto-trader && git pull"
scp -r ./src/* pi:/opt/ai-crypto-trader/src/
ssh pi "cd /opt/ai-crypto-trader && source venv/bin/activate && python test_imports.py"
ssh pi "cd /opt/ai-crypto-trader && source venv/bin/activate && python src/main.py --test"

# Monitoring and logs
ssh pi "cd /opt/ai-crypto-trader && tail -f src/data/logs/system/main.log"

# System status check
ssh pi "cd /opt/ai-crypto-trader && source venv/bin/activate && python -c 'from src.monitoring.health_checker import HealthChecker; hc = HealthChecker(); print(hc.get_system_status())'"
```

## Verification Checklist

- [ ] SSH key pair generated successfully
- [ ] Public key copied to Pi authorized_keys
- [ ] SSH config file created with aliases
- [ ] SSH agent configured and running
- [ ] Passwordless connection tested
- [ ] File transfer (SCP/SFTP) working
- [ ] Remote command execution functional
- [ ] Port forwarding operational (if needed)
- [ ] Security settings configured
- [ ] Deployment workflow automated

## Success Indicators

✅ **Connection**: `ssh pi` connects without password prompt  
✅ **File Transfer**: `scp file.txt pi:~/` works seamlessly  
✅ **Remote Execution**: `ssh pi "python --version"` returns immediately  
✅ **Deployment**: Full project deployment completes without manual intervention  
✅ **Monitoring**: Real-time log access via SSH tunneling  

## Next Steps

With passwordless SSH established:

1. **Automated CI/CD**: Integrate with GitHub Actions or Jenkins
2. **Monitoring Dashboard**: Set up port forwarding for web interfaces
3. **Backup Automation**: Schedule automated backups via SSH
4. **Multi-Pi Management**: Extend configuration for Pi cluster
5. **Security Monitoring**: Implement SSH connection logging and alerting

---

**Note**: This configuration enables the seamless AI crypto trading system deployment workflow demonstrated in the main project, eliminating manual password entry and enabling fully automated remote operations.