#!/usr/bin/env python3
"""
Isolated Monitoring System Integration Test
Tests monitoring components without triggering full AI system imports
"""

import sys
import os
import time
from datetime import datetime

def log_test(message, status="INFO"):
    """Simple logging for test output"""
    timestamp = datetime.now().strftime("%H:%M:%S")
    status_symbol = "✓" if status == "PASS" else "✗" if status == "FAIL" else "ℹ"
    print(f"[{timestamp}] {status_symbol} {message}")

def test_monitoring_dependencies():
    """Test monitoring-specific dependencies"""
    log_test("Testing monitoring system dependencies...")
    
    dependencies = [
        ("psutil", "System monitoring"),
        ("flask", "Web framework"),
        ("flask_socketio", "WebSocket support"),
        ("aiohttp", "Async HTTP"),
        ("jinja2", "Template engine"),
        ("jwt", "JWT authentication"),
        ("flask_cors", "CORS support"),
        ("aiosmtplib", "SMTP support"),
        ("sqlite3", "Database"),
        ("threading", "Threading support"),
        ("asyncio", "Async support"),
        ("json", "JSON support"),
        ("logging", "Logging support")
    ]
    
    missing = []
    for dep, desc in dependencies:
        try:
            __import__(dep)
            log_test(f"{dep} ({desc}) available", "PASS")
        except ImportError:
            log_test(f"{dep} ({desc}) missing", "FAIL")
            missing.append(dep)
    
    return missing

def test_monitoring_config_isolated():
    """Test monitoring config without triggering full system imports"""
    log_test("Testing monitoring configuration (isolated)...")
    
    try:
        # Add current directory to path
        sys.path.insert(0, '.')
        
        # Import monitoring config directly without going through src.__init__
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "monitoring_config", 
            "src/monitoring/config.py"
        )
        config_module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(config_module)
        
        # Test config access
        config = config_module.monitoring_config
        log_test(f"Monitoring config loaded successfully", "PASS")
        log_test(f"Config has {len(config.__dict__)} sections", "INFO")
        
        return True
        
    except Exception as e:
        log_test(f"Monitoring config import failed: {str(e)}", "FAIL")
        return False

def test_monitoring_components_isolated():
    """Test individual monitoring components without full system imports"""
    log_test("Testing monitoring components (isolated)...")
    
    components = [
        ("src/monitoring/system_monitor.py", "SystemMonitor"),
        ("src/monitoring/ai_monitor.py", "AIPerformanceMonitor"),
        ("src/monitoring/alert_manager.py", "AlertManager"),
        ("src/monitoring/notification_system.py", "NotificationSystem"),
        ("src/monitoring/dashboard_backend.py", "DashboardBackend"),
        ("src/monitoring/health_checker.py", "HealthChecker"),
        ("src/monitoring/performance_profiler.py", "PerformanceProfiler"),
        ("src/monitoring/log_aggregator.py", "LogAggregator"),
        ("src/monitoring/metrics_collector.py", "MetricsCollector")
    ]
    
    results = {}
    
    for file_path, component_name in components:
        try:
            # Check if file exists
            if not os.path.exists(file_path):
                log_test(f"{component_name}: File not found", "FAIL")
                results[component_name] = False
                continue
            
            # Try to load the module without executing imports
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
                
            # Basic syntax check
            try:
                compile(content, file_path, 'exec')
                log_test(f"{component_name}: Syntax valid", "PASS")
                results[component_name] = True
            except SyntaxError as e:
                log_test(f"{component_name}: Syntax error - {e}", "FAIL")
                results[component_name] = False
                
        except Exception as e:
            log_test(f"{component_name}: Error - {str(e)}", "FAIL")
            results[component_name] = False
    
    return results

def test_monitoring_main_module():
    """Test the main monitoring module structure"""
    log_test("Testing main monitoring module...")
    
    try:
        # Check if main monitoring __init__.py exists and is valid
        init_path = "src/monitoring/__init__.py"
        if not os.path.exists(init_path):
            log_test("Monitoring __init__.py not found", "FAIL")
            return False
            
        with open(init_path, 'r', encoding='utf-8') as f:
            content = f.read()
            
        # Check for key components
        key_components = [
            "MonitoringSystem",
            "ComponentManager", 
            "DependencyResolver"
        ]
        
        found_components = []
        for component in key_components:
            if component in content:
                found_components.append(component)
                log_test(f"Found {component} in main module", "PASS")
            else:
                log_test(f"Missing {component} in main module", "FAIL")
        
        return len(found_components) == len(key_components)
        
    except Exception as e:
        log_test(f"Main module test failed: {str(e)}", "FAIL")
        return False

def main():
    """Run isolated monitoring system tests"""
    print("=" * 60)
    print("AI Crypto Trading System - Isolated Monitoring Test")
    print("=" * 60)
    
    # Test 1: Dependencies
    missing_deps = test_monitoring_dependencies()
    
    # Test 2: Configuration
    config_ok = test_monitoring_config_isolated()
    
    # Test 3: Component files
    component_results = test_monitoring_components_isolated()
    
    # Test 4: Main module
    main_module_ok = test_monitoring_main_module()
    
    # Summary
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)
    
    if missing_deps:
        print(f"❌ Missing dependencies: {', '.join(missing_deps)}")
    else:
        print("✅ All monitoring dependencies available")
    
    if config_ok:
        print("✅ Monitoring configuration loads successfully")
    else:
        print("❌ Monitoring configuration has issues")
    
    passed_components = sum(1 for result in component_results.values() if result)
    total_components = len(component_results)
    print(f"📊 Component syntax check: {passed_components}/{total_components} passed")
    
    if main_module_ok:
        print("✅ Main monitoring module structure is valid")
    else:
        print("❌ Main monitoring module has issues")
    
    # Overall assessment
    overall_ok = (
        len(missing_deps) == 0 and 
        config_ok and 
        passed_components == total_components and 
        main_module_ok
    )
    
    if overall_ok:
        print("\n🎉 Monitoring system structure is ready for integration!")
        print("Next steps: Test actual component instantiation and integration")
    else:
        print("\n⚠️  Monitoring system has issues that need to be resolved")
        print("Fix the above issues before proceeding with integration")

if __name__ == "__main__":
    main()