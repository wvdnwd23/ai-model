#!/bin/bash
echo "===== AI CRYPTO TRADING SYSTEM - RASPBERRY PI DEPLOYMENT TEST ====="
echo "Starting deployment and testing process..."
echo

# Step 1: Extract and verify files
echo "Step 1: Extracting project files..."
cd /home/pi
if [ -f "ai-crypto-trader.tar.gz" ]; then
    tar -xzf ai-crypto-trader.tar.gz
    echo "✓ Files extracted successfully"
else
    echo "✗ Archive file not found!"
    exit 1
fi

# Step 2: Create application directory
echo "Step 2: Setting up application directory..."
sudo mkdir -p /opt/ai-crypto-trader
sudo chown pi:pi /opt/ai-crypto-trader
echo "✓ Application directory created"

# Step 3: Move files
echo "Step 3: Moving files to application directory..."
cp -r src/ /opt/ai-crypto-trader/
cp *.py *.txt *.md *.sh *.service .env requirements.txt /opt/ai-crypto-trader/ 2>/dev/null || true
cd /opt/ai-crypto-trader
echo "✓ Files moved to /opt/ai-crypto-trader"

# Step 4: Verify file integrity
echo "Step 4: Verifying file integrity..."
echo "File count in src/: $(find src/ -type f | wc -l)"
echo "Total project files: $(find . -type f | wc -l)"
ls -la src/utils/config*.py
echo "✓ File integrity verified"

# Step 5: System information
echo "Step 5: System information..."
echo "OS: $(cat /etc/os-release | grep PRETTY_NAME)"
echo "Python version: $(python3 --version)"
echo "Available memory: $(free -h | grep Mem)"
echo "Disk space: $(df -h / | tail -1)"

# Step 6: Set up Python environment
echo "Step 6: Setting up Python virtual environment..."
python3 -m venv venv
source venv/bin/activate
echo "✓ Virtual environment created"

# Step 7: Install dependencies
echo "Step 7: Installing Python dependencies..."
pip install --upgrade pip
pip install -r requirements.txt
echo "✓ Dependencies installed"

# Step 8: Create necessary directories
echo "Step 8: Creating directory structure..."
mkdir -p src/data/{database,logs/{system,trades,errors,ai_learning},cache/{market_data,news_data,session_data},backups/{configs,database}}
echo "✓ Directory structure created"

# Step 9: Set permissions
echo "Step 9: Setting file permissions..."
chmod +x *.sh
chmod 644 *.service
chmod 600 .env
echo "✓ Permissions set"

# Step 10: Test Python imports
echo "Step 10: Testing Python imports..."
source venv/bin/activate

echo "Testing basic Python functionality..."
python3 -c "import sys; print(f'Python {sys.version}')"

echo "Testing minimal config import..."
python3 -c "
try:
    import src.utils.config_minimal as config
    print('✓ Minimal config import successful')
    print(f'Development mode: {config.config_manager.is_development_mode}')
    print(f'OpenAI configured: {config.config_manager.is_openai_configured()}')
except Exception as e:
    print(f'✗ Minimal config import failed: {e}')
"

echo "Testing main config import..."
python3 -c "
try:
    import src.utils.config as config
    print('✓ Main config import successful')
    cm = config.get_config_manager()
    print(f'Development mode: {cm.is_development_mode}')
    print(f'OpenAI configured: {cm.is_openai_configured()}')
except Exception as e:
    print(f'✗ Main config import failed: {e}')
"

echo "Testing core module imports..."
modules=("src.utils.logging" "src.utils.database" "src.modules.ai_controller" "src.modules.chart_checker" "src.modules.coin_scanner" "src.modules.combiner" "src.monitoring.system_monitor")

for module in "${modules[@]}"; do
    python3 -c "
try:
    import $module
    print('✓ $module import successful')
except Exception as e:
    print('✗ $module import failed: {e}')
" 2>/dev/null || echo "✗ $module import failed"
done

# Step 11: Test main application
echo "Step 11: Testing main application startup..."
timeout 10 python3 src/main.py --test 2>&1 || echo "Main application test completed (timeout expected)"

# Step 12: Performance test
echo "Step 12: Performance validation..."
echo "CPU usage: $(top -bn1 | grep "Cpu(s)" | awk '{print $2}' | cut -d'%' -f1)"
echo "Memory usage: $(free | grep Mem | awk '{printf "%.1f%%", $3/$2 * 100.0}')"
echo "Load average: $(uptime | awk -F'load average:' '{print $2}')"

echo
echo "===== DEPLOYMENT TEST COMPLETED ====="
echo "Check the output above for any errors or issues."
echo "If all tests passed, the system is ready for operation."