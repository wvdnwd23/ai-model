#!/bin/bash

# AI Crypto Trading System - OpenAI Migration Installation Script
# Optimized for Raspberry Pi 5 ARM64 Architecture
# This script migrates from OpenRouter/Ollama to OpenAI and sets up the complete system

set -e

# Configuration
INSTALL_DIR="/opt/ai-crypto-trader"
SERVICE_USER="ai-trader"
SERVICE_GROUP="ai-trader"
PYTHON_VERSION="3.11"
VENV_DIR="$INSTALL_DIR/venv"
BACKUP_DIR="$INSTALL_DIR/backup/$(date +%Y%m%d_%H%M%S)"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m'

# Logging functions
log() {
    echo -e "${GREEN}[$(date '+%Y-%m-%d %H:%M:%S')] $1${NC}"
}

warn() {
    echo -e "${YELLOW}[$(date '+%Y-%m-%d %H:%M:%S')] WARNING: $1${NC}"
}

error() {
    echo -e "${RED}[$(date '+%Y-%m-%d %H:%M:%S')] ERROR: $1${NC}"
    exit 1
}

info() {
    echo -e "${BLUE}[$(date '+%Y-%m-%d %H:%M:%S')] $1${NC}"
}

# Check if running as root
check_root() {
    if [[ $EUID -eq 0 ]]; then
        error "This script should not be run as root. Please run as a regular user with sudo privileges."
    fi
}

# Check Raspberry Pi 5 compatibility
check_raspberry_pi() {
    info "Checking Raspberry Pi 5 compatibility..."
    
    # Check if running on Raspberry Pi
    if [[ ! -f /proc/device-tree/model ]]; then
        warn "Not running on Raspberry Pi - some optimizations may not apply"
        return
    fi
    
    local model=$(cat /proc/device-tree/model 2>/dev/null | tr -d '\0')
    if [[ "$model" == *"Raspberry Pi 5"* ]]; then
        log "Detected Raspberry Pi 5 - applying ARM64 optimizations"
        export RPI5_OPTIMIZED=true
    else
        warn "Not running on Raspberry Pi 5 - detected: $model"
        export RPI5_OPTIMIZED=false
    fi
    
    # Check architecture
    local arch=$(uname -m)
    if [[ "$arch" == "aarch64" ]]; then
        log "ARM64 architecture detected"
        export ARM64_ARCH=true
    else
        warn "Non-ARM64 architecture detected: $arch"
        export ARM64_ARCH=false
    fi
}

# Check prerequisites
check_prerequisites() {
    info "Checking system prerequisites..."
    
    # Check Python version
    if ! command -v python3 >/dev/null 2>&1; then
        error "Python 3 is not installed"
    fi
    
    local python_version=$(python3 --version | cut -d' ' -f2 | cut -d'.' -f1,2)
    if [[ $(echo "$python_version >= 3.11" | bc -l) -eq 0 ]]; then
        error "Python 3.11+ is required. Found: $python_version"
    fi
    log "Python version check passed: $python_version"
    
    # Check required system packages
    local required_packages=("git" "curl" "wget" "build-essential" "python3-dev" "python3-venv" "sqlite3")
    local missing_packages=()
    
    for package in "${required_packages[@]}"; do
        if ! dpkg -l | grep -q "^ii  $package "; then
            missing_packages+=("$package")
        fi
    done
    
    if [[ ${#missing_packages[@]} -gt 0 ]]; then
        info "Installing missing system packages: ${missing_packages[*]}"
        sudo apt-get update
        sudo apt-get install -y "${missing_packages[@]}"
    fi
    
    log "System prerequisites check completed"
}

# Create backup of existing installation
create_backup() {
    if [[ -d "$INSTALL_DIR" ]]; then
        info "Creating backup of existing installation..."
        sudo mkdir -p "$BACKUP_DIR"
        
        # Backup configuration files
        if [[ -f "$INSTALL_DIR/.env" ]]; then
            sudo cp "$INSTALL_DIR/.env" "$BACKUP_DIR/.env.backup"
            log "Backed up .env file"
        fi
        
        # Backup database
        if [[ -f "$INSTALL_DIR/data/database/trading_system.db" ]]; then
            sudo mkdir -p "$BACKUP_DIR/data/database"
            sudo cp "$INSTALL_DIR/data/database/trading_system.db" "$BACKUP_DIR/data/database/"
            log "Backed up database"
        fi
        
        # Backup logs
        if [[ -d "$INSTALL_DIR/data/logs" ]]; then
            sudo cp -r "$INSTALL_DIR/data/logs" "$BACKUP_DIR/data/"
            log "Backed up logs"
        fi
        
        log "Backup created at: $BACKUP_DIR"
    fi
}

# Create service user
create_service_user() {
    info "Setting up service user..."
    
    if ! id "$SERVICE_USER" >/dev/null 2>&1; then
        sudo useradd -r -s /bin/bash -d "$INSTALL_DIR" -c "AI Crypto Trader Service" "$SERVICE_USER"
        log "Created service user: $SERVICE_USER"
    else
        log "Service user already exists: $SERVICE_USER"
    fi
    
    # Add user to gpio group for Raspberry Pi hardware access
    if [[ "$RPI5_OPTIMIZED" == "true" ]]; then
        sudo usermod -a -G gpio "$SERVICE_USER"
        log "Added $SERVICE_USER to gpio group for hardware access"
    fi
}

# Setup installation directory
setup_install_directory() {
    info "Setting up installation directory..."
    
    # Create installation directory
    sudo mkdir -p "$INSTALL_DIR"
    sudo chown "$SERVICE_USER:$SERVICE_GROUP" "$INSTALL_DIR"
    
    # Create directory structure
    local directories=(
        "src"
        "data/database"
        "data/logs/system"
        "data/logs/trades"
        "data/logs/errors"
        "data/cache"
        "config"
        "backup"
    )
    
    for dir in "${directories[@]}"; do
        sudo mkdir -p "$INSTALL_DIR/$dir"
        sudo chown "$SERVICE_USER:$SERVICE_GROUP" "$INSTALL_DIR/$dir"
    done
    
    log "Installation directory structure created"
}

# Setup Python virtual environment with ARM64 optimizations
setup_virtual_environment() {
    info "Setting up Python virtual environment with ARM64 optimizations..."
    
    # Remove old virtual environment if it exists
    if [[ -d "$VENV_DIR" ]]; then
        sudo rm -rf "$VENV_DIR"
        log "Removed existing virtual environment"
    fi
    
    # Create new virtual environment
    sudo -u "$SERVICE_USER" python3 -m venv "$VENV_DIR"
    log "Created Python virtual environment"
    
    # Upgrade pip and install wheel for ARM64 compatibility
    sudo -u "$SERVICE_USER" "$VENV_DIR/bin/pip" install --upgrade pip wheel setuptools
    
    # Install ARM64 optimized packages if on Raspberry Pi 5
    if [[ "$RPI5_OPTIMIZED" == "true" ]]; then
        info "Installing ARM64 optimized packages..."
        
        # Install numpy with OpenBLAS for better ARM64 performance
        sudo -u "$SERVICE_USER" "$VENV_DIR/bin/pip" install numpy==1.24.3 --no-cache-dir
        
        # Install other ARM64 optimized packages
        sudo -u "$SERVICE_USER" "$VENV_DIR/bin/pip" install scipy==1.11.4 --no-cache-dir
    fi
    
    log "Virtual environment setup completed"
}

# Install Python dependencies
install_dependencies() {
    info "Installing Python dependencies..."
    
    # Copy requirements.txt to install directory
    if [[ -f "requirements.txt" ]]; then
        sudo cp requirements.txt "$INSTALL_DIR/"
        sudo chown "$SERVICE_USER:$SERVICE_GROUP" "$INSTALL_DIR/requirements.txt"
    else
        error "requirements.txt not found in current directory"
    fi
    
    # Install dependencies with ARM64 optimizations
    if [[ "$ARM64_ARCH" == "true" ]]; then
        info "Installing dependencies with ARM64 optimizations..."
        
        # Set environment variables for ARM64 compilation
        export CFLAGS="-O3 -mcpu=cortex-a76"
        export CXXFLAGS="-O3 -mcpu=cortex-a76"
        
        # Install with no cache to ensure ARM64 compatibility
        sudo -u "$SERVICE_USER" "$VENV_DIR/bin/pip" install -r "$INSTALL_DIR/requirements.txt" --no-cache-dir
    else
        sudo -u "$SERVICE_USER" "$VENV_DIR/bin/pip" install -r "$INSTALL_DIR/requirements.txt"
    fi
    
    log "Python dependencies installed successfully"
}

# Install Playwright browsers
install_playwright_browsers() {
    info "Installing Playwright browsers..."
    
    # Install Playwright browsers with ARM64 support
    sudo -u "$SERVICE_USER" "$VENV_DIR/bin/playwright" install chromium
    
    # Install system dependencies for Playwright
    sudo "$VENV_DIR/bin/playwright" install-deps chromium
    
    log "Playwright browsers installed"
}

# Copy application files
copy_application_files() {
    info "Copying application files..."
    
    # Copy source code
    if [[ -d "src" ]]; then
        sudo cp -r src/* "$INSTALL_DIR/src/"
        sudo chown -R "$SERVICE_USER:$SERVICE_GROUP" "$INSTALL_DIR/src"
        log "Copied source code"
    else
        error "src directory not found"
    fi
    
    # Copy configuration files
    local config_files=(".env" "startup.sh" "health_check.sh")
    for file in "${config_files[@]}"; do
        if [[ -f "$file" ]]; then
            sudo cp "$file" "$INSTALL_DIR/"
            sudo chown "$SERVICE_USER:$SERVICE_GROUP" "$INSTALL_DIR/$file"
            log "Copied $file"
        fi
    done
    
    # Make scripts executable
    sudo chmod +x "$INSTALL_DIR/startup.sh" "$INSTALL_DIR/health_check.sh"
    
    log "Application files copied successfully"
}

# Setup OpenAI configuration
setup_openai_configuration() {
    info "Setting up OpenAI configuration..."
    
    # Create default configuration files
    sudo -u "$SERVICE_USER" "$VENV_DIR/bin/python" -c "
import sys
sys.path.append('$INSTALL_DIR/src')
from utils.config import create_default_configs
create_default_configs()
"
    
    # Prompt for OpenAI API key if not set
    if [[ -f "$INSTALL_DIR/.env" ]]; then
        local api_key=$(grep "OPENAI_API_KEY=" "$INSTALL_DIR/.env" | cut -d'=' -f2)
        if [[ -z "$api_key" || "$api_key" == "your_openai_api_key_here" ]]; then
            warn "OpenAI API key not configured in .env file"
            echo "Please edit $INSTALL_DIR/.env and set your OpenAI API key"
            echo "OPENAI_API_KEY=sk-your-actual-api-key-here"
        fi
    fi
    
    log "OpenAI configuration setup completed"
}

# Test OpenAI connectivity
test_openai_connectivity() {
    info "Testing OpenAI connectivity..."
    
    # Test OpenAI API connection
    local test_result=$(sudo -u "$SERVICE_USER" "$VENV_DIR/bin/python" -c "
import sys
sys.path.append('$INSTALL_DIR/src')
try:
    from utils.openai_client import OpenAIClient
    client = OpenAIClient()
    # Simple test - this will fail if API key is not set
    print('OpenAI client initialized successfully')
    print('SUCCESS')
except Exception as e:
    print(f'OpenAI test failed: {e}')
    print('FAILED')
" 2>/dev/null)
    
    if echo "$test_result" | grep -q "SUCCESS"; then
        log "OpenAI connectivity test passed"
    else
        warn "OpenAI connectivity test failed - please check your API key configuration"
    fi
}

# Setup systemd services
setup_systemd_services() {
    info "Setting up systemd services..."
    
    # Copy service files
    local service_files=("ai-crypto-trader.service" "ai-crypto-trader-monitoring.service")
    for service_file in "${service_files[@]}"; do
        if [[ -f "$service_file" ]]; then
            sudo cp "$service_file" "/etc/systemd/system/"
            log "Copied $service_file"
        fi
    done
    
    # Remove old Ollama service if it exists
    if [[ -f "/etc/systemd/system/ollama-enhanced.service" ]]; then
        sudo systemctl stop ollama-enhanced.service 2>/dev/null || true
        sudo systemctl disable ollama-enhanced.service 2>/dev/null || true
        sudo rm "/etc/systemd/system/ollama-enhanced.service"
        log "Removed old Ollama service"
    fi
    
    # Reload systemd and enable services
    sudo systemctl daemon-reload
    sudo systemctl enable ai-crypto-trader.service
    sudo systemctl enable ai-crypto-trader-monitoring.service
    
    log "Systemd services configured"
}

# Setup log rotation
setup_log_rotation() {
    info "Setting up log rotation..."
    
    sudo tee /etc/logrotate.d/ai-crypto-trader > /dev/null << EOF
$INSTALL_DIR/data/logs/*/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 $SERVICE_USER $SERVICE_GROUP
    postrotate
        systemctl reload ai-crypto-trader.service > /dev/null 2>&1 || true
    endscript
}
EOF
    
    log "Log rotation configured"
}

# Setup health monitoring
setup_health_monitoring() {
    info "Setting up health monitoring..."
    
    # Create health check cron job
    sudo tee /etc/cron.d/ai-crypto-trader-health > /dev/null << EOF
# AI Crypto Trader Health Check
*/5 * * * * $SERVICE_USER $INSTALL_DIR/health_check.sh check >/dev/null 2>&1
EOF
    
    log "Health monitoring configured"
}

# Optimize for Raspberry Pi 5
optimize_raspberry_pi() {
    if [[ "$RPI5_OPTIMIZED" != "true" ]]; then
        return
    fi
    
    info "Applying Raspberry Pi 5 optimizations..."
    
    # Set CPU governor to performance for better trading performance
    echo 'GOVERNOR="performance"' | sudo tee /etc/default/cpufrequtils > /dev/null
    
    # Increase GPU memory split for better browser performance
    if ! grep -q "gpu_mem=" /boot/config.txt; then
        echo "gpu_mem=128" | sudo tee -a /boot/config.txt > /dev/null
    fi
    
    # Enable hardware random number generator
    if ! grep -q "dtparam=random=on" /boot/config.txt; then
        echo "dtparam=random=on" | sudo tee -a /boot/config.txt > /dev/null
    fi
    
    # Optimize network settings for trading
    sudo tee -a /etc/sysctl.conf > /dev/null << EOF

# AI Crypto Trader optimizations
net.core.rmem_max = 16777216
net.core.wmem_max = 16777216
net.ipv4.tcp_rmem = 4096 87380 16777216
net.ipv4.tcp_wmem = 4096 65536 16777216
EOF
    
    log "Raspberry Pi 5 optimizations applied"
}

# Final validation
final_validation() {
    info "Performing final validation..."
    
    # Check if all required files exist
    local required_files=(
        "$INSTALL_DIR/src/main.py"
        "$INSTALL_DIR/.env"
        "$INSTALL_DIR/startup.sh"
        "$INSTALL_DIR/health_check.sh"
        "$VENV_DIR/bin/python"
    )
    
    for file in "${required_files[@]}"; do
        if [[ ! -f "$file" ]]; then
            error "Required file missing: $file"
        fi
    done
    
    # Check if services are properly configured
    if ! systemctl is-enabled ai-crypto-trader.service >/dev/null 2>&1; then
        error "Main service not enabled"
    fi
    
    # Test Python imports
    local import_test=$(sudo -u "$SERVICE_USER" "$VENV_DIR/bin/python" -c "
import sys
sys.path.append('$INSTALL_DIR/src')
try:
    import openai
    from utils.config import config_manager
    from utils.openai_client import OpenAIClient
    print('SUCCESS')
except Exception as e:
    print(f'FAILED: {e}')
" 2>/dev/null)
    
    if [[ "$import_test" != "SUCCESS" ]]; then
        error "Python import test failed: $import_test"
    fi
    
    log "Final validation completed successfully"
}

# Print installation summary
print_summary() {
    echo ""
    echo "=============================================="
    echo "  AI Crypto Trader - OpenAI Migration Complete"
    echo "=============================================="
    echo ""
    echo "Installation Directory: $INSTALL_DIR"
    echo "Service User: $SERVICE_USER"
    echo "Python Virtual Environment: $VENV_DIR"
    echo "Backup Location: $BACKUP_DIR"
    echo ""
    echo "Services:"
    echo "  - ai-crypto-trader.service (main trading system)"
    echo "  - ai-crypto-trader-monitoring.service (monitoring)"
    echo ""
    echo "Configuration:"
    echo "  - Edit $INSTALL_DIR/.env to set your OpenAI API key"
    echo "  - Configuration files in $INSTALL_DIR/config/"
    echo ""
    echo "Management Commands:"
    echo "  - Start: sudo systemctl start ai-crypto-trader"
    echo "  - Stop: sudo systemctl stop ai-crypto-trader"
    echo "  - Status: sudo systemctl status ai-crypto-trader"
    echo "  - Logs: sudo journalctl -u ai-crypto-trader -f"
    echo "  - Health: $INSTALL_DIR/health_check.sh"
    echo ""
    if [[ "$RPI5_OPTIMIZED" == "true" ]]; then
        echo "Raspberry Pi 5 Optimizations Applied:"
        echo "  - ARM64 compiled packages"
        echo "  - Performance CPU governor"
        echo "  - Optimized network settings"
        echo "  - Hardware RNG enabled"
        echo ""
    fi
    echo "Next Steps:"
    echo "1. Set your OpenAI API key in $INSTALL_DIR/.env"
    echo "2. Configure exchange API keys (optional)"
    echo "3. Start the service: sudo systemctl start ai-crypto-trader"
    echo "4. Monitor logs: sudo journalctl -u ai-crypto-trader -f"
    echo ""
    echo "=============================================="
}

# Main installation function
main() {
    log "Starting AI Crypto Trader OpenAI Migration Installation"
    
    check_root
    check_raspberry_pi
    check_prerequisites
    create_backup
    create_service_user
    setup_install_directory
    setup_virtual_environment
    install_dependencies
    install_playwright_browsers
    copy_application_files
    setup_openai_configuration
    test_openai_connectivity
    setup_systemd_services
    setup_log_rotation
    setup_health_monitoring
    optimize_raspberry_pi
    final_validation
    
    log "Installation completed successfully!"
    print_summary
}

# Handle command line arguments
case "${1:-install}" in
    install)
        main
        ;;
    test)
        info "Running installation test..."
        check_root
        check_raspberry_pi
        check_prerequisites
        log "Installation test completed"
        ;;
    *)
        echo "Usage: $0 {install|test}"
        echo "  install - Run full installation"
        echo "  test    - Test prerequisites only"
        exit 1
        ;;
esac