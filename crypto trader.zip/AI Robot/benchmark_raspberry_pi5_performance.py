#!/usr/bin/env python3
"""
Raspberry Pi 5 Performance Benchmarking Suite for OpenAI Migration
Comprehensive performance testing optimized for ARM64 architecture.
Tests system performance, OpenAI API efficiency, and resource utilization.
"""

import asyncio
import time
import json
import os
import sys
import psutil
import platform
import subprocess
import threading
import statistics
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, asdict
import concurrent.futures
import gc
import tracemalloc

# Add src to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

# Import system components
from src.utils.openai_client import openai_client, TaskType
from src.utils.config import config_manager
from src.utils.logging import get_logger, get_performance_logger

@dataclass
class BenchmarkResult:
    """Benchmark test result."""
    test_name: str
    duration: float
    success: bool
    metrics: Dict[str, Any]
    system_metrics: Dict[str, Any]
    error_message: Optional[str] = None

@dataclass
class SystemSnapshot:
    """System resource snapshot."""
    timestamp: datetime
    cpu_percent: float
    memory_percent: float
    memory_available_mb: float
    disk_io_read_mb: float
    disk_io_write_mb: float
    network_sent_mb: float
    network_recv_mb: float
    temperature_c: Optional[float] = None
    gpu_memory_mb: Optional[float] = None

class RaspberryPi5Monitor:
    """Raspberry Pi 5 specific monitoring."""
    
    def __init__(self):
        self.logger = get_logger("pi5_monitor")
        self.baseline_metrics = None
        self.monitoring = False
        self.metrics_history = []
        
    def get_temperature(self) -> Optional[float]:
        """Get CPU temperature."""
        try:
            if os.path.exists('/sys/class/thermal/thermal_zone0/temp'):
                with open('/sys/class/thermal/thermal_zone0/temp', 'r') as f:
                    temp = int(f.read().strip()) / 1000.0
                    return temp
        except Exception as e:
            self.logger.warning(f"Could not read temperature: {e}")
        return None
    
    def get_gpu_memory(self) -> Optional[float]:
        """Get GPU memory usage (if available)."""
        try:
            # Try to get GPU memory from vcgencmd
            result = subprocess.run(['vcgencmd', 'get_mem', 'gpu'], 
                                  capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                # Parse output like "gpu=76M"
                gpu_mem = result.stdout.strip().split('=')[1].rstrip('M')
                return float(gpu_mem)
        except Exception:
            pass
        return None
    
    def get_system_snapshot(self) -> SystemSnapshot:
        """Get current system resource snapshot."""
        # CPU and memory
        cpu_percent = psutil.cpu_percent(interval=0.1)
        memory = psutil.virtual_memory()
        
        # Disk I/O
        disk_io = psutil.disk_io_counters()
        disk_read_mb = disk_io.read_bytes / (1024 * 1024) if disk_io else 0
        disk_write_mb = disk_io.write_bytes / (1024 * 1024) if disk_io else 0
        
        # Network I/O
        net_io = psutil.net_io_counters()
        net_sent_mb = net_io.bytes_sent / (1024 * 1024) if net_io else 0
        net_recv_mb = net_io.bytes_recv / (1024 * 1024) if net_io else 0
        
        return SystemSnapshot(
            timestamp=datetime.now(),
            cpu_percent=cpu_percent,
            memory_percent=memory.percent,
            memory_available_mb=memory.available / (1024 * 1024),
            disk_io_read_mb=disk_read_mb,
            disk_io_write_mb=disk_write_mb,
            network_sent_mb=net_sent_mb,
            network_recv_mb=net_recv_mb,
            temperature_c=self.get_temperature(),
            gpu_memory_mb=self.get_gpu_memory()
        )
    
    def start_monitoring(self, interval: float = 1.0):
        """Start continuous monitoring."""
        self.monitoring = True
        self.metrics_history = []
        
        def monitor_loop():
            while self.monitoring:
                snapshot = self.get_system_snapshot()
                self.metrics_history.append(snapshot)
                time.sleep(interval)
        
        self.monitor_thread = threading.Thread(target=monitor_loop, daemon=True)
        self.monitor_thread.start()
    
    def stop_monitoring(self) -> List[SystemSnapshot]:
        """Stop monitoring and return collected metrics."""
        self.monitoring = False
        if hasattr(self, 'monitor_thread'):
            self.monitor_thread.join(timeout=2)
        return self.metrics_history.copy()
    
    def get_pi5_specific_info(self) -> Dict[str, Any]:
        """Get Raspberry Pi 5 specific information."""
        info = {}
        
        # Model information
        try:
            if os.path.exists('/proc/device-tree/model'):
                with open('/proc/device-tree/model', 'r') as f:
                    model = f.read().strip('\x00')
                    info['model'] = model
                    info['is_pi5'] = 'Raspberry Pi 5' in model
        except Exception:
            info['model'] = 'Unknown'
            info['is_pi5'] = False
        
        # CPU information
        try:
            with open('/proc/cpuinfo', 'r') as f:
                cpuinfo = f.read()
                info['cpu_cores'] = cpuinfo.count('processor')
                if 'Hardware' in cpuinfo:
                    for line in cpuinfo.split('\n'):
                        if line.startswith('Hardware'):
                            info['hardware'] = line.split(':')[1].strip()
                            break
        except Exception:
            info['cpu_cores'] = psutil.cpu_count()
        
        # Memory information
        memory = psutil.virtual_memory()
        info['memory_total_gb'] = memory.total / (1024**3)
        
        # ARM64 architecture check
        info['architecture'] = platform.machine()
        info['is_arm64'] = platform.machine() in ['aarch64', 'arm64']
        
        # GPU memory split (Pi specific)
        gpu_mem = self.get_gpu_memory()
        if gpu_mem:
            info['gpu_memory_mb'] = gpu_mem
        
        return info

class OpenAIPerformanceBenchmark:
    """OpenAI API performance benchmarking."""
    
    def __init__(self):
        self.logger = get_logger("openai_benchmark")
        self.monitor = RaspberryPi5Monitor()
        
    async def benchmark_api_latency(self, num_requests: int = 10) -> BenchmarkResult:
        """Benchmark API response latency."""
        test_start = time.time()
        self.monitor.start_monitoring(0.5)
        
        try:
            latencies = []
            successful_requests = 0
            
            for i in range(num_requests):
                request_start = time.time()
                
                try:
                    response = await openai_client.generate_response(
                        f"Test request {i+1}",
                        TaskType.GENERAL_COORDINATION,
                        max_tokens=10
                    )
                    
                    request_duration = time.time() - request_start
                    latencies.append(request_duration)
                    
                    if response and response.success:
                        successful_requests += 1
                        
                except Exception as e:
                    self.logger.warning(f"Request {i+1} failed: {e}")
                
                # Small delay between requests
                await asyncio.sleep(0.1)
            
            system_metrics = self.monitor.stop_monitoring()
            
            # Calculate statistics
            if latencies:
                avg_latency = statistics.mean(latencies)
                min_latency = min(latencies)
                max_latency = max(latencies)
                p95_latency = statistics.quantiles(latencies, n=20)[18] if len(latencies) >= 20 else max_latency
            else:
                avg_latency = min_latency = max_latency = p95_latency = 0
            
            metrics = {
                "total_requests": num_requests,
                "successful_requests": successful_requests,
                "success_rate": successful_requests / num_requests if num_requests > 0 else 0,
                "average_latency_ms": avg_latency * 1000,
                "min_latency_ms": min_latency * 1000,
                "max_latency_ms": max_latency * 1000,
                "p95_latency_ms": p95_latency * 1000,
                "requests_per_second": successful_requests / (time.time() - test_start)
            }
            
            return BenchmarkResult(
                test_name="API Latency Benchmark",
                duration=time.time() - test_start,
                success=successful_requests > 0,
                metrics=metrics,
                system_metrics=self._summarize_system_metrics(system_metrics)
            )
            
        except Exception as e:
            self.monitor.stop_monitoring()
            return BenchmarkResult(
                test_name="API Latency Benchmark",
                duration=time.time() - test_start,
                success=False,
                metrics={},
                system_metrics={},
                error_message=str(e)
            )
    
    def _summarize_system_metrics(self, snapshots: List[SystemSnapshot]) -> Dict[str, Any]:
        """Summarize system metrics from snapshots."""
        if not snapshots:
            return {}
        
        cpu_values = [s.cpu_percent for s in snapshots]
        memory_values = [s.memory_percent for s in snapshots]
        temp_values = [s.temperature_c for s in snapshots if s.temperature_c is not None]
        
        summary = {
            "duration_seconds": (snapshots[-1].timestamp - snapshots[0].timestamp).total_seconds(),
            "sample_count": len(snapshots),
            "cpu_usage": {
                "average": statistics.mean(cpu_values),
                "max": max(cpu_values),
                "min": min(cpu_values)
            },
            "memory_usage": {
                "average": statistics.mean(memory_values),
                "max": max(memory_values),
                "min": min(memory_values)
            }
        }
        
        if temp_values:
            summary["temperature"] = {
                "average": statistics.mean(temp_values),
                "max": max(temp_values),
                "min": min(temp_values)
            }
        
        # Calculate resource deltas
        if len(snapshots) >= 2:
            first, last = snapshots[0], snapshots[-1]
            summary["resource_deltas"] = {
                "disk_read_mb": last.disk_io_read_mb - first.disk_io_read_mb,
                "disk_write_mb": last.disk_io_write_mb - first.disk_io_write_mb,
                "network_sent_mb": last.network_sent_mb - first.network_sent_mb,
                "network_recv_mb": last.network_recv_mb - first.network_recv_mb
            }
        
        return summary

class RaspberryPi5BenchmarkSuite:
    """Complete benchmark suite for Raspberry Pi 5."""
    
    def __init__(self):
        self.logger = get_logger("pi5_benchmark_suite")
        self.monitor = RaspberryPi5Monitor()
        self.openai_benchmark = OpenAIPerformanceBenchmark()
        self.results = []
        
    async def run_full_benchmark_suite(self) -> Dict[str, Any]:
        """Run complete benchmark suite."""
        self.logger.system("Starting Raspberry Pi 5 benchmark suite")
        
        # Get system information
        system_info = self.monitor.get_pi5_specific_info()
        
        # Run benchmarks
        benchmarks = [
            ("System Baseline", self._benchmark_system_baseline),
            ("OpenAI API Latency", lambda: self.openai_benchmark.benchmark_api_latency(5)),
            ("Network Performance", self._benchmark_network)
        ]
        
        for benchmark_name, benchmark_func in benchmarks:
            try:
                self.logger.system(f"Running {benchmark_name} benchmark")
                result = await benchmark_func()
                self.results.append(result)
                
                if result.success:
                    self.logger.system(f"{benchmark_name} completed successfully")
                else:
                    self.logger.warning(f"{benchmark_name} failed: {result.error_message}")
                    
            except Exception as e:
                self.logger.error(f"Error in {benchmark_name}: {e}")
                self.results.append(BenchmarkResult(
                    test_name=benchmark_name,
                    duration=0,
                    success=False,
                    metrics={},
                    system_metrics={},
                    error_message=str(e)
                ))
        
        # Generate comprehensive report
        report = self._generate_benchmark_report(system_info)
        
        self.logger.system("Raspberry Pi 5 benchmark suite completed")
        return report
    
    async def _benchmark_system_baseline(self) -> BenchmarkResult:
        """Benchmark system baseline performance."""
        test_start = time.time()
        
        try:
            # CPU baseline
            cpu_times = []
            for _ in range(5):
                start = time.time()
                # Simple CPU-bound task
                sum(i * i for i in range(100000))
                cpu_times.append(time.time() - start)
            
            # Memory baseline
            memory_start = psutil.virtual_memory().used
            large_list = [i for i in range(1000000)]  # Allocate ~40MB
            memory_peak = psutil.virtual_memory().used
            del large_list
            memory_end = psutil.virtual_memory().used
            
            metrics = {
                "cpu_computation_avg_ms": statistics.mean(cpu_times) * 1000,
                "memory_allocation_mb": (memory_peak - memory_start) / (1024 * 1024),
                "memory_cleanup_mb": (memory_start - memory_end) / (1024 * 1024),
                "system_info": self.monitor.get_pi5_specific_info()
            }
            
            return BenchmarkResult(
                test_name="System Baseline",
                duration=time.time() - test_start,
                success=True,
                metrics=metrics,
                system_metrics={}
            )
            
        except Exception as e:
            return BenchmarkResult(
                test_name="System Baseline",
                duration=time.time() - test_start,
                success=False,
                metrics={},
                system_metrics={},
                error_message=str(e)
            )
    
    async def _benchmark_network(self) -> BenchmarkResult:
        """Benchmark network performance."""
        test_start = time.time()
        
        try:
            import urllib.request
            import socket
            
            # Test DNS resolution
            dns_start = time.time()
            socket.gethostbyname("google.com")
            dns_time = time.time() - dns_start
            
            # Test HTTP connectivity
            http_start = time.time()
            try:
                with urllib.request.urlopen("https://httpbin.org/get", timeout=10) as response:
                    response.read()
                http_time = time.time() - http_start
                http_success = True
            except Exception:
                http_time = time.time() - http_start
                http_success = False
            
            # Test OpenAI API connectivity
            api_start = time.time()
            try:
                response = await openai_client.generate_response(
                    "Network test",
                    TaskType.GENERAL_COORDINATION,
                    max_tokens=5
                )
                api_time = time.time() - api_start
                api_success = response.success if response else False
            except Exception:
                api_time = time.time() - api_start
                api_success = False
            
            metrics = {
                "dns_resolution_ms": dns_time * 1000,
                "http_request_ms": http_time * 1000,
                "http_success": http_success,
                "openai_api_ms": api_time * 1000,
                "openai_api_success": api_success,
                "total_network_tests": 3,
                "successful_tests": sum([True, http_success, api_success])
            }
            
            return BenchmarkResult(
                test_name="Network Performance",
                duration=time.time() - test_start,
                success=True,
                metrics=metrics,
                system_metrics={}
            )
            
        except Exception as e:
            return BenchmarkResult(
                test_name="Network Performance",
                duration=time.time() - test_start,
                success=False,
                metrics={},
                system_metrics={},
                error_message=str(e)
            )
    
    def _generate_benchmark_report(self, system_info: Dict[str, Any]) -> Dict[str, Any]:
        """Generate comprehensive benchmark report."""
        
        # Calculate overall scores
        successful_tests = sum(1 for r in self.results if r.success)
        total_tests = len(self.results)
        overall_success_rate = successful_tests / total_tests if total_tests > 0 else 0
        
        # Performance grades
        def calculate_grade(score: float) -> str:
            if score >= 0.9: return "A"
            elif score >= 0.8: return "B"
            elif score >= 0.7: return "C"
            elif score >= 0.6: return "D"
            else: return "F"
        
        # Extract key metrics
        api_latency_result = next((r for r in self.results if "API Latency" in r.test_name), None)
        
        performance_summary = {
            "overall_grade": calculate_grade(overall_success_rate),
            "success_rate": overall_success_rate,
            "total_tests": total_tests,
            "successful_tests": successful_tests,
            "failed_tests": total_tests - successful_tests
        }
        
        if api_latency_result and api_latency_result.success:
            performance_summary["api_performance"] = {
                "average_latency_ms": api_latency_result.metrics.get("average_latency_ms", 0),
                "success_rate": api_latency_result.metrics.get("success_rate", 0),
                "grade": calculate_grade(api_latency_result.metrics.get("success_rate", 0))
            }
        
        report = {
            "timestamp": datetime.now().isoformat(),
            "system_info": system_info,
            "performance_summary": performance_summary,
            "detailed_results": [asdict(result) for result in self.results],
            "recommendations": self._generate_recommendations()
        }
        
        return report
    
    def _generate_recommendations(self) -> List[str]:
        """Generate performance recommendations based on results."""
        recommendations = []
        
        # Check API performance
        api_result = next((r for r in self.results if "API Latency" in r.test_name), None)
        if api_result and api_result.success:
            avg_latency = api_result.metrics.get("average_latency_ms", 0)
            if avg_latency > 5000:
                recommendations.append("API latency is high (>5s). Consider optimizing network connection or reducing request complexity.")
            elif avg_latency > 3000:
                recommendations.append("API latency is moderate (>3s). Monitor for consistency and consider caching strategies.")
        
        # Check overall success rate
        success_rate = sum(1 for r in self.results if r.success) / len(self.results) if self.results else 0
        if success_rate < 0.8:
            recommendations.append("Low overall test success rate (<80%). Review failed tests and address underlying issues.")
        
        if not recommendations:
            recommendations.append("All benchmarks performed well. System is optimized for current workload.")
        
        return recommendations

async def main():
    """Main benchmark execution."""
    print("🚀 Starting Raspberry Pi 5 Performance Benchmark Suite")
    print("=" * 60)
    
    try:
        # Initialize benchmark suite
        benchmark_suite = RaspberryPi5BenchmarkSuite()
        
        # Run full benchmark
        report = await benchmark_suite.run_full_benchmark_suite()
        
        # Save report
        report_file = f"raspberry_pi5_benchmark_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2, default=str)
        
        # Print summary
        print("\n" + "=" * 60)
        print("📊 BENCHMARK RESULTS SUMMARY")
        print("=" * 60)
        
        perf_summary = report["performance_summary"]
        print(f"Overall Grade: {perf_summary['overall_grade']}")
        print(f"Success Rate: {perf_summary['success_rate']:.1%}")
        print(f"Tests Passed: {perf_summary['successful_tests']}/{perf_summary['total_tests']}")
        
        if "api_performance" in perf_summary:
            api_perf = perf_summary["api_performance"]
            print(f"API Latency: {api_perf['average_latency_ms']:.0f}ms (Grade: {api_perf['grade']})")
        
        print("\n📋 RECOMMENDATIONS:")
        for i, rec in enumerate(report["recommendations"], 1):
            print(f"{i}. {rec}")
        
        print(f"\n📄 Full report saved to: {report_file}")
        print("✅ Benchmark suite completed successfully!")
        
        return True
        
    except Exception as e:
        print(f"❌ Benchmark suite failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    asyncio.run(main())