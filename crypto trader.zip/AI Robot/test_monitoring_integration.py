#!/usr/bin/env python3
"""
Integration test script for the AI Crypto Trading System monitoring components.
This script systematically tests each component to identify integration issues.
"""

import sys
import os
import traceback
from datetime import datetime

def log_test(message, success=True):
    """Log test results with timestamp."""
    status = "✓" if success else "✗"
    timestamp = datetime.now().strftime("%H:%M:%S")
    print(f"[{timestamp}] {status} {message}")

def test_basic_imports():
    """Test basic Python imports."""
    log_test("Testing basic Python imports...")
    
    try:
        import time, threading, logging, json, hashlib, sqlite3
        log_test("Basic Python modules imported successfully")
        return True
    except ImportError as e:
        log_test(f"Basic Python import failed: {e}", False)
        return False

def test_external_dependencies():
    """Test external dependencies required by monitoring system."""
    log_test("Testing external dependencies...")
    
    dependencies = [
        ('psutil', 'System monitoring'),
        ('requests', 'HTTP requests'),
        ('flask', 'Web framework'),
        ('aiohttp', 'Async HTTP'),
        ('jinja2', 'Template engine'),
    ]
    
    missing_deps = []
    
    for dep_name, description in dependencies:
        try:
            __import__(dep_name)
            log_test(f"{dep_name} ({description}) available")
        except ImportError:
            log_test(f"{dep_name} ({description}) missing", False)
            missing_deps.append(dep_name)
    
    return len(missing_deps) == 0, missing_deps

def test_project_structure():
    """Test project structure and paths."""
    log_test("Testing project structure...")
    
    required_paths = [
        'src',
        'src/utils',
        'src/modules',
        'src/monitoring',
        'src/utils/database.py',
        'src/utils/logging.py',
        'src/utils/config.py',
        'src/monitoring/__init__.py',
        'src/monitoring/config.py'
    ]
    
    missing_paths = []
    
    for path in required_paths:
        if os.path.exists(path):
            log_test(f"Path exists: {path}")
        else:
            log_test(f"Path missing: {path}", False)
            missing_paths.append(path)
    
    return len(missing_paths) == 0, missing_paths

def test_monitoring_config_import():
    """Test monitoring configuration import."""
    log_test("Testing monitoring configuration import...")
    
    try:
        # Add current directory to Python path
        sys.path.insert(0, '.')
        
        from src.monitoring.config import monitoring_config
        log_test("Monitoring config imported successfully")
        
        # Test config access
        if hasattr(monitoring_config, 'alerts'):
            log_test("Config alerts section accessible")
        else:
            log_test("Config alerts section missing", False)
            
        return True
    except Exception as e:
        log_test(f"Monitoring config import failed: {e}", False)
        traceback.print_exc()
        return False

def test_utils_imports():
    """Test utility module imports."""
    log_test("Testing utility module imports...")
    
    try:
        from src.utils.logging import get_logger
        log_test("Utils logging imported successfully")
        
        from src.utils.database import db_manager
        log_test("Utils database imported successfully")
        
        from src.utils.config import Config
        log_test("Utils config imported successfully")
        
        return True
    except Exception as e:
        log_test(f"Utils import failed: {e}", False)
        traceback.print_exc()
        return False

def main():
    """Main test execution."""
    print("=" * 60)
    print("AI Crypto Trading System - Monitoring Integration Test")
    print("=" * 60)
    
    # Test basic imports
    if not test_basic_imports():
        print("\n❌ Basic imports failed. Cannot continue.")
        return False
    
    # Test external dependencies
    deps_ok, missing_deps = test_external_dependencies()
    if not deps_ok:
        print(f"\n❌ Missing dependencies: {missing_deps}")
        print("Install missing dependencies with: pip install " + " ".join(missing_deps))
        return False
    
    # Test project structure
    structure_ok, missing_paths = test_project_structure()
    if not structure_ok:
        print(f"\n❌ Missing project paths: {missing_paths}")
        return False
    
    # Test utility imports
    if not test_utils_imports():
        print("\n❌ Utility imports failed. Check utils module.")
        return False
    
    # Test monitoring config import
    if not test_monitoring_config_import():
        print("\n❌ Monitoring config import failed.")
        return False
    
    print("\n" + "=" * 60)
    print("✅ All basic integration tests passed!")
    print("✅ Ready to proceed with advanced monitoring tests.")
    print("=" * 60)
    
    return True

if __name__ == "__main__":
    try:
        success = main()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n\n❌ Test interrupted by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n❌ Unexpected error: {e}")
        traceback.print_exc()
        sys.exit(1)