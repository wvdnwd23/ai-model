#!/usr/bin/env python3
"""
Comprehensive integration test for Gemma Brain learning system.

This test validates:
- FeedbackAnalyzer integration and functionality
- SelfImprover safety mechanisms and code modification
- LearningEngine coordination and orchestration
- Integration with existing Gemma brain components
- End-to-end learning workflow
"""

import asyncio
import sys
import os
import tempfile
import shutil
import json
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import Mock, AsyncMock, patch

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.modules.gemma_brain.feedback_analyzer import (
    FeedbackAnalyzer, TradeOutcome, MarketCondition, AnalysisType,
    TradeOutcomeData, FeedbackInsights
)
from src.modules.gemma_brain.self_improver import (
    SelfImprover, ImprovementType, SafetyLevel, ModificationStatus,
    CodeModification
)
from src.modules.gemma_brain.learning_engine import (
    LearningEngine, LearningPhase, LearningStrategy, LearningPriority,
    LearningTask, LearningMetrics
)

class MockGemmaBrain:
    """Mock Gemma Brain for testing."""
    
    def __init__(self):
        self.decisions = []
        self.feedback_data = []
        
    def create_mock_decision(self, decision_id: str, confidence: float = 0.8):
        """Create a mock decision object."""
        decision = Mock()
        decision.decision_id = decision_id
        decision.timestamp = datetime.now()
        decision.confidence = confidence
        decision.reasoning = f"Mock reasoning for decision {decision_id}"
        decision.data = {
            "strategy_version": "1.0",
            "market_condition": "bull",
            "rsi": 65.0,
            "bollinger_position": "upper",
            "volume_ratio": 1.2,
            "trend_strength": 0.8
        }
        return decision

class TestGemmaLearningIntegration:
    """Integration test suite for Gemma learning system."""
    
    def __init__(self):
        self.mock_brain = MockGemmaBrain()
        self.feedback_analyzer = None
        self.self_improver = None
        self.learning_engine = None
        self.test_results = []
        self.temp_dir = None
        
    async def setup(self):
        """Set up test environment."""
        print("🔧 Setting up test environment...")
        
        # Create temporary directory for backups
        self.temp_dir = tempfile.mkdtemp()
        
        # Initialize components
        self.feedback_analyzer = FeedbackAnalyzer(self.mock_brain)
        self.self_improver = SelfImprover(self.mock_brain)
        self.learning_engine = LearningEngine(self.mock_brain)
        
        # Override backup directory for testing
        self.self_improver.backup_directory = Path(self.temp_dir) / "backups"
        self.self_improver.backup_directory.mkdir(parents=True, exist_ok=True)
        
        # Set up learning engine components
        self.learning_engine.set_components(self.feedback_analyzer, self.self_improver)
        
        # Mock database operations
        self._mock_database_operations()
        
        # Initialize components
        await self.feedback_analyzer.initialize()
        await self.self_improver.initialize()
        await self.learning_engine.initialize()
        
        print("✅ Test environment setup complete")
    
    def _mock_database_operations(self):
        """Mock database operations for testing."""
        with patch('src.utils.database.db_manager') as mock_db:
            mock_db.get_trades.return_value = []
            mock_db.get_learning_data.return_value = []
            mock_db.insert_learning_data.return_value = True
    
    async def teardown(self):
        """Clean up test environment."""
        print("🧹 Cleaning up test environment...")
        
        # Shutdown learning engine
        if self.learning_engine:
            await self.learning_engine.shutdown()
        
        # Clean up temporary directory
        if self.temp_dir and os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
        
        print("✅ Test environment cleanup complete")
    
    async def test_feedback_analyzer_basic_functionality(self):
        """Test basic feedback analyzer functionality."""
        print("\n📊 Testing FeedbackAnalyzer basic functionality...")
        
        try:
            # Create mock decision and feedback
            decision = self.mock_brain.create_mock_decision("test_001", 0.85)
            feedback_data = {
                "trade_info": {
                    "trade_id": 1,
                    "symbol": "BTCUSDT",
                    "side": "long",
                    "entry_price": 50000.0,
                    "exit_price": 51000.0,
                    "quantity": 0.1,
                    "leverage": 2,
                    "pnl": 100.0,
                    "pnl_percentage": 2.0,
                    "exit_time": (datetime.now() + timedelta(minutes=30)).isoformat(),
                    "stop_loss_hit": False,
                    "take_profit_hit": True
                },
                "metadata": {
                    "test_trade": True
                }
            }
            
            # Process feedback
            insights = await self.feedback_analyzer.process_feedback(decision, feedback_data)
            
            # Validate results
            assert insights is not None, "Insights should not be None"
            assert insights.confidence > 0, "Insights confidence should be positive"
            assert len(insights.actionable_recommendations) >= 0, "Should have recommendations"
            
            # Test pattern analysis
            pattern_insights = await self.feedback_analyzer.analyze_trading_patterns(7)
            assert pattern_insights is not None, "Pattern insights should not be None"
            
            self.test_results.append({
                "test": "feedback_analyzer_basic",
                "status": "PASSED",
                "details": f"Processed feedback with confidence {insights.confidence:.2f}"
            })
            
            print("✅ FeedbackAnalyzer basic functionality test passed")
            
        except Exception as e:
            self.test_results.append({
                "test": "feedback_analyzer_basic",
                "status": "FAILED",
                "error": str(e)
            })
            print(f"❌ FeedbackAnalyzer basic functionality test failed: {e}")
    
    async def test_self_improver_safety_mechanisms(self):
        """Test self-improver safety mechanisms."""
        print("\n🛡️ Testing SelfImprover safety mechanisms...")
        
        try:
            # Create a test file for modification
            test_file = Path(self.temp_dir) / "test_code.py"
            test_file.write_text("confidence_threshold = 0.8\n")
            
            # Create a safe modification
            safe_modification = CodeModification(
                modification_id="test_safe_001",
                improvement_type=ImprovementType.PARAMETER_OPTIMIZATION,
                safety_level=SafetyLevel.SAFE,
                target_file=str(test_file),
                target_function="test_function",
                original_code="confidence_threshold = 0.8",
                modified_code="confidence_threshold = 0.7",
                reasoning="Test safe modification",
                expected_improvement="Improved confidence calibration",
                confidence=0.9,
                timestamp=datetime.now(),
                status=ModificationStatus.PROPOSED,
                validation_results={},
                test_results={},
                performance_metrics={}
            )
            
            # Test modification proposal
            success = await self.self_improver.propose_modification(safe_modification)
            assert success, "Safe modification should be proposed successfully"
            
            # Test modification application
            success = await self.self_improver.apply_modification("test_safe_001")
            assert success, "Safe modification should be applied successfully"
            
            # Verify backup was created
            assert safe_modification.backup_path is not None, "Backup should be created"
            assert os.path.exists(safe_modification.backup_path), "Backup file should exist"
            
            # Test rollback
            rollback_success = await self.self_improver.rollback_modification(
                "test_safe_001", "Test rollback"
            )
            assert rollback_success, "Rollback should be successful"
            
            # Verify file was restored
            restored_content = test_file.read_text()
            assert "confidence_threshold = 0.8" in restored_content, "File should be restored"
            
            self.test_results.append({
                "test": "self_improver_safety",
                "status": "PASSED",
                "details": "Safety mechanisms working correctly"
            })
            
            print("✅ SelfImprover safety mechanisms test passed")
            
        except Exception as e:
            self.test_results.append({
                "test": "self_improver_safety",
                "status": "FAILED",
                "error": str(e)
            })
            print(f"❌ SelfImprover safety mechanisms test failed: {e}")
    
    async def test_learning_engine_coordination(self):
        """Test learning engine coordination capabilities."""
        print("\n🎯 Testing LearningEngine coordination...")
        
        try:
            # Test learning task creation and scheduling
            decision = self.mock_brain.create_mock_decision("coord_001", 0.75)
            outcome_data = {
                "trade_info": {
                    "trade_id": 2,
                    "symbol": "ETHUSDT",
                    "side": "short",
                    "entry_price": 3000.0,
                    "exit_price": 2950.0,
                    "quantity": 1.0,
                    "leverage": 3,
                    "pnl": 150.0,
                    "pnl_percentage": 5.0,
                    "exit_time": (datetime.now() + timedelta(minutes=45)).isoformat()
                }
            }
            
            # Process trading outcome
            await self.learning_engine.process_trading_outcome(decision, outcome_data)
            
            # Verify task was created
            assert len(self.learning_engine.active_tasks) > 0, "Learning task should be created"
            
            # Test learning progress evaluation
            metrics = await self.learning_engine.evaluate_learning_progress()
            assert metrics is not None, "Learning metrics should be generated"
            assert isinstance(metrics, LearningMetrics), "Should return LearningMetrics object"
            
            # Test strategy adaptation
            await self.learning_engine.adapt_learning_strategy(metrics.to_dict())
            
            # Test phase transition
            await self.learning_engine.transition_learning_phase(
                LearningPhase.EXPLORATION, "Test transition"
            )
            assert self.learning_engine.current_phase == LearningPhase.EXPLORATION
            
            # Get learning statistics
            stats = self.learning_engine.get_learning_statistics()
            assert isinstance(stats, dict), "Statistics should be a dictionary"
            assert "current_phase" in stats, "Should include current phase"
            
            self.test_results.append({
                "test": "learning_engine_coordination",
                "status": "PASSED",
                "details": f"Coordinated learning with {len(self.learning_engine.active_tasks)} active tasks"
            })
            
            print("✅ LearningEngine coordination test passed")
            
        except Exception as e:
            self.test_results.append({
                "test": "learning_engine_coordination",
                "status": "FAILED",
                "error": str(e)
            })
            print(f"❌ LearningEngine coordination test failed: {e}")
    
    async def test_end_to_end_learning_workflow(self):
        """Test complete end-to-end learning workflow."""
        print("\n🔄 Testing end-to-end learning workflow...")
        
        try:
            # Simulate a series of trading decisions and outcomes
            decisions_and_outcomes = [
                {
                    "decision": self.mock_brain.create_mock_decision("e2e_001", 0.9),
                    "outcome": {
                        "trade_info": {
                            "trade_id": 3,
                            "symbol": "BTCUSDT",
                            "side": "long",
                            "entry_price": 52000.0,
                            "exit_price": 51000.0,  # Loss
                            "quantity": 0.05,
                            "leverage": 2,
                            "pnl": -50.0,
                            "pnl_percentage": -1.9,
                            "exit_time": (datetime.now() + timedelta(minutes=15)).isoformat(),
                            "stop_loss_hit": True
                        }
                    }
                },
                {
                    "decision": self.mock_brain.create_mock_decision("e2e_002", 0.6),
                    "outcome": {
                        "trade_info": {
                            "trade_id": 4,
                            "symbol": "ETHUSDT",
                            "side": "long",
                            "entry_price": 3100.0,
                            "exit_price": 3200.0,  # Win
                            "quantity": 0.5,
                            "leverage": 2,
                            "pnl": 100.0,
                            "pnl_percentage": 3.2,
                            "exit_time": (datetime.now() + timedelta(minutes=60)).isoformat(),
                            "take_profit_hit": True
                        }
                    }
                }
            ]
            
            # Process each decision-outcome pair
            for i, data in enumerate(decisions_and_outcomes):
                await self.learning_engine.process_trading_outcome(
                    data["decision"], data["outcome"]
                )
                
                # Allow some processing time
                await asyncio.sleep(0.1)
            
            # Wait for some task processing
            await asyncio.sleep(0.5)
            
            # Verify learning activities occurred
            assert len(self.learning_engine.completed_tasks) >= 0, "Should have completed tasks"
            
            # Check feedback analyzer statistics
            feedback_stats = self.feedback_analyzer.get_analysis_statistics()
            assert feedback_stats["total_analyses"] >= 0, "Should have analysis statistics"
            
            # Check self-improver statistics
            improver_stats = self.self_improver.get_improvement_statistics()
            assert "active_modifications" in improver_stats, "Should have improvement statistics"
            
            # Evaluate overall learning progress
            final_metrics = await self.learning_engine.evaluate_learning_progress()
            assert final_metrics.timestamp is not None, "Should have final metrics"
            
            self.test_results.append({
                "test": "end_to_end_workflow",
                "status": "PASSED",
                "details": f"Processed {len(decisions_and_outcomes)} decision-outcome pairs"
            })
            
            print("✅ End-to-end learning workflow test passed")
            
        except Exception as e:
            self.test_results.append({
                "test": "end_to_end_workflow",
                "status": "FAILED",
                "error": str(e)
            })
            print(f"❌ End-to-end learning workflow test failed: {e}")
    
    async def test_error_handling_and_resilience(self):
        """Test error handling and system resilience."""
        print("\n🛠️ Testing error handling and resilience...")
        
        try:
            # Test feedback analyzer with invalid data
            decision = self.mock_brain.create_mock_decision("error_001", 0.8)
            invalid_feedback = {"invalid": "data"}
            
            insights = await self.feedback_analyzer.process_feedback(decision, invalid_feedback)
            assert insights is not None, "Should handle invalid feedback gracefully"
            
            # Test self-improver with invalid modification
            invalid_modification = CodeModification(
                modification_id="invalid_001",
                improvement_type=ImprovementType.PARAMETER_OPTIMIZATION,
                safety_level=SafetyLevel.SAFE,
                target_file="/nonexistent/file.py",
                target_function="nonexistent_function",
                original_code="invalid code",
                modified_code="more invalid code",
                reasoning="Test invalid modification",
                expected_improvement="None",
                confidence=0.5,
                timestamp=datetime.now(),
                status=ModificationStatus.PROPOSED,
                validation_results={},
                test_results={},
                performance_metrics={}
            )
            
            success = await self.self_improver.propose_modification(invalid_modification)
            assert not success, "Should reject invalid modifications"
            
            # Test learning engine with corrupted data
            await self.learning_engine.process_trading_outcome(None, {})
            
            # System should still be functional
            stats = self.learning_engine.get_learning_statistics()
            assert stats is not None, "Should still provide statistics after errors"
            
            self.test_results.append({
                "test": "error_handling",
                "status": "PASSED",
                "details": "System handled errors gracefully"
            })
            
            print("✅ Error handling and resilience test passed")
            
        except Exception as e:
            self.test_results.append({
                "test": "error_handling",
                "status": "FAILED",
                "error": str(e)
            })
            print(f"❌ Error handling and resilience test failed: {e}")
    
    async def test_performance_and_scalability(self):
        """Test performance and scalability characteristics."""
        print("\n⚡ Testing performance and scalability...")
        
        try:
            start_time = datetime.now()
            
            # Process multiple decisions rapidly
            decisions = []
            for i in range(10):
                decision = self.mock_brain.create_mock_decision(f"perf_{i:03d}", 0.7 + (i * 0.02))
                outcome = {
                    "trade_info": {
                        "trade_id": 100 + i,
                        "symbol": "BTCUSDT",
                        "side": "long" if i % 2 == 0 else "short",
                        "entry_price": 50000.0 + (i * 100),
                        "exit_price": 50000.0 + (i * 100) + (50 if i % 2 == 0 else -50),
                        "quantity": 0.01,
                        "leverage": 2,
                        "pnl": 5.0 if i % 2 == 0 else -5.0,
                        "pnl_percentage": 0.1 if i % 2 == 0 else -0.1,
                        "exit_time": (datetime.now() + timedelta(minutes=i)).isoformat()
                    }
                }
                
                await self.learning_engine.process_trading_outcome(decision, outcome)
                decisions.append((decision, outcome))
            
            # Allow processing time
            await asyncio.sleep(1.0)
            
            end_time = datetime.now()
            processing_time = (end_time - start_time).total_seconds()
            
            # Verify performance
            assert processing_time < 10.0, f"Processing should be fast, took {processing_time:.2f}s"
            
            # Check memory usage (basic check)
            active_tasks = len(self.learning_engine.active_tasks)
            completed_tasks = len(self.learning_engine.completed_tasks)
            
            assert active_tasks + completed_tasks >= len(decisions), "Should track all tasks"
            
            self.test_results.append({
                "test": "performance_scalability",
                "status": "PASSED",
                "details": f"Processed {len(decisions)} decisions in {processing_time:.2f}s"
            })
            
            print("✅ Performance and scalability test passed")
            
        except Exception as e:
            self.test_results.append({
                "test": "performance_scalability",
                "status": "FAILED",
                "error": str(e)
            })
            print(f"❌ Performance and scalability test failed: {e}")
    
    def print_test_summary(self):
        """Print comprehensive test summary."""
        print("\n" + "="*80)
        print("🧪 GEMMA LEARNING INTEGRATION TEST SUMMARY")
        print("="*80)
        
        passed_tests = [t for t in self.test_results if t["status"] == "PASSED"]
        failed_tests = [t for t in self.test_results if t["status"] == "FAILED"]
        
        print(f"📊 Total Tests: {len(self.test_results)}")
        print(f"✅ Passed: {len(passed_tests)}")
        print(f"❌ Failed: {len(failed_tests)}")
        print(f"📈 Success Rate: {len(passed_tests)/len(self.test_results)*100:.1f}%")
        
        if passed_tests:
            print(f"\n✅ PASSED TESTS ({len(passed_tests)}):")
            for test in passed_tests:
                print(f"   • {test['test']}: {test.get('details', 'OK')}")
        
        if failed_tests:
            print(f"\n❌ FAILED TESTS ({len(failed_tests)}):")
            for test in failed_tests:
                print(f"   • {test['test']}: {test.get('error', 'Unknown error')}")
        
        print("\n" + "="*80)
        
        # Component-specific summaries
        if self.feedback_analyzer:
            print("📊 FeedbackAnalyzer Statistics:")
            stats = self.feedback_analyzer.get_analysis_statistics()
            for key, value in stats.items():
                print(f"   • {key}: {value}")
        
        if self.self_improver:
            print("\n🛡️ SelfImprover Statistics:")
            stats = self.self_improver.get_improvement_statistics()
            for key, value in stats.items():
                print(f"   • {key}: {value}")
        
        if self.learning_engine:
            print("\n🎯 LearningEngine Statistics:")
            stats = self.learning_engine.get_learning_statistics()
            for key, value in stats.items():
                if isinstance(value, dict):
                    print(f"   • {key}: {len(value)} items")
                else:
                    print(f"   • {key}: {value}")
        
        print("="*80)
        
        return len(failed_tests) == 0

async def main():
    """Run the complete integration test suite."""
    print("🚀 Starting Gemma Learning Integration Tests")
    print("="*80)
    
    test_suite = TestGemmaLearningIntegration()
    
    try:
        # Setup
        await test_suite.setup()
        
        # Run all tests
        await test_suite.test_feedback_analyzer_basic_functionality()
        await test_suite.test_self_improver_safety_mechanisms()
        await test_suite.test_learning_engine_coordination()
        await test_suite.test_end_to_end_learning_workflow()
        await test_suite.test_error_handling_and_resilience()
        await test_suite.test_performance_and_scalability()
        
        # Print summary
        success = test_suite.print_test_summary()
        
        if success:
            print("\n🎉 ALL TESTS PASSED! Gemma learning system is ready for deployment.")
            return 0
        else:
            print("\n⚠️ SOME TESTS FAILED! Please review and fix issues before deployment.")
            return 1
            
    except Exception as e:
        print(f"\n💥 CRITICAL ERROR during testing: {e}")
        return 1
        
    finally:
        # Cleanup
        await test_suite.teardown()

if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)