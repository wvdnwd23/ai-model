#!/bin/bash
# OpenAI Migration Deployment Validation Script
# Comprehensive validation for AI Crypto Trading System OpenAI deployment
# Optimized for Raspberry Pi 5 ARM64 architecture

set -euo pipefail

# Script configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="${SCRIPT_DIR}/validation_logs/openai_deployment_validation_$(date +%Y%m%d_%H%M%S).log"
VALIDATION_REPORT="${SCRIPT_DIR}/validation_logs/openai_validation_report_$(date +%Y%m%d_%H%M%S).json"
TEMP_DIR="/tmp/openai_validation_$$"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Validation results
VALIDATION_RESULTS=()
TOTAL_CHECKS=0
PASSED_CHECKS=0
FAILED_CHECKS=0
WARNING_CHECKS=0

# Create necessary directories
mkdir -p "$(dirname "$LOG_FILE")"
mkdir -p "$TEMP_DIR"

# Cleanup function
cleanup() {
    rm -rf "$TEMP_DIR"
}
trap cleanup EXIT

# Logging functions
log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" | tee -a "$LOG_FILE"
}

log_info() {
    echo -e "${BLUE}[INFO]${NC} $1" | tee -a "$LOG_FILE"
}

log_success() {
    echo -e "${GREEN}[PASS]${NC} $1" | tee -a "$LOG_FILE"
    ((PASSED_CHECKS++))
}

log_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1" | tee -a "$LOG_FILE"
    ((WARNING_CHECKS++))
}

log_error() {
    echo -e "${RED}[FAIL]${NC} $1" | tee -a "$LOG_FILE"
    ((FAILED_CHECKS++))
}

# Add validation result
add_result() {
    local check_name="$1"
    local status="$2"
    local details="$3"
    
    VALIDATION_RESULTS+=("{\"check\":\"$check_name\",\"status\":\"$status\",\"details\":\"$details\",\"timestamp\":\"$(date -Iseconds)\"}")
    ((TOTAL_CHECKS++))
}

# System information gathering
get_system_info() {
    log_info "Gathering system information..."
    
    local system_info=""
    system_info+="Platform: $(uname -a)\n"
    system_info+="Architecture: $(uname -m)\n"
    system_info+="OS: $(cat /etc/os-release | grep PRETTY_NAME | cut -d'"' -f2 2>/dev/null || echo 'Unknown')\n"
    system_info+="CPU Cores: $(nproc)\n"
    system_info+="Memory: $(free -h | awk '/^Mem:/ {print $2}')\n"
    system_info+="Disk Space: $(df -h / | awk 'NR==2 {print $4 " available of " $2}')\n"
    
    # Raspberry Pi specific checks
    if [[ -f /proc/device-tree/model ]]; then
        local pi_model=$(cat /proc/device-tree/model 2>/dev/null | tr -d '\0')
        system_info+="Raspberry Pi Model: $pi_model\n"
    fi
    
    # Temperature check for Raspberry Pi
    if [[ -f /sys/class/thermal/thermal_zone0/temp ]]; then
        local temp=$(cat /sys/class/thermal/thermal_zone0/temp)
        local temp_c=$((temp / 1000))
        system_info+="CPU Temperature: ${temp_c}°C\n"
    fi
    
    echo -e "$system_info"
}

# Check Python environment
check_python_environment() {
    log_info "Validating Python environment..."
    
    # Check Python version
    if command -v python3 &> /dev/null; then
        local python_version=$(python3 --version 2>&1)
        log_success "Python available: $python_version"
        add_result "python_version" "pass" "$python_version"
        
        # Check if Python 3.11+ (required for Raspberry Pi 5 ARM64)
        local version_check=$(python3 -c "import sys; print(sys.version_info >= (3, 11))" 2>/dev/null)
        if [[ "$version_check" == "True" ]]; then
            log_success "Python version meets requirements (3.11+)"
            add_result "python_version_requirement" "pass" "Python 3.11+ detected"
        else
            log_warning "Python version may not be optimal for Raspberry Pi 5 (recommend 3.11+)"
            add_result "python_version_requirement" "warning" "Python version below 3.11"
        fi
    else
        log_error "Python3 not found"
        add_result "python_version" "fail" "Python3 not available"
        return 1
    fi
    
    # Check pip
    if command -v pip3 &> /dev/null; then
        log_success "pip3 available"
        add_result "pip_availability" "pass" "pip3 found"
    else
        log_error "pip3 not found"
        add_result "pip_availability" "fail" "pip3 not available"
    fi
    
    # Check virtual environment
    if [[ -n "${VIRTUAL_ENV:-}" ]]; then
        log_success "Virtual environment active: $VIRTUAL_ENV"
        add_result "virtual_environment" "pass" "Active virtual environment: $VIRTUAL_ENV"
    else
        log_warning "No virtual environment detected (recommended for deployment)"
        add_result "virtual_environment" "warning" "No virtual environment active"
    fi
}

# Check required dependencies
check_dependencies() {
    log_info "Checking required dependencies..."
    
    local required_packages=(
        "openai"
        "numpy"
        "pandas"
        "requests"
        "aiohttp"
        "psutil"
        "python-dotenv"
        "pydantic"
        "loguru"
    )
    
    local missing_packages=()
    local installed_packages=()
    
    for package in "${required_packages[@]}"; do
        if python3 -c "import $package" &> /dev/null; then
            local version=$(python3 -c "import $package; print(getattr($package, '__version__', 'unknown'))" 2>/dev/null)
            log_success "Package $package installed (version: $version)"
            installed_packages+=("$package:$version")
            add_result "dependency_$package" "pass" "Installed version: $version"
        else
            log_error "Package $package not found"
            missing_packages+=("$package")
            add_result "dependency_$package" "fail" "Package not installed"
        fi
    done
    
    # Check OpenAI specific version
    if python3 -c "import openai" &> /dev/null; then
        local openai_version=$(python3 -c "import openai; print(openai.__version__)" 2>/dev/null)
        local version_check=$(python3 -c "
import openai
from packaging import version
required = version.parse('1.12.0')
current = version.parse(openai.__version__)
print(current >= required)
" 2>/dev/null || echo "False")
        
        if [[ "$version_check" == "True" ]]; then
            log_success "OpenAI package version meets requirements: $openai_version"
            add_result "openai_version_requirement" "pass" "Version $openai_version >= 1.12.0"
        else
            log_warning "OpenAI package version may be outdated: $openai_version (recommend 1.12.0+)"
            add_result "openai_version_requirement" "warning" "Version $openai_version may be outdated"
        fi
    fi
    
    # ARM64 specific packages for Raspberry Pi 5
    local arm64_packages=("RPi.GPIO" "gpiozero")
    for package in "${arm64_packages[@]}"; do
        if python3 -c "import $package" &> /dev/null; then
            log_success "ARM64 package $package available"
            add_result "arm64_$package" "pass" "Package available"
        else
            log_warning "ARM64 package $package not found (optional for GPIO features)"
            add_result "arm64_$package" "warning" "Package not installed"
        fi
    done
    
    if [[ ${#missing_packages[@]} -gt 0 ]]; then
        log_error "Missing required packages: ${missing_packages[*]}"
        return 1
    fi
}

# Check OpenAI API configuration
check_openai_configuration() {
    log_info "Validating OpenAI API configuration..."
    
    # Check environment variables
    if [[ -n "${OPENAI_API_KEY:-}" ]]; then
        local key_length=${#OPENAI_API_KEY}
        if [[ $key_length -gt 20 ]]; then
            log_success "OPENAI_API_KEY environment variable set (length: $key_length)"
            add_result "openai_api_key_env" "pass" "API key configured in environment"
            
            # Validate key format
            if [[ "$OPENAI_API_KEY" =~ ^sk-[a-zA-Z0-9]{48,}$ ]]; then
                log_success "OpenAI API key format appears valid"
                add_result "openai_api_key_format" "pass" "Key format valid"
            else
                log_warning "OpenAI API key format may be invalid"
                add_result "openai_api_key_format" "warning" "Key format unusual"
            fi
        else
            log_error "OPENAI_API_KEY appears too short"
            add_result "openai_api_key_env" "fail" "API key too short"
        fi
    else
        log_error "OPENAI_API_KEY environment variable not set"
        add_result "openai_api_key_env" "fail" "API key not configured"
    fi
    
    # Check .env file
    if [[ -f "$SCRIPT_DIR/.env" ]]; then
        log_success ".env file found"
        add_result "env_file" "pass" ".env file exists"
        
        # Check if .env contains OpenAI configuration
        if grep -q "OPENAI_API_KEY" "$SCRIPT_DIR/.env"; then
            log_success ".env file contains OpenAI configuration"
            add_result "env_openai_config" "pass" "OpenAI config in .env"
        else
            log_warning ".env file exists but no OpenAI configuration found"
            add_result "env_openai_config" "warning" "No OpenAI config in .env"
        fi
    else
        log_warning ".env file not found"
        add_result "env_file" "warning" ".env file missing"
    fi
    
    # Test API connectivity
    if [[ -n "${OPENAI_API_KEY:-}" ]]; then
        log_info "Testing OpenAI API connectivity..."
        
        local api_test_result=$(curl -s -w "%{http_code}" -o "$TEMP_DIR/api_test.json" \
            -H "Authorization: Bearer $OPENAI_API_KEY" \
            -H "Content-Type: application/json" \
            -d '{
                "model": "gpt-4o-mini",
                "messages": [{"role": "user", "content": "test"}],
                "max_tokens": 5
            }' \
            "https://api.openai.com/v1/chat/completions" 2>/dev/null || echo "000")
        
        if [[ "$api_test_result" == "200" ]]; then
            log_success "OpenAI API connectivity test passed"
            add_result "openai_api_connectivity" "pass" "API accessible"
            
            # Check response content
            if [[ -f "$TEMP_DIR/api_test.json" ]]; then
                local model_used=$(jq -r '.model // "unknown"' "$TEMP_DIR/api_test.json" 2>/dev/null || echo "unknown")
                log_success "API response received, model: $model_used"
                add_result "openai_api_response" "pass" "Model: $model_used"
            fi
        elif [[ "$api_test_result" == "401" ]]; then
            log_error "OpenAI API authentication failed (invalid API key)"
            add_result "openai_api_connectivity" "fail" "Authentication failed"
        elif [[ "$api_test_result" == "429" ]]; then
            log_warning "OpenAI API rate limit exceeded"
            add_result "openai_api_connectivity" "warning" "Rate limited"
        else
            log_error "OpenAI API connectivity test failed (HTTP $api_test_result)"
            add_result "openai_api_connectivity" "fail" "HTTP $api_test_result"
        fi
    fi
}

# Check system configuration
check_system_configuration() {
    log_info "Validating system configuration..."
    
    # Check file permissions
    local config_files=("$SCRIPT_DIR/.env" "$SCRIPT_DIR/src/utils/config.py")
    for file in "${config_files[@]}"; do
        if [[ -f "$file" ]]; then
            local perms=$(stat -c "%a" "$file" 2>/dev/null || echo "unknown")
            if [[ "$perms" =~ ^[67][04][04]$ ]]; then
                log_success "File permissions secure for $file ($perms)"
                add_result "file_permissions_$(basename "$file")" "pass" "Permissions: $perms"
            else
                log_warning "File permissions may be too permissive for $file ($perms)"
                add_result "file_permissions_$(basename "$file")" "warning" "Permissions: $perms"
            fi
        fi
    done
    
    # Check directory structure
    local required_dirs=(
        "$SCRIPT_DIR/src"
        "$SCRIPT_DIR/src/utils"
        "$SCRIPT_DIR/src/modules"
        "$SCRIPT_DIR/src/data/logs"
        "$SCRIPT_DIR/src/data/database"
    )
    
    for dir in "${required_dirs[@]}"; do
        if [[ -d "$dir" ]]; then
            log_success "Required directory exists: $dir"
            add_result "directory_$(basename "$dir")" "pass" "Directory exists"
        else
            log_error "Required directory missing: $dir"
            add_result "directory_$(basename "$dir")" "fail" "Directory missing"
        fi
    done
    
    # Check log directory permissions
    if [[ -d "$SCRIPT_DIR/src/data/logs" ]]; then
        local log_perms=$(stat -c "%a" "$SCRIPT_DIR/src/data/logs" 2>/dev/null || echo "unknown")
        if [[ "$log_perms" =~ ^7[57][57]$ ]]; then
            log_success "Log directory permissions appropriate ($log_perms)"
            add_result "log_directory_permissions" "pass" "Permissions: $log_perms"
        else
            log_warning "Log directory permissions may need adjustment ($log_perms)"
            add_result "log_directory_permissions" "warning" "Permissions: $log_perms"
        fi
    fi
}

# Check ARM64 compatibility
check_arm64_compatibility() {
    log_info "Checking ARM64 compatibility for Raspberry Pi 5..."
    
    local arch=$(uname -m)
    if [[ "$arch" == "aarch64" || "$arch" == "arm64" ]]; then
        log_success "ARM64 architecture detected: $arch"
        add_result "arm64_architecture" "pass" "Architecture: $arch"
        
        # Check for Raspberry Pi 5 specific features
        if [[ -f /proc/device-tree/model ]]; then
            local model=$(cat /proc/device-tree/model 2>/dev/null | tr -d '\0')
            if [[ "$model" =~ "Raspberry Pi 5" ]]; then
                log_success "Raspberry Pi 5 detected: $model"
                add_result "raspberry_pi_5" "pass" "Model: $model"
            else
                log_info "Raspberry Pi model: $model"
                add_result "raspberry_pi_model" "info" "Model: $model"
            fi
        fi
        
        # Check CPU features
        if grep -q "asimd" /proc/cpuinfo; then
            log_success "ARM NEON (ASIMD) support detected"
            add_result "arm_neon_support" "pass" "NEON support available"
        fi
        
        # Check memory configuration
        local total_mem=$(free -m | awk '/^Mem:/ {print $2}')
        if [[ $total_mem -ge 4096 ]]; then
            log_success "Sufficient memory for AI operations: ${total_mem}MB"
            add_result "memory_sufficient" "pass" "Memory: ${total_mem}MB"
        elif [[ $total_mem -ge 2048 ]]; then
            log_warning "Limited memory for AI operations: ${total_mem}MB (recommend 4GB+)"
            add_result "memory_sufficient" "warning" "Memory: ${total_mem}MB"
        else
            log_error "Insufficient memory for AI operations: ${total_mem}MB"
            add_result "memory_sufficient" "fail" "Memory: ${total_mem}MB"
        fi
    else
        log_warning "Non-ARM64 architecture detected: $arch"
        add_result "arm64_architecture" "warning" "Architecture: $arch"
    fi
    
    # Check for ARM64 optimized packages
    local arm_packages=("numpy" "pandas" "scipy")
    for package in "${arm_packages[@]}"; do
        if python3 -c "
import $package
import platform
print(f'$package on {platform.machine()}')
try:
    if hasattr($package, '__config__'):
        print('Optimized build detected')
    else:
        print('Standard build')
except:
    print('Build info unavailable')
" 2>/dev/null; then
            log_success "Package $package available for ARM64"
            add_result "arm64_package_$package" "pass" "Package optimized"
        else
            log_warning "Package $package may not be ARM64 optimized"
            add_result "arm64_package_$package" "warning" "Package not optimized"
        fi
    done
}

# Check systemd service configuration
check_systemd_service() {
    log_info "Checking systemd service configuration..."
    
    local service_file="$SCRIPT_DIR/ai-crypto-trader.service"
    if [[ -f "$service_file" ]]; then
        log_success "Systemd service file found: $service_file"
        add_result "systemd_service_file" "pass" "Service file exists"
        
        # Check service file content
        if grep -q "OPENAI_API_KEY" "$service_file"; then
            log_success "Service file contains OpenAI configuration"
            add_result "systemd_openai_config" "pass" "OpenAI config in service"
        else
            log_warning "Service file may be missing OpenAI configuration"
            add_result "systemd_openai_config" "warning" "No OpenAI config in service"
        fi
        
        # Check if service is installed
        if systemctl list-unit-files | grep -q "ai-crypto-trader.service"; then
            log_success "Systemd service is installed"
            add_result "systemd_service_installed" "pass" "Service installed"
            
            # Check service status
            local service_status=$(systemctl is-active ai-crypto-trader.service 2>/dev/null || echo "inactive")
            if [[ "$service_status" == "active" ]]; then
                log_success "Service is running"
                add_result "systemd_service_status" "pass" "Service active"
            else
                log_info "Service status: $service_status"
                add_result "systemd_service_status" "info" "Status: $service_status"
            fi
        else
            log_warning "Systemd service not installed"
            add_result "systemd_service_installed" "warning" "Service not installed"
        fi
    else
        log_warning "Systemd service file not found"
        add_result "systemd_service_file" "warning" "Service file missing"
    fi
}

# Check health monitoring
check_health_monitoring() {
    log_info "Checking health monitoring configuration..."
    
    # Check health check script
    local health_script="$SCRIPT_DIR/health_check.sh"
    if [[ -f "$health_script" && -x "$health_script" ]]; then
        log_success "Health check script found and executable"
        add_result "health_check_script" "pass" "Script available"
        
        # Test health check execution
        if timeout 30 "$health_script" &> "$TEMP_DIR/health_check.log"; then
            log_success "Health check script executed successfully"
            add_result "health_check_execution" "pass" "Script runs successfully"
        else
            log_warning "Health check script execution failed or timed out"
            add_result "health_check_execution" "warning" "Script execution issues"
        fi
    else
        log_warning "Health check script not found or not executable"
        add_result "health_check_script" "warning" "Script missing or not executable"
    fi
    
    # Check monitoring directories
    local monitoring_dirs=(
        "$SCRIPT_DIR/src/monitoring"
        "$SCRIPT_DIR/src/data/logs/system"
        "$SCRIPT_DIR/src/data/logs/errors"
    )
    
    for dir in "${monitoring_dirs[@]}"; do
        if [[ -d "$dir" ]]; then
            log_success "Monitoring directory exists: $dir"
            add_result "monitoring_dir_$(basename "$dir")" "pass" "Directory exists"
        else
            log_warning "Monitoring directory missing: $dir"
            add_result "monitoring_dir_$(basename "$dir")" "warning" "Directory missing"
        fi
    done
}

# Check security configuration
check_security_configuration() {
    log_info "Checking security configuration..."
    
    # Check file ownership
    local current_user=$(whoami)
    local script_owner=$(stat -c "%U" "$SCRIPT_DIR" 2>/dev/null || echo "unknown")
    
    if [[ "$current_user" == "$script_owner" ]]; then
        log_success "Script directory owned by current user: $current_user"
        add_result "file_ownership" "pass" "Owner: $current_user"
    else
        log_warning "Script directory owner mismatch: $script_owner vs $current_user"
        add_result "file_ownership" "warning" "Owner mismatch"
    fi
    
    # Check for sensitive files in wrong locations
    local sensitive_patterns=("*.key" "*.pem" "*secret*" "*password*")
    local found_sensitive=false
    
    for pattern in "${sensitive_patterns[@]}"; do
        if find "$SCRIPT_DIR" -name "$pattern" -type f 2>/dev/null | grep -q .; then
            log_warning "Potentially sensitive files found matching pattern: $pattern"
            add_result "sensitive_files_$pattern" "warning" "Sensitive files found"
            found_sensitive=true
        fi
    done
    
    if [[ "$found_sensitive" == "false" ]]; then
        log_success "No obviously sensitive files found in project directory"
        add_result "sensitive_files_check" "pass" "No sensitive files found"
    fi
    
    # Check .env file security
    if [[ -f "$SCRIPT_DIR/.env" ]]; then
        local env_perms=$(stat -c "%a" "$SCRIPT_DIR/.env" 2>/dev/null || echo "unknown")
        if [[ "$env_perms" == "600" || "$env_perms" == "640" ]]; then
            log_success ".env file has secure permissions: $env_perms"
            add_result "env_file_permissions" "pass" "Permissions: $env_perms"
        else
            log_warning ".env file permissions may be too permissive: $env_perms"
            add_result "env_file_permissions" "warning" "Permissions: $env_perms"
        fi
    fi
}

# Run integration test
run_integration_test() {
    log_info "Running integration test..."
    
    local test_script="$SCRIPT_DIR/test_openai_migration.py"
    if [[ -f "$test_script" ]]; then
        log_success "Integration test script found"
        add_result "integration_test_script" "pass" "Test script available"
        
        # Run basic integration test
        if timeout 300 python3 "$test_script" --basic --output "$TEMP_DIR/integration_test.json" &> "$TEMP_DIR/integration_test.log"; then
            log_success "Integration test completed successfully"
            add_result "integration_test_execution" "pass" "Test passed"
            
            # Parse test results if available
            if [[ -f "$TEMP_DIR/integration_test.json" ]]; then
                local test_status=$(jq -r '.test_report.overall_status // "unknown"' "$TEMP_DIR/integration_test.json" 2>/dev/null || echo "unknown")
                local success_rate=$(jq -r '.test_report.summary.success_rate // 0' "$TEMP_DIR/integration_test.json" 2>/dev/null || echo "0")
                
                log_success "Integration test status: $test_status (Success rate: $success_rate%)"
                add_result "integration_test_results" "pass" "Status: $test_status, Success: $success_rate%"
            fi
        else
            log_error "Integration test failed or timed out"
            add_result "integration_test_execution" "fail" "Test failed"
            
            # Show last few lines of test log for debugging
            if [[ -f "$TEMP_DIR/integration_test.log" ]]; then
                log_error "Last 10 lines of integration test log:"
                tail -10 "$TEMP_DIR/integration_test.log" | while read -r line; do
                    log_error "  $line"
                done
            fi
        fi
    else
        log_warning "Integration test script not found"
        add_result "integration_test_script" "warning" "Test script missing"
    fi
}

# Generate validation report
generate_report() {
    log_info "Generating validation report..."
    
    local report_json="{"
    report_json+="\"validation_report\":{"
    report_json+="\"timestamp\":\"$(date -Iseconds)\","
    report_json+="\"script_version\":\"1.0\","
    report_json+="\"system_info\":{"
    report_json+="\"platform\":\"$(uname -s)\","
    report_json+="\"architecture\":\"$(uname -m)\","
    report_json+="\"hostname\":\"$(hostname)\","
    report_json+="\"user\":\"$(whoami)\""
    report_json+="},"
    report_json+="\"summary\":{"
    report_json+="\"total_checks\":$TOTAL_CHECKS,"
    report_json+="\"passed_checks\":$PASSED_CHECKS,"
    report_json+="\"failed_checks\":$FAILED_CHECKS,"
    report_json+="\"warning_checks\":$WARNING_CHECKS,"
    report_json+="\"success_rate\":$(echo "scale=2; $PASSED_CHECKS * 100 / $TOTAL_CHECKS" | bc -l 2>/dev/null || echo "0")"
    report_json+="},"
    report_json+="\"checks\":["
    
    # Add validation results
    local first=true
    for result in "${VALIDATION_RESULTS[@]}"; do
        if [[ "$first" == "true" ]]; then
            first=false
        else
            report_json+=","
        fi
        report_json+="$result"
    done
    
    report_json+="],"
    
    # Add recommendations
    report_json+="\"recommendations\":["
    local recommendations=()
    
    if [[ $FAILED_CHECKS -gt 0 ]]; then
        recommendations+=("\"Address $FAILED_CHECKS failed validation checks before deployment\"")
    fi
    
    if [[ $WARNING_CHECKS -gt 0 ]]; then
        recommendations+=("\"Review $WARNING_CHECKS warning conditions\"")
    fi
    
    # Add specific recommendations based on failed checks
    for result in "${VALIDATION_RESULTS[@]}"; do
        if echo "$result" | grep -q '"status":"fail"'; then
            local check_name=$(echo "$result" | jq -r '.check' 2>/dev/null || echo "unknown")
            case "$check_name" in
                *"openai_api_key"*)
                    recommendations+=("\"Configure valid OpenAI API key\"")
                    ;;
                *"dependency"*)
                    recommendations+=("\"Install missing Python dependencies\"")
                    ;;
                *"memory"*)
                    recommendations+=("\"Upgrade system memory for optimal performance\"")
                    ;;
            esac
        fi
    done
    
    if [[ ${#recommendations[@]} -eq 0 ]]; then
        recommendations+=("\"All validations passed - system ready for deployment\"")
        recommendations+=("\"Monitor system performance after deployment\"")
        recommendations+=("\"Set up automated health checks\"")
    fi
    
    # Join recommendations
    local rec_first=true
    for rec in "${recommendations[@]}"; do
        if [[ "$rec_first" == "true" ]]; then
            rec_first=false
        else
            report_json+=","
        fi
        report_json+="$rec"
    done
    
    report_json+="],"
    
    # Overall status
    if [[ $FAILED_CHECKS -eq 0 ]]; then
        report_json+="\"overall_status\":\"PASS\""
    else
        report_json+="\"overall_status\":\"FAIL\""
    fi
    
    report_json+="}}"
    
    # Save report
    echo "$report_json" | jq '.' > "$VALIDATION_REPORT" 2>/dev/null || echo "$report_json" > "$VALIDATION_REPORT"
    
    log_success "Validation report saved to: $VALIDATION_REPORT"
}

# Print summary
print_summary() {
    echo
    echo "=============================================="
    echo "OpenAI Migration Deployment Validation Summary"
    echo "=============================================="
    echo
    echo -e "Total Checks: $TOTAL_CHECKS"
    echo -e "${GREEN}Passed: $PASSED_CHECKS${NC}"
    echo -e "${YELLOW}Warnings: $WARNING_CHECKS${NC}"
    echo -e "${RED}Failed: $FAILED_CHECKS${NC}"
    echo
    
    local success_rate=0
    if [[ $TOTAL_CHECKS -gt 0 ]]; then
        success_rate=$(echo "scale=1; $PASSED_CHECKS * 100 / $TOTAL_CHECKS" | bc -l 2>/dev/null || echo "0")
    fi
    echo -e "Success Rate: ${success_rate}%"
    echo
    
    if [[ $FAILED_CHECKS -eq 0 ]]; then
        echo -e "${GREEN}✅ DEPLOYMENT VALIDATION PASSED${NC}"
        echo "System is ready for OpenAI migration deployment"
    else
        echo -e "${RED}❌ DEPLOYMENT VALIDATION FAILED${NC}"
        echo "Please address failed checks before deployment"
    fi
    
    echo
    echo "Detailed logs: $LOG_FILE"
    echo "Full report: $VALIDATION_REPORT"
    echo
}

# Main execution
main() {
    echo "🚀 OpenAI Migration Deployment Validation"
    echo "=========================================="
    echo
    
    log "Starting OpenAI deployment validation..."
    
    # System information
    echo "📋 System Information:"
    get_system_info
    echo
    
    # Run all validation checks
    check_python_environment
    check_dependencies
    check_openai_configuration
    check_system_configuration
    check_arm64_compatibility
    check_systemd_service
    check_health_monitoring
    check_security_configuration
    run_integration_test
    
    # Generate report and summary
    generate_report
    print_summary
    
    # Exit with appropriate code
    if [[ $FAILED_CHECKS -eq 0 ]]; then
        log "Deployment validation completed successfully"
        exit 0
    else
        log "Deployment validation failed with $FAILED_CHECKS errors"
        exit 1
    fi
}

# Script options
case "${1:-}" in
    --help|-h)
        echo "OpenAI Migration Deployment Validation Script"
        echo
        echo "Usage: $0 [options]"
        echo
        echo "Options:"
        echo "  --help, -h     Show this help message"
        echo "  --quick        Run quick validation (skip integration tests)"
        echo "  --verbose      Enable verbose output"
        echo
        echo "This script validates the deployment environment for the"
        echo "OpenAI migration of the AI Crypto Trading System."
        echo
        echo "The script checks:"
        echo "  - Python environment and dependencies"
        echo "  - OpenAI API configuration and connectivity"
        echo "  - System configuration and security"
        echo "  - ARM64/Raspberry Pi 5 compatibility"
        echo "  - Service configuration"
        echo "  - Health monitoring setup"
        echo "  - Integration test execution"
        echo
        exit 0
        ;;
    --quick)
        echo "Running quick validation (skipping integration tests)..."
        # Override the integration test function
        run_integration_test() {
            log_info "Skipping integration test (quick mode)"
            add_result "integration_test_execution" "skipped" "Quick mode - test skipped"
        }
        ;;
    --verbose)
        set -x
        ;;
esac

# Ensure required tools are available
if ! command -v jq &> /dev/null; then
    echo "Warning: jq not found. JSON report formatting may be limited."
fi

if ! command -v bc &> /dev/null; then
    echo "Warning: bc not found. Some calculations may be limited."
fi

# Run main function
main "$@"