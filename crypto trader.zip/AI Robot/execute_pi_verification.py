#!/usr/bin/env python3
"""
Master Execution Script for Raspberry Pi Deployment Verification
Coordinates the complete end-to-end verification process.
"""

import asyncio
import sys
import json
import time
import subprocess
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(f'pi_verification_master_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class MasterVerificationCoordinator:
    """Master coordinator for comprehensive Pi verification."""
    
    def __init__(self, pi_host: str = "192.168.1.91", pi_user: str = "pi", 
                 install_dir: str = "/opt/ai-crypto-trader"):
        self.pi_host = pi_host
        self.pi_user = pi_user
        self.install_dir = install_dir
        self.start_time = datetime.now()
        self.verification_phases = []
        self.overall_results = {}
        
    def log_phase(self, phase_name: str, status: str, details: str = "", duration: float = 0.0):
        """Log verification phase result."""
        phase_result = {
            "phase": phase_name,
            "status": status,
            "details": details,
            "duration": duration,
            "timestamp": datetime.now().isoformat()
        }
        self.verification_phases.append(phase_result)
        
        status_icon = {"PASS": "✅", "FAIL": "❌", "WARN": "⚠️", "SKIP": "⏭️"}.get(status, "❓")
        logger.info(f"{status_icon} {phase_name}: {status}")
        if details:
            logger.info(f"   {details}")
        if duration > 0:
            logger.info(f"   Duration: {duration:.2f}s")

    async def execute_remote_verification(self) -> Dict[str, Any]:
        """Execute the remote verification process."""
        logger.info("\n🌐 Phase 1: Remote Connectivity and System Verification")
        logger.info("=" * 80)
        
        try:
            start_time = time.time()
            
            # Import and run remote verification
            from remote_pi_verification import RemotePiVerifier
            
            remote_verifier = RemotePiVerifier(
                pi_host=self.pi_host,
                pi_user=self.pi_user,
                install_dir=self.install_dir
            )
            
            # Execute remote verification
            remote_report = await remote_verifier.run_comprehensive_remote_verification()
            
            duration = time.time() - start_time
            
            # Analyze results
            remote_summary = remote_report["remote_verification_summary"]
            remote_tests = remote_summary["remote_tests"]
            
            if remote_tests["failed"] == 0:
                self.log_phase("Remote Verification", "PASS", 
                              f"All {remote_tests['total']} remote tests passed", duration)
            elif remote_tests["failed"] <= 2:
                self.log_phase("Remote Verification", "WARN", 
                              f"{remote_tests['failed']} tests failed, {remote_tests['passed']} passed", duration)
            else:
                self.log_phase("Remote Verification", "FAIL", 
                              f"{remote_tests['failed']} tests failed", duration)
            
            self.overall_results["remote_verification"] = remote_report
            return remote_report
            
        except Exception as e:
            self.log_phase("Remote Verification", "FAIL", f"Error: {e}")
            return {"error": str(e)}

    def analyze_pi_verification_results(self, remote_report: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze the Pi verification results in detail."""
        logger.info("\n🔍 Phase 2: Detailed Pi Verification Analysis")
        logger.info("=" * 80)
        
        try:
            start_time = time.time()
            
            pi_report = remote_report.get("remote_verification_summary", {}).get("pi_verification_report")
            
            if not pi_report:
                self.log_phase("Pi Analysis", "FAIL", "No Pi verification report found")
                return {"status": "no_report"}
            
            if isinstance(pi_report, dict) and "verification_report" in pi_report:
                verification_data = pi_report["verification_report"]
                summary = verification_data["summary"]
                
                # Analyze each verification category
                analysis_results = {
                    "overall_status": summary["overall_status"],
                    "test_breakdown": {
                        "total_tests": summary["total_tests"],
                        "passed_tests": summary["passed_tests"],
                        "failed_tests": summary["failed_tests"],
                        "warning_tests": summary["warning_tests"],
                        "success_rate": summary["success_rate"]
                    },
                    "critical_issues": verification_data.get("critical_issues", []),
                    "warnings": verification_data.get("warnings", []),
                    "recommendations": verification_data.get("recommendations", [])
                }
                
                # Categorize test results by component
                test_categories = {
                    "system_resources": [],
                    "file_structure": [],
                    "virtual_environment": [],
                    "configuration": [],
                    "database": [],
                    "ai_clients": [],
                    "module_imports": [],
                    "monitoring": []
                }
                
                for test_result in verification_data.get("test_results", []):
                    test_name = test_result["test_name"].lower()
                    
                    if any(keyword in test_name for keyword in ["cpu", "memory", "disk", "temperature", "system"]):
                        test_categories["system_resources"].append(test_result)
                    elif any(keyword in test_name for keyword in ["file", "directory", "permission"]):
                        test_categories["file_structure"].append(test_result)
                    elif any(keyword in test_name for keyword in ["virtual", "environment", "python", "package"]):
                        test_categories["virtual_environment"].append(test_result)
                    elif any(keyword in test_name for keyword in ["config", "environment"]):
                        test_categories["configuration"].append(test_result)
                    elif any(keyword in test_name for keyword in ["database", "sqlite"]):
                        test_categories["database"].append(test_result)
                    elif any(keyword in test_name for keyword in ["openai", "ai", "client"]):
                        test_categories["ai_clients"].append(test_result)
                    elif any(keyword in test_name for keyword in ["import", "module"]):
                        test_categories["module_imports"].append(test_result)
                    elif any(keyword in test_name for keyword in ["monitoring", "health"]):
                        test_categories["monitoring"].append(test_result)
                
                analysis_results["test_categories"] = test_categories
                
                # Log detailed analysis
                logger.info(f"📊 Overall Status: {summary['overall_status']}")
                logger.info(f"📈 Success Rate: {summary['success_rate']}%")
                logger.info(f"✅ Passed: {summary['passed_tests']}")
                logger.info(f"❌ Failed: {summary['failed_tests']}")
                logger.info(f"⚠️ Warnings: {summary['warning_tests']}")
                
                if verification_data.get("critical_issues"):
                    logger.info(f"🚨 Critical Issues: {len(verification_data['critical_issues'])}")
                    for issue in verification_data["critical_issues"]:
                        logger.info(f"   - {issue}")
                
                if verification_data.get("warnings"):
                    logger.info(f"⚠️ Warnings: {len(verification_data['warnings'])}")
                    for warning in verification_data["warnings"]:
                        logger.info(f"   - {warning}")
                
                duration = time.time() - start_time
                self.log_phase("Pi Analysis", "PASS", "Detailed analysis completed", duration)
                
                self.overall_results["pi_analysis"] = analysis_results
                return analysis_results
                
            else:
                self.log_phase("Pi Analysis", "WARN", "Pi verification completed but report format unexpected")
                return {"status": "unexpected_format", "data": pi_report}
                
        except Exception as e:
            self.log_phase("Pi Analysis", "FAIL", f"Analysis error: {e}")
            return {"status": "error", "error": str(e)}

    def generate_issue_diagnosis(self, analysis_results: Dict[str, Any]) -> Dict[str, Any]:
        """Generate detailed issue diagnosis and recommendations."""
        logger.info("\n🔬 Phase 3: Issue Diagnosis and Recommendations")
        logger.info("=" * 80)
        
        try:
            start_time = time.time()
            
            diagnosis = {
                "timestamp": datetime.now().isoformat(),
                "overall_health": analysis_results.get("overall_status", "UNKNOWN"),
                "critical_issues_analysis": [],
                "warning_analysis": [],
                "component_health": {},
                "deployment_readiness": "UNKNOWN",
                "priority_actions": [],
                "monitoring_recommendations": []
            }
            
            # Analyze component health
            test_categories = analysis_results.get("test_categories", {})
            
            for category, tests in test_categories.items():
                if tests:
                    passed = len([t for t in tests if t["status"] == "PASS"])
                    failed = len([t for t in tests if t["status"] == "FAIL"])
                    warned = len([t for t in tests if t["status"] == "WARN"])
                    total = len(tests)
                    
                    health_score = (passed / total * 100) if total > 0 else 0
                    
                    component_status = "HEALTHY" if failed == 0 and warned <= 1 else \
                                     "WARNING" if failed <= 1 else "CRITICAL"
                    
                    diagnosis["component_health"][category] = {
                        "status": component_status,
                        "health_score": round(health_score, 1),
                        "passed": passed,
                        "failed": failed,
                        "warnings": warned,
                        "total": total
                    }
                    
                    logger.info(f"🔧 {category.replace('_', ' ').title()}: {component_status} ({health_score:.1f}%)")
            
            # Analyze critical issues
            critical_issues = analysis_results.get("critical_issues", [])
            for issue in critical_issues:
                issue_analysis = {
                    "issue": issue,
                    "severity": "CRITICAL",
                    "impact": "Deployment blocking",
                    "recommended_action": self._get_issue_recommendation(issue)
                }
                diagnosis["critical_issues_analysis"].append(issue_analysis)
                diagnosis["priority_actions"].append(issue_analysis["recommended_action"])
            
            # Analyze warnings
            warnings = analysis_results.get("warnings", [])
            for warning in warnings:
                warning_analysis = {
                    "warning": warning,
                    "severity": "WARNING",
                    "impact": "Performance or reliability concern",
                    "recommended_action": self._get_issue_recommendation(warning)
                }
                diagnosis["warning_analysis"].append(warning_analysis)
            
            # Determine deployment readiness
            if len(critical_issues) == 0:
                if len(warnings) <= 2:
                    diagnosis["deployment_readiness"] = "READY"
                else:
                    diagnosis["deployment_readiness"] = "READY_WITH_MONITORING"
            else:
                diagnosis["deployment_readiness"] = "NOT_READY"
            
            # Generate monitoring recommendations
            diagnosis["monitoring_recommendations"] = [
                "Set up automated health checks every 15 minutes",
                "Monitor CPU temperature (alert if >70°C)",
                "Monitor memory usage (alert if >80%)",
                "Monitor disk space (alert if >85%)",
                "Set up log rotation for application logs",
                "Configure system backup schedule",
                "Monitor AI API response times and error rates"
            ]
            
            duration = time.time() - start_time
            self.log_phase("Issue Diagnosis", "PASS", "Diagnosis completed", duration)
            
            # Log deployment readiness
            readiness_icon = {"READY": "🎉", "READY_WITH_MONITORING": "⚠️", "NOT_READY": "❌"}
            logger.info(f"{readiness_icon.get(diagnosis['deployment_readiness'], '❓')} Deployment Readiness: {diagnosis['deployment_readiness']}")
            
            if diagnosis["priority_actions"]:
                logger.info("🔧 Priority Actions Required:")
                for action in diagnosis["priority_actions"][:5]:  # Top 5 actions
                    logger.info(f"   • {action}")
            
            self.overall_results["diagnosis"] = diagnosis
            return diagnosis
            
        except Exception as e:
            self.log_phase("Issue Diagnosis", "FAIL", f"Diagnosis error: {e}")
            return {"error": str(e)}

    def _get_issue_recommendation(self, issue: str) -> str:
        """Get specific recommendation for an issue."""
        issue_lower = issue.lower()
        
        if "virtual environment" in issue_lower or "python" in issue_lower:
            return "Recreate virtual environment and reinstall dependencies"
        elif "database" in issue_lower:
            return "Check database file permissions and run database initialization"
        elif "openai" in issue_lower or "api" in issue_lower:
            return "Verify API key configuration and network connectivity"
        elif "permission" in issue_lower:
            return "Fix file permissions using chmod/chown commands"
        elif "import" in issue_lower or "module" in issue_lower:
            return "Check Python path and install missing dependencies"
        elif "memory" in issue_lower:
            return "Optimize memory usage or upgrade system RAM"
        elif "disk" in issue_lower:
            return "Clean up disk space or expand storage"
        elif "temperature" in issue_lower:
            return "Improve cooling or reduce system load"
        else:
            return "Review system logs and configuration files"

    def generate_final_report(self) -> Dict[str, Any]:
        """Generate comprehensive final report."""
        logger.info("\n📋 Phase 4: Final Report Generation")
        logger.info("=" * 80)
        
        try:
            start_time = time.time()
            
            total_duration = (datetime.now() - self.start_time).total_seconds()
            
            final_report = {
                "comprehensive_verification_report": {
                    "metadata": {
                        "timestamp": datetime.now().isoformat(),
                        "pi_host": self.pi_host,
                        "pi_user": self.pi_user,
                        "install_directory": self.install_dir,
                        "total_duration": round(total_duration, 2),
                        "verification_version": "1.0"
                    },
                    "verification_phases": self.verification_phases,
                    "detailed_results": self.overall_results,
                    "executive_summary": self._generate_executive_summary()
                }
            }
            
            # Save comprehensive report
            report_filename = f"comprehensive_pi_verification_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            report_path = Path(report_filename)
            
            with open(report_path, 'w') as f:
                json.dump(final_report, f, indent=2)
            
            duration = time.time() - start_time
            self.log_phase("Final Report", "PASS", f"Report saved to {report_filename}", duration)
            
            logger.info(f"📄 Comprehensive verification report saved to: {report_path}")
            
            return final_report
            
        except Exception as e:
            self.log_phase("Final Report", "FAIL", f"Report generation error: {e}")
            return {"error": str(e)}

    def _generate_executive_summary(self) -> Dict[str, Any]:
        """Generate executive summary of verification results."""
        summary = {
            "overall_status": "UNKNOWN",
            "deployment_recommendation": "REVIEW_REQUIRED",
            "key_findings": [],
            "critical_actions_required": [],
            "system_health_score": 0,
            "confidence_level": "LOW"
        }
        
        try:
            # Analyze overall results
            diagnosis = self.overall_results.get("diagnosis", {})
            
            if diagnosis:
                summary["overall_status"] = diagnosis.get("overall_health", "UNKNOWN")
                summary["deployment_recommendation"] = diagnosis.get("deployment_readiness", "REVIEW_REQUIRED")
                summary["critical_actions_required"] = diagnosis.get("priority_actions", [])[:3]
                
                # Calculate system health score
                component_health = diagnosis.get("component_health", {})
                if component_health:
                    health_scores = [comp["health_score"] for comp in component_health.values()]
                    summary["system_health_score"] = round(sum(health_scores) / len(health_scores), 1)
                
                # Determine confidence level
                if summary["system_health_score"] >= 95:
                    summary["confidence_level"] = "HIGH"
                elif summary["system_health_score"] >= 80:
                    summary["confidence_level"] = "MEDIUM"
                else:
                    summary["confidence_level"] = "LOW"
            
            # Generate key findings
            phase_results = {phase["phase"]: phase["status"] for phase in self.verification_phases}
            
            if phase_results.get("Remote Verification") == "PASS":
                summary["key_findings"].append("✅ SSH connectivity and remote execution successful")
            
            if phase_results.get("Pi Analysis") == "PASS":
                summary["key_findings"].append("✅ Pi system verification completed successfully")
            
            if phase_results.get("Issue Diagnosis") == "PASS":
                summary["key_findings"].append("✅ Comprehensive issue analysis completed")
            
            if summary["system_health_score"] >= 90:
                summary["key_findings"].append(f"✅ System health score: {summary['system_health_score']}%")
            elif summary["system_health_score"] >= 70:
                summary["key_findings"].append(f"⚠️ System health score: {summary['system_health_score']}%")
            else:
                summary["key_findings"].append(f"❌ System health score: {summary['system_health_score']}%")
            
        except Exception as e:
            summary["key_findings"].append(f"❌ Error generating summary: {e}")
        
        return summary

    async def run_comprehensive_verification(self) -> Dict[str, Any]:
        """Run the complete comprehensive verification process."""
        logger.info("🚀 STARTING COMPREHENSIVE RASPBERRY PI DEPLOYMENT VERIFICATION")
        logger.info("=" * 100)
        logger.info(f"Target: {self.pi_user}@{self.pi_host}")
        logger.info(f"Install Directory: {self.install_dir}")
        logger.info(f"Start Time: {self.start_time.isoformat()}")
        logger.info("=" * 100)
        
        try:
            # Phase 1: Remote verification
            remote_report = await self.execute_remote_verification()
            
            # Phase 2: Detailed analysis
            analysis_results = self.analyze_pi_verification_results(remote_report)
            
            # Phase 3: Issue diagnosis
            diagnosis = self.generate_issue_diagnosis(analysis_results)
            
            # Phase 4: Final report
            final_report = self.generate_final_report()
            
            return final_report
            
        except Exception as e:
            logger.error(f"💥 CRITICAL ERROR in comprehensive verification: {e}")
            self.log_phase("Comprehensive Verification", "FAIL", f"Critical error: {e}")
            return {"error": str(e), "phases": self.verification_phases}

def print_comprehensive_summary(report: Dict[str, Any]):
    """Print comprehensive verification summary."""
    print("\n" + "=" * 100)
    print("🎯 COMPREHENSIVE RASPBERRY PI DEPLOYMENT VERIFICATION SUMMARY")
    print("=" * 100)
    
    try:
        verification_report = report["comprehensive_verification_report"]
        metadata = verification_report["metadata"]
        executive_summary = verification_report["executive_summary"]
        
        print(f"Target Pi: {metadata['pi_user']}@{metadata['pi_host']}")
        print(f"Install Directory: {metadata['install_directory']}")
        print(f"Total Duration: {metadata['total_duration']}s")
        print(f"Verification Time: {metadata['timestamp']}")
        print()
        
        print("📊 EXECUTIVE SUMMARY")
        print("-" * 50)
        print(f"Overall Status: {executive_summary['overall_status']}")
        print(f"Deployment Recommendation: {executive_summary['deployment_recommendation']}")
        print(f"System Health Score: {executive_summary['system_health_score']}%")
        print(f"Confidence Level: {executive_summary['confidence_level']}")
        print()
        
        print("🔍 KEY FINDINGS")
        print("-" * 50)
        for finding in executive_summary["key_findings"]:
            print(f"  {finding}")
        print()
        
        if executive_summary["critical_actions_required"]:
            print("🚨 CRITICAL ACTIONS REQUIRED")
            print("-" * 50)
            for action in executive_summary["critical_actions_required"]:
                print(f"  • {action}")
            print()
        
        # Deployment recommendation
        recommendation = executive_summary["deployment_recommendation"]
        if recommendation == "READY":
            print("🎉 DEPLOYMENT APPROVED!")
            print("✅ System is ready for production deployment")
        elif recommendation == "READY_WITH_MONITORING":
            print("⚠️ CONDITIONAL DEPLOYMENT APPROVAL")
            print("🔍 System can be deployed but requires close monitoring")
        else:
            print("❌ DEPLOYMENT NOT RECOMMENDED")
            print("🚨 Critical issues must be resolved before deployment")
        
    except Exception as e:
        print(f"❌ Error displaying summary: {e}")
    
    print("=" * 100)

async def main():
    """Main execution function."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Comprehensive Raspberry Pi Deployment Verification")
    parser.add_argument("--host", default="192.168.1.91", help="Pi hostname or IP address")
    parser.add_argument("--user", default="pi", help="SSH username")
    parser.add_argument("--install-dir", default="/opt/ai-crypto-trader", help="Installation directory on Pi")
    parser.add_argument("--verbose", action="store_true", help="Enable verbose output")
    
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Initialize master coordinator
    coordinator = MasterVerificationCoordinator(
        pi_host=args.host,
        pi_user=args.user,
        install_dir=args.install_dir
    )
    
    try:
        # Run comprehensive verification
        report = await coordinator.run_comprehensive_verification()
        
        # Print summary
        print_comprehensive_summary(report)
        
        # Exit with appropriate code based on results
        if "error" in report:
            return 3
        
        try:
            exec_summary = report["comprehensive_verification_report"]["executive_summary"]
            recommendation = exec_summary["deployment_recommendation"]
            
            if recommendation == "READY":
                return 0
            elif recommendation == "READY_WITH_MONITORING":
                return 1
            else:
                return 2
        except:
            return 3
            
    except KeyboardInterrupt:
        logger.info("\n⏹️ Comprehensive verification interrupted by user")
        return 130
    except Exception as e:
        logger.error(f"\n💥 CRITICAL ERROR: {e}")
        return 3

if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)